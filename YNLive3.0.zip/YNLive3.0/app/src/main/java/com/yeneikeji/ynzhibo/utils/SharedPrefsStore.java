package com.yeneikeji.ynzhibo.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.yeneikeji.ynzhibo.model.RecordVideoBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 此处仅为存储示例 您的项目中可能使用其他存储形式
 * 
 * @author baidu
 */
public class SharedPrefsStore {
    private static final String MAIN_VIDEO_LIST_SPNAME = "video-main";
    private static final String CACHE_VIDEO_LIST_SPNAME = "video-cache";
    private static final String SETTINGS_SPNAME = "video-settings";

    private static final String KEY_VIDEOS_ARRAY = "videos";

    public static boolean addToMainVideo(Context context, RecordVideoBean info)
    {
        SharedPreferences spList = context.getSharedPreferences(MAIN_VIDEO_LIST_SPNAME, 0);
        String jsonStr = spList.getString(KEY_VIDEOS_ARRAY, "[]");
        try {
            JSONArray jsonArray = new JSONArray(jsonStr);
            jsonArray.put(info.toJson());
            SharedPreferences.Editor editor = spList.edit();
            editor.putString(KEY_VIDEOS_ARRAY, jsonArray.toString());
            editor.commit();
        } catch (JSONException e1) {
            e1.printStackTrace();
            return false;
        }

        return true;
    }

    public static boolean deleteMainVideo(Context context, RecordVideoBean info) {
        SharedPreferences spList = context.getSharedPreferences(MAIN_VIDEO_LIST_SPNAME, 0);
        String jsonStr = spList.getString(KEY_VIDEOS_ARRAY, "[]");
        try
        {
            JSONArray jsonArray = new JSONArray(jsonStr);
            JSONArray newJsonArray = new JSONArray();
            for (int i = 0; i < jsonArray.length(); ++i)
            {
                try
                {
                    JSONObject json = (JSONObject) jsonArray.get(i);
                    RecordVideoBean info2 = YNJsonUtil.JsonToBean(json.toString(), RecordVideoBean.class);
                    if (info2.getPlayableUrlList().equals(info.getPlayableUrlList()) && info2.getTitle().equals(info.getTitle())) {
                        continue;
                    } else {
                        newJsonArray.put(json);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (newJsonArray.length() == jsonArray.length()) {
                return false;
            } else {
                SharedPreferences.Editor editor = spList.edit();
                editor.putString(KEY_VIDEOS_ARRAY, newJsonArray.toString());
                editor.commit();
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        return false;
    }

    public static boolean addToCacheVideo(Context context, RecordVideoBean info) {
        SharedPreferences spList = context.getSharedPreferences(CACHE_VIDEO_LIST_SPNAME, 0);
        String jsonStr = spList.getString(KEY_VIDEOS_ARRAY, "[]");
        try {
            JSONArray jsonArray = new JSONArray(jsonStr);
            jsonArray.put(YNJsonUtil.toJson(info));
            SharedPreferences.Editor editor = spList.edit();
            editor.putString(KEY_VIDEOS_ARRAY, jsonArray.toString());
            editor.commit();
        } catch (JSONException e1) {
            e1.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean deleteCacheVideo(Context context, RecordVideoBean info) {
        SharedPreferences spList = context.getSharedPreferences(CACHE_VIDEO_LIST_SPNAME, 0);
        String jsonStr = spList.getString(KEY_VIDEOS_ARRAY, "[]");
        try {
            JSONArray jsonArray = new JSONArray(jsonStr);
            JSONArray newJsonArray = new JSONArray();
            for (int i = 0; i < jsonArray.length(); ++i) {
                try {
                    JSONObject json = (JSONObject) jsonArray.get(i);
                    RecordVideoBean info2 = YNJsonUtil.JsonToBean(json.toString(), RecordVideoBean.class);
                    if (info2.getPlayableUrlList().equals(info.getPlayableUrlList()) && info2.getTitle().equals(info.getTitle()))
                    {
                        continue;
                    } else {
                        newJsonArray.put(json);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (newJsonArray.length() == jsonArray.length()) {
                return false;
            } else {
                SharedPreferences.Editor editor = spList.edit();
                editor.putString(KEY_VIDEOS_ARRAY, newJsonArray.toString());
                editor.commit();
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        return false;
    }

    public static ArrayList<RecordVideoBean> getAllMainVideoFromSP(Context context) {
        ArrayList<RecordVideoBean> infoList = new ArrayList<RecordVideoBean>();
        // add sample data first
//        infoList.addAll();

        // add user added data
        SharedPreferences spList = context.getSharedPreferences(MAIN_VIDEO_LIST_SPNAME, 0);
        String jsonStr = spList.getString(KEY_VIDEOS_ARRAY, "[]");
        try {
            JSONArray jsonArray = new JSONArray(jsonStr);
            for (int i = 0; i < jsonArray.length(); ++i) {
                try {
                    JSONObject json = (JSONObject) jsonArray.get(i);
                    RecordVideoBean info = RecordVideoBean.fromJson(json);
                    infoList.add(info);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }

        return infoList;
    }

    public static void setDefaultOrientation(Context context, boolean isPortrait) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        SharedPreferences.Editor editor = spList.edit();
        editor.putBoolean("isPortrait", isPortrait);
        editor.commit();
    }

    public static boolean isDefaultPortrait(Context context) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        return spList.getBoolean("isPortrait", true);
    }

    public static void setControllBar(Context context, boolean isSimple) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        SharedPreferences.Editor editor = spList.edit();
        editor.putBoolean("isSimple", isSimple);
        editor.commit();
    }

    public static boolean isControllBarSimple(Context context) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        return spList.getBoolean("isSimple", false);
    }

    public static void setPlayerFitMode(Context context, boolean isCrapping) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        SharedPreferences.Editor editor = spList.edit();
        editor.putBoolean("isCrapping", isCrapping);
        editor.commit();
    }

    public static boolean isPlayerFitModeCrapping(Context context) {
        SharedPreferences spList = context.getSharedPreferences(SETTINGS_SPNAME, 0);
        return spList.getBoolean("isCrapping", false);
    }
}
