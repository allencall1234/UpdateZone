package com.yeneikeji.ynzhibo.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2017/4/26.
 */

public class MonthWealthBean  {


    private int code;
    private String   info;
    private DataBean data;

    public int getCode() { return code;}

    public void setCode(int code) { this.code = code;}

    public String getInfo() { return info;}

    public void setInfo(String info) { this.info = info;}

    public DataBean getData() { return data;}

    public void setData(DataBean data) { this.data = data;}

    public static class DataBean {
        private List<List<GiftBean>> gift;
        private List<List<GiftBean>>              zan;
        private List<List<GiftBean>>           others;

        public List<List<GiftBean>> getGift() { return gift;}

        public void setGift(List<List<GiftBean>> gift) { this.gift = gift;}

        public List<List<GiftBean>> getZan() { return zan;}

        public void setZan(List<List<GiftBean>> zan) { this.zan = zan;}

        public List<List<GiftBean>> getOthers() { return others;}

        public void setOthers(List<List<GiftBean>> others) { this.others = others;}

        public static class GiftBean implements Serializable{

            private String id;
            private String userid;
            private String toId;
            private String giftName;
            private String count;
            private String price;
            private String time;
            private String type;
            private String username;
            private int    wealth;

            public String getId() { return id;}

            public void setId(String id) { this.id = id;}

            public String getUserid() { return userid;}

            public void setUserid(String userid) { this.userid = userid;}

            public String getToId() { return toId;}

            public void setToId(String toId) { this.toId = toId;}

            public String getGiftName() { return giftName;}

            public void setGiftName(String giftName) { this.giftName = giftName;}

            public String getCount() { return count;}

            public void setCount(String count) { this.count = count;}

            public String getPrice() { return price;}

            public void setPrice(String price) { this.price = price;}

            public String getTime() { return time;}

            public void setTime(String time) { this.time = time;}

            public String getType() { return type;}

            public void setType(String type) { this.type = type;}

            public String getUsername() { return username;}

            public void setUsername(String username) { this.username = username;}

            public int getWealth() { return wealth;}

            public void setWealth(int wealth) { this.wealth = wealth;}
        }
    }
}
