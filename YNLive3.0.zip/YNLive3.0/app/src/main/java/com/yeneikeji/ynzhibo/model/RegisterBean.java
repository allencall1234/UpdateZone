package com.yeneikeji.ynzhibo.model;


public class RegisterBean
{
    /**
     * phone : 18192870120
     * password : e10adc3949ba59abbe56e057f20f883e
     * register_time : 1483076955
     */

    private String phone;
    private String password;
    private int register_time;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRegister_time() {
        return register_time;
    }

    public void setRegister_time(int register_time) {
        this.register_time = register_time;
    }
}
