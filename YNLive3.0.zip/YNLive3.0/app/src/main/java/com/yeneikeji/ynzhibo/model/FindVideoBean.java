package com.yeneikeji.ynzhibo.model;

/**
 * 视频实体类
 * Created by Administrator on 2017/7/3.
 */
public class FindVideoBean extends BaseBean
{
    private String id;
    private String userid;
    private String vedio;
    private String time;
    private String playableUrlList;
    private String thumbnailList;
    private String publishTime;
    private String title;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPlayableUrlList() {
        return playableUrlList;
    }

    public void setPlayableUrlList(String playableUrlList) {
        this.playableUrlList = playableUrlList;
    }

    public String getThumbnailList() {
        return thumbnailList;
    }

    public void setThumbnailList(String thumbnailList) {
        this.thumbnailList = thumbnailList;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getVedio() {
        return vedio;
    }

    public void setVedio(String vedio) {
        this.vedio = vedio;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
