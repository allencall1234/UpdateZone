package com.yeneikeji.ynzhibo.view.live;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyTextView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.database.HistoryDao;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.view.community.PersonalHomePageActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 搜索界面
 * Created by Administrator on 2016/10/27.
 */
public class YNSearchActivity extends YNBaseTopBarActivity implements View.OnClickListener
{

    private LinearLayout mLLLatelySearch;
    private ListView mHistoryLV;
    private TextView mBtnClear;
    private RelativeLayout mRLSearchContent;
    private YNMyTextView mTVAnchor;
    private RelativeLayout mRLLiveHost;
    private LinearLayout mLLShowResult;
    private TextView mTVNoResult;
    private RelativeLayout mRLSearchResult;
    private ImageView mIVHead;
    private TextView mTVUserName;
    private TextView mTVNoteTitle;
    private TextView mTVRoomId;
    private TextView mTVUserIntroduce;
//    private LinearLayout mLLLivingState;

    private CommonAdapter mAdapter;
//    private YNSQLHelper sqlHelper;
    private HistoryDao historyDao;
    List<String> dataSource = new ArrayList<>();
    private LiveRoomBean liveRoomBean;
    private boolean onClickListItem = false;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.LIVE_SEARCH_FLAG:
                    onClickListItem = false;
                    mRLLiveHost.setVisibility(View.VISIBLE);
                    mLLShowResult.setVisibility(View.VISIBLE);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mRLSearchResult.setVisibility(View.VISIBLE);
                            mTVNoResult.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                liveRoomBean = YNJsonUtil.JsonToBean(jsonObject.getString("data"), LiveRoomBean.class);
                                if (liveRoomBean.getArticleTitle() == null)
                                {
                                    mTVNoteTitle.setText(liveRoomBean.getTag());
                                    mTVRoomId.setVisibility(View.VISIBLE);
                                    mTVRoomId.setText("房间号: " + liveRoomBean.getRoom_id());
                                    mTVUserIntroduce.setText(liveRoomBean.getDescribe());
                                }
                                else
                                {
                                    mTVNoteTitle.setText(liveRoomBean.getArticleTitle());
                                    mTVRoomId.setVisibility(View.GONE);
                                    mTVUserIntroduce.setText(liveRoomBean.getArticleContent());
                                }

                                YNImageLoaderUtil.setImage(YNSearchActivity.this, mIVHead, liveRoomBean.getIcon());
                                mTVUserName.setText(liveRoomBean.getUsername());
//                                if (YNCommonConfig.LIVE_STATUS_ONGOING.equals(liveRoomBean.getStatus()))
//                                    mLLLivingState.setVisibility(View.VISIBLE);
//                                else
//                                    mLLLivingState.setVisibility(View.GONE);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mLLShowResult.setVisibility(View.VISIBLE);
                            mTVNoResult.setVisibility(View.VISIBLE);
                            mRLSearchResult.setVisibility(View.GONE);
                        }
                    }
                    else
                    {
                        mRLSearchResult.setVisibility(View.GONE);
                        mTVNoResult.setVisibility(View.GONE);
                        YNToastMaster.showToast(YNSearchActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view = getLayoutInflater().inflate(R.layout.activity_search, null);
//        AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle("");
        getLeftBtnLL().setVisibility(View.GONE);
        getCenterLL().setVisibility(View.GONE);
        getSearchET().setVisibility(View.VISIBLE);
        getRightBtn().setVisibility(View.GONE);
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.cancel));

        mLLLatelySearch = (LinearLayout) findViewById(R.id.ll_lately_search);
        mHistoryLV = (ListView) findViewById(R.id.lv_history);
        mBtnClear = (TextView) findViewById(R.id.btn_clear);
        mRLSearchContent = (RelativeLayout) findViewById(R.id.rl_search_content);
        mTVAnchor = (YNMyTextView) findViewById(R.id.tv_anchor);
        mRLLiveHost = (RelativeLayout) findViewById(R.id.rl_live_host);
        mLLShowResult = (LinearLayout) findViewById(R.id.ll_show_result);
        mTVNoResult = (TextView) findViewById(R.id.tv_no_result);
        mRLSearchResult = (RelativeLayout) findViewById(R.id.search_result);
        mIVHead = (ImageView) mRLSearchResult.findViewById(R.id.iv_head);
        mTVUserName = (TextView) mRLSearchResult.findViewById(R.id.tv_name);
        mTVNoteTitle = (TextView) mRLSearchResult.findViewById(R.id.tv_title);
        mTVRoomId = (TextView) mRLSearchResult.findViewById(R.id.tv_room_id);
        mTVUserIntroduce = (TextView) mRLSearchResult.findViewById(R.id.tv_userIntroduce);
//        mLLLivingState = (LinearLayout) mLLSearchResult.findViewById(R.id.ll_living_state);
    }

    @Override
    protected void addEvent()
    {
        getRightTV().setOnClickListener(this);
        mRLSearchContent.setOnClickListener(this);
        mBtnClear.setOnClickListener(this);
        mRLSearchResult.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        historyDao = new HistoryDao(this);
        getHistoryData();
        mHistoryLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id)
            {
                onClickListItem = true;
                mHistoryLV.setVisibility(View.GONE);
                mBtnClear.setVisibility(View.GONE);
                mRLSearchContent.setVisibility(View.GONE);
                getSearchET().setText(dataSource.get(position));
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().liveSearch(YNSearchActivity.this, YNCommonConfig.LIVE_SEARCH_URL, dataSource.get(position), mHandler, YNCommonConfig.LIVE_SEARCH_FLAG, false);
                    }
                });
            }
        });

        // 搜索框的键盘搜索键点击回调
        getSearchET().setOnKeyListener(new View.OnKeyListener() {// 输入完后按键盘上的搜索键

            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)
                {// 修改回车键功能
                    // 先隐藏键盘
                    ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                            getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    if (TextUtils.isEmpty(getSearchET().getText().toString()))
                    {
                        YNToastMaster.showToast(YNSearchActivity.this, "请输入主播房间号");
                    }
                    if (!YNCommonUtils.isNumber(getSearchET().getText().toString()))
                    {
                        YNToastMaster.showToast(YNSearchActivity.this, "房间号有误");
                    }
                    if (!TextUtils.isEmpty(getSearchET().getText().toString()) && YNCommonUtils.isNumber(getSearchET().getText().toString()))
                    {
                        mRLSearchContent.setVisibility(View.GONE);
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().liveSearch(YNSearchActivity.this, YNCommonConfig.LIVE_SEARCH_URL, getSearchET().getText().toString(), mHandler, YNCommonConfig.LIVE_SEARCH_FLAG, false);
                            }
                        });
                        historyDao.insertRecord(getSearchET().getText().toString().trim());
                        getHistoryData();
                    }
                }
                return false;
            }
        });

        getSearchET().addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                if (getSearchET().getText().length() > 0)
                {
                    mLLLatelySearch.setVisibility(View.GONE);
                    mRLSearchContent.setVisibility(onClickListItem ? View.GONE : View.VISIBLE);
                    mTVAnchor.setText("搜索房间号“" + getSearchET().getText().toString() + "”的主播");
                    mTVAnchor.setSpecifiedTextsColor(mTVAnchor.getText().toString(), getSearchET().getText().toString().trim(), Color.parseColor("#FF0000"));
                }
                else
                {
                    mLLLatelySearch.setVisibility(View.VISIBLE);
                    mRLSearchContent.setVisibility(View.GONE);
                    mRLLiveHost.setVisibility(View.GONE);
                    mLLShowResult.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s)
            {
                if (getSearchET().getText().length() > 0)
                {
                    mLLLatelySearch.setVisibility(View.GONE);
                    mRLSearchContent.setVisibility(onClickListItem ? View.GONE : View.VISIBLE);
                    mTVAnchor.setText("搜索包含“" + getSearchET().getText().toString() + "”的主播");
                    mTVAnchor.setSpecifiedTextsColor(mTVAnchor.getText().toString(), getSearchET().getText().toString().trim(), Color.parseColor("#FF0000"));
                }
                else
                {
                    mLLLatelySearch.setVisibility(View.VISIBLE);
                    mRLSearchContent.setVisibility(View.GONE);
                    mRLLiveHost.setVisibility(View.GONE);
                    mLLShowResult.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_tv_right:
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(YNSearchActivity.this.getCurrentFocus().getWindowToken()
                        ,InputMethodManager.HIDE_NOT_ALWAYS);
                finish();
                break;

            case R.id.rl_search_content:
                if (TextUtils.isEmpty(getSearchET().getText().toString()))
                {
                    YNToastMaster.showToast(YNSearchActivity.this, "请输入主播房间号");
                    return;
                }
                if (!YNCommonUtils.isNumber(getSearchET().getText().toString()))
                {
                    YNToastMaster.showToast(YNSearchActivity.this, "房间号有误");
                    return;
                }
                mRLSearchContent.setVisibility(View.GONE);
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().liveSearch(YNSearchActivity.this, YNCommonConfig.LIVE_SEARCH_URL, getSearchET().getText().toString(), mHandler, YNCommonConfig.LIVE_SEARCH_FLAG, false);
                    }
                });
                historyDao.insertRecord(getSearchET().getText().toString().trim());
                getHistoryData();
                break;

            case R.id.btn_clear:
                historyDao.deleteData();
                getHistoryData();
                mBtnClear.setText("暂时无相关搜索记录");
                mBtnClear.setClickable(false);
                break;

            case R.id.search_result:
                if (YNBaseActivity.isConnectNet)
                {
                    intent.setClass(context, FindAnchorHomeActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("userId", liveRoomBean.getUserid());
                    intent.putExtras(bundle);
//                    if (AccountUtils.getLoginInfo())
//                    {
//                        if (AccountUtils.getAccountBean().getId().equals(liveRoomBean.getUserid()))
//                        {
//                            intent.putExtra(YNCommonConfig.ISSHOW, false);
//                        }
//                        else
//                        {
//                            intent.putExtra(YNCommonConfig.ISSHOW, true);
//                        }
//                    }
//                    else
//                    {
//                        intent.putExtra(YNCommonConfig.ISSHOW, true);
//                    }
                    context.startActivity(intent);
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
                break;
        }
    }

    private void getHistoryData()
    {
        dataSource.clear();
        String[] searchRecord = historyDao.queryAllSearchRecord();
        for (int i = 0; i < searchRecord.length; i++)
        {
            dataSource.add(searchRecord[i]);
        }

        if (dataSource.isEmpty())
        {
            mBtnClear.setText("暂时无相关搜索记录");
            mBtnClear.setClickable(false);
        }
        else
        {
            mBtnClear.setText(R.string.delete_history);
            mBtnClear.setClickable(true);
        }

        mAdapter = new CommonAdapter<String>(this, dataSource, R.layout.history_item)
        {
            @Override
            public void convert(final CommonViewHolder viewHolder, final String item)
            {
                viewHolder.setText(R.id.tv_room_id, item);

                viewHolder.getView(R.id.ll_clear).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        historyDao.deleteRecord(item);
                        getHistoryData();
                    }
                });
            }
        };

        mHistoryLV.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }
}
