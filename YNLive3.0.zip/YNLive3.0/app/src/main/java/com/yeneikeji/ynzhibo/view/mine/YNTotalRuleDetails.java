package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.lidong.pdf.PDFView;
import com.lidong.pdf.listener.OnDrawListener;
import com.lidong.pdf.listener.OnLoadCompleteListener;
import com.lidong.pdf.listener.OnPageChangeListener;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;

public class YNTotalRuleDetails
        extends YNBaseTopBarActivity
        implements View.OnClickListener, OnLoadCompleteListener, OnPageChangeListener,
                   OnDrawListener
{

    private String  mFlag;
    private PDFView pdfView;
    private YNLoadingDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yntotal_rule_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        //获取跳转过来页面的标识
        mFlag = getIntent().getStringExtra(YNCommonConfig.SELECT_VIDEO_FLAG);
        pdfView = (PDFView) findViewById(R.id.pdfView);
        mDialog=new YNLoadingDialog(new YNLoadingDialog.Builder(YNTotalRuleDetails.this));
        showProgress();
        if(mFlag.equals("pushstreamIntroduction")){
            configTopBarCtrollerWithTitle("推流工具使用说明");

            loadNetPdfFile(YNCommonConfig.GET_PUSH_TOOL_INTRODUCTION,"pushToolIntroduction.pdf");

        }
        if(mFlag.equals("roomManageintroduction")){
            configTopBarCtrollerWithTitle("房管的设置方法");

        }
        if(mFlag.equals("hostSignedRule")){
            configTopBarCtrollerWithTitle("主播签约协定");
            loadNetPdfFile(YNCommonConfig.GET_HOST_SIGNED_RULE_INTRODUCTION,"hostSignedRule.pdf");

        }
        if(mFlag.equals("hostMustRule")){
            configTopBarCtrollerWithTitle("主播直播守则");

        }
        if(mFlag.equals("calculateMoney")){
            configTopBarCtrollerWithTitle("薪资结算调整通知");

        }
        if(mFlag.equals("controllerLiveContent")){
            configTopBarCtrollerWithTitle("直播内容监管");

        }
        if(mFlag.equals("punishHostNotice")){
            configTopBarCtrollerWithTitle("违反协定处罚告示");

        }
    }

    //加载进度条
    private void showProgress() {
        mDialog.show();
    }
    //隐藏进度条
    private void hideDialog() {
        mDialog.dismiss();
    }

    //加载网络pdf文档协议
    private void loadNetPdfFile(String path,String fileName) {
        pdfView.fileFromLocalStorage(this,this,this,path,fileName);
    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }

    @Override
    public void loadComplete(int nbPages) {
    hideDialog();

    }


    @Override
    public void onPageChanged(int page, int pageCount) {
        getRightTV().setVisibility(View.VISIBLE);
    getRightTV().setText(""+page+"/"+pageCount);
    }

    @Override
    public void onLayerDrawn(Canvas canvas, float pageWidth, float pageHeight, int displayedPage) {

    }

}
