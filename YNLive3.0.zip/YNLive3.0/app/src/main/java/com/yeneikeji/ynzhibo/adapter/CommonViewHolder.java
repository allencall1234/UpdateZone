package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.yeneikeji.ynzhibo.R;

/**
 * 自定义多用ViewHodler
 */
public class CommonViewHolder {

	private final SparseArray<View> mViews;
	private View mConvertView;

	private int position;
	public CommonViewHolder(Context context, ViewGroup parent, int layoutId,
							int position) {
		// TODO Auto-generated constructor stub
		this.mViews = new SparseArray<View>();
		mConvertView = LayoutInflater.from(context).inflate(layoutId, parent,
				false);
		//AutoUtils.auto(mConvertView);
		mConvertView.setTag(this);

		this.position = position;
	}

	public static CommonViewHolder get(Context context, View convertView,
									   ViewGroup parent, int layoutId, int position) {
		if (convertView == null) {
			return new CommonViewHolder(context, parent, layoutId, position);
		}
		return (CommonViewHolder) convertView.getTag();
	}

	public <T extends View> T getView(int viewId) {
		// TODO Auto-generated method stub
		View view = mViews.get(viewId);
		if (view == null) {
			view = mConvertView.findViewById(viewId);
			mViews.put(viewId, view);
		}
		return (T) view;
	}

	public View getConvertView() {
		return mConvertView;
	}
	
	/**
	 * 给TextView及其子类设置文字内容
	 * @param viewId
	 * @param text
	 * @return
	 */
	public CommonViewHolder setText(int viewId, String text) {
		TextView view = getView(viewId);
		view.setText(text);
		return this;
	}
	
	/**
	 * 修改字體顏色
	 * @param viewId
	 * @param text
	 * @param color
	 * @return
	 */
	public CommonViewHolder setText(int viewId, String text, int color) {
		TextView view = getView(viewId);
		view.setTextColor(color);
		view.setText(text);
		return this;
	}

	public CommonViewHolder setTextVisible(int viewId, Boolean flag) {
		TextView view = getView(viewId);
		if(flag){
			view.setVisibility(View.VISIBLE);
		}else{
			view.setVisibility(View.GONE);
		}
		return this;
	}

	public CommonViewHolder setImageVisible(int viewId, Boolean flag){
		ImageView view = getView(viewId);
		if(flag){
			view.setVisibility(View.VISIBLE);
		}else{
			view.setVisibility(View.GONE);
		}
		return this;
	}


	public CommonViewHolder setCheckedVisible(int viewId, Boolean flag){
		CheckBox view = getView(viewId);
		if(flag){
			view.setVisibility(View.VISIBLE);
		}else{
			view.setVisibility(View.GONE);
		}
		return this;
	}

	public CommonViewHolder setIsChecked(int viewId, Boolean flag){
		CheckBox view = getView(viewId);
		view.setChecked(flag);
		return this;
	}

	public CommonViewHolder setTextBackground(int viewId, int drawableId){
		TextView view = getView(viewId);
		view.setBackgroundResource(drawableId);
		return this;
	}
	
	/** 
     * 为ImageView及其子类设置图片 
     * @param viewId 
     * @param drawableId 
     * @return 
     */  
    public CommonViewHolder setImageResource(int viewId, int drawableId)
    {  
        ImageView view = getView(viewId);
		view.setTag(position);
        view.setImageResource(drawableId);  
  
        return this;  
    }  
  
    /** 
     * 为ImageView及其子类设置图片 
     *  
     * @param viewId 
     * @return
     */  
    public CommonViewHolder setImageBitmap(int viewId, Bitmap bm)
    {  
        ImageView view = getView(viewId);  
        view.setImageBitmap(bm);  
        return this;  
    }  
  
	/**
	 * 为ImageView及其子类设置网络图片
	 *
	 * @param viewId
	 * @return
	 */
	public CommonViewHolder setImage(Context context, int viewId, String url)
	{
		Glide.with(context).load(url)
//				.placeholder(R.drawable.head_photo)
				.error(R.drawable.head_photo)
				.diskCacheStrategy(DiskCacheStrategy.ALL)
				.into((ImageView) getView(viewId));
		return this;
	}
    
    public CommonViewHolder setChecked(int viewId, boolean check){
    	CompoundButton button = getView(viewId);
    	button.setChecked(check);
    	return this;
    }


    public CommonViewHolder setListener(int viewId, OnClickListener listener){
    	View view = getView(viewId);
    	view.setOnClickListener(listener);
    	return this;
    };

    public int getPosition() {
		return position;
	}
}
