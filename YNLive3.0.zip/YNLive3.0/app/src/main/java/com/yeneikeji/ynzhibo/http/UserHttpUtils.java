package com.yeneikeji.ynzhibo.http;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v4.util.ArrayMap;

import org.xutils.http.RequestParams;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.MessageDigest;

public class UserHttpUtils extends BaseHttpUtils
{
    private static final String TAG = "HttpUtil";

    private static UserHttpUtils instance = null;
    public static UserHttpUtils newInstance()
    {
        if(instance == null)
        {
            instance = new UserHttpUtils();


        }
        return instance;
    }

    private UserHttpUtils()
    {

    }

    /**
     * 获取webchinese短信验证码
     * @param context
     * @param url
     * @param Uid
     * @param Key
     * @param smsMob
     * @param smsText
     * @param handler
     * @param whichFlag
     */
    public void userGetWebChineseSMSCode(final Context context, String url, String Uid, String Key, String smsMob, String smsText, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("Uid", Uid);
        params.addBodyParameter("Key", Key);
        params.addBodyParameter("smsMob", smsMob);
        params.addBodyParameter("smsText", smsText);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户注册
     * @param context
     * @param url
     * @param phone
     * @param password
     * @param password
     * @param equipmentId
     */
    public void userRegister(final Context context, String url, String phone, String password, String userAccount, String equipmentId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("phone", phone);
        params.addBodyParameter("password", password);
        params.addBodyParameter("useraccount", userAccount);
        params.addBodyParameter("equipmentId", equipmentId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户注册下一步(判断该手机号是否注册)
     * @param context
     * @param url
     * @param phone
     * @param handler
     * @param whichFlag
     */
    public void userRegisterNext(final Context context, String url, String phone, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("phone", phone);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 忘记密码
     * @param context
     * @param url
     * @param phone
     * @param handler
     * @param whichFlag
     */
    public void userForgetPassword(final Context context, String url, String phone, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
//        params.addBodyParameter("userid", userid);
        params.addBodyParameter("phone", phone);
//        params.addBodyParameter("code", code);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 忘记密码时重置密码
     * @param context
     * @param url
     * @param phone
     * @param newpassword
     * @param handler
     * @param whichFlag
     */
    public void userResetPassWord(final Context context, String url, String phone, String newpassword, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("phone", phone);
        params.addBodyParameter("newpassword", newpassword);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 修改密码
     * @param context
     * @param url
     * @param userid
     * @param password
     * @param newpassword
     * @param handler
     * @param whichFlag
     */
    public void userUpdatePassWord(final Context context, String url, String userid, String password, String newpassword, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("password", password);
        params.addBodyParameter("newpassword", newpassword);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户登录
     * @param context
     * @param url
     * @param phone
     * @param password
     * @param handler
     * @param whichFlag
     */
    public void userLogin(final Context context, String url, String phone, String password, String app_equipmentId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("phone", phone);
        params.addBodyParameter("password", password);
        params.addBodyParameter("status", String.valueOf(0));
        params.addBodyParameter("app_equipmentId", app_equipmentId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户退出app
     * @param context
     * @param url
     * @param phone
     * @param status
     * @param handler
     * @param whichFlag
     */
    public void userExitApp(final Context context, String url, String phone, String status, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("phone", phone);
        params.addBodyParameter("status", status);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取融云token
     * @param context
     * @param url
     * @param userid
     * @param username
     * @param icon
     * @param handler
     * @param whichFlag
     */
    public void getRongCloudToken(final Context context, String url, String userid, String username, String icon, String hostId, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("username", username);
        params.addBodyParameter("icon", icon);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);

    }

    /**
     * 更新直播间用户登录状态
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void updateLiveRoomUserState(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 参与直播间
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void liveRoomTakePartIn(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 查询聊天室成员信息
     * @param context
     * @param url
     * @param room_id
     * @param count
     * @param order
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void queryChatRoomUserList(final Context context, String url, String room_id, int count, int order, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("count", String.valueOf(count));
        params.addBodyParameter("order", String.valueOf(order));
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 查询聊天室房管信息
     * @param context
     * @param url
     * @param room_id
     * @param handler
     * @param whichFlag
     */
    public void queryChatRoomManagerInfo(final Context context, String url, String room_id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 我的录制视频列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void myRecordVideoList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 直播间直播评价
     * @param context
     * @param url
     * @param userid
     * @param uid
     * @param score
     * @param handler
     * @param whichFlag
     */
    public void liveEvaluate(final Context context, String url, String userid, String uid, int score, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("uid", uid);
        params.addBodyParameter("score", String.valueOf(score));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 直播间获取主播资料
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getAnchorInfo(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 直播间获取贡献值前20名用户列表
     * @param context
     * @param url
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void getContributionValueTopTwenty(final Context context, String url, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 直播间获取排行榜(周榜、总榜)
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getContributionValueList(final Context context, String url, String userid, int type, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 直播间提问、回复
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param content
     * @param payCoin
     * @param type
     * @param handler
     * @param whichFlag
     * @param isShow
     */
    public void liveRoomAsk(final Context context, String url, String userid, String hostId, String content, int payCoin, int type, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("content", content);
        params.addBodyParameter("payCoin", String.valueOf(payCoin));
        params.addBodyParameter("type", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);

    }

    /**
     * 获取直播间提问列表
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     * @param isShow
     */
    public void getLiveRoomAskList(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);

    }

    /**
     * 获取直播间笔记
     * @param context
     * @param url
     * @param myselfId
     * @param userid
     * @param is_purchase
     * @param handler
     * @param whichFlag
     * @param isShow
     */
    public void getLiveRoomNote(final Context context, String url, String myselfId, String userid, int is_purchase, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("is_purchase", String.valueOf(is_purchase));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 获取直播间公告列表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getLiveRoomNoticeList(final Context context, String url, String roomId, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", roomId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 获取主播直播间提问列表
     * @param context
     * @param url
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void getLiveHostLiveRoomAskList(final Context context, String url, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 主播直播间阅读提问
     * @param context
     * @param url
     * @param id
     * @param handler
     * @param whichFlag
     */
    public void liveHostReadAsk(final Context context, String url, String id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 主播直播间回复提问
     * @param context
     * @param url
     * @param id
     * @param reply
     * @param handler
     * @param whichFlag
     */
    public void liveHostReplyAsk(final Context context, String url, String id, String reply, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);
        params.addBodyParameter("reply", reply);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 主播发布直播间公告
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void releaseLiveNotice(final Context context, String url, String room_id, String content, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("content", content);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 主播获取直播财富榜
     * @param userid
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void liveHostGetWealthSort(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取直播间在线人数
     * @param room_id
     * @param count
     * @param order
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getLiveRoomPersonalNum(final Context context, String url, String room_id, int count, int order, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("count", String.valueOf(count));
        params.addBodyParameter("order", String.valueOf(order));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的界面我的财富
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyWealthIncome(final Context context, String url, String userid, int type, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("month", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 我的界面总财富
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getTotallWealthIncome(final Context context, String url, String userid,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取结算财富列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getCalculateInfo(final Context context, String url, String userid,String type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", type);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 结算财富信息
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getCalculateWealthInfo(final Context context, String url, String userid,String wealth,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("wealth", wealth);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }
    /**
     * 保存银行卡信息
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void saveBankCardInfo(final Context context, String url, String userid,String name,String cardId,String bank,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("name", name);
        params.addBodyParameter("cardId", cardId);
        params.addBodyParameter("bank", bank);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 保存银行卡信息
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void editBankCardInfo(final Context context, String url, String userid,String name,String cardId,String bank,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("name", name);
        params.addBodyParameter("cardId", cardId);
        params.addBodyParameter("bank", bank);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 提现
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void tiXian(final Context context, String url,String Amount,String wealth, String userid,String name,String cardId,String bank,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("Amount", Amount);
        params.addBodyParameter("wealth", wealth);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("name", name);
        params.addBodyParameter("cardId", cardId);
        params.addBodyParameter("bank", bank);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 我的界面当月的财富
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMonthWealthIncome(final Context context, String url, String userid, int type, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("date", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取聊天室用户信息详情
     * @param context
     * @param url
     * @param room_id
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getChatRoomUserInfo(final Context context, String url, String room_id, String userid, String myselfId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("myselfId", myselfId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取聊天室自己的信息详情
     * @param context
     * @param url
     * @param room_id
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getChatRoomMySelfInfo(final Context context, String url, String room_id, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 查询被禁言的用户
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void queryChatRoomBeBlockedUesrList(final Context context, String url, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 举报用户
     * @param context
     * @param url
     * @param myselfId
     * @param userid
     * @param content
     * @param handler
     * @param whichFlag
     */
    public void reportUser(final Context context, String url, String myselfId, String userid, int content, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("content", String.valueOf(content));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 聊天室禁言用户
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void chatRoomGagUser(final Context context, String url, String room_id, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 聊天室解除用户禁言
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void chatRoomCancelGagUser(final Context context, String url, String room_id, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams();
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 聊天室封禁用户
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void chatRoomStopSpeak(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
//        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 聊天室解除封禁
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void chatRoomUnBlockSpeak(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
//        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 邀请房管
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void addRoomManager(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 接受主播房管邀请
     * @param context
     * @param url
     * @param hostId
     * @param manageId
     * @param handler
     * @param whichFlag
     */
    public void agreeBecomingRoomManager(final Context context, String url, String id, String hostId, String manageId, int is_accept, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("manageId", manageId);
        params.addBodyParameter("is_accept", String.valueOf(is_accept));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 删除房管
     * @param context
     * @param url
     * @param room_id
     * @param manageId
     * @param handler
     * @param whichFlag
     */
    public void deleteRoomManager(final Context context, String url, String room_id, String manageId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);
        params.addBodyParameter("manageId", manageId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户退出直播观看
     * @param context
     * @param url
     * @param userid
     * @param myselfId
     * @param handler
     * @param whichFlag
     */
    public void userExitWatchLive(final Context context, String url, String userid, String myselfId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("myselfId", myselfId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 直播搜索
     * @param context
     * @param url
     * @param room_id
     * @param handler
     * @param whichFlag
     */
    public void liveSearch(final Context context, String url, String room_id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("room_id", room_id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 用户上传个人资料
     * @param context
     * @param url
     * @param userid
     * @param username
     * @param date
     * @param sex
     * @param icon
     * @param describe
     * @param handler
     * @param whichFlag
     */
    public void uploadUserInfo(final Context context, String url, String userid, String username, String date, int sex, File icon, String describe, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("username", username);
        params.addBodyParameter("date", date);
        params.addBodyParameter("sex", String.valueOf(sex));
        if (icon != null)
            params.addBodyParameter("icon", icon);
        else
            params.addBodyParameter("icon", "");

        params.addBodyParameter("describes", describe);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 用户直播身份验证
     * @param context
     * @param url
     * @param userid
     * @param realname
     * @param id_card
     * @param picture
     * @param handler
     * @param whichFlag
     */
    public void userLiveAuthentication(final Context context, String url, String userid, String realname, String id_card, String phone, File[] picture, String mobile_type,
                                       int kind, String experience, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("realname", realname);
        params.addBodyParameter("id_card", id_card);
        params.addBodyParameter("phone", phone);

        if(picture != null)
        {
            for (int i = 0; i < picture.length; i++)
            {
                params.addBodyParameter("picture" + i, picture[i]);
            }
        }

        params.addBodyParameter("mobile_type", mobile_type);
        params.addBodyParameter("kind", String.valueOf(kind));
        params.addBodyParameter("experience", experience);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 用户主播状态获取
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getUserStatus(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 推流成功后请求
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void pushStreamSuccessRequest(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 修改直播选择信息
     * @param context
     * @param url
     * @param userid
     * @param picture
     * @param title
     * @param tag2
     * @param handler
     * @param whichFlag
     */
    public void updateLiveInfo(final Context context, String url, String userid, File picture, String title, String tag2,String classify,String send_status, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        if (picture == null)
            params.addBodyParameter("picture", "");
        else
            params.addBodyParameter("picture", picture);

        if (title == null)
            params.addBodyParameter("title", "");
        else
            params.addBodyParameter("title", title);

//        params.addBodyParameter("tag1", String.valueOf(tag1));
//        params.addBodyParameter("tag2", String.valueOf(tag2));
//        params.addBodyParameter("tag3", String.valueOf(tag3));
//        params.addBodyParameter("tag4", String.valueOf(tag4));
        params.addBodyParameter("tag2", tag2);
        params.addBodyParameter("classify", classify);
        params.addBodyParameter("send_status", send_status);
//        params.addBodyParameter("equipment", String.valueOf(equipment));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 修改直播串流码
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void updateStreamingCode(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 设置直播间密码
     * @param context
     * @param url
     * @param userid
     * @param pwd
     * @param handler
     * @param whichFlag
     */
    public void setLiveRoomPass(final Context context, String url, String userid, String pwd, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("pwd", pwd);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 设置直播间收费
     * @param context
     * @param url
     * @param userid
     * @param exptime
     * @param status
     * @param payCoin
     * @param handler
     * @param whichFlag
     */
    public void setLiveRoomPay(final Context context, String url, String userid, String exptime, int status, int payCoin, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("exptime", exptime);
        params.addBodyParameter("live_status", String.valueOf(status));
        params.addBodyParameter("payCoin", String.valueOf(payCoin));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 直播间送礼物
     * @param context
     * @param url
     * @param userid
     * @param toId
     * @param giftName
     * @param count
     * @param price
     * @param type
     * @param handler
     * @param whichFlag
     */
    public void liveRoomSendGift(final Context context, String url, String userid, String toId, String giftName, int count, float price, int type, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("toId", toId);
        params.addBodyParameter("giftName", giftName);
        params.addBodyParameter("count", String.valueOf(count));
        params.addBodyParameter("price", String.valueOf(price));
        params.addBodyParameter("type", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 观看直播验证房间密码
     * @param context
     * @param url
     * @param userid
     * @param pwd
     * @param handler
     * @param whichFlag
     */
    public void watchLiveValidationPass(final Context context, String url, String userid, String pwd, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("pwd", pwd);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 观看直播付费
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void watchLiveValidationPayCoin(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取用户当前金币
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getCurrentGoldCoin(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 立即开播获取推流地址
     * @param context
     * @param url
     * @param userid
     * @param picture
     * @param title
     * @param tag
     * @param handler
     * @param whichFlag
     */
    public void getPushAddressUrl(final Context context, String url, String userid, String app_name, File picture, String title, String tag,String classify,String send_status, int equipment,
                                  final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("app_name", app_name);
        if (picture == null)
            params.addBodyParameter("picture", "");
        else
            params.addBodyParameter("picture", picture);

        if (title == null)
            params.addBodyParameter("title", "");
        else
            params.addBodyParameter("title", title);

//        params.addBodyParameter("tag1", String.valueOf(tag1));
//        params.addBodyParameter("tag2", String.valueOf(tag2));
//        params.addBodyParameter("tag3", String.valueOf(tag3));
//        params.addBodyParameter("tag4", String.valueOf(tag4));
        params.addBodyParameter("tag2", tag);
        params.addBodyParameter("classify", classify);
        params.addBodyParameter("send_status", send_status);
//        params.addBodyParameter("equipment", String.valueOf(equipment));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 停止直播
     * @param context
     * @param url
     * @param userid
     */
    public void stopLive(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 我的直播视频列表
     * @param context
     * @param url
     * @param userid
     */
    public void myVideoList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的被举报记录列表
     * @param context
     * @param url
     * @param userid
     */
    public void myReportedList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 获取直播首页列表以及分类列表
     * @param context
     * @param url
     * @param tag
     * @param handler
     * @param whichFlag
     */
    public void getLiveHomePageList(final Context context, String url, int tag, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("tag", String.valueOf(tag));
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取发现首页
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getFindFirstPage(final Context context, String url, String userid, int kind, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("kind", String.valueOf(kind));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**

    /**
     * 获取股市解读
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getMarketInterpretList(final Context context, String url, String userid, int kind, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", String.valueOf(kind));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取大咖页面列表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getBigShotList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 获取语音观点
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getVoicePointList(final Context context, String url, String userid, int kind, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", String.valueOf(kind));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 获取精选热文
     * @param context
     * @param url
     * @parandler
     * @param whichFlag
     */
    public void getExcitingArticalList(final Context context, String url, String userid,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 获取今日必读
     * @param context
     * @param url
     * @parandler
     * @param whichFlag
     */
    public void getMustReadTodaylList(final Context context, String url, String userid,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
    /**
    /**
    /**
    /**
     * 获取发现家教首页
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getFindFirstPageTeach(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取发现个人主页
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getFindPersonalHome(final Context context, String url, String myselfId, String userid, int is_purchase, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("is_purchase", String.valueOf(is_purchase));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取发现个人主页语音列表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getPersonnalAudioList(final Context context, String url,String userid, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);


        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }
    /**
     * 获取发现主播主页
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getFindAnchorHome(final Context context, String url, String myselfId, String userid, int is_purchase, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("is_purchase", String.valueOf(is_purchase));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 获取已经购买文章内容
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getBuyedArtical(final Context context, String url, String myselfId, String userid, int is_purchase, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("is_purchase", String.valueOf(is_purchase));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 获取文章详情
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getArticalDetails(final Context context, String url,String aid,String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message = new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("aid", aid);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 文章评价
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getEvaluateArtical(final Context context, String url,String aid, String userid,String type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("aid", aid);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", type);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 文章发表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getArticalPublish(final Context context, String url, String userid,String title,String describes,String content,File[] files,String describe0,String describe1,String describe2,String is_pay,String payCoin,String mobile_type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("title", title);
        params.addBodyParameter("describes", describes);
        params.addBodyParameter("content", content);
        if(files != null)
        {
            for (int i = 0; i < files.length; i++)
            {
                params.addBodyParameter("picture" + i, files[i]);
            }
        }
        params.addBodyParameter("describe0", describe0);
        params.addBodyParameter("describe1", describe1);
        params.addBodyParameter("describe2", describe2);
        params.addBodyParameter("is_pay", is_pay);
        params.addBodyParameter("payCoin", payCoin);
        params.addBodyParameter("mobile_type", mobile_type);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 被驳回笔记重新发表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getArticalRePublish(final Context context, String url, String userid,String title,String describes,String aid,String content,File[] files,String describe0,String describe1,String describe2,String is_pay,String payCoin,String mobile_type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("title", title);
        params.addBodyParameter("describes", describes);
        params.addBodyParameter("aid", aid);
        params.addBodyParameter("content", content);
        if(files != null)
        {
            for (int i = 0; i < files.length; i++)
            {
                params.addBodyParameter("picture" + i, files[i]);
            }
        }
        params.addBodyParameter("describe0", describe0);
        params.addBodyParameter("describe1", describe1);
        params.addBodyParameter("describe2", describe2);
        params.addBodyParameter("is_pay", is_pay);
        params.addBodyParameter("payCoin", payCoin);
        params.addBodyParameter("mobile_type", mobile_type);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 发布视频
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void releaseVideo(final Context context, String url, String userid, String mediaId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("mediaId", mediaId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 语音观点发表
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getVoicePointPublish(final Context context, String url, String userid,File file,String describle,String playTime,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("audio", file);
        params.addBodyParameter("describe1", describle);
        params.addBodyParameter("playTime", playTime);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 语音观点评价
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getEvaluateVoice(final Context context, String url,String aid, String userid,String type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("aid", aid);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", type);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 社区发布
     * @param url
     * @param userid
     * @param content
     * @param files
     * @param handler
     * @param whichFlag
     */
    public void releaseDynamic(final Context context, String url, String mobileType, String userid, String content, File[] files, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("mobile_type", mobileType);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("content", content);
        if(files != null)
        {
            for (int i = 0; i < files.length; i++)
            {
//                params.addBodyParameter("picture[]", pictures[i]);
                params.addBodyParameter("picture" + i, files[i]);
            }
        }

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 个人动态主页
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getPersonalHomePage(final Context context, String url, String userid, String myselfId, int page, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("myselfId", myselfId);
        params.addBodyParameter("page", String.valueOf(page));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 发现主播主页
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getFindPersonalHomePage(final Context context, String url, String userid, String myselfId,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("myselfId", myselfId);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 发现观点主页
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getFindPointHomePage(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 删除个人动态
     * @param context
     * @param url
     * @param cid
     * @param handler
     * @param whichFlag
     */
    public void deletePersonalDynamic(final Context context, String url, String cid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("cid", cid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }

    /**
     * 获取首页动态
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getHomePageDynamic(final Context context, String url, String equipmentId, String userid, int page, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("equipmentId", equipmentId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("page", String.valueOf(page));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取首页更多动态
     * @param context
     * @param url
     * @param page
     * @param handler
     * @param whichFlag
     */
    public void getHomePageMoreDynamic(final Context context, String url, String equipmentId, int page, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("equipmentId", equipmentId);
        params.addBodyParameter("page", String.valueOf(page));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取动态详情中用户评论列表排序(0：按时间排序  1：按点赞数排序)
     * @param context
     * @param url
     * @param userid
     * @param cid
     * @param is_sort
     * @param handler
     * @param whichFlag
     */
    public void getUserCommentsList(final Context context, String url, String userid, String cid, int is_sort, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("cid", cid);
        params.addBodyParameter("is_sort", String.valueOf(is_sort));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 动态正文中用户评论排序(0：按时间排序  1：按点赞数排序)
     * @param context
     * @param url
     * @param userid
     * @param cid
     * @param is_sort
     * @param handler
     * @param whichFlag
     */
    public void userCommentsListSort(final Context context, String url, String userid, String cid, int is_sort, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("cid", cid);
        params.addBodyParameter("is_sort", String.valueOf(is_sort));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取动态详情中用户点赞列表
     * @param context
     * @param url
     * @param cid
     * @param handler
     * @param whichFlag
     */
    public void getUserThumbList(final Context context, String url, String cid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("cid", cid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取我和我关注的用户动态列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyAttentionUserDynamicList(final Context context, String url, String userid, int page, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("page", String.valueOf(page));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 关注用户
     * @param context
     * @param url
     * @param userid
     * @param attentionid
     * @param handler
     * @param whichFlag
     */
    public void attentionUser(final Context context, String url, String userid, String attentionid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("attentionid", attentionid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 取消关注
     * @param context
     * @param url
     * @param userid
     * @param id
     * @param handler
     * @param whichFlag
     */
    public void cancelAttentionUser(final Context context, String url, String userid, String id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("id", id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 社区点赞和取消点赞
     * thumb:没点过赞传0，点过赞传1
     * @param context
     * @param url
     * @param cid
     * @param thumb
     * @param handler
     * @param whichFlag
     */
    public void userThumbUp(final Context context, String url, String userid, String cid, int thumb, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("cid", cid);
        params.addBodyParameter("thumb", String.valueOf(thumb));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 社区评论列表点赞取消点赞
     * @param context
     * @param url
     * @param cid
     * @param userid
     * @param comentId
     * @param thumb
     * @param handler
     * @param whichFlag
     */
    public void communityCommentsListThumb(final Context context, String url, String cid, String userid, String comentId, int thumb, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("cid", cid);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("comentId", comentId);
        params.addBodyParameter("thumb", String.valueOf(thumb));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的评论(与我相关的评论)
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void myComments(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的关注列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyAttentionList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取我的粉丝列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyFansList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取文章详情
     * @param context
     * @param url
     * @param handler
     * @param whichFlag
     */
    public void getGoldCoin(final Context context, String url,String userid,String amount, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message = new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("Amount", amount);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);

    }
    /**
     * 获取我的贡献列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyContributionList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 用户评论
     * @param context
     * @param url
     * @param cid
     * @param userid
     * @param content
     * @param callbackId
     * @param handler
     * @param whichFlag
     */
    public void userComment(final Context context, String url, String cid, String userid, String content, int callbackId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("cid", cid);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("content", content);
        params.addBodyParameter("callbackId", String.valueOf(callbackId));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 删除评论
     * @param context
     * @param url
     * @param id
     * @param handler
     * @param whichFlag
     */
    public void deleteComment(final Context context, String url, String id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 意见反馈
     * @param context
     * @param url
     * @param userid
     * @param suggestion
     * @param phone
     * @param handler
     * @param whichFlag
     */
    public void feedBack(final Context context, String url, String userid, String suggestion, String phone, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("suggestion", suggestion);
        params.addBodyParameter("phone", phone);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 打开或者关闭推送通知
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void openOrClosePush(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的消息里面的评论和赞
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMyCommentThumbMsg(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 我的消息里面的系统通知
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void getMySystemMsg(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }



    /**
     * 单个删除我的消息里面的系统通知
     * @param context
     * @param url
     * @param id
     * @param handler
     * @param whichFlag
     */
    public void deleteMySystemMsg(final Context context, String url ,String id, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id" ,id);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow ,0);

    }


    /**
     * 单个删除我的消息里面的系统通知
     * @param context
     * @param url
     * @param id
     * @param is_read
     * @param handler
     * @param whichFlag
     */
    public void isReadMySystemMsg(final Context context, String url ,String id, String is_read, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id" ,id);
        params.addBodyParameter("is_read", is_read);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }




    /**
     * 购买文章
     * @param context
     * @param url
     * @param aid
     * @param userid
     * @param userid
     * @param fee
     * @param whichFlag
     */
    public void buyArticle(final Context context, String url, String aid, String userid, int fee, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("aid", aid);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("fee", String.valueOf(fee));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 获取设置推送列表
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void getSetUpPushList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 设置推送
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void getSetUpPushOpenOrClose(final Context context, String url, String userid,String attentionid, String type, String status, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("attentionid", attentionid);
        params.addBodyParameter("type", type);
        params.addBodyParameter("status", status);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 获取个人主页视频列表
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void getHomePageVideoList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 获取个人主页音频列表
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void getHomePageAudioList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 商品下单
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void orderGoods(final Context context, String url, String userid, int price, String content, final Handler handler, int whichFlag, boolean isShow, int height)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("price", String.valueOf(price));
        params.addBodyParameter("content", content);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, height);
    }

    /**
     * 获取分享地址
     * @param context
     * @param url
     * @param whichFlag
     */
    public void getShareAddress(final Context context, String url, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 绑定手机
     * @param context
     * @param url
     * @param whichFlag
     */
    public void bindPhone(final Context context, String url, String userid, String phone, String password, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("phone", phone);
        params.addBodyParameter("password", password);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 查询多通道直播状态
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void queryMultiChannelLiveState(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     *职务变化接口
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void getEmployeChange(final Context context, String url, String userid,String type,final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", type);
        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     *子房间替换房主接口
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void childRoomHostChange(final Context context, String url, String hostId,String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 申请多通道直播
     * @param context
     * @param url
     * @param userid
     * @param code
     * @param describes
     * @param title
     * @param whichFlag
     */
    public void applyMultiChannelLive(final Context context, String url, String userid, String title, String describes, String code, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("title", title);
        params.addBodyParameter("describes", describes);
        params.addBodyParameter("code", code);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 进入主房间
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void enterIntoMainRoom(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 搜索主播
     * @param context
     * @param url
     * @param userid
     * @param whichFlag
     */
    public void searchAnchor(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 多通道房间邀请房管
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void multichannelRoomInvitationManager(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }


    /**
     * 接收、拒绝多通道房间房管邀请
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void agreeMultichannelRoomManagerInvitation(final Context context, String url, String id, String hostId, String userid, int isAccept, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("is_accept", String.valueOf(isAccept));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 子房间房主邀请
     * @param context
     * @param url
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void childRoomOwnerInvitation(final Context context, String url, String userid, String hostId, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 接受、拒绝子房间房主邀请
     * @param context
     * @param url
     * @param id
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void agreeChildRoomOwnerInvitation(final Context context, String url, String id, String userid, String hostId, int isAccept, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("is_accept", String.valueOf(isAccept));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 子房间列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void childRoomOwnerList(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 副房主、房管进入多通道房间
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void deputyOwnerManagerEnterIntoMultichannelRoom(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 进入子房间解绑操作
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void EnterChildRoomUnbind(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }
            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }
    /**
     * 接受、拒绝子房间房主邀请
     * @param context
     * @param url
     * @param id
     * @param userid
     * @param hostId
     * @param handler
     * @param whichFlag
     */
    public void agreeRefuseAuthentication(final Context context, String url, String id, String userid, String hostId, int isAccept, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("id", id);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("hostId", hostId);
        params.addBodyParameter("is_accept", String.valueOf(isAccept));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 转播失败后切换房间
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void liveRoomExchage(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 多通道房间排麦
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void multichannelRowsWheat(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 多通道房间直播的用户信息、管理员列表、排麦列表
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void multichannelLivingInfo(final Context context, String url, String userid, int type, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);
        params.addBodyParameter("type", String.valueOf(type));

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 多通道房间直播抢麦
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void multichannelGrabWheat(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 多通道房间直播抢麦
     * @param context
     * @param url
     * @param userid
     * @param handler
     * @param whichFlag
     */
    public void multichannelUnderWheat(final Context context, String url, String userid, final Handler handler, int whichFlag, boolean isShow)
    {
        final Message message=new Message();
        message.what = whichFlag;
        RequestParams params = new RequestParams(url);
        params.addBodyParameter("userid", userid);

        postHttpRequest(context, params, new HttpUtilsCallBack()
        {
            @Override
            public void onSuccess(String result)
            {
                message.obj = result;
                handler.sendMessage(message);
            }

            @Override
            public void onError()
            {
                handler.sendMessage(message);
            }
        }, isShow, 0);
    }

    /**
     * 获取总的页数
     * @param totalNum
     * @return
     */
    public int getTotalPages(int totalNum)
    {
        int pages = totalNum / YNCommonConfig.NUMBER_EACH_PAGE == 0 ? totalNum / YNCommonConfig.NUMBER_EACH_PAGE : totalNum / YNCommonConfig.NUMBER_EACH_PAGE + 1;
        return pages;
    }

    // 融云网络请求
    public interface OnResponse {
        void onResponse(int code, String body);
    }

    public void post(String url, Header header, String body, OnResponse callback) {
        HttpAsyncTask httpTask = new HttpAsyncTask(url, header, body, callback);
        httpTask.execute();
    }

    public static Header getRcHeader(String appKey, String secret) {
        String nonce = String.valueOf(Math.random() * 0xffffff);
        String time_stamp = String.valueOf(System.currentTimeMillis() / 1000);
        String signature = toHex(toSHA1(secret + nonce + time_stamp));

        Header header = new Header();
        header.addHeader("App-Key", appKey);
        header.addHeader("Nonce", nonce);
        header.addHeader("Timestamp", time_stamp);
        header.addHeader("Signature", signature);
        header.addHeader("Content-Type", "application/x-www-form-urlencoded");
        return header;
    }

    private static byte[] toSHA1(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(value.getBytes());
            return md.digest();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    private static String toHex(byte[] data) {
        final char[] DIGITS_LOWER = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        int l = data.length;
        char[] out = new char[l << 1];
        int i = 0;

        for (int j = 0; i < l; ++i) {
            out[j++] = DIGITS_LOWER[(0xf0 & data[i]) >>> 4];
            out[j++] = DIGITS_LOWER[0x0f & data[i]];
        }
        return String.valueOf(out);
    }

    public static class Header {

        private ArrayMap<String, String> headerMap = new ArrayMap<>();

        public void addHeader(String key, String value) {
            headerMap.put(key, value);
        }

        public int size() {
            return headerMap.size();
        }

        public String getKey(int pos) {
            return headerMap.keyAt(pos);
        }

        public String getValue(int pos) {
            return headerMap.valueAt(pos);
        }
    }

    private static class Response {
        int code;
        String body;

        public Response(int code, String body) {
            this.code = code;
            this.body = body;
        }
    }

    private class HttpAsyncTask extends AsyncTask<Void, Void, Response>
    {
        private String url;
        private Header header;
        private String body;
        private OnResponse callback;
        private HttpURLConnection conn;

        public HttpAsyncTask(String url, Header header, String body, OnResponse callback) {
            this.url = url;
            this.header = header;
            this.body = body;
            this.callback = callback;
        }

        @Override
        protected void onPreExecute() {
            try {
                // Create HttpURLConnection.
                URL reqUrl = new URL(url);
                conn = (HttpURLConnection) reqUrl.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                // Write header.
                for (int i = 0; i < header.size(); i++) {
                    conn.setRequestProperty(header.getKey(i), header.getValue(i));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected Response doInBackground(Void... params) {
            try {
                // Write body.
                DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                out.writeBytes(body);
                out.flush();

                int code = conn.getResponseCode();
                InputStream in;
                if (code == 200) {
                    in = conn.getInputStream();
                } else {
                    in = conn.getErrorStream();
                }

                // Send http request, convert response to String
                ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len;
                while ((len = in.read(buffer)) != -1) {
                    outStream.write(buffer, 0, len);
                }
                byte[] data = outStream.toByteArray();
                out.close();
                outStream.close();

                String json = new String(data);
                return new Response(code, json);
            } catch (UnknownHostException e) {
                e.printStackTrace();
                return new Response(-1, "网络连接出错!");
            } catch (IOException e) {
                throw new RuntimeException("Parser http response error!");
            }
        }

        @Override
        protected void onPostExecute(Response res) {
            callback.onResponse(res.code, res.body);
        }
    }
}
