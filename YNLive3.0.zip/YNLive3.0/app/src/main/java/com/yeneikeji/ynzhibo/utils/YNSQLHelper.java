package com.yeneikeji.ynzhibo.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * 创建数据库帮助类
 * Created by Administrator on 2016/8/8.
 */
public class YNSQLHelper extends SQLiteOpenHelper
{
    public static final String DB_NAME = "yndatabase.db";// 数据库名称
    public static final int VERSION = 1;

    public static final String TABLE_CHANNEL = "ynChannel";// 数据表

    public static final String ID = "id";
    public static final String NAME = "name";

    private Context mContext;

    private YNSQLHelper sqlHelper;
    private SQLiteDatabase db;

    public YNSQLHelper(Context context)
    {
        super(context, DB_NAME, null, VERSION);
        this.mContext = context;
    }

    public Context getmContext()
    {
        return mContext;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // 创建数据库后，对数据库的操作
        String sql = "create table if not exists " + TABLE_CHANNEL +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ID + " INTEGER, " + NAME + " VARCHAR)";

        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        // 更改数据库版本
        onCreate(db);
    }

    /**
     * 打开数据库
     */
    private void establishDb() {
        if (sqlHelper == null)
        {
            sqlHelper = new YNSQLHelper(mContext);
        }

        db = sqlHelper.getWritableDatabase();
    }

    /**
     * 插入一条记录
     * @return 插入记录的id -1表示插入不成功
     */
    public long insertRecord(String searchStr)
    {
        boolean isInsert = true;
        establishDb();
        String[] searchRecord = queryAllSearchRecord();
        for (int i = 0; i < searchRecord.length; i++) {
            if (searchStr.equals(searchRecord[i])) {
                isInsert = false;
                break;
            }
        }
        long id = -1;
        if (db != null && isInsert)
        {
            ContentValues values = new ContentValues();
            values.put(NAME, searchStr);
            id = db.insert(TABLE_CHANNEL, null, values);
        }
        return id;
    }

    /**
     *  删除一条记录
     * @param roomId
     */
    public void deleteRecord(String roomId)
    {
        establishDb();
        String whereClauses = NAME + "=?";
        String [] whereArgs = { roomId };
        //调用delete方法，删除数据
        db.delete(TABLE_CHANNEL, whereClauses, whereArgs);
        closeDb();
    }

    /**
     * 清空数据
     */
    public void deleteData()
    {
        establishDb();
        db.execSQL("delete from " + TABLE_CHANNEL);
        closeDb();
    }

    /**
     * 查询所有搜索字段
     * @return 所有记录的list集合
     */
    public String[] queryAllSearchRecord()
    {
        establishDb();
        if (db != null) {
            Cursor cursor = db.query(TABLE_CHANNEL, null, null, null, null,
                    null, null);
            int count = cursor.getCount();
            String[] searchRecord = new String[count];
            if (count > 0) {
                cursor.moveToFirst();
                for (int i = 0; i < count; i++) {
                    searchRecord[i] = cursor.getString(cursor
                            .getColumnIndex(NAME));
                    cursor.moveToNext();
                }
            }
            return searchRecord;
        }
        else
        {
            return new String[0];
        }

    }

    /**
     * 关闭数据库
     */
    public void closeDb() {
        if (this.db != null) {
            this.db.close();
            this.db = null;
        }
    }

}
