package com.yeneikeji.ynzhibo.view.live;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.fragment.YNBaseFragment;

/**
 * 该Fragment是用于MainDialogFragment中的pager，为了实现滑动隐藏交互Fragment的
 */
public class EmptyFragment extends YNBaseFragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_empty, container, false);
    }

    @Override
    public String getFragmentName() {
        return null;
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }
}