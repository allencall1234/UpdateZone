package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;
import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/*
* 这是精彩热文和今日必读界面界面
* */
public class ExcitingArticalActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private  SmoothListView                                   mSmoothListView;
    private List<FindCategaryBean>                           findCategaryBeans;
    private String                                           userid;
    private String                                           toBuyArticalaid;//记录要买文章的aid
    private String                                           toBuyArticalCoin;//记录要买文章的费用，以便更新本地保存的用户余额状态
    private MyListViewAdapter adapter;
    private YNPayDialog                                      buytDialog;
    private RelativeLayout mEmpty;
    private String mFlag;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.MARKET_INTERPRET_FLAG:

                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    JSONArray array = jsonObject.getJSONArray("data");
                                    Type      type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    findCategaryBeans = YNJsonUtil.JsonToLBean(array.toString(),
                                                                               type);
                                    adapter =new MyListViewAdapter(findCategaryBeans);
                                    mSmoothListView.setAdapter(adapter);
                                }
                            } catch (JSONException e) {
                                Toast.makeText(ExcitingArticalActivity.this, "发生一点小意外哦", Toast.LENGTH_SHORT)
                                     .show();
                                e.printStackTrace();
                            }
                        }else{
                            mEmpty.setVisibility(View.VISIBLE);
                        }

                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    break;
                case YNCommonConfig.ON_REFRESH:
                    //记得清空 防止出现重复视图
                    if (findCategaryBeans != null) {
                        findCategaryBeans.removeAll(findCategaryBeans);
                    }
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                mEmpty.setVisibility(View.GONE);
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    JSONArray array = jsonObject.getJSONArray("data");
                                    Type      type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    findCategaryBeans = YNJsonUtil.JsonToLBean(array.toString(),
                                                                               type);
                                    adapter =new MyListViewAdapter(findCategaryBeans);
                                    mSmoothListView.setAdapter(adapter);
                                }
                            } catch (JSONException e) {
                                Toast.makeText(ExcitingArticalActivity.this, "发生一点小意外哦", Toast.LENGTH_SHORT)
                                     .show();
                                e.printStackTrace();
                            }
                        }

                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    mSmoothListView.stopRefresh();
                    break;
                //购买文章
                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 102) {
                            //购买成功
                            Toast.makeText(ExcitingArticalActivity.this, "购买成功", Toast.LENGTH_SHORT)
                                 .show();
                            for (FindCategaryBean bean :findCategaryBeans)
                            {
                                if (toBuyArticalaid.equals(bean.getId()))
                                {
                                    bean.setIs_purchase(1);
                                    //刷新数据
                                    adapter.updataData(findCategaryBeans);
                                    //更新用户余额值
                                    UserInfoBean userInfoBean = AccountUtils.getAccountBean();
                                    userInfoBean.setCurrentCoin(userInfoBean.getCurrentCoin()-Integer.parseInt(toBuyArticalCoin));
                                    AccountUtils.saveAccountBean(userInfoBean);
                                    //跳转到文章详情页面
                                    Intent intent = new Intent(ExcitingArticalActivity.this, ArticalDetailsActivity.class);
                                    intent.putExtra("aid", toBuyArticalaid);
                                    startActivity(intent);
                                    break;
                                }
                            }
                        }
                    }else
                    {
                        YNToastMaster.showToast(ExcitingArticalActivity.this, "购买失败，再试试吧", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;
            }
            super.handleMessage(msg);
        }

    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exciting_artical);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        //跳转过来的标记
        mFlag = getIntent().getStringExtra(YNCommonConfig.Artical_EXCITING_FLAG);
        initView();
        addEvent();
    }


    @Override
    protected void initView() {

        if(mFlag.equals("exciting")){
            configTopBarCtrollerWithTitle("精选热文");
        }else if(mFlag.equals("mustReadToday")){
            configTopBarCtrollerWithTitle("今日必读");
        }

        mSmoothListView = (SmoothListView) findViewById(R.id.mListView);
        mSmoothListView.setDivider(null);
        mEmpty = (RelativeLayout) findViewById(R.id.empty);
        mSmoothListView.setLoadMoreEnable(false);
        if(AccountUtils.getLoginInfo()){
            userid=AccountUtils.getAccountBean().getId();
        }else{
            userid="";
        }
        netRequest();
    }

    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mSmoothListView.setSmoothListViewListener(this);
        mEmpty.setOnClickListener(this);
    }

    private void netRequest() {
        //判断是否有网络
        if(YNBaseActivity.isConnectNet) {
        if(mFlag.equals("exciting")){
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getExcitingArticalList(ExcitingArticalActivity.this,
                                                         YNCommonConfig.GET_EXCITING_ARTICAL_URL,
                                                         userid,
                                                         mHandler,
                                                         YNCommonConfig.MARKET_INTERPRET_FLAG,
                                                         true);
                }
            });
        }else if(mFlag.equals("mustReadToday")){
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMustReadTodaylList(ExcitingArticalActivity.this,
                                                         YNCommonConfig.GET_MUSTREAD_TODAY_URL,
                                                         userid,
                                                         mHandler,
                                                         YNCommonConfig.MARKET_INTERPRET_FLAG,
                                                         true);
                }
            });
        }
        }else{
            Toast.makeText(ExcitingArticalActivity.this, "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }
    @Override
    public void onRefresh() {
        //判断是否有网络
        if(YNBaseActivity.isConnectNet) {
        if(mFlag.equals("exciting")){
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getExcitingArticalList(ExcitingArticalActivity.this,
                                                         YNCommonConfig.GET_EXCITING_ARTICAL_URL,
                                                         userid,
                                                         mHandler,
                                                         YNCommonConfig.ON_REFRESH,
                                                         true);
                }
            });
        }else if(mFlag.equals("mustReadToday")){
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMustReadTodaylList(ExcitingArticalActivity.this,
                                                        YNCommonConfig.GET_MUSTREAD_TODAY_URL,
                                                        userid,
                                                        mHandler,
                                                        YNCommonConfig.ON_REFRESH,
                                                        true);
                }
            });
        }
        }else{
            Toast.makeText(ExcitingArticalActivity.this, "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onLoadMore() {


    }
    //点击事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.empty:
                onRefresh();
                break;

        }
    }

    class  MyListViewAdapter extends BaseAdapter {
        private List<FindCategaryBean> VoiceBeans;
        public MyListViewAdapter(List<FindCategaryBean> voiceBeans) {
            VoiceBeans = voiceBeans;
        }

        public void updataData( List<FindCategaryBean> data){
            this.VoiceBeans = data;
            notifyDataSetChanged();
        }
        @Override
        public int getCount() {
            if(VoiceBeans!=null){
                return VoiceBeans.size();
            }
            return 0;
        }

        @Override
        public FindCategaryBean getItem(int position) {
            if(VoiceBeans!=null){
                return VoiceBeans.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder =null;
            holder=new MyListViewAdapter.ViewHolder();
            if(convertView==null){
                convertView=View.inflate(ExcitingArticalActivity.this, R.layout.market_interpret_listview_item, null);
                holder.title= (TextView) convertView.findViewById(R.id.market_interpret_artical_title);
                holder.goldIv= (ImageView) convertView.findViewById(R.id.iv_gold);
                holder.coinNumb= (TextView) convertView.findViewById(R.id.to_buy_coin_numb);
                holder.tobuy= (TextView) convertView.findViewById(R.id.to_buy_tv);
                holder.content= (TextView) convertView.findViewById(R.id.market_interpret_artical_content);
                holder.multIv= (MultiImageView) convertView.findViewById(R.id.market_interpret_artical_iv);
                holder.authorName=(TextView) convertView.findViewById(R.id.market_interpret_author_name);
                holder.Publishtime=(TextView) convertView.findViewById(R.id.market_interpret_artical_time);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            final FindCategaryBean findCategaryBean = VoiceBeans.get(position);
            holder.title.setText(findCategaryBean.getTitle());
            holder.content.setText(findCategaryBean.getContent());
            holder.coinNumb.setText(findCategaryBean.getPayCoin());
            //判断是否显示购买
            if( (("0").equals(findCategaryBean.getPayCoin()))||findCategaryBean.getIs_purchase()==1) {
                holder.goldIv.setVisibility(View.GONE);
                holder.tobuy.setVisibility(View.GONE);
                holder.coinNumb.setVisibility(View.GONE);
            }else{
                holder.goldIv.setVisibility(View.VISIBLE);
                holder.tobuy.setVisibility(View.VISIBLE);
                holder.coinNumb.setVisibility(View.VISIBLE);
            }
            //先判断是否需要购买，已经购买了跳转到文章详情
            holder.content.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(findCategaryBean.getIs_pay().equals("0")||findCategaryBean.getIs_purchase()==1) {
                        Intent intent = new Intent(ExcitingArticalActivity.this, ArticalDetailsActivity.class);
                        intent.putExtra("aid", findCategaryBean.getId());
                        startActivity(intent);
                    }else {
                        //需要购买(购买之前请登录)
                        if(AccountUtils.getLoginInfo()){
                            //是自己的文章直接跳转
                            if(AccountUtils.getAccountBean().getId().equals(findCategaryBean.getUserid())){
                                Intent intent = new Intent(ExcitingArticalActivity.this, ArticalDetailsActivity.class);
                                intent.putExtra("aid", findCategaryBean.getId());
                                startActivity(intent);
                            }else{
                                showBuyDialog(findCategaryBean.getPayCoin(),findCategaryBean.getId());
                            }
                        }else{
                            Intent intent = new Intent(ExcitingArticalActivity.this, YNLoginActivity.class);
                            startActivity(intent);
                        }

                    }
                }
            });

            //购买文章
            holder.tobuy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //如果已经购买或者是免费的直接跳转
                    if(findCategaryBean.getIs_purchase()==1) {
                        Intent intent = new Intent(ExcitingArticalActivity.this, ArticalDetailsActivity.class);
                        intent.putExtra("aid", findCategaryBean.getId());
                        startActivity(intent);
                    }else {
                        //登录了才能判断
                        if(AccountUtils.getLoginInfo()){
                            //需要购买,如果是自己发表的文章那个就不需要支付了
                            if(AccountUtils.getAccountBean().getId().equals(findCategaryBean.getUserid())){
                                Intent intent = new Intent(ExcitingArticalActivity.this, ArticalDetailsActivity.class);
                                intent.putExtra("aid", findCategaryBean.getId());
                                startActivity(intent);
                            }else {
                                showBuyDialog(findCategaryBean.getPayCoin(),findCategaryBean.getId());
                            }

                        }else{
                            //跳转到登录界面
                            Intent intent = new Intent(ExcitingArticalActivity.this, YNLoginActivity.class);
                            startActivity(intent);
                        }


                    }
                }
            });
            //显示大图片
            if (findCategaryBean.getPicture() != null) {
                final List<PhotoInfoBean> photos = new ArrayList<>();

                for (int i = 0; i < findCategaryBean.getPicture()
                                                    .size(); i++) {
                    photos.add(new PhotoInfoBean(findCategaryBean.getPicture()
                                                                 .get(i)
                                                                 .getBig(),
                                                 findCategaryBean.getPicture()
                                                                 .get(i)
                                                                 .getSmall(),
                                                 320,
                                                 400));
                }
                holder.multIv.setVisibility(View.VISIBLE);
                holder.multIv.setList(photos);
                holder.multIv.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position)
                    {
                        //imagesize是作为loading时的图片size
                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(),
                                                                                                  view.getMeasuredHeight());
                        List<String> photoUrls = new ArrayList();
                        for (PhotoInfoBean photoInfo : photos) {
                            photoUrls.add(photoInfo.getBig());
                        }
                        ImagePagerActivity.startImagePagerActivity(ExcitingArticalActivity.this,
                                                                   photoUrls,
                                                                   position,
                                                                   imageSize);
                    }

                });
            }else{
                holder.multIv.setVisibility(View.GONE);
            }
            holder.authorName.setText(findCategaryBean.getUsername());
            holder.Publishtime.setText(timeStamp2StringSHort(findCategaryBean.getTime()));
            return convertView;
        }
        class ViewHolder{
            private TextView       title;
            private ImageView     goldIv;
            private TextView       coinNumb;
            private TextView       tobuy;
            private TextView       content;
            private MultiImageView multIv;
            private TextView       authorName;
            private TextView       Publishtime;
        }
    }

    public void showBuyDialog(final String payCoin, final String aid) {
        buytDialog = new YNPayDialog.Builder(ExcitingArticalActivity.this)
                .setHeight(0.3f)  //屏幕高度*0.3
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("此文章需要付费" + payCoin + "金币，是否付费阅读？")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }
                    //取消
                    @Override
                    public void clickBottomLeftButton(View view) {

                        buytDialog.dismiss();
                    }
                    //确定
                    @Override
                    public void clickBottomRightButton(View view) {
                        if (AccountUtils.getLoginInfo()) {
                            //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                            if (AccountUtils.getAccountBean()
                                            .getCurrentCoin() > Integer.parseInt(payCoin))
                            {

                                toBuyArticalaid = aid;
                                toBuyArticalCoin=payCoin;
                                mHandler.post(new Runnable() {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance()
                                                     .buyArticle(ExcitingArticalActivity.this,
                                                                 YNCommonConfig.BUY_ARTICLE_URL,
                                                                 aid,
                                                                 AccountUtils.getAccountBean().getId(),
                                                                 Integer.parseInt(payCoin),
                                                                 mHandler,
                                                                 YNCommonConfig.BUY_ARTICLE_FLAG,
                                                                 true);
                                    }
                                });

                            } else {
                                Toast.makeText(ExcitingArticalActivity.this, "余额不足，请先充值再购买哦", Toast.LENGTH_SHORT)
                                     .show();
                            }
                        }else {
                            Intent intent = new Intent(ExcitingArticalActivity.this, YNLoginActivity.class);
                            mContext.startActivity(intent);

                        }
                        buytDialog.dismiss();
                    }
                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        buytDialog.show();

    }

}

