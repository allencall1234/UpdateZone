package com.yeneikeji.ynzhibo.model;

import java.util.List;

public class UserWealthBean {

    public int code;
    public DataBean data;
    public String   data1;
    public String   data2;
    public String   info;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getData1() {
        return data1;
    }

    public void setData1(String data1) {
        this.data1 = data1;
    }

    public String getData2() {
        return data2;
    }

    public void setData2(String data2) {
        this.data2 = data2;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public static class DataBean {

        public int currentsum;
        public int                sum;
        public List<YeIncomeBean> yeIncome;

        public int getCurrentsum() {
            return currentsum;
        }

        public void setCurrentsum(int currentsum) {
            this.currentsum = currentsum;
        }

        public int getSum() {
            return sum;
        }

        public void setSum(int sum) {
            this.sum = sum;
        }

        public List<YeIncomeBean> getYeIncome() {
            return yeIncome;
        }

        public void setYeIncome(List<YeIncomeBean> yeIncome) {
            this.yeIncome = yeIncome;
        }

        public static class YeIncomeBean {

            public int sum;
            public int                year;
            public List<MoIncomeBean> moIncome;

            public int getSum() {
                return sum;
            }

            public void setSum(int sum) {
                this.sum = sum;
            }

            public int getYear() {
                return year;
            }

            public void setYear(int year) {
                this.year = year;
            }

            public List<MoIncomeBean> getMoIncome() {
                return moIncome;
            }

            public void setMoIncome(List<MoIncomeBean> moIncome) {
                this.moIncome = moIncome;
            }

            public static class MoIncomeBean {

                public int month;
                public int sum;

                public int getMonth() {
                    return month;
                }

                public void setMonth(int month) {
                    this.month = month;
                }

                public int getSum() {
                    return sum;
                }

                public void setSum(int sum) {
                    this.sum = sum;
                }
            }
        }
    }
}
