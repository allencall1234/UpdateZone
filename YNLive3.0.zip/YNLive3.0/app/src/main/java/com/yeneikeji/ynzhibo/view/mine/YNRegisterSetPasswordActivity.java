package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.InputType;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 用户注册后设置密码界面
 */
public class YNRegisterSetPasswordActivity extends YNBaseTopBarActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener
{
    private EditText edtPassword;
    private int time = 60;
    private final int REGISTER_RESULT = 4;

    private final int REGISTER_TO_LOGIN = 5;

    private TextView txtVerificationCode;
    private CheckBox chbEye;
    private TextView txtFinish;
    private TextView txtVerificationCodeError;
    private TextView txtCountdown;
    private EditText edtVerificationCode;
//    private EditText mETUserName;
    private LinearLayout llProtocol;
    private String userPhone;
    private String randomNumber;
    private String resultCode;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.CODE_ING:
                    txtCountdown.setClickable(false);
                    txtCountdown.setText(time + "秒");
                    time--;
                    break;

                case YNCommonConfig.CODE_REPEAT:
                    txtCountdown.setText("重新发送");
                    txtCountdown.setClickable(true);
                    break;

                case YNCommonConfig.USER_REGISTER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, baseBean.getInfo());
                        if (baseBean.getCode() == 2)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                UserInfoBean infoBean = YNJsonUtil.JsonToBean(object.getString("data"), UserInfoBean.class);
                                // 将登陆成功后返回的用户信息类保存
                                AccountUtils.saveAccountBean(infoBean);
                                // 设置状态为登陆状态，保存标志位
                                AccountUtils.saveLogin(true);
//                                Intent intent = new Intent(YNRegisterSetPassword.this, YNMainTabActivity.class);
//                                intent.setAction("Login");
//                                startActivity(intent);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;

                case YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG:
                    if (msg.obj != null)
                    {
                        resultCode = msg.obj.toString();
                        if ("1".equals(resultCode))
                        {
                            txtVerificationCode.setVisibility(View.VISIBLE);
                            txtVerificationCode.setText("验证码已发送至" + userPhone);
                        }
                        else
                        {
                            YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, "验证码发送失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, "验证码发送失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ynregister_set_password);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }


    @Override
    protected void initView()
    {
        userPhone = getIntent().getStringExtra(YNCommonConfig.PHONE_NUMBER);
        configTopBarCtrollerWithTitle("设置密码");

        txtVerificationCode = (TextView) findViewById(R.id.txtVerificationCode);
        chbEye = (CheckBox) findViewById(R.id.chbEye);
        txtFinish = (TextView) findViewById(R.id.txtFinish);
        txtVerificationCodeError = (TextView) findViewById(R.id.txtVerificationCodeError);
        txtCountdown = (TextView) findViewById(R.id.txtCountdown);
        edtVerificationCode = (EditText) findViewById(R.id.edtVerificationCode);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
//        mETUserName = (EditText) findViewById(R.id.et_user_name);

//        Intent intent = getIntent();
//        if (intent.getAction() == "num")
//        {
//            Bundle bundle = intent.getExtras();
//            String str = bundle.getString("num");
//            userPhone = str;
//            txtVerificationCode.setText("验证码已发送至" + str);
//            txtVerificationCode.setText(YNCommonUtils.hidePhoneCenterNumber(txtVerificationCode.getText().toString()));
//            StartCountTime();
//        }

        llProtocol = (LinearLayout) findViewById(R.id.llProtocol);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        chbEye.setOnCheckedChangeListener(this);

        edtPassword.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                String code = edtVerificationCode.getText().toString();
                String passWord = edtPassword.getText().toString();
                if (TextUtils.isEmpty(code) || TextUtils.isEmpty(passWord))
                {
                    txtVerificationCodeError.setVisibility(View.VISIBLE);
                    txtVerificationCodeError.setText("密码或验证码为空");
                    txtFinish.setBackgroundResource(R.drawable.btn_next_unclick);
                }
                else
                {
                    txtVerificationCodeError.setVisibility(View.GONE);
                    txtFinish.setBackgroundResource(R.drawable.btn_login_selector);
                }
            }
        });

        txtFinish.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // 获取短信验证码
                final String code = edtVerificationCode.getText().toString();
                // 获取密码
                final String passWord = edtPassword.getText().toString();
//                final String userAccount = mETUserName.getText().toString();
                if (TextUtils.isEmpty(code))
                {
                    YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, "请输入验证码");
                    return;
                }
                if (!randomNumber.equals(code))
                {
                    YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, "验证码不匹配");
                    return;
                }
//                if (TextUtils.isEmpty(userAccount))
//                {
//                    YNToastMaster.showToast(YNRegisterSetPasswordActivity.this, "用户名不能为空");
//                    return;
//                }
                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userRegister(YNRegisterSetPasswordActivity.this, YNCommonConfig.USER_REGISTER_URL, userPhone, passWord, "", YNApplication.deviceId, handler, YNCommonConfig.USER_REGISTER_FLAG, false);
                    }
                }, 1000);
            }
        });

        txtCountdown.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                randomNumber = YNCommonUtils.getRandomSixNumber();
                // 获取验证码
                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userGetWebChineseSMSCode(YNRegisterSetPasswordActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, userPhone, "验证码:" + randomNumber + "，你正在进行注册业内直播账号的手机号，此验证码10分钟内有效", handler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                    }
                }, 500);
//                SMSSDK.getVerificationCode("86", String.valueOf(phoneNum));
                txtCountdown.setClickable(false);
                time = 60;
                StartCountTime();
            }
        });


        llProtocol.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(getApplicationContext(), AgreementActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void settingDo() {

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken()
                        ,InputMethodManager.HIDE_NOT_ALWAYS);
                finish();
                break;

        }
    }

    private void StartCountTime() {
        new Thread() {
            @Override
            public void run() {

                super.run();
                for (int i = 60; i > 0; i--)
                {
                    handler.sendEmptyMessage(YNCommonConfig.CODE_ING);
                    if (i <= 0)
                    {
                        break;
                    }
                    try
                    {
                        Thread.sleep(1000);
                        handler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
    {
        if (isChecked)
        {
            // 显示为普通文本
            edtPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            // 使光标始终在最后位置
            Editable etable = edtPassword.getText();
            Selection.setSelection(etable, etable.length());
        }
        else
        {
            // 显示为密码
            edtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            // 使光标始终在最后位置
            Editable etable = edtPassword.getText();
            Selection.setSelection(etable, etable.length());
        }
    }

}
