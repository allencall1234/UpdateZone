package com.yeneikeji.ynzhibo.fragment;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewHolder;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;
import com.yeneikeji.ynzhibo.model.YNLiveCategrayBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.BadgeView;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.ContributionChartsActivity;
import com.yeneikeji.ynzhibo.view.mine.MyContributionActivity;
import com.yeneikeji.ynzhibo.view.mine.MyIncomeActivity;
import com.yeneikeji.ynzhibo.view.mine.YNAllMsgActivity;
import com.yeneikeji.ynzhibo.view.mine.YNCameraActivity;
import com.yeneikeji.ynzhibo.view.mine.YNGoldCoinActivity;
import com.yeneikeji.ynzhibo.view.mine.YNHeartFansActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.view.mine.YNPersonalActivity;
import com.yeneikeji.ynzhibo.view.mine.YNRealNameActivity;
import com.yeneikeji.ynzhibo.view.mine.YNRecordActivity;
import com.yeneikeji.ynzhibo.view.mine.YNSettingActivity;
import com.yeneikeji.ynzhibo.view.mine.multichannel.RowsWheatActivity;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.TranslucentScrollView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.umeng.socialize.utils.DeviceConfig.context;

/**
 * 我的界面
 * Created by Administrator on 2016/8/16.
 */
public class MineFragment
        extends YNBaseFragment
        implements View.OnClickListener
{
    public static final String TAG = "MineFragment";

    //    private PullToRefreshLayout mRefreshView;
    private TranslucentScrollView mScrollView;
    private TextView           mTVGoldCcoin;
    private ImageView          mIVEditInfo;
    private TextView           mTVUserId;
    private RelativeLayout     rlUnLogin, rlLogin, rlContributionCharts, rlMyIncome, rlMessage, rlSetting, rlCamera, rlHeart, rlRecord, rlGoldCoin;
    //    private RelativeLayout mRlMySubscrible;
    private TextView          mTVMsgCount;
    private YNCircleImageView imgAvatar;
    private TextView          txtTel;

    private TextView       txtMyIncome;// 金币收益
    private View           lineView;
    private TextView       txtMsg;// 新消息
    private TextView       txtDescribe;// 简介描述
    private TextView       txtNickName;// 昵称
    private LinearLayout   llInfo;
    private RelativeLayout rlGold;

    private RecyclerView mRecyclerView;
    private List<String> headImgList = new ArrayList();
    private CommonRecyclerViewAdapter<String> mAdapter;
    private boolean        isLogin      = false;
    // 本地用户信息
    private PersonInfoBean localBean    = null;
    private UserInfoBean   userInfoBean = null;
    private RelativeLayout mMyContribution;
    private List<ChatRoomUserBean>   TopcontributionList = new ArrayList<>();
    private List<YNLiveCategrayBean> mTypeBeen           = new ArrayList();
    private List<YNLiveCategrayBean> mClumBeen           = new ArrayList();

    public static boolean isForeground = false;
    //for receive customer msg from jpush server
    private MessageReceiver mMsgCountReceiver;
    public static final String MESSAGE_RECEIVED_ACTION = "MESSAGE_COUNT_RECEIVED_ACTION";
    private BadgeView         mBadgeView;
    private String            mUserId;
    private List<MessageBean> mMessageList;
    private int               noReadCount;

    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_USER_STATUS_FLAG:
                    if (msg.obj != null) {

                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 36) {
                            YNLogUtil.e("cdy111", msg.obj.toString());
                            try {
                                JSONObject     jsonObject     = new JSONObject(msg.obj.toString());
                                UserStatusBean userStatusBean = YNJsonUtil.JsonToBean(jsonObject.getString(
                                        "data"), UserStatusBean.class);
                                userInfoBean = YNJsonUtil.JsonToBean(jsonObject.getString("data"),
                                                                     UserInfoBean.class);
                                AccountUtils.saveUserStatus(userStatusBean);
                                AccountUtils.saveAccountBean(userInfoBean);

                                Intent intent = new Intent();
                                switch (Integer.parseInt(userStatusBean.getCheck_status())) {
                                    // 通过审核
                                    case 0:
                                        List<YNLiveCategrayBean> mTypeBeens = null;
                                        List<YNLiveCategrayBean> mClumBeens = null;

                                        Type type = new TypeToken<List<YNLiveCategrayBean>>() {}.getType();
                                        JSONArray tagArray = jsonObject.optJSONObject("data1")
                                                .optJSONArray("tag");

                                        JSONArray clumArray = jsonObject.getJSONObject("data1")
                                                .optJSONArray("type");

                                        if (tagArray != null)
                                        {
                                            mTypeBeens = YNJsonUtil.JsonToLBean(tagArray.toString(), type);
                                        }

                                        if (clumArray != null)
                                        {
                                            mClumBeens = YNJsonUtil.JsonToLBean(clumArray.toString(), type);
                                        }

                                        intent.putExtra("dataList1", (Serializable) mTypeBeens);
                                        intent.putExtra("dataList2", (Serializable) mClumBeens);
                                        if (userStatusBean.getPid().length() <= 1)
                                        {
                                            intent.setClass(getActivity(), YNCameraActivity.class);
                                        }
                                        else
                                        {
                                            // 判断是否进入多通道(pid截取后字符串等于0是主房间的管理人员，否则是子房间的房主)
                                            if ("0".equals(YNCommonUtils.interceptionMultichannelRoomPID(userStatusBean.getPid())))
                                                intent.setClass(getActivity(), RowsWheatActivity.class);
                                            else
                                                intent.setClass(getActivity(), YNCameraActivity.class);
                                        }
                                        startActivity(intent);
                                        break;

                                    // 未审核
                                    case 1:
                                        YNToastMaster.showToast(mContext, "认证未审核，请耐心等待");
                                        break;

                                    // 未通过
                                    case 2:
                                        YNToastMaster.showToast(mContext, "认证未通过, 请重新上传资料");
                                        intent.setClass(getActivity(), YNRealNameActivity.class);
                                        startActivity(intent);
                                        break;

                                    //  未认证
                                    case 3:
                                        YNToastMaster.showToast(mContext, "还未认证，请上传资料");
                                        if (TextUtils.isEmpty(AccountUtils.getLocalPerson().getDescribe()))
                                        {
                                            YNToastMaster.showToast(mContext, "快去完善你的个人资料吧");
                                        }
                                        else
                                        {
                                            intent.setClass(getActivity(), YNRealNameActivity.class);
                                            startActivity(intent);
                                        }
//                                        intent.setClass(getActivity(), AgreementActivity.class);
//                                        startActivity(intent);
                                        break;
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        //                        YNToastMaster.showToast(mContext, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                    if (msg.obj != null) {
                        //                        mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject  = new JSONObject(msg.obj.toString());
                                float        currentCoin = Float.parseFloat(jsonObject.optString(
                                        "data"));
                                mTVGoldCcoin.setText("金币：" + currentCoin);
                                AccountUtils.getAccountBean()
                                            .setCurrentCoin(currentCoin);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            //                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                        }
                    } else {
                        //                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                        YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    break;

                //排行榜前三用户头像
                case YNCommonConfig.GET_MEFRAGMENT_CONTRIBUTION_VALUE_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array      = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                                    TopcontributionList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    //添加完数据再设置adapter
                                    if(TopcontributionList.size()>=3) {
                                        for (int i = 0; i < 3; i++) {
                                            headImgList.add(TopcontributionList.get(i)
                                                                               .getIcon());
                                        }
                                    }else if(TopcontributionList!=null&&TopcontributionList.size()>0){
                                        for (int i = 0; i < TopcontributionList.size(); i++) {
                                            headImgList.add(TopcontributionList.get(i)
                                                                               .getIcon());
                                        }
                                    }
                                    mAdapter.updateListView(headImgList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {

                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject  = new JSONObject(msg.obj.toString());
                                float        currentCoin = Float.parseFloat(jsonObject.optString(
                                        "data"));
                                mTVGoldCcoin.setText("金币 : " + currentCoin);
                                AccountUtils.getAccountBean()
                                            .setCurrentCoin(currentCoin);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;
                case YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG:
                    if (msg.obj != null) {
                        //                        YNLogUtil.e(TAG, " msg.obj  MESSAGE---->" + msg.obj);
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  jsonArray  = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<MessageBean>>() {}.getType();
                                mMessageList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                getNoReadData();
                                YNLogUtil.e(TAG, "noReadCount------> " + noReadCount);
                                mBadgeView.setBadgeCount(noReadCount);
                                if(noReadCount == 0){
                                    mBadgeView.setVisibility(View.GONE);
                                }else{
                                    mBadgeView.setVisibility(View.VISIBLE);
                                }
                                if (noReadCount >= 100) {
                                    mBadgeView.setText("99+");
                                }
                                mBadgeView.setGravity(Gravity.CENTER_VERTICAL);
                                mBadgeView.setBackground(12, Color.parseColor("#ff0000"));
                                mBadgeView.setTargetView(txtMsg);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;

            }
        }
    };

    private void initMessageData() {
        if (YNBaseActivity.isConnectNet) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMySystemMsg(context,
                                                 YNCommonConfig.MY_SYSTEM_MESSAGE_URL,
                                                 mUserId,
                                                 handler,
                                                 YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG,
                                                 false);
                }
            }, 0);


        }
    }

    private void getNoReadData() {
        noReadCount = 0;
        if (mMessageList != null && mMessageList.size() > 0) {
            for (int i = 0; i < mMessageList.size(); i++) {
                if (mMessageList.get(i)
                                .getIs_read()
                                .equals(YNCommonConfig.IS_NO_READ))
                {
                    noReadCount++;
                }
            }
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.fragment_mine, container, false);
        // AutoUtils.auto(rootView);
        initView(rootView);
        initFragment();
        return rootView;
    }

    @Override
    public void onResume()
    {
        initMessageData();
        registerMessageReceiver();  // used for receive msg
        if (NetUtils.isConnected(mContext)) {
            if (AccountUtils.getLoginInfo()) {
                loginRefreshUI();
            }else{
                unLoginRefreshUI();
            }
        }
        isForeground = true;
        super.onResume();
    }

    @Override
    public void onPause()
    {
        this.getActivity()
            .unregisterReceiver(mMsgCountReceiver);
        isForeground = false;
        super.onPause();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
    }

    @Override

    protected void initView(View view)
    {
        mScrollView = (TranslucentScrollView) view.findViewById(R.id.personal_scrollView);
        //        mRefreshView = (PullToRefreshLayout) view.findViewById(R.id.refresh_view);
        rlUnLogin = (RelativeLayout) view.findViewById(R.id.rlUnLogin);
        rlLogin = (RelativeLayout) view.findViewById(R.id.rlLogin);

        imgAvatar = (YNCircleImageView) view.findViewById(R.id.imgAvatar);
        rlContributionCharts = (RelativeLayout) view.findViewById(R.id.rlContributionCharts);
        rlMyIncome = (RelativeLayout) view.findViewById(R.id.rlMyIncome);
        rlMessage = (RelativeLayout) view.findViewById(R.id.rlMessage);
        //        rlSuggestion = (RelativeLayout) view.findViewById(R.id.rlSuggestion);
        rlSetting = (RelativeLayout) view.findViewById(R.id.rlSetting);
        txtTel = (TextView) view.findViewById(R.id.txtTel);
        rlCamera = (RelativeLayout) view.findViewById(R.id.rlCamera);
        rlHeart = (RelativeLayout) view.findViewById(R.id.rlHeart);
        rlRecord = (RelativeLayout) view.findViewById(R.id.rlRecord);
        rlGoldCoin = (RelativeLayout) view.findViewById(R.id.rlGoldCoin);
        llInfo = (LinearLayout) view.findViewById(R.id.llInfo);
        rlGold = (RelativeLayout) view.findViewById(R.id.rlGold);
        mIVEditInfo = (ImageView) view.findViewById(R.id.imgEdit);
        //txtMyIncome = (TextView) view.findViewById(R.id.tv_my_income);
        mMyContribution = (RelativeLayout) view.findViewById(R.id.rlMyContribution);
        //订阅
        //        mRlMySubscrible = (RelativeLayout) view.findViewById(R.id.rl_subscribe);
        lineView = view.findViewById(R.id.line2);
        txtMsg = (TextView) view.findViewById(R.id.tv_msg);
        txtDescribe = (TextView) view.findViewById(R.id.txtDescribe);
        txtNickName = (TextView) view.findViewById(R.id.txtNickName);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycle_view);
        mTVGoldCcoin = (TextView) view.findViewById(R.id.tv_gold_coin);
        mTVUserId = (TextView) view.findViewById(R.id.tv_user_id);
       // mScrollView.setPullZoomView(rlUnLogin);

        //mScrollView.fullScroll(ScrollView.FOCUS_DOWN); // 滚动到底部
        //        mScrollView.scrollTo(0, 0);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mRecyclerView.setLayoutManager(layoutManager);

        mBadgeView = new BadgeView(getActivity());

        //        localBean = AccountUtils.getLocalPerson();
        //        userInfoBean = AccountUtils.getAccountBean();
    }

    //请求总榜的数据
    private void loadData()
    {
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getContributionValueList(getActivity(),
                                                       YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL,
                                                       AccountUtils.getAccountBean()
                                                                   .getId(),
                                                       1,
                                                       handler,
                                                       YNCommonConfig.GET_MEFRAGMENT_CONTRIBUTION_VALUE_LIST_FLAG,
                                                       false);
            }
        });
    }

    @Override
    protected void addEvents()
    {
        /*mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                if (AccountUtils.getLoginInfo())
                {
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getCurrentGoldCoin(mContext, YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, AccountUtils.getAccountBean().getId(), handler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);
                        }
                    });
                }
                else
                {
                    mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                }
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });*/

        rlUnLogin.setOnClickListener(this);
        mTVGoldCcoin.setOnClickListener(this);
        imgAvatar.setOnClickListener(this);
        rlCamera.setOnClickListener(this);
        rlHeart.setOnClickListener(this);
        rlRecord.setOnClickListener(this);
        rlGoldCoin.setOnClickListener(this);
        rlMessage.setOnClickListener(this);
        rlContributionCharts.setOnClickListener(this);
        rlMyIncome.setOnClickListener(this);
        mMyContribution.setOnClickListener(this);
        //        rlSuggestion.setOnClickListener(this);
        rlSetting.setOnClickListener(this);
        txtTel.setOnClickListener(this);
        txtDescribe.setOnClickListener(this);
        llInfo.setOnClickListener(this);
        //        rlGold.setOnClickListener(this);
        mIVEditInfo.setOnClickListener(this);
        mRecyclerView.setOnClickListener(this);
        //        //订阅
        //        mRlMySubscrible.setOnClickListener(this);

    }

    protected void settingDo()
    {
        if (AccountUtils.getLoginInfo()) {
            mUserId = AccountUtils.getAccountBean().getId();
            if (AccountUtils.getAccountBean()
                            .getUser_status() == 0)

            { loadData(); }
        }

        mAdapter = new CommonRecyclerViewAdapter<String>(mContext,
                                                         headImgList,
                                                         R.layout.contribution_charts_recyclerview_item)
        {
            @Override
            public void convert(CommonRecyclerViewHolder holder, String data, int position)
            {
                if (data.length() > 1) { holder.setImage(mContext, R.id.iv_head, data); } else {
                    holder.setImageResource(R.id.iv_head, R.drawable.safa);
                }
            }
        };

        mAdapter.setOnItemClickListener(new CommonRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void OnItemClickListener(View view, int position)
            {
                if (YNBaseActivity.isConnectNet) {
                    Intent intent = new Intent();
                    if (isLogin) {
                        intent.setClass(getActivity(), ContributionChartsActivity.class);
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                    }
                    startActivity(intent);
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
            }
        });

        mRecyclerView.setAdapter(mAdapter);

    }

    private void callPhone() {
        new AlertDialog.Builder(getContext()).setTitle("拨打电话")
                                             .setMessage("0755-25184613")
                                             .setPositiveButton("拨打",
                                                                new DialogInterface.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(
                                                                            DialogInterface dialogInterface,
                                                                            int i)
                                                                    {
                                                                        Intent intent = new Intent(
                                                                                Intent.ACTION_CALL,
                                                                                Uri.parse("tel:" + "0755-25184613"));
                                                                        startActivity(intent);

                                                                    }
                                                                })
                                             .setNegativeButton("取消",
                                                                new DialogInterface.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(
                                                                            DialogInterface dialogInterface,
                                                                            int i)
                                                                    {
                                                                        dialogInterface.dismiss();
                                                                    }
                                                                })
                                             .create()
                                             .show();
    }

   /*排行榜没有用户的时候添加三张本地的图片作为用户默认头像*/
/*    private List<String> getHeadImgList()
    {
      *//*  headImgList.add(""+new Integer(R.drawable.safa));
        headImgList.add(""+new Integer(R.drawable.safa));
        headImgList.add(""+new Integer(R.drawable.safa));*//*
        return  headImgList;
    }*/

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.rlUnLogin:
                intent.setClass(getActivity(), YNLoginActivity.class);
                startActivity(intent);
                break;

            case R.id.imgEdit:
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo())
                    {
                        intent.setClass(getActivity(), YNPersonalActivity.class);
                    }
                    else
                    {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                    }
                    startActivity(intent);
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

/*            case R.id.imgAvatar:
                intent.setClass(getActivity(), YNPersonalActivity.class);
                startActivity(intent);
                break;

            case R.id.llInfo:
                intent.setClass(getActivity(), YNPersonalActivity.class);
                startActivity(intent);
                break;*/

            /****跳转到金币充值界面****/
            case R.id.rlGoldCoin:
            case R.id.tv_gold_coin:
                if (YNBaseActivity.isConnectNet) {
                    if (AccountUtils.getLoginInfo()) {
                        intent = new Intent(getActivity(), YNGoldCoinActivity.class);
                        startActivity(intent);
                    } else {
                        intent = new Intent(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            case R.id.rlCamera:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        checkUserStatus();
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            case R.id.rlHeart:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        intent.setClass(getActivity(), YNHeartFansActivity.class);
                        startActivity(intent);
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            case R.id.rlRecord:
                intent.setClass(getActivity(), YNRecordActivity.class);
                startActivity(intent);
                //                  if (YNBaseActivity.isConnectNet)
                //                  {
                //                      if(isLogin)
                //                      {
                //                           intent.setClass(getActivity(), YNRecordActivity.class);
                //                           startActivity(intent);
                //                      }
                //                      else
                //                      {
                //                           intent.setClass(getActivity(), YNLoginActivity.class);
                //                           startActivity(intent);
                //                      }
                //                  }
                //                  else
                //                  {
                //                      YNToastMaster.showToast(mContext, "网络未连接");
                //                  }
                break;

            //            case R.id.rlGoldCoin:
            //                if(isLogin)
            //                {
            //                    intent.setClass(getActivity(), YNGoldCoinActivity.class);
            //                    startActivity(intent);
            //                }
            //                else
            //                {
            //                    intent.setClass(getActivity(), YNLoginActivity.class);
            //                    startActivity(intent);
            //                }
            //                break;

            case R.id.rlContributionCharts:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        intent.setClass(getActivity(), ContributionChartsActivity.class);
                        startActivity(intent);
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            case R.id.rlMyIncome:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        intent.setClass(getActivity(), MyIncomeActivity.class);
                        startActivity(intent);
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            case R.id.rlMyContribution:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        intent.setClass(getActivity(), MyContributionActivity.class);
                        startActivity(intent);
                    } else {
                        intent = new Intent(getContext(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;

            //跳转到订阅
          /*  case R.id.rl_subscribe:
                if (YNBaseActivity.isConnectNet)
                {
                    if(isLogin)
                    {
                        intent = new Intent(getContext(), MySubscribleActivity.class);
                        startActivity(intent);
                    }
                    else
                    {
                        intent = new Intent(getContext(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
            break;*/

            case R.id.rlMessage:
                if (YNBaseActivity.isConnectNet) {
                    if (isLogin) {
                        intent.setClass(getActivity(), YNAllMsgActivity.class);
                        startActivity(intent);
                    } else {
                        intent.setClass(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
                break;
            case R.id.rlSetting:
                intent.setClass(getActivity(), YNSettingActivity.class);
                startActivity(intent);
                break;

            case R.id.txtTel:
                if (Build.VERSION.SDK_INT >= 23) {
                    int checkCallPhonePermission = getActivity().checkSelfPermission(Manifest.permission.CALL_PHONE);
                    if (checkCallPhonePermission != PackageManager.PERMISSION_GRANTED) {
                        getActivity().requestPermissions(new String[]{Manifest.permission.CALL_PHONE},
                                                         123);
                        callPhone();
                        return;
                    } else {
                        callPhone();
                    }
                } else {
                    callPhone();
                }
                break;
        }
    }

    @Override
    public void loginRefreshUI()
    {

        userInfoBean = AccountUtils.getAccountBean();
        localBean = AccountUtils.getLocalPerson();
        isLogin = true;
        rlUnLogin.setVisibility(View.GONE);
        rlLogin.setVisibility(View.VISIBLE);
        rlGold.setVisibility(View.VISIBLE);
        mScrollView.setPullZoomView(rlLogin);
        if (AccountUtils.getAccountBean()
                        .getUser_status() == 0)
        {
            rlContributionCharts.setVisibility(View.VISIBLE);
            rlMyIncome.setVisibility(View.VISIBLE);
            lineView.setVisibility(View.VISIBLE);
        } else {
            rlContributionCharts.setVisibility(View.GONE);
            rlMyIncome.setVisibility(View.GONE);
            lineView.setVisibility(View.GONE);
        }
        if (localBean != null) {
            //            mTVGoldCcoin.setText("金币：" + AccountUtils.getAccountBean().getCurrentCoin());
            mTVUserId.setText("ID：" + Integer.parseInt(AccountUtils.getAccountBean()
                                                                            .getId()));
//            YNImageLoaderUtil.loadImageViewLodingSize(getContext(), localBean.getIcon(), 50, 50, imgAvatar, R.drawable.hand_none);
            YNImageLoaderUtil.setImage(getContext(), imgAvatar, localBean.getIcon());
            txtNickName.setText(localBean.getUsername());
            if (localBean.getDescribe().isEmpty())
                txtDescribe.setText("你太懒了,还没有编辑个人资料哦");
            else
                txtDescribe.setText(localBean.getDescribe());
            //            txtMyIncome.setText(AccountUtils.getAccountBean().getIncomeCoin() + "");
        }else{
            localBean = AccountUtils.getLocalPerson();
        }


        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                        .getCurrentGoldCoin(mContext,
                                YNCommonConfig.GET_CURRENT_GOLD_COIN_URL,
                                AccountUtils.getAccountBean()
                                        .getId(),
                                handler,
                                YNCommonConfig.ON_REFRESH,
                                false);
            }
        });

    }

    @Override
    public void unLoginRefreshUI()
    {
        isLogin = false;
        rlUnLogin.setVisibility(View.VISIBLE);
        rlLogin.setVisibility(View.GONE);
        rlGold.setVisibility(View.GONE);
        rlContributionCharts.setVisibility(View.GONE);
        rlMyIncome.setVisibility(View.GONE);
        lineView.setVisibility(View.GONE);
    }

    private void checkUserStatus()
    {
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getUserStatus(mContext,
                                            YNCommonConfig.GET_USER_STATU_URL,
                                            AccountUtils.getAccountBean()
                                                        .getId(),
                                            handler,
                                            YNCommonConfig.GET_USER_STATUS_FLAG,
                                            true);
            }
        });

    }

    private void registerMessageReceiver()
    {
        mMsgCountReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(MESSAGE_RECEIVED_ACTION);
        this.getActivity()
            .registerReceiver(mMsgCountReceiver, filter);
    }

    private class MessageReceiver
            extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction())) {


            }
        }
    }

}
