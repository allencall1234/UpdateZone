//package com.yeneikeji.ynzhibo.utils;
//
//import com.lsjwzh.widget.materialloadingprogressbar.CircleProgressBar;
//
///**
// * Created by 张琛 on 2016/8/6.
// */
//
//
//    /*  CircleProgressBar控件属性说明
//
//        mlpb_inner_radius  设置内圆(即进度条的圆环半径)半径
//
//        mlpb_background_color  整个控件的背景色
//
//        mlpb_progress_color  内圆边框颜色
//
//        mlpb_progress_stoke_width  内圆的边框宽度
//
//        mlpb_show_arrow  内圆上是否带箭头，true或false
//
//        mlpb_enable_circle_background  是否显示背景，true或false
//
//        mlpb_arrow_width  箭头的宽度
//
//        mlpb_arrow_height 箭头的高度
//
//
//        mlpb_progress  当前进度值
//
//        mlpb_max  最大进度值
//
//
//        mlpb_progress_text_size  进度值文字的大小
//
//        mlpb_progress_text_color  进度值文字颜色
//
//
//        mlpb_progress_text_visibility : 是否显示进度值文字,默认不显示，visible或invisible  。如：30%
//
//*/
//
//public class LoadingUtils {
//
//    private static CircleProgressBar circleProgressBar;
//
//    public void setCircleProgressBar(CircleProgressBar circleProgressBar) {
//
//        this.circleProgressBar = circleProgressBar;
//    }
//
//    /**
//     * 给进度条设置进度
//     * @param progress 进度值
//     */
//    public static void setProgress(int progress){
//
//        circleProgressBar.setProgress(progress);
//
//    }
//
//}
//
