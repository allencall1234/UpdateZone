package com.yeneikeji.ynzhibo.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 数据库处理工具类
 * Created by Administrator on 2016/8/8.
 */
public class YNDBUtil
{
    private static YNDBUtil mInstance;
    private Context mContext;
    private YNSQLHelper mYNSQLHelp;
    private SQLiteDatabase mSQLiteDatabase;

    private YNDBUtil(Context context)
    {
        this.mContext = context;
        mYNSQLHelp = new YNSQLHelper(context);
        mSQLiteDatabase = mYNSQLHelp.getWritableDatabase();
    }

    /**
     * 初始化数据库操作YNDBUtil
     * @param context
     * @return
     */
    public static YNDBUtil getInstance(Context context)
    {
        if (mInstance == null)
        {
            mInstance = new YNDBUtil(context);
        }
        return mInstance;
    }

    /**
     * 操作完成后关闭数据库
     */
    public void close()
    {
        mYNSQLHelp.close();
        mYNSQLHelp = null;
        mSQLiteDatabase.close();
        mSQLiteDatabase = null;
        mInstance = null;
    }

    /**
     * 添加数据
     * @param values
     */
    public void insertData(ContentValues values)
    {
        mSQLiteDatabase.insert(YNSQLHelper.TABLE_CHANNEL, null, values);
    }

    /**
     * 修改数据
     * @param values
     * @param whereClause
     * @param whereArgs
     */
    public void updateData(ContentValues values, String whereClause, String[] whereArgs)
    {
        mSQLiteDatabase.update(YNSQLHelper.TABLE_CHANNEL, values, whereClause, whereArgs);
    }

    /**
     * 删除数据
     * @param whereClause
     * @param whereArgs
     */
    public void deleteData(String whereClause, String[] whereArgs)
    {
        mSQLiteDatabase.delete(YNSQLHelper.TABLE_CHANNEL, whereClause, whereArgs);
    }

    /**
     * 查询数据
     * @param columns
     * @param selection
     * @param selectionArgs
     * @param groupBy
     * @param having
     * @param orderBy
     * @return
     */
    public Cursor queryDate(String[] columns, String selection, String[] selectionArgs, String groupBy, String having, String orderBy)
    {
        Cursor cursor = mSQLiteDatabase.query(YNSQLHelper.TABLE_CHANNEL,columns, selection, selectionArgs, groupBy, having, orderBy);
        return cursor;
    }
}

