package com.yeneikeji.ynzhibo.view.mine;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.weigan.loopview.LoopView;
import com.weigan.loopview.OnItemSelectedListener;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNFileUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 实名认证界面
 * Created by Administrator on 2016/10/24.
 */
public class YNRealNameActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private LinearLayout mLLErrorInfo;
    private TextView mTVErrorInfo;

    private RelativeLayout mRLLivetype, mRLWrite;
    private EditText mETUserName, mETIDCardNumber, mETPhoneNumber;
    private ImageView mIVAddIdCardPositive, mIVAddIdCardReverse, mIVAboutQualifications;
    private TextView mTVLiveType;
    private TextView mBtnSubmit;

    private List<String> picPathList = new ArrayList<>();
    private ArrayList<String> liveTypeList;
    private File[] files = null;
    private String picPath;
    private int chooseImgFlag;
    private int liveType;// 直播分类
    private String experience;
//    private boolean isIdCardPositive = false;
//    private boolean isIdCardReverse = false;
//    private boolean isChooseIdCard = false;

    private YNPayDialog submitDialog;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.USER_LIVE_AUTHENTICATION_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 24)
                        {
                            // 显示对话框
                            createSubmitDialog();
                        }

                        YNToastMaster.showToast(YNRealNameActivity.this, baseBean.getInfo());

                    }
                    else
                    {
                        YNToastMaster.showToast(YNRealNameActivity.this, getString(R.string.request_fail));
                    }
                    break;

                default:
                    break;
            }
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_realname);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
       configTopBarCtrollerWithTitle(getResources().getString(R.string.realname));

        mRLLivetype = (RelativeLayout) findViewById(R.id.rl_choose_live_type);
//        mLLErrorInfo = (LinearLayout) findViewById(R.id.ll_error_info);
//        mTVErrorInfo = (TextView) findViewById(R.id.tv_error_info);
        mETUserName = (EditText) findViewById(R.id.et_user_name);
        mETIDCardNumber = (EditText) findViewById(R.id.et_idCard_number);
        mETPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
        mIVAddIdCardPositive = (ImageView) findViewById(R.id.iv_add_idCard_positive);
        mIVAddIdCardReverse = (ImageView) findViewById(R.id.iv_add_idCard_reverse);
        mTVLiveType = (TextView) findViewById(R.id.tv_live_type);
//        mETLiveGoodAtType = (EditText) findViewById(R.id.et_good_at_type);
        mIVAboutQualifications = (ImageView) findViewById(R.id.iv_about_qualifications);
//        mETInvestmentExperience = (EditText) findViewById(R.id.et_investment_experience);
        mRLWrite = (RelativeLayout) findViewById(R.id.rl_write);

        mBtnSubmit = (TextView) findViewById(R.id.btn_submit);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mIVAddIdCardPositive.setOnClickListener(this);
        mIVAddIdCardReverse.setOnClickListener(this);
        mIVAboutQualifications.setOnClickListener(this);
        mRLLivetype.setOnClickListener(this);
        mRLWrite.setOnClickListener(this);
        mBtnSubmit.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        picPath = YNFileUtil.getRootFilePath(this) + YNCommonConfig.PHOTO_DIR + "/identify.jpg";
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()){
            case R.id.star_1_com_topbar_iv_left:
                YNCommonUtils.hideSoftInput(this, view);
                finish();
                break;

            case R.id.iv_add_idCard_positive:
                chooseImgFlag = 1;
                showDialog();
                break;

            case R.id.iv_add_idCard_reverse:
                chooseImgFlag = 2;
                showDialog();
                break;

            case R.id.iv_about_qualifications:
                chooseImgFlag = 3;
                showDialog();
                break;

            case R.id.rl_choose_live_type:
                chooseLiveType();
                break;

            case R.id.rl_write:
                Intent intent = new Intent(this, WriteExperienceActivity.class);
                intent.putExtra(YNCommonConfig.OBJECT, experience);
                intent.putExtra(YNCommonConfig.TITLE, getResources().getString(R.string.write_experience));
                startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
                break;

            case R.id.btn_submit:
                if (TextUtils.isEmpty(mETUserName.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("请填写您的真实姓名");
                    YNToastMaster.showToast(this, "请填写您的真实姓名", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!YNCommonUtils.isChinese(mETUserName.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("姓名有误，姓名应全部为汉字");
                    YNToastMaster.showToast(this, "姓名有误，姓名应全部为汉字", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(mETIDCardNumber.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("请填写您的身份证号码");
                    YNToastMaster.showToast(this, "请填写您的身份证号码", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!YNCommonUtils.personIdValidation(mETIDCardNumber.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("身份证号码有误");
                    YNToastMaster.showToast(this, "身份证号码有误", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(mETPhoneNumber.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("身份证号码有误");
                    YNToastMaster.showToast(this, "请填写您的手机号码", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!YNCommonUtils.isCellPhone(mETPhoneNumber.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("身份证号码有误");
                    YNToastMaster.showToast(this, "手机号码格式有误", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (picPathList.size() < 3)
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("身份证正反面未上传");
                    YNToastMaster.showToast(this, "身份证正反面未上传、相关资质未上传", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(mTVLiveType.getText().toString()))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("直播分类未选择");
                    YNToastMaster.showToast(this, "直播分类未选择", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(experience))
                {
//                    mLLErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setVisibility(View.VISIBLE);
//                    mTVErrorInfo.setText("投资经历未填写");
                    YNToastMaster.showToast(this, "最成功的经历未填写", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }

//                mLLErrorInfo.setVisibility(View.GONE);
//                mTVErrorInfo.setVisibility(View.GONE);

                String filePath;
                if (picPathList.size() > 0)
                {
                    files = new File[picPathList.size()];
                    for (int i = 0; i < picPathList.size(); i++)
                    {
                        BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(picPathList.get(i));
                        int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
                        int imgMax = Math.max(options.outWidth, options.outHeight);
                        int inSimpleSize = 1;
                        if (screenMax <= imgMax)
                        {
                            inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
                        }
                        filePath = YNBitMapUtil.compressBitmap(context, picPathList.get(i), Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                        files[i] = new File(filePath);
                    }
                    YNLogUtil.i("selectedPhotos", picPathList.toString());

                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userLiveAuthentication(YNRealNameActivity.this, YNCommonConfig.USER_LIVE_AUTHENTICATION_URL, AccountUtils.getAccountBean().getId(),
                                    mETUserName.getText().toString(), mETIDCardNumber.getText().toString(), mETPhoneNumber.getText().toString(), files, "Android", liveType + 1,
                                    experience, handler, YNCommonConfig.USER_LIVE_AUTHENTICATION_FLAG, true);
                        }
                    });
                }

               /* BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(picPath);
                int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
                int imgMax = Math.max(options.outWidth, options.outHeight);
                int inSimpleSize = 1;
                if (screenMax <= imgMax)
                {
                    inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
                }
                picPath = YNBitMapUtil.compressBitmap(context, picPath, Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                final File file = new File(picPath);

                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userLiveAuthentication(YNRealNameActivity.this, YNCommonConfig.USER_LIVE_AUTHENTICATION_URL, AccountUtils.getAccountBean().getId(),
                                mETUserName.getText().toString(), mETIDCardNumber.getText().toString(), file, handler, YNCommonConfig.USER_LIVE_AUTHENTICATION_FLAG);
                    }
                }, 500);*/
                break;
        }
    }

    /**
     * 创建提交弹出框
     */
    private void createSubmitDialog()
    {
        submitDialog = new YNPayDialog.Builder(this)
                .setHeight(0.23f)  //屏幕高度*0.23
                .setWidth(0.8f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setSingleMode(true)
                .setContentText(getString(R.string.realname_notice))
                .setSingleButtonText("确定")
                .setSingleButtonTextColor(R.color.live_details_text_black)
                .setCanceledOnTouchOutside(false)
                .setSingleListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view)
                    {
                        submitDialog.dismiss();
                        finish();
                    }
                })
                .build();
        submitDialog.show();

//        YNCommonAnimDialog dialog = new YNCommonAnimDialog(this, R.style.transparentFrameWindowStyle, R.drawable.succeed, getString(R.string.realname_notice), false, new YNCommonAnimDialog.CustomDialogListener() {
//            @Override
//            public void OnClick(View view)
//            {
//               finish();
//            }
//        });
//        dialog.show();
    }

    /**
     *  返回键点击处理
     */
    @Override
    public void onBackPressed()
    {
        if (submitDialog != null)
        {
            submitDialog.dismiss();
            finish();
        }
        else
        {
            this.finish();
        }
    }

/*    @Override
    public boolean dispatchKeyEvent(KeyEvent event)
    {
        if (submitDialog != null)
        {
            if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP)
            {
                submitDialog.dismiss();
                finish();
                return true;
            }
            else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getAction() == KeyEvent.ACTION_DOWN)
            {

            }
        }
        return super.dispatchKeyEvent(event);
    }*/

    // 选择图片或照相
    private void showDialog()
    {
        View view = getLayoutInflater().inflate(R.layout.head_image_choose_dialog, null);
        Dialog dialog = new Dialog(this, R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(true);

        buttonHeadOnClickListenner(dialog);

        dialog.show();
    }

    // 选择图片中按钮监听事件
    private void buttonHeadOnClickListenner(final Dialog dialog)
    {
        Button btn_takephoto = (Button) dialog.getWindow().findViewById(R.id.btn_takephoto);
        Button btn_choose_images = (Button) dialog.getWindow().findViewById(R.id.btn_choose_images);
        Button btn_cancel = (Button) dialog.getWindow().findViewById(R.id.btn_cancel);

        btn_takephoto.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, YNCommonConfig.TAKE_PHOTO);
                picPath = YNFileUtil.getRootFilePath(YNRealNameActivity.this) + YNCommonConfig.PHOTO_DIR + YNCommonUtils.getPhotoFileName();
                picPathList.add(picPath);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(picPath)));//拍照后输出，保存在本地中
                dialog.dismiss();
            }
        });

        btn_choose_images.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent in = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(in, YNCommonConfig.CHOOSE_IMAGES);
                dialog.dismiss();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });
    }

    // 选择直播分类
    private void chooseLiveType()
    {
        View view = getLayoutInflater().inflate(R.layout.dialog_evaluate, null);
        TextView mTVChoose = (TextView) view.findViewById(R.id.tv_choose_title);
        LoopView mLoopView = (LoopView) view.findViewById(R.id.loopview);
        mTVChoose.setVisibility(View.VISIBLE);
        Dialog dialog = new Dialog(this, R.style.transparentFrameWindowStyle);
//        view.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(this) * 0.5));
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();

        wl.x = 0;
        wl.y = getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;
//        wl.height = WindowManager.LayoutParams.WRAP_CONTENT;
//        wl.gravity = Gravity.BOTTOM;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);

        buttonLiveTypeOnClickListenner(dialog);

        liveTypeList = new ArrayList<>();
        liveTypeList.add("金融" );
        liveTypeList.add("家教" );

        //设置数据
        mLoopView.setItems(liveTypeList);
        mLoopView.setNotLoop();
        //设置滚轮字体大小
        mLoopView.setTextSize(14);

        //滚动监听 可以知道选择了哪个item
        mLoopView.setListener(new OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(int index)
            {
                liveType = index;
            }
        });

        dialog.setContentView(view);

        dialog.show();
    }

    // 直播分类选择中按钮监听事件
    private void buttonLiveTypeOnClickListenner(final Dialog dialog)
    {
        TextView cancel = (TextView) dialog.getWindow().findViewById(R.id.evaluate_cancle);
        TextView sure = (TextView) dialog.getWindow().findViewById(R.id.evaluate_sure);

        cancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        sure.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mTVLiveType.setText(liveTypeList.get(liveType));
                dialog.dismiss();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (data == null)
            return;

        Bitmap image = null;

        switch (requestCode)
        {
            case YNCommonConfig.TAKE_PHOTO:
                if (resultCode == Activity.RESULT_OK)
                {
                    image = (Bitmap)data.getExtras().get("data");
                }
                break;

            case YNCommonConfig.CHOOSE_IMAGES:
                if (resultCode == Activity.RESULT_OK)
                {
                    ContentResolver resolver = getContentResolver();
                    Uri originalUri = data.getData(); //获得图片的uri
//                    picPath  = getRealPathFromURI(originalUri);
                    picPath  = YNBitMapUtil.getPathByUri(YNRealNameActivity.this, originalUri);
                    picPathList.add(picPath);
                    try
                    {
                        image = MediaStore.Images.Media.getBitmap(resolver, originalUri);
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                break;

            case YNCommonConfig.ACTIVITY_RESULT:
                if (resultCode == YNCommonConfig.ACTIVITY_RESULT)
                {
                    experience = data.getStringExtra(YNCommonConfig.OBJECT);
                }
                break;
        }

//        if (chooseImgFlag == 1 && chooseImgFlag == 2)
//            isChooseIdCard = true;

        if (chooseImgFlag == 1)
        {
            mIVAddIdCardPositive.setImageBitmap(image);//设置显示图片
//            isIdCardPositive = true;
        }

        if (chooseImgFlag == 2)
        {
            mIVAddIdCardReverse.setImageBitmap(image);//设置显示图片
//            isIdCardReverse = true;
        }

        if (chooseImgFlag == 3)
            mIVAboutQualifications.setImageBitmap(image);

//        if (isIdCardPositive && isIdCardReverse)
//            isChooseIdCard = true;

    }

}

