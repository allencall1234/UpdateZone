package com.yeneikeji.ynzhibo.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNTopBarControl;

/**
 * Created by Administrator on 2016/8/10.
 */
public abstract class YNBaseTopBarFragment extends YNBaseFragment
{
    public YNTopBarControl mTopBarControl;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = null;

        return view;
    }

    /**
     * 必须在setContentView调用后才能使用
     */
    protected void configTopBarCtrollerWithTitle(View view, String title)
    {
        mTopBarControl = (YNTopBarControl) view.findViewById(R.id.yn_topbar_lo_panel);
        mTopBarControl.titleTv.setText(title);
        mTopBarControl.leftItemIv.setVisibility(View.INVISIBLE);
    }

    protected ImageView getLeftBtn()
    {
        return  mTopBarControl.leftItemIv;
    }

    protected ImageView getRightBtn()
    {
        return  mTopBarControl.rightItemIv;
    }

    protected TextView getTitleTxt()
    {
        return mTopBarControl.titleTv;
    }

    protected TextView getLeftTV()
    {
        return mTopBarControl.leftItemTv;
    }

    protected TextView getRightTV()
    {
        return mTopBarControl.rightItemTv;
    }

    protected ViewGroup getLeftBtnLL()
    {
        return mTopBarControl.leftItemBtn;
    }

    protected ViewGroup getRightBtnLL()
    {
        return mTopBarControl.rightItemBtn;
    }

}
