package com.yeneikeji.ynzhibo.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Administrator on 2017/5/8.
 */
public class DbOpenHelper extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "yndatabase.db";
    private static final int DATABASE_VERSION = 1;
    private static DbOpenHelper instance;

    public static final String CREATE_HISTORY_TABLE = "CREATE TABLE "
            + HistoryDao.TABLE_NAME + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            + HistoryDao.COLUMN_NAME_ID + " INTEGER, "
            + HistoryDao.COLUMN_NAME_NAME + " VARCHAR)";

    private static final String CREATE_COMMENT_TABLE = "CREATE TABLE "
            + CommentDao.TABLE_NAME + "("
            + CommentDao.COLUMN_NAME_ID +" INTEGER, "
            + CommentDao.COLUMN_NAME_USER_ID + " INTEGER, "
            + CommentDao.COLUMN_NAME_CID + " INTEGER, "
            + CommentDao.COLUMN_NAME_IS_READ + " INTEGER, "
            + CommentDao.COLUMN_NAME_CONTENT + " VARCHAR, "
            + CommentDao.COLUMN_NAME_TIME + " VARCHAR, "
            + CommentDao.COLUMN_NAME_ICON + " VARCHAR, "
            + CommentDao.COLUMN_NAME_USERNAME + " VARCHAR)";

    private static final String CREATE_DYNAMIC_TABLE = "CREATE TABLE "
            + DynamicDao.TABLE_NAME + "("
            + DynamicDao.COLUMN_NAME_ID +" INTEGER, "
            + DynamicDao.COLUMN_NAME_USER_ID + " INTEGER, "
            + DynamicDao.COLUMN_NAME_CONTENT + " VARCHAR, "
            + DynamicDao.COLUMN_NAME_TIME + " VARCHAR, "
            + DynamicDao.COLUMN_NAME_ICON + " VARCHAR, "
            + DynamicDao.COLUMN_NAME_USERNAME + " VARCHAR, "
            + DynamicDao.COLUMN_COMMENT_NUM + " INTEGER, "
            + DynamicDao.COLUMN_ZAN_NUM + " INTEGER, "
            + DynamicDao.COLUMN_IS_ATTENTION + " INTEGER, "
            + DynamicDao.COLUMN_THUMB + " INTEGER, "
            + DynamicDao.COLUMN_PIC0 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC1 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC2 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC3 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC4 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC5 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC6 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC7 + " VARCHAR, "
            + DynamicDao.COLUMN_PIC8 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC0 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC1 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC2 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC3 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC4 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC5 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC6 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC7 + " VARCHAR, "
            + DynamicDao.COLUMN_SMALL_PIC8 + " VARCHAR)";

    private static final String CREATE_WATCH_RECORD_TABLE = "CREATE TABLE "
            + WatchRecordDao.TABLE_NAME + "("
            + WatchRecordDao.COLUMN_NAME_ID + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_USER_ID + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_USERNAME + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_ICON + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_PUSH_ADDRESS + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_PLAY_ADDRESS + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_ROOM_ID + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_PICTURE + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_TITLE + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_TAG + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_IS_ATTENTION + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_FANS_COUNT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_FOCUS_COUNT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_DYNAMIC_COUNT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_ACCOUNT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_EQUIPMENT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_ATTENTION_ID + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_DESCRIBES + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_USER_STATUS + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_STATUS + " VARCHAR, "
            + WatchRecordDao.COLUMN_NAME_PAY_COIN + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_LIVING + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_LIVE_STATUS + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_LOCK + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_IS_PAY + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_LIVE_COUNT + " INTEGER, "
            + WatchRecordDao.COLUMN_NAME_TIME + " VARCHAR)";

    private static final String CREATE_SYSTEM_MESSAGE_TABLE = "CREATE TABLE "
            + SystemMessageDao.TABLE_NAME + "("
            + SystemMessageDao.COLUMN_NAME_ID + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_USERID + " VARCHAR,"
            + SystemMessageDao.COLUMN_NAME_UID + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_SEND_TYPE + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_TYPE + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_MESSAGE_TYPE + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_CONTENT + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_TIME + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_IS_READ + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_IS_ACCEPT + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_USERNAME + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_DESCRIBES + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_ICON + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_LIVE_TYPE + " VARCHAR, "
            + SystemMessageDao.COLUMN_NAME_LIVE_COLUMN + " VARCHAR)";

    private DbOpenHelper(Context context)
    {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static DbOpenHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DbOpenHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_HISTORY_TABLE);
        db.execSQL(CREATE_COMMENT_TABLE);
        db.execSQL(CREATE_DYNAMIC_TABLE);
        db.execSQL(CREATE_WATCH_RECORD_TABLE);
        db.execSQL(CREATE_SYSTEM_MESSAGE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // 更改数据库版本
        onCreate(db);
    }

    public void closeDb()
    {
        if (instance != null) {
            try {
                SQLiteDatabase db = instance.getWritableDatabase();
                db.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            instance = null;
        }
    }
}
