package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import java.util.ArrayList;
import java.util.List;

public class YNMessageDetailsActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private TextView mTitle;
    private SmoothListView mListView;
    private RelativeLayout mEmptyRl;
    private MessageBean mMsgBean;
    private List<MessageBean> mDatas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ynmessage_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        mMsgBean = (MessageBean) getIntent().getSerializableExtra("data");
        mDatas = new ArrayList();
        mDatas.add(mMsgBean);
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {

        mListView = (SmoothListView) findViewById(R.id.message_details_ListView);
        mEmptyRl = (RelativeLayout) findViewById(R.id.meg_details_empty);
        if(mMsgBean.getMessage_type().equals(YNCommonConfig.SYSTEM_MESSAGE)){
            configTopBarCtrollerWithTitle(getString(R.string.system_message));
        }else if(mMsgBean.getMessage_type().equals(YNCommonConfig.FOLLOW_MESSAGE)){
            configTopBarCtrollerWithTitle(getString(R.string.follow_message));
        }else if(mMsgBean.getMessage_type().equals("2")){
            configTopBarCtrollerWithTitle("评论消息");
        }else if(mMsgBean.getMessage_type().equals("4")){
            configTopBarCtrollerWithTitle("点赞消息");
        }else if(mMsgBean.getMessage_type().equals("6")){
            configTopBarCtrollerWithTitle("提问消息");
        }else if(mMsgBean.getMessage_type().equals("7")){
            configTopBarCtrollerWithTitle("回复消息");
        }else if(mMsgBean.getMessage_type().equals("11")){
            configTopBarCtrollerWithTitle("充值");
        }
    }

    @Override
    protected void addEvent() {
       mListView.setLoadMoreEnable(false);
        getLeftBtn().setOnClickListener(this);

    }
    @Override
    protected void settingDo() {
        MessageDetailsAdapter adapter=new MessageDetailsAdapter(mDatas);
        mListView.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                 break;
        }
    }

    class MessageDetailsAdapter extends BaseAdapter{
        private List<MessageBean> dataLists;
        public MessageDetailsAdapter(List<MessageBean> dataList) {
            this.dataLists = dataList;

        }

        @Override
        public int getCount() {
            if(dataLists!=null){
              return dataLists.size();
            }
            return 0;
        }

        @Override
        public MessageBean getItem(int position) {
            if(dataLists!=null){
                return  dataLists.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if(convertView==null){
                holder=new Holder();
                convertView=View.inflate(YNMessageDetailsActivity.this,R.layout.message_details_item,null);
                holder.ivType= (YNCircleImageView) convertView.findViewById(R.id.type_imagview);
                holder.time= (TextView) convertView.findViewById(R.id.top_time);
                holder.conTent= (TextView) convertView.findViewById(R.id.message_content);
                convertView.setTag(holder);
            }else {
                holder= (Holder) convertView.getTag();
            }
            MessageBean messageBean = dataLists.get(position);

//            YNImageLoaderUtil.setImage(YNMessageDetailsActivity.this, holder.ivType, messageBean.getIcon());
            holder.ivType.setImageResource(R.drawable.message_official);
            holder.time.setText(DateUtil.timeTick2DateNotSec(messageBean.getTime()));
            holder.conTent.setText(messageBean.getContent());

            return convertView;
        }
        class Holder{
            TextView time;
            TextView conTent;
            com.yeneikeji.ynzhibo.common.YNCircleImageView ivType;
        }
    }
}
