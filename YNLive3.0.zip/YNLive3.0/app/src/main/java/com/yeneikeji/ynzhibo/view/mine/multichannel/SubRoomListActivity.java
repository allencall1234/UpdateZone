package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RoomOwnerBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 子房间列表
 * Created by Administrator on 2017/7/28.
 */
public class SubRoomListActivity extends YNBaseTopBarActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private SmoothListView mSubRoomLV;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;
    private Button mBtnCreate;

    private CommonAdapter mSubRoomAdapter;
    private List<RoomOwnerBean> mChildRoomList = new ArrayList<>();

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.QUERY_CHILD_ROOM_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("lxy",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 27)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mSubRoomLV.setVisibility(View.VISIBLE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    mChildRoomList = YNJsonUtil.JsonToLBean(jsonObject.optString("data"), type);
                                    mSubRoomAdapter.updateListView(mChildRoomList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mSubRoomLV.setVisibility(View.GONE);
                            mRLEmpty.setVisibility(View.VISIBLE);
//                            YNToastMaster.showToast(SubRoomListActivity.this, baseBean.getInfo());
                        }
                    }
                    else
                    {
                        mSubRoomLV.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(SubRoomListActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 27)
                        {
                            try
                            {
                                mRLEmpty.setVisibility(View.GONE);
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    mChildRoomList = YNJsonUtil.JsonToLBean(jsonObject.optString("data"), type);
                                    mSubRoomAdapter.updateListView(mChildRoomList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            YNToastMaster.showToast(SubRoomListActivity.this, baseBean.getInfo());
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(SubRoomListActivity.this, R.string.request_fail);
                    }
                    onStopLoad();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subroom_list);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.sub_room_title));

        mSubRoomLV = (SmoothListView) findViewById(R.id.lv_sub_room);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) findViewById(R.id.tv_refresh_net);
        mBtnCreate = (Button) findViewById(R.id.btn_create);

    }

    @Override
    protected void addEvent()
    {
        mSubRoomLV.setLoadMoreEnable(false);
        getLeftBtn().setOnClickListener(this);

        mSubRoomLV.setSmoothListViewListener(this);
        mSubRoomLV.setLoadMoreEnable(false);
        mRLEmpty.setOnClickListener(this);
        mTVRefreshNet.setOnClickListener(this);
        mBtnCreate.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
//        queryChildRoomList();

        mSubRoomAdapter = new CommonAdapter<RoomOwnerBean>(this, mChildRoomList, R.layout.item_subroom)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, RoomOwnerBean item)
            {
                viewHolder.setText(R.id.tv_sub_room_sort, item.getSort() + "");
                viewHolder.setText(R.id.tv_sub_room_info, "ID:" + item.getUserid() + "   房主(" + item.getUsername() + ")");
            }
        };

        mSubRoomLV.setAdapter(mSubRoomAdapter);

        mSubRoomLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(SubRoomListActivity.this, MultichannelRoomMemberActivity.class);
               /* intent.putExtra(YNCommonConfig.OBJECT, mChildRoomList.get(position - 1).getUserid());
                intent.putExtra(YNCommonConfig.TITLE, true);*/
                intent.putExtra(YNCommonConfig.TITLE, true);
                intent.putExtra("roomid",mChildRoomList.get(position - 1).getRoom_id());
                intent.putExtra("userid",mChildRoomList.get(position - 1).getUserid());
                startActivityForResult(intent, 0x12);
            }
        });
    }

    @Override
    protected void onResume()
    {
       /* if (!YNBaseActivity.isConnectNet)
        {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mRLEmpty.setVisibility(View.GONE);
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("暂时没有数据，点击屏幕刷新界面~");
        }*/

        super.onResume();
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.tv_refresh_net:
            case R.id.empty:
                if (YNBaseActivity.isConnectNet)
                {
                    mRLEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有数据，点击屏幕刷新界面~");

                    queryChildRoomList();
                }
                break;

            case R.id.btn_create:
                Intent intent = new Intent(this, CreateSubRoomActivity.class);
                intent.putExtra(YNCommonConfig.OBJECT, AccountUtils.getAccountBean().getId());
                intent.putExtra(YNCommonConfig.TITLE, false);
                startActivity(intent);
                break;
        }
    }

    /**
     * 查询子房间列表
     */
    private void queryChildRoomList()
    {
        if(AccountUtils.getLoginInfo()) {
            mHandler.post(new Runnable() {
                @Override
                public void run()

                {
                    UserHttpUtils.newInstance()
                                 .childRoomOwnerList(SubRoomListActivity.this,
                                                     YNCommonConfig.QUERY_CHILD_ROOM_LIST_URL,
                                                     AccountUtils.getAccountBean()
                                                                 .getId(),
                                                     mHandler,
                                                     YNCommonConfig.QUERY_CHILD_ROOM_LIST_FLAG,
                                                     true);
                }
            });
        }else{
            Intent intent=new Intent(SubRoomListActivity.this, YNLoginActivity.class);
            startActivity(intent);
        }

    }

    @Override
    public void onRefresh()
    {
        if(AccountUtils.getLoginInfo()) {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().childRoomOwnerList(SubRoomListActivity.this, YNCommonConfig.QUERY_CHILD_ROOM_LIST_URL, AccountUtils.getAccountBean().getId(), mHandler,
                        YNCommonConfig.ON_REFRESH, true);
            }
        });
        }else{
            Intent intent=new Intent(SubRoomListActivity.this, YNLoginActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onLoadMore()
    {
    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mSubRoomLV.stopRefresh();
        mSubRoomLV.stopLoadMore();
        mSubRoomLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == 0x12 && requestCode==28)
        {
            queryChildRoomList();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
