package com.yeneikeji.ynzhibo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.yeneikeji.ynzhibo.view.YNBaseActivity;

public class MyReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive(final Context context, Intent intent)
    {
        ConnectivityManager manager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mMobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if(!wifi.isConnected() && !mMobile.isConnected())
        {
            YNBaseActivity.isConnectNet = false;

//            AlertDialog.Builder ab = new AlertDialog.Builder(context);
//
//            //设定标题
//            ab.setMessage("网络连接断开，请检查网络");
//            //设定退出按钮
//            ab.setNegativeButton("取消", new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialog, int which)
//                {
//                    dialog.dismiss();
//                }
//            });
//
//            //网络设置按钮
//            ab.setPositiveButton("设置", new DialogInterface.OnClickListener() {
//
//                @Override
//                public void onClick(DialogInterface dialog, int which)
//                {
//                    dialog.dismiss();
//                    NetUtils.openSetting(context);
//                }
//            }).show();
        }
        else
        {
            YNBaseActivity.isConnectNet = true;
        }
    }
}
