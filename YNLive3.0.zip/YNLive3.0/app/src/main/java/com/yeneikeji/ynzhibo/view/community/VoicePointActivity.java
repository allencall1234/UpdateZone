package com.yeneikeji.ynzhibo.view.community;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.czt.mp3recorder.MP3Recorder;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import java.io.File;
import java.io.IOException;

/*
* 这是语音观点的类
* */
public class VoicePointActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener

{

    private YNPayDialog mDiaialog;
    private ImageView mIvStar;
    private ImageView mIvStop;
    private ImageView mIvPlay;
    private ImageView mIvStopPlay;
    //语音操作对象
    private MediaPlayer   mPlayer   = null;
    private MP3Recorder mRecorder = null;
    //语音文件保存路径
    private String FileName = null;
    private TextView mRecordTime;
    private LinearLayout mSelectLl;
    private Button mTvCancle;
    private Button mTvCompomplete;
    private TextView mTvNotice;
    //录音计时
    private  int Count=0;
    private  int PlayCount=120;
    private  TimeTask time;
    private  boolean isOpen;
    private  File file;
    private String describle;
    //定义一个开关记录语音观点是否已经发表成功了，以便用户退出时提示
    private boolean hasPablished;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.VOICE_PUBLISH_FLAG:
                    if (msg.obj != null) {
                        YNLogUtil.e("lxy",msg.obj.toString());
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 108) {
                            hasPablished=false;
                            Toast.makeText(VoicePointActivity.this, "发表成功", Toast.LENGTH_SHORT)
                                 .show();
                            mEtDescrible.setText(null);
                        } else {
                            hasPablished=false;
                            Toast.makeText(VoicePointActivity.this, "发表失败", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    break;
            }
        }

    };
    private EditText mEtDescrible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_point);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        //一进来就弹出免责提示框，拒绝的话直接finish掉
        mDiaialog = new YNPayDialog.Builder(context)
                .setHeight(0.3f)  //屏幕高度
                .setWidth(0.8f)  //屏幕宽度
                .setTitleVisible(true)
                .setTitleText("免责声明")
                .setTitleTextSize(16)
                .setTitleTextColor(R.color.live_details_text_black)
                .setContentText("本人确定语音观点仅为个人观点，与业内直播无关")
                .setContentTextColor(R.color.live_details_text_black)
                .setContentTextSize(14)
                .setLeftButtonText("同意")
                .setLeftButtonTextColor(R.color.Topblue)
                .setRightButtonText("拒绝")
                .setRightButtonTextColor(R.color.Topblue)
                .setButtonTextSize(16)
                .setCanceledOnTouchOutside(false)
                .setInterceptBack(true)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }
                    //同意
                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        mDiaialog.dismiss();
                    }
                    //拒绝
                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        mDiaialog.dismiss();
                        finish();
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();

        mDiaialog.show();

        initView();
        addEvent();
    }
    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("语音观点");
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText("发表");
        //发表语音的描述
        mEtDescrible = (EditText) findViewById(R.id.voice_point_describle);

        mRecordTime = (TextView) findViewById(R.id.record_time);

        mIvStar = (ImageView) findViewById(R.id.iv_star);
        mIvStop = (ImageView) findViewById(R.id.iv_stop);
        mIvPlay = (ImageView) findViewById(R.id.iv_play);
        mIvStopPlay = (ImageView) findViewById(R.id.iv_stop_play);
        //提示语句
        mTvNotice = (TextView) findViewById(R.id.tv_notice);
        //录制结束后底部弹出选择框
        mSelectLl = (LinearLayout) findViewById(R.id.linear_layout_select);

        mTvCancle = (Button) findViewById(R.id.btn_cancle);
        mTvCompomplete = (Button) findViewById(R.id.btn_complete);
        //设置sdcard的路径
        FileName = Environment.getExternalStorageDirectory().getAbsolutePath();
        FileName += "/audiorecordtest.mp3";

    }
    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
   //获取对语音观点的描述
        mEtDescrible.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                describle=s.toString().trim();
            }
        });

        mIvStar.setOnClickListener(new startRecordListener());
        mIvStop.setOnClickListener(new stopRecordListener());
        mIvPlay.setOnClickListener(new startPlayListener());
        mIvStopPlay.setOnClickListener(new stopPlayListener());

        mTvCancle.setOnClickListener(this);
        mTvCompomplete.setOnClickListener(this);
    }

    @Override
    protected void settingDo() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                //点击返回时，检查是否编辑了内容，有的话要弹出提示框 是否放弃编辑,如果是发表了以后就不要提示了
                if(describle!=null && hasPablished==false){
                    mDiaialog = new YNPayDialog.Builder(context)
                            .setHeight(0.3f)  //屏幕高度
                            .setWidth(0.8f)  //屏幕宽度
                            .setTitleVisible(true)
                            .setTitleText("温馨提示")
                            .setTitleTextSize(16)
                            .setTitleTextColor(R.color.live_details_text_black)
                            .setContentText("如果现在退出，你将会放弃当前的编辑内容哦，是否确定要退出？")
                            .setContentTextColor(R.color.live_details_text_black)
                            .setContentTextSize(14)
                            .setLeftButtonText("确定")
                            .setLeftButtonTextColor(R.color.Topblue)
                            .setRightButtonText("取消")
                            .setRightButtonTextColor(R.color.Topblue)
                            .setButtonTextSize(16)
                            .setCanceledOnTouchOutside(false)
                            .setInterceptBack(true)
                            .setOnclickListener(new IDialogOnClickListener() {
                                @Override
                                public void clickTopLeftButton(View view) {

                                }

                                @Override
                                public void clickTopRightButton(View view) {

                                }
                                //同意
                                @Override
                                public void clickBottomLeftButton(View view)
                                {
                                    mDiaialog.dismiss();
                                    finish();
                                }
                                //拒绝
                                @Override
                                public void clickBottomRightButton(View view)
                                {
                                    mDiaialog.dismiss();
                                }

                                @Override
                                public void clickBottomButton(View view) {

                                }
                            })
                            .build();

                    mDiaialog.show();
                }else{
                    finish();
                }
                break;
            //取消
            case R.id.btn_cancle:
                //删除老文件
                file.delete();
                mSelectLl.setVisibility(View.GONE);
                //重新开始录制，暂停按钮和正在播放按钮都要隐藏
                mIvPlay.setVisibility(View.GONE);
                mIvStopPlay.setVisibility(View.GONE);
                mIvStar.setVisibility(View.VISIBLE);
                mTvNotice.setText("请把录音限制在两分钟之内");
                mTvNotice.setClickable(false);
                //重新计时
                isOpen=false;
                Count=0;
                mRecordTime.setText("00:00");
                mTvNotice.setVisibility(View.VISIBLE);
                break;
            //完成
            case R.id.btn_complete:
                mSelectLl.setVisibility(View.GONE);
                mTvNotice.setVisibility(View.VISIBLE);
                mTvNotice.setText("重新录制");
                mTvNotice.setClickable(true);
                mTvNotice.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //回到进来的状态
                        mIvStop.setVisibility(View.GONE);
                        mIvPlay.setVisibility(View.GONE);
                        mIvStar.setVisibility(View.VISIBLE);
                        mTvNotice.setVisibility(View.VISIBLE);
                        mTvNotice.setText("请把录音限制在两分钟之内");
                        mTvNotice.setClickable(false);
                        //重新计时
                        isOpen=false;
                        Count=0;
                        mRecordTime.setText("00:00");
                    }
                });
                break;
            //发表
            case R.id.star_1_com_topbar_tv_right:

                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().getVoicePointPublish(VoicePointActivity.this, YNCommonConfig.Voice_PUBLISH_URL,
                                                                         AccountUtils.getAccountBean().getId(), file, describle,showTimeCount(PlayCount), mHandler, YNCommonConfig.VOICE_PUBLISH_FLAG, true);
                    }
                });
                break;
        }
    }

    //开始录音
    class startRecordListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            //动态获取录音权限并授权
            if(ContextCompat.checkSelfPermission(VoicePointActivity.this, android.Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(VoicePointActivity.this,
                                                  new String[]{android.Manifest.permission.RECORD_AUDIO},
                                                  1);

                ActivityCompat.requestPermissions(VoicePointActivity.this,
                                                  new String[]{Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS},
                                                  2);


            }

                //生成录音文件
            file = new File(FileName);
             mRecorder = new MP3Recorder(file);
           //重置计时器
            Count=0;
            PlayCount=120;
            mIvStar.setVisibility(View.GONE);
            mTvNotice.setText("点击结束");
            mTvNotice.setClickable(false);
            mIvStop.setVisibility(View.VISIBLE);

           // mRecorder = new MediaRecorder();
           /* mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mRecorder.setOutputFile(FileName);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            try {
                mRecorder.prepare();
            } catch (IOException e) {
            }*/
            try {
                mRecorder.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
            isOpen=true;
            time=new TimeTask();
            time.run();
        }
    }

    //停止录音
    class stopRecordListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            //如果小于一秒重新开始录制
            if(Count<=1){
                Toast.makeText(context, "录音时间太短,请重新录制", Toast.LENGTH_SHORT).show();
                //重新计时,并删除无效录音文件
                Count=0;
                file.delete();
                mRecordTime.setText("00:00");
                //重新开始按钮显示出来
                mIvStar.setVisibility(View.VISIBLE);

                //播放按钮隐藏起来
                mIvPlay.setVisibility(View.GONE);
                mIvStop.setVisibility(View.GONE);
                mTvNotice.setVisibility(View.VISIBLE);

            }else {
                mIvStop.setVisibility(View.GONE);
                mTvNotice.setVisibility(View.GONE);
                mIvPlay.setVisibility(View.VISIBLE);
                mSelectLl.setVisibility(View.VISIBLE);
            }

            //停止计时
            isOpen=false;
            //记录当前的时间长度
            PlayCount=Count-1;
            mRecorder.stop();
            mRecorder = null;
        }

    }
    //播放录音
    class startPlayListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            mIvPlay.setVisibility(View.GONE);
            mIvStopPlay.setVisibility(View.VISIBLE);
            mPlayer = new MediaPlayer();
            try{
                mPlayer.setDataSource(FileName);
                mPlayer.prepare();
                mPlayer.start();
                //显示播放时间
                mRecordTime.setText("00:00");
                //开始播放计时,重置时间起点
                Count=0;
                isOpen=true;
                time.run();

            }catch(IOException e){
                Toast.makeText(context, "播放失败", Toast.LENGTH_SHORT)
                     .show();
            }
        }

    }
    //停止播放录音
    class stopPlayListener implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            mIvStopPlay.setVisibility(View.GONE);
            mIvPlay.setVisibility(View.VISIBLE);
            if(mPlayer!=null){
                mPlayer.release();
                mPlayer = null;
            }
            //停止计时
            Count=0;
            isOpen=false;
        }
    }

    class TimeTask extends Thread implements Runnable{
        final Handler handler=new Handler();
        @Override
        public void run() {
            //开启计时
            if (isOpen) {
                if (Count >PlayCount) {//限时两分钟
                    if(mRecorder!=null){
                        mRecorder.stop();
                    }
                   if(mPlayer!=null){
                       mPlayer.release();
                       mPlayer = null;
                   }
                    Count=0;
                    isOpen=false;
                }

                String str = showTimeCount( Count);
                mRecordTime.setText(str);
                handler.postDelayed(this, 1000);//每一秒刷新一次 }
                Count++;
            }
        }

    }
    //将秒数转换成时间显示格式
    public String showTimeCount(int time) {
        String s ="00:";
        if(time<=59){
            return time<10 ? s+"0"+String.valueOf(time) : s+String.valueOf(time);
        }else if(time-60<10){
            return ("0"+String.valueOf(time/60)+":0"+String.valueOf(time-60));
        }else {
            return ("0"+String.valueOf(time/60)+":"+String.valueOf(time-60));
        }
    }
}
