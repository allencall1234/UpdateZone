package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 笔记列表
 * Created by Administrator on 2017/7/3.
 */
public class NoteListFragment extends BaseFragment implements SmoothListView.ISmoothListViewListener, View.OnClickListener
{
    private SmoothListView mNoteLV;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private RelativeLayout mRLHomePageEmpty;
    private ImageView mIVHomePageEmpty;

    private CommonAdapter mNoteAdapter;
    private List<FindCategaryBean> mNoteList = new ArrayList<>();
    private FindCategaryBean findCategary;

    private YNPayDialog buytDialog;

    private int homePageFlag;
    private int type;
    private String hostId;
    private String userId = "";
    private int currentCoin;// 当前金币
    private boolean isPhoneLiving;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_LIVE_ROOM_NOTE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                        YNToastMaster.showToast(getContext(), baseBean.getInfo());
                        if (baseBean.getCode() == 28)
                        {
                            mNoteLV.setVisibility(View.VISIBLE);
                            if (homePageFlag == 1)
                                mRLEmpty.setVisibility(View.GONE);
                            else
                                mRLHomePageEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    mNoteList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mNoteAdapter.updateListView(mNoteList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                        else
                        {
                            mNoteLV.setVisibility(View.GONE);
                            if (homePageFlag == 1)
                                mRLEmpty.setVisibility(View.VISIBLE);
                            else
                                mRLHomePageEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
//                        YNToastMaster.showToast(getContext(), R.string.request_fail);
                        mNoteLV.setVisibility(View.GONE);
                        if (homePageFlag == 1)
                            mRLEmpty.setVisibility(View.VISIBLE);
                        else
                            mRLHomePageEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 102)
                        {
                            AccountUtils.getAccountBean().setCurrentCoin(currentCoin - Integer.parseInt(findCategary.getPayCoin()));
                            AccountUtils.saveAccountBean(AccountUtils.getAccountBean());
                            buytDialog.dismiss();
                            for (FindCategaryBean findCategaryBean : mNoteList)
                            {
                                if (findCategary.getId().equals(findCategaryBean.getId()))
                                {
                                    findCategaryBean.setIs_purchase(1);
                                    mNoteAdapter.updateListView(mNoteList);
                                    Intent intent = new Intent(getContext(), ArticalDetailsActivity.class);
                                    intent.putExtra("aid", findCategary.getId());
                                    startActivity(intent);
                                    break;
                                }
                            }
                        }

                        YNToastMaster.showToast(getActivity(), baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    onStopLoad();
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mNoteLV.setVisibility(View.VISIBLE);
                            if (homePageFlag == 1)
                                mRLEmpty.setVisibility(View.GONE);
                            else
                                mRLHomePageEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    mNoteList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mNoteAdapter.updateListView(mNoteList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                            YNToastMaster.showToast(getContext(), "刷新成功");
                        }
                        else
                        {
                            YNToastMaster.showToast(getContext(), "刷新失败");
                            mNoteLV.setVisibility(View.GONE);
                            if (homePageFlag == 1)
                               mRLEmpty.setVisibility(View.VISIBLE);
                            else
                               mRLHomePageEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getContext(), "刷新失败");
                        mNoteLV.setVisibility(View.GONE);
                        if (homePageFlag == 1)
                            mRLEmpty.setVisibility(View.VISIBLE);
                        else
                            mRLHomePageEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                currentCoin = Integer.parseInt(jsonObject.getString("data"));
                                AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                    }
                    else
                    {
//                    YNToastMaster.showToast(getContext(), getString(R.string.request_fail));
                    }
                    break;

            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void initView()
    {
        mNoteLV = (SmoothListView) findViewById(R.id.lv_note);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) mRLEmpty.findViewById(R.id.iv_empty);
        mRLHomePageEmpty = (RelativeLayout) findViewById(R.id.personal_homepage_empty);
        mIVHomePageEmpty = (ImageView) mRLHomePageEmpty.findViewById(R.id.iv_homepage_empty);

        mRLEmpty.setBackgroundColor(Color.parseColor("#00000000"));

        mIVEmpty.setOnClickListener(this);
        mIVHomePageEmpty.setOnClickListener(this);
        mNoteLV.setSmoothListViewListener(this);
        mNoteLV.setLoadMoreEnable(false);
    }

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            hostId = bundle.getString(YNCommonConfig.USER_ID);
            homePageFlag = bundle.getInt(YNCommonConfig.HOME_PAGE_FLAG);
            isPhoneLiving = bundle.getBoolean(YNCommonConfig.ISSHOW);
        }
        return R.layout.fragment_note_list;
    }

    @Override
    protected void loadData()
    {
        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();
        }

//        if (!AccountUtils.getLoginInfo())
        getNetData();

        mNoteAdapter = new CommonAdapter<FindCategaryBean>(getContext(), mNoteList, R.layout.totalartical_listview_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, final FindCategaryBean item)
            {
                if (homePageFlag == 1)
                {
                    ((TextView)viewHolder.getView(R.id.total_artical_title)).setTextColor(ContextCompat.getColor(getActivity(), R.color.ynkj_white));
                    if (isPhoneLiving)
                    {
                        ((TextView)viewHolder.getView(R.id.total_artical_content)).setTextColor(ContextCompat.getColor(getActivity(), R.color.gift_txt_color));
                        ((TextView)viewHolder.getView(R.id.time)).setTextColor(ContextCompat.getColor(getActivity(), R.color.gift_txt_color));
                        ((TextView)viewHolder.getView(R.id.have_buyed_people)).setTextColor(ContextCompat.getColor(getActivity(), R.color.gift_txt_color));
                        viewHolder.getView(R.id.line_view).setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.gift_txt_color));
                    }
                    else
                    {
                        ((TextView)viewHolder.getView(R.id.total_artical_content)).setTextColor(ContextCompat.getColor(getActivity(), R.color.search_txt));
                        ((TextView)viewHolder.getView(R.id.time)).setTextColor(ContextCompat.getColor(getActivity(), R.color.private_msg_introduce_txt));
                        ((TextView)viewHolder.getView(R.id.have_buyed_people)).setTextColor(ContextCompat.getColor(getActivity(), R.color.private_msg_introduce_txt));
                        viewHolder.getView(R.id.line_view).setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.private_msg_introduce_txt));
                    }
                }
                else
                {
                    ((TextView)viewHolder.getView(R.id.total_artical_title)).setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗
                }

                // 已购
                if (type == 1)
                {
                    viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.GONE);
                    viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.GONE);
                    viewHolder.getView(R.id.iv_gold).setVisibility(View.GONE);
                    viewHolder.getView(R.id.tv_purchase).setVisibility(View.GONE);
                }
                else
                {
                    if ("0".equals(item.getIs_pay())) // 全部中不收费
                    {
                        viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.INVISIBLE);
                        viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.INVISIBLE);
                        viewHolder.getView(R.id.iv_gold).setVisibility(View.INVISIBLE);
                        viewHolder.getView(R.id.tv_purchase).setVisibility(View.GONE);
                    }
                    else
                    {
                        if (item.getIs_purchase() == 1)// 全部中已购
                        {
                            viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.GONE);
                            viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.GONE);
                            viewHolder.getView(R.id.iv_gold).setVisibility(View.GONE);
                            viewHolder.getView(R.id.tv_purchase).setVisibility(View.VISIBLE);
                        }
                        else
                        {
                            viewHolder.getView(R.id.tv_purchase).setVisibility(View.GONE);
                            if (AccountUtils.getLoginInfo() && userId.equals(item.getUserid()))
                            {
                                viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.INVISIBLE);
                                viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.INVISIBLE);
                                viewHolder.getView(R.id.iv_gold).setVisibility(View.INVISIBLE);
                            }
                            else

                            {
                                viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.VISIBLE);
                                viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.VISIBLE);
                                ((TextView)viewHolder.getView(R.id.totalartical_buy_coin_numb)).setTextColor(ContextCompat.getColor(getContext(), R.color.ynkj_topbar_text_right));
                                viewHolder.getView(R.id.iv_gold).setVisibility(View.VISIBLE);
                            }
                        }
                    }
                }

                final List<PhotoInfoBean> photos = new ArrayList<>();

                if (item.getPicture() == null)
                {
                    viewHolder.getView(R.id.total_artical_leftimg).setVisibility(View.GONE);
                }
                else
                {
                    viewHolder.getView(R.id.total_artical_leftimg).setVisibility(View.VISIBLE);
                    for (int i = 0; i < item.getPicture().size(); i++)
                    {
                        photos.add(new PhotoInfoBean(item.getPicture().get(i).getBig(), item.getPicture().get(i).getSmall(), 320, 480));
                    }
                }

                ((MultiImageView)viewHolder.getView(R.id.total_artical_leftimg)).setList(photos);
                ((MultiImageView)viewHolder.getView(R.id.total_artical_leftimg)).setOnItemClickListener(new MultiImageView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(View view, int position)
                    {
                        findCategary = item;
                        if ("0".equals(item.getIs_pay()) || type == 1 || item.getIs_purchase() == 1)
                        {
                            //imagesize是作为loading时的图片size
                            ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                            List<String> photoUrls = new ArrayList<>();
                            for (PhotoInfoBean photoInfo : photos)
                            {
                                photoUrls.add(photoInfo.getBig());
                            }
                            ImagePagerActivity.startImagePagerActivity(getActivity(), photoUrls, position, imageSize);
                        }
                        else
                        {
                            initPaymentDialog(findCategary);
                        }
                    }

                });

                viewHolder.setText(R.id.total_artical_title, item.getTitle());
                viewHolder.setText(R.id.total_artical_content, item.getContent());
                viewHolder.setText(R.id.time, DateUtil.timeTick2DateNotSec(item.getTime()));
                viewHolder.setText(R.id.totalartical_buy_coin_numb, "x " + item.getPayCoin());
                viewHolder.setText(R.id.have_buyed_people, item.getPurchase() + "人已购买");

                viewHolder.getView(R.id.total_artical_to_buy).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        findCategary = item;
                        initPaymentDialog(item);
                    }
                });
            }
        };

        mNoteLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                FindCategaryBean findNote = mNoteList.get(position - 1);
                if ("0".equals(findNote.getIs_pay()) || type == 1 || findNote.getIs_purchase() == 1 || userId.equals(hostId))
                {
                    Intent intent = new Intent(getContext(), ArticalDetailsActivity.class);
                    intent.putExtra("aid", findNote.getId());
                    startActivity(intent);
                }
                else
                {
                    if (AccountUtils.getLoginInfo() && userId.equals(findNote.getUserid()))
                    {
                        Intent intent = new Intent(getContext(), ArticalDetailsActivity.class);
                        intent.putExtra("aid", findNote.getId());
                        startActivity(intent);
                    }
                    else
                    {
                        findCategary = findNote;
                        initPaymentDialog(findCategary);
                    }
                }
            }
        });
        mNoteLV.setAdapter(mNoteAdapter);
    }

    // 购买对话框
    private void initPaymentDialog(final FindCategaryBean bean)
    {
        buytDialog = new YNPayDialog.Builder(getActivity())
                .setHeight(0.3f)  //屏幕高度*0.3
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("此文章需要付费" + bean.getPayCoin() + "金币，是否付费阅读？")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        buytDialog.dismiss();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        if (AccountUtils.getLoginInfo())
                        {
                            if (currentCoin >= Integer.parseInt(bean.getPayCoin()))
                            {
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().buyArticle(getActivity(), YNCommonConfig.BUY_ARTICLE_URL, bean.getId(), userId, Integer.parseInt(bean.getPayCoin()),
                                                mHandler, YNCommonConfig.BUY_ARTICLE_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                YNToastMaster.showToast(getActivity(), "您的余额不足，请及时充值=="+currentCoin+"=="+bean.getPayCoin());
                            }
                        }
                        else
                        {
                            buytDialog.dismiss();
                            YNToastMaster.showToast(getActivity(), R.string.un_login_opreate_notice);
                            Intent intent = new Intent(getContext(), YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
            .build();
            buytDialog.show();
    }

    public void setmTag(int type) {
        this.type = type;
    }

    private void getNetData()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomNote(getContext(), YNCommonConfig.GET_LIVE_ROOM_NOTE_URL, userId, hostId,
                        type, mHandler, YNCommonConfig.GET_LIVE_ROOM_NOTE_FLAG, true, 500);
            }
        });
    }

    @Override
    public void onRefresh()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomNote(getContext(), YNCommonConfig.GET_LIVE_ROOM_NOTE_URL, userId, hostId,
                        type, mHandler, YNCommonConfig.ON_REFRESH, false, 500);
            }
        });
        mHandler.sendEmptyMessage(0);
    }

    @Override
    public void onLoadMore()
    {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mNoteLV.stopRefresh();
        mNoteLV.stopLoadMore();
        mNoteLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_empty:
            case R.id.iv_homepage_empty:
                getNetData();
                break;
        }
    }

    @Override
    protected void onResumeLazy()
    {
//        if (AccountUtils.getLoginInfo())
//        {
//            userId = AccountUtils.getAccountBean().getId();
//            mHandler.post(new Runnable()
//            {
//                @Override
//                public void run()
//                {
//                    UserHttpUtils.newInstance().getCurrentGoldCoin(getActivity(), YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, mHandler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);
//
//                }
//            });
//
//            mHandler.post(new Runnable()
//            {
//                @Override
//                public void run()
//                {
//                    UserHttpUtils.newInstance().getLiveRoomNote(getContext(), YNCommonConfig.GET_LIVE_ROOM_NOTE_URL, userId, hostId,
//                            type, mHandler, YNCommonConfig.GET_LIVE_ROOM_NOTE_FLAG, true, 500);
//                }
//            });
//        }

        super.onResumeLazy();
    }

    @Override
    protected void onDestroyViewLazy()
    {
        mHandler.removeCallbacks(mHandler.getLooper().getThread());
        super.onDestroyViewLazy();
    }

    private void loginRefreshUI()
    {
        if (AccountUtils.getLoginInfo())
        {
            if (homePageFlag == 1)
            {
                Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
                intent.putExtra("liveRoom", true);
                LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
            }
            else
            {
                Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
                intent.putExtra("liveRoom", false);
                LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
            }

            userId = AccountUtils.getAccountBean().getId();
            getCurrentCoin();
            getNetData();
        }
    }

    // 获取用户当前金币
    private void getCurrentCoin()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getCurrentGoldCoin(getContext(), YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, mHandler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == YNCommonConfig.ACTIVITY_RESULT)
        {
            loginRefreshUI();
        }
    }
}
