package com.yeneikeji.ynzhibo.view.mine;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.MessageCenterAdapter;
import com.yeneikeji.ynzhibo.database.CommentDao;
import com.yeneikeji.ynzhibo.database.DynamicDao;
import com.yeneikeji.ynzhibo.database.SystemMessageDao;
import com.yeneikeji.ynzhibo.fragment.YNBaseFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.ISelectChangeCallBack;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 消息中心内容界面
 * Created by Administrator on 2016/10/26.
 */
public class YNMsgContentFragment extends YNBaseFragment implements SmoothListView.ISmoothListViewListener {

    private SmoothListView lvMsg;

    static String TAG = "YNMsgContentFragment";

    private MessageCenterAdapter adapter;
    private List<MessageBean>    commentList;
    private List<MessageBean>    systemMsgtList = new ArrayList<>();
    private ISelectChangeCallBack callBack;
    private int                  msgType;
    private CommentDao           commentDao;
    private DynamicDao           dynamicDao;
    private SystemMessageDao     mSystemMessageDao;
    private  String mUserId;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
               /* case YNCommonConfig.GET_MY_COMMENT_THUMB_MESSAGE_FLAG:
                        if (msg.obj != null)
                        {
                            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                            if (baseBean.getCode() == 28)
                            {
                                try
                                {
                                    JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                                    Type type = new TypeToken<List<CommentBean>>() {}.getType();
                                    commentList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    commentDao.saveCommentList(commentList);
                                    commentList = commentDao.getCommentList();
                                    if (!commentList.isEmpty())
                                    {
                                        for (CommentBean commentBean : commentList)
                                        {
                                            dynamicDao.saveDynamic(commentBean.getPublish_content());
                                        }
                                    }
                                    adapter.updateData(commentList);
                                }
                                catch (JSONException e)
                                {
                                    e.printStackTrace();
                                }
                            }
                            else
                            {
                                //                            commentList = commentDao.getCommentList();
                                adapter.updateData(commentList);
                            }
                    }
                    else
                    {
                        commentList = commentDao.getCommentList();
                        adapter.updateData(commentList);
                    }
                    break;
*/
                case YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.i("cdy123", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.getJSONArray("data");
                                Type type = new TypeToken<List<MessageBean>>() {}.getType();
                                systemMsgtList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                //避免消息重复保存，保存之前清空
                                mSystemMessageDao.deleteAllRecord();
                                mSystemMessageDao.saveCommentList(systemMsgtList);
                                adapter.updateData(systemMsgtList);
                                lvMsg.stopRefresh();
                                lvMsg.stopLoadMore();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                            //联网但是没有登录的话跳转到登录界面
                        }else if(baseBean.getCode() == 29){
                            Intent intent=new Intent(getActivity(),YNLoginActivity.class);
                            getActivity().startActivity(intent);
                        }
                    }
                    break;
                case 0:
                    lvMsg.stopRefresh();
                    lvMsg.stopLoadMore();
                    break;
            }
        }
    };

    @Override
    public String getFragmentName() {
        return null;
    }

    @Override
    public void loginRefreshUI() {
    }

    @Override
    public void unLoginRefreshUI() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.fragment_msg_center_content,container,false);
        initView(rootView);
        initFragment();
        return rootView;
    }

    @Override
    protected void initView(View view)
    {
        lvMsg = (SmoothListView) view.findViewById(R.id.lvMsg);
        lvMsg.setLoadMoreEnable(false);
        lvMsg.setSmoothListViewListener(this);
    }

    public void setMsgType(int msgType) {
        this.msgType = msgType;
    }

    @Override
    protected void addEvents()
    {
        lvMsg.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if (msgType == 1)
                {
                    // 更新db
                    ContentValues values = new ContentValues();
                    values.put(SystemMessageDao.COLUMN_NAME_IS_READ, "1");
                    mSystemMessageDao.updateCommentOrThumb((systemMsgtList.get(position - 1).getId()), values);
                    MessageBean msgBean = systemMsgtList.get(position - 1);
                    msgBean.setIs_read("1");
                    adapter.updateData(systemMsgtList);
                    switch (msgBean.getMessage_type()) {
                        case "6":
//                            Intent      intent     = new Intent(mContext, MessageDetailsActivity.class);
//                            intent.putExtra(YNCommonConfig.OBJECT, msgBean);
//                            getActivity().startActivity(intent);
                             break;
                        default:
                            Intent      intent1 = new Intent(mContext, YNMessageDetailsActivity.class);
                            intent1.putExtra("data",systemMsgtList.get(position-1));
                            getActivity().startActivity(intent1);
                        break;
                    }

                }
            }
        });
    }

    @Override
    protected void settingDo()
    {
      /*  commentDao = new CommentDao(mContext);
        dynamicDao = new DynamicDao(mContext);*/

        if (AccountUtils.getLoginInfo())
        {
            mUserId=AccountUtils.getAccountBean().getId();
        }

        mSystemMessageDao = new SystemMessageDao(mContext);

        adapter = new MessageCenterAdapter(mContext, systemMsgtList, callBack, msgType);
        lvMsg.setAdapter(adapter);

        if (msgType == 0)
        {
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyCommentThumbMsg(mContext, YNCommonConfig.MY_COMMENT_THUMB_MESSAGE_URL, AccountUtils.getAccountBean().getId(), handler, YNCommonConfig.GET_MY_COMMENT_THUMB_MESSAGE_FLAG, false);
                }
            });
        }
        else
        {
            //是否联网
            if(YNBaseActivity.isConnectNet) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance()
                                     .getMySystemMsg(mContext,
                                                     YNCommonConfig.MY_SYSTEM_MESSAGE_URL,
                                                     mUserId,
                                                     handler,
                                                     YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG,
                                                     true);
                    }
                },1000);

            }else{
                systemMsgtList=mSystemMessageDao.getCommentList();
                adapter.updateData(systemMsgtList);
                lvMsg.stopRefresh();
            }
        }


    }

    public void setShowSelected(boolean flag)
    {
       if(adapter!= null)
       {
           adapter.setShowSelected(flag);
           adapter.notifyDataSetChanged();
       }
    }

    public void setAllSelected(boolean flag)
    {
        if(flag)
        {
            if(adapter!= null)
            {
                Map<Integer, Boolean> selectedItem = adapter.getSelectedItem();
                for (int i = 0; i < selectedItem.size(); i++)
                {
                    selectedItem.put(i,true);
                }
                adapter.setSelectedItem(selectedItem);
                adapter.notifyDataSetChanged();
            }
        }
        else
        {
            if(adapter!= null)
            {
                Map<Integer, Boolean> selectedItem = adapter.getSelectedItem();
                for (int i = 0; i < selectedItem.size(); i++)
                {
                    selectedItem.put(i,false);
                }
                adapter.setSelectedItem(selectedItem);
                adapter.notifyDataSetChanged();
            }
        }
    }

    public void setCallBack(ISelectChangeCallBack callBack)
    {
        this.callBack = callBack;
    }

    public void delete()
    {
        Map<Integer, Boolean> selectedItem = adapter.getSelectedItem();
        if(systemMsgtList!=null&&systemMsgtList.size()>0) {
            for (int i = systemMsgtList.size() - 1; i >= 0; i--) {
                if (selectedItem.get(i)) {
                    mSystemMessageDao.deleteCommentOrThumb(Integer.parseInt(systemMsgtList.get(i)
                                                                                          .getId()));
                    systemMsgtList.remove(i);
                    selectedItem.remove(i);
                }
            }
            adapter.setSelectedItem(selectedItem);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRefresh()
    {
        //是否有网
        if(YNBaseActivity.isConnectNet) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMySystemMsg(mContext,
                                                 YNCommonConfig.MY_SYSTEM_MESSAGE_URL,
                                                 AccountUtils.getAccountBean()
                                                             .getId(),
                                                 handler,
                                                 YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG,
                                                 true);
                }
            },1000);

        }else{
            systemMsgtList=mSystemMessageDao.getCommentList();
            adapter.updateData(systemMsgtList);
            lvMsg.stopRefresh();
        }

    }

    @Override
    public void onLoadMore()
    {
        new Thread()
        {
            @Override
            public void run()
            {
                SystemClock.sleep(1000);
                handler.sendEmptyMessage(1);
            }
        }.start();
    }
}

