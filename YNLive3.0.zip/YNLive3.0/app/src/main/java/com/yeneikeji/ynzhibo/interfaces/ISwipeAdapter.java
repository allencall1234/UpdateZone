package com.yeneikeji.ynzhibo.interfaces;

public interface ISwipeAdapter {
    public int getSwipeLayoutResourceId(int position);
}
