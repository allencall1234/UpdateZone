package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.List;

/*
* 这是正在审核的观点界面
* */
public class ExamingActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private ListView mListView;
    private List<RecordVideoBean> mDatas;
    private String mPointType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_examing);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }
    @Override
    protected void initView() {
        mPointType = getIntent().getStringExtra("pointType");
        mDatas = (List<RecordVideoBean>) getIntent().getSerializableExtra("comefrom");
        mListView = (ListView) findViewById(R.id.examing_point_listview);
        mListView.setDivider(null);
        if(mPointType.equals("examing")){
            configTopBarCtrollerWithTitle("正在审核观点");
        }else if(mPointType.equals("refuse")){
            configTopBarCtrollerWithTitle("被驳回观点");
        }

    }

    @Override
    protected void addEvent() {
        MyAdapter adapter=new MyAdapter(mDatas);
        mListView.setAdapter(adapter);
        getLeftBtn().setOnClickListener(this);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent =new Intent(ExamingActivity.this, ExamingDetailsActivity.class);
                if(mPointType.equals("examing")){
                    intent.putExtra("pointType","examing");
                 }else if(mPointType.equals("refuse")){
                    intent.putExtra("pointType","refuse");
            }
                intent.putExtra("RecordVideoBean",mDatas.get(position));
                startActivity(intent);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
    class  MyAdapter extends BaseAdapter{
        private List<RecordVideoBean> mDatas;
        public MyAdapter(List<RecordVideoBean> datas) {
            mDatas = datas;
        }


        @Override
        public int getCount() {
            if(mDatas!=null){
                return  mDatas.size();
            }
            return 0;
        }

        @Override
        public RecordVideoBean getItem(int position) {
            if(mDatas!=null){
                return  mDatas.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder=null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView=View.inflate(ExamingActivity.this,R.layout.examing_point_listview_item,null);
                holder.typeIv= (ImageView) convertView.findViewById(R.id.type_iv);
                holder.titleTv= (TextView) convertView.findViewById(R.id.title_tv);
                holder.timeTv= (TextView) convertView.findViewById(R.id.time_tv);
                convertView.setTag(holder);
            }else{
                holder= (ViewHolder)convertView.getTag();
            }
            RecordVideoBean recordVideoBean = mDatas.get(position);
            holder.titleTv.setText(recordVideoBean.getTitle());
            holder.timeTv.setText(DateUtil.timeStamp2StringSHort(recordVideoBean.getTime()));
            return convertView;
        }
        class ViewHolder{
            private ImageView typeIv;
            private TextView titleTv;
            private  TextView timeTv;
        }
    }
}
