package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.tb.emoji.Emoji;
import com.tb.emoji.EmojiUtil;
import com.tb.emoji.FaceFragment;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.CommentBean;
import com.yeneikeji.ynzhibo.model.CommentItemBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.rongcloud.EmojiManager;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.CommentListView;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 动态正文界面
 * Created by Administrator on 2016/11/18.
 */
public class DynamicDetailsActivity extends YNBaseTopBarActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener, FaceFragment.OnEmojiClickListener
{
    private SmoothListView mCommentLV;
    private ImageView mHeadIV;
    private TextView mUNameTV;
    private TextView mCreateTimeTV;
    private TextView mContent;
    private TextView mFocuseOn;
    private ImageView mMore;
    private MultiImageView multiImgView;

    private TextView mCommentBarTV;
    private TextView mThumbBarTV;
    private ImageView mCommentIndicatorIV;
    private ImageView mThumbIndicatorIV;
    private RelativeLayout mRLSortTitle;
    private ImageView mSortIV;
    private TextView mSortTitleTV;

    private LinearLayout mCommentLL;
    private LinearLayout mThumbLL;
    private TextView mCommentNum;
    private TextView mThumbNum;
    private ImageView mThumbIV;

    private RelativeLayout mRLCommentEmpty;
    private CommentListView commentListView;

    private LinearLayout ll_input_bar;
    private LinearLayout mEditContentLL;
    private ImageView mBottomThumb;
    private EditText mEditTextContent;
    private ImageView emojiBtn;
    private TextView sendBtn;
//    private EmojiBoard emojiBoard;
    private FrameLayout emojiBoard;

    private DynamicBean dynamicBean;
//    private boolean isShow;

    private CommonAdapter mCommentAdapter;
//    private BaseAdapter mThumbAdapter;
//    private List<ThumbBean> mThumbList;
//    private List<PhotoInfoBean> mPhotoList;
    private List<CommentBean> commentList = new ArrayList<>();
    private List<CommentItemBean> commentItemList;

    private YNCommonDialog dialog;
    private int titleType;
    private int isSort = 1;
    private String userId;
    private CommentBean commentBean;
    private String beReplyName;
    private String commentContent;
    private int beReplyUserId;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_USER_COMMENTS_LIST_FLAG:
                    mCommentLV.setVisibility(View.VISIBLE);
                    ll_input_bar.setVisibility(View.VISIBLE);
                    mRLCommentEmpty.setVisibility(View.GONE);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
//                            commentList.removeAll(commentList);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("comment");
                                Type type = new TypeToken<List<CommentBean>>() {}.getType();
                                commentList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mCommentAdapter.updateListView(commentList);
                            } catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

//                            mCommentLV.setLoadMoreEnable(false);
                        }
                        else
                        {

                        }

//                        YNToastMaster.showToast(DynamicDetailsActivity.this, baseBean.getInfo());
                    }
                    else
                    {
//                        mRLCommentEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(DynamicDetailsActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.GET_USER_THUMB_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {

                        }
                    }
                    break;

                case YNCommonConfig.COMMUNITY_USER_THUMB_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 34)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                int thumb = object.getInt("thumb");
                                int thumb_num = object.getJSONObject("data").getInt("zan_num");
                                String cid = object.getJSONObject("data").getString("id");
//                                for (NewDynamicBean dynamicBean : dynamicList)
//                                {
//                                    if (cid.equals(dynamicBean.getId()))
//                                    {
//                                        dynamicBean.setThumb(thumb);
//                                        dynamicBean.setZan_num(thumb_num);
//                                        break;
//                                    }
//                                }
                                mThumbBarTV.setText("点赞 " + thumb_num);
                                mThumbNum.setText(thumb_num + "");
                                mThumbIV.setImageResource(thumb == 1 ? R.drawable.like_red : R.drawable.like);
                                mBottomThumb.setImageResource(thumb == 1 ? R.drawable.like_red : R.drawable.like);
                                dynamicBean.setThumb(thumb);
                                dynamicBean.setZan_num(thumb_num);
//                                mCommentAdapter.notifyDataSetChanged();
                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(DynamicDetailsActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(DynamicDetailsActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.COMMUNITY_USER_COMMENT_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43)
                        {
                            beReplyUserId = 0;
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                CommentBean commentBean = YNJsonUtil.JsonToBean(object.getString("data"), CommentBean.class);
                                commentList.add(commentBean);
                                setCommentThumbNum(mCommentBarTV, mThumbBarTV, dynamicBean.getComment_num() + 1, dynamicBean.getZan_num());
                                mEditTextContent.getText().clear();
                                if (commentList != null) {
                                    mCommentLV.setSelection(commentList.size());
                                }
                                mCommentAdapter.notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        YNToastMaster.showToast(DynamicDetailsActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(DynamicDetailsActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43)
                        {
                            dynamicBean.setIs_attention(1);
                            mFocuseOn.setVisibility(View.VISIBLE);
                            mFocuseOn.setText("已关注");
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13) {
                            dynamicBean.setIs_attention(0);
                            mFocuseOn.setVisibility(View.VISIBLE);
                            mFocuseOn.setText("+关注");
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.COMMUNITY_COMMENTS_LIST_THUMB_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 34)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                int thumb = object.getInt("thumb");
                                if (thumb == 1)
                                {
                                    commentBean.setThumb(thumb);
                                    commentBean.setZanCount(object.getJSONObject("data").getInt("zanCount"));
                                }
                                else
                                {
                                    commentBean.setThumb(thumb);
                                    commentBean.setZanCount(commentBean.getZanCount() - 1);
                                }
                                mCommentAdapter.notifyDataSetChanged();
                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(DynamicDetailsActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(DynamicDetailsActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        YNLogUtil.i("cdy123", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("comment");
                                Type type = new TypeToken<List<CommentBean>>() {}.getType();
                                commentList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mCommentAdapter.updateListView(commentList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(DynamicDetailsActivity.this, R.string.request_fail);
                    }
                    onStopLoad();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
//        isShow = getIntent().getBooleanExtra(YNCommonConfig.ISSHOW, isShow);
        dynamicBean = (DynamicBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
        configTopBarCtrollerWithTitle(getString(R.string.dynamic_content));

        mCommentLV = (SmoothListView) findViewById(R.id.lv_comment);
        mRLCommentEmpty = (RelativeLayout) findViewById(R.id.empty);

        ll_input_bar = (LinearLayout) findViewById(R.id.ll_input_bar);
        mBottomThumb = (ImageView) findViewById(R.id.iv_thumb);
        mEditContentLL = (LinearLayout) findViewById(R.id.ll_comment_object);
        mEditTextContent = (EditText) findViewById(R.id.tv_editor);
        emojiBtn = (ImageView) findViewById(R.id.iv_emoji_btn);
        sendBtn = (TextView) findViewById(R.id.tv_send);
        emojiBoard = (FrameLayout) findViewById(R.id.frameLayou_emoji);
//        emojiBoard = (EmojiBoard) findViewById(R.id.input_emoji_board);

        FaceFragment faceFragment = FaceFragment.Instance();
        getSupportFragmentManager().beginTransaction().add(R.id.frameLayou_emoji,faceFragment).commit();

        mCommentLV.addHeaderView(addHeadView());
        mCommentLV.addHeaderView(addFloatView());

        mCommentLV.setVisibility(View.GONE);
        ll_input_bar.setVisibility(View.GONE);
    }

    /**
     * 初始化头部详情布局
     * @return
     */
    private View addHeadView()
    {
        View headView = getLayoutInflater().inflate(R.layout.dynamic_item, null);
        mHeadIV = (ImageView) headView.findViewById(R.id.iv_head);
        mUNameTV = (TextView) headView.findViewById(R.id.tv_uname);
        mCreateTimeTV = (TextView) headView.findViewById(R.id.tv_create_time);
        mContent = (TextView) headView.findViewById(R.id.tv_content);
        mFocuseOn = (TextView) headView.findViewById(R.id.tv_focus_on);
        mMore = (ImageView) headView.findViewById(R.id.iv_more);
        multiImgView = (MultiImageView) headView.findViewById(R.id.multiImgView);
        mCommentLL = (LinearLayout) headView.findViewById(R.id.ll_comment);
        mThumbLL = (LinearLayout) headView.findViewById(R.id.ll_thumb);
        mCommentNum = (TextView) headView.findViewById(R.id.tv_comment_num);
        mThumbNum = (TextView) headView.findViewById(R.id.tv_praise_num);
        mThumbIV = (ImageView) headView.findViewById(R.id.iv_praise);
//        mCommentLL.setVisibility(View.GONE);
//        mThumbLL.setVisibility(View.GONE);
        return  headView;
    }

    /**
     * 初始化顶部评论、点赞
     * @return
     */
    private View addFloatView()
    {
        View floatView = getLayoutInflater().inflate(R.layout.dynamic_details_floatview, null);
        mCommentBarTV = (TextView) floatView.findViewById(R.id.tv_commentBar);
        mThumbBarTV = (TextView) floatView.findViewById(R.id.tv_thumbBar);
        mCommentIndicatorIV = (ImageView) floatView.findViewById(R.id.iv_comment_indicator);
        mThumbIndicatorIV = (ImageView) floatView.findViewById(R.id.iv_thumb_indicator);
        mRLSortTitle = (RelativeLayout) floatView.findViewById(R.id.rl_sort_title);
        mSortIV = (ImageView) floatView.findViewById(R.id.iv_sort);
        mSortTitleTV = (TextView) floatView.findViewById(R.id.tv_sort_title);

        return  floatView;
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mHeadIV.setOnClickListener(this);
        mFocuseOn.setOnClickListener(this);
        mMore.setOnClickListener(this);
        mBottomThumb.setOnClickListener(this);
        mCommentLV.setSmoothListViewListener(this);
        mCommentLV.setLoadMoreEnable(false);
        mRLSortTitle.setOnClickListener(this);

        mCommentLV.setOnScrollListener(new AbsListView.OnScrollListener()
        {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
                if (YNCommonUtils.isShowSoftInput(DynamicDetailsActivity.this))
                {
                    YNCommonUtils.hideSoftInput(DynamicDetailsActivity.this, view);
//                    if (scrollState == SCROLL_STATE_IDLE)
//                        ll_input_bar.setVisibility(View.VISIBLE);
//                    else
//                        ll_input_bar.setVisibility(View.GONE);
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
            {

            }
        });

        mCommentLV.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
        {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
            {

                return false;
            }
        });

        mCommentBarTV.setOnClickListener(this);
        mThumbBarTV.setOnClickListener(this);

        sendBtn.setOnClickListener(this);

        mEditTextContent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                emojiBoard.setVisibility(View.GONE);
                emojiBtn.setSelected(false);
            }
        });

        mEditTextContent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                mEditContentLL.setSelected(hasFocus);
                emojiBoard.setVisibility(View.GONE);
                emojiBtn.setSelected(false);
            }
        });

        mEditTextContent.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s)
            {
                sendBtn.setEnabled(!s.toString().isEmpty());
                // 解决输入法不能连续输入中文
//                int start = mEditTextContent.getSelectionStart();
//                int end = mEditTextContent.getSelectionEnd();
//                mEditTextContent.removeTextChangedListener(this);
//                CharSequence cs = EmojiManager.parse(s.toString(), mEditTextContent.getTextSize());
//                mEditTextContent.setText(cs, TextView.BufferType.SPANNABLE);
//                mEditTextContent.setSelection(start, end);
//                mEditTextContent.addTextChangedListener(this);
            }
        });

        emojiBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                emojiBoard.setVisibility(emojiBoard.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                emojiBtn.setSelected(emojiBoard.getVisibility() == View.VISIBLE);
                YNCommonUtils.hideSoftInput(DynamicDetailsActivity.this, view);
            }
        });

        sendBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (AccountUtils.getLoginInfo())
                {
                    //发布评论
                    commentContent = mEditTextContent.getText().toString();
                    if(TextUtils.isEmpty(commentContent))
                    {
                        YNToastMaster.showToast(DynamicDetailsActivity.this, "评论内容不能为空！");
                        return;
                    }

                    if (!TextUtils.isEmpty(beReplyName))
                        commentContent = "回复 " + beReplyName + ":" + commentContent;

                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userComment(DynamicDetailsActivity.this, YNCommonConfig.COMMUNITY_USER_COMMENT_URL, dynamicBean.getId(), userId, commentContent, beReplyUserId, mHandler, YNCommonConfig.COMMUNITY_USER_COMMENT_FLAG, false);
                        }
                    });
                    YNToastMaster.showToast(DynamicDetailsActivity.this, beReplyUserId + "");
                    emojiBoard.setVisibility(View.GONE);
                    emojiBtn.setSelected(false);
                    YNCommonUtils.hideSoftInput(DynamicDetailsActivity.this, mEditTextContent);
                }
                else
                {
                    YNToastMaster.showToast(DynamicDetailsActivity.this, R.string.un_login_opreate_notice);
                }
            }
        });

//        emojiBoard.setItemClickListener(new EmojiBoard.OnEmojiItemClickListener() {
//            @Override
//            public void onClick(String code)
//            {
//                if (code.equals("/DEL"))
//                {
//                    mEditTextContent.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL));
//                }
//                else
//                {
//                    emojiCode = code;
//                    mEditTextContent.getText().insert(mEditTextContent.getSelectionStart(), code);
//                }
//            }
//        });

        // 点击屏幕区域关闭底部评论框
       /* mCommentLV.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (ll_input_bar.getVisibility() == View.VISIBLE)
                {
                    updateEditTextBodyVisible(View.GONE, null, "");
                }
                return false;
            }
        });*/

    }

    @Override
    protected void settingDo()
    {
        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();

        if (dynamicBean.getIs_attention() == 1)
        {
            mFocuseOn.setVisibility(View.VISIBLE);
            mFocuseOn.setText("已关注");
//            mFocuseOn.setTextColor(ContextCompat.getColor(this, R.color.followed_text_color));
//            mMore.setVisibility(View.VISIBLE);
//            mMore.setImageResource(R.drawable.arrow_down);
        }
        else
        {
            mFocuseOn.setVisibility(View.VISIBLE);
            mFocuseOn.setText("+关注");
//            mFocuseOn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_red));
            mMore.setVisibility(View.GONE);
        }

        if (AccountUtils.getLoginInfo())
        {
            if (dynamicBean.getUserid().equals(AccountUtils.getAccountBean().getId()))
            {
                mFocuseOn.setVisibility(View.GONE);
                mMore.setVisibility(View.VISIBLE);
                mMore.setImageResource(R.drawable.delet_comment);
            }
        }

        YNImageLoaderUtil.setImage(context, mHeadIV, dynamicBean.getIcon());
        mUNameTV.setText(dynamicBean.getUsername());
        mCreateTimeTV.setText(DateUtil.timeStamp2String(dynamicBean.getTime()));
        mContent.setText(dynamicBean.getContent());
        mCommentNum.setText(dynamicBean.getComment_num() + "");
        mThumbNum.setText(dynamicBean.getZan_num() + "");
        mThumbIV.setImageResource(dynamicBean.getThumb() == 1 ? R.drawable.like_red : R.drawable.like);
        mEditTextContent.setHint("评论 " +dynamicBean.getUsername());
        mBottomThumb.setImageResource(dynamicBean.getThumb() == 1 ? R.drawable.like_red : R.drawable.like);

        if (dynamicBean.getPicture() != null)
        {
//            String[] imgUrlList = item.getPicture();
            final List<PhotoInfoBean> photos = new ArrayList<>();

            for (int i = 0; i < dynamicBean.getPicture().size(); i++)
            {
                photos.add(new PhotoInfoBean(dynamicBean.getPicture().get(i).getBig(), dynamicBean.getPicture().get(i).getSmall(), 640, 792));
            }
            multiImgView.setVisibility(View.VISIBLE);
            multiImgView.setList(photos);
            multiImgView.setOnItemClickListener(new MultiImageView.OnItemClickListener()
            {
                @Override
                public void onItemClick(View view, int position)
                {
                    //imagesize是作为loading时的图片size
                    ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());

                    List<String> photoUrls = new ArrayList<String>();
                    for(PhotoInfoBean photoInfo : photos)
                    {
                        photoUrls.add(photoInfo.getBig());
                    }
                    ImagePagerActivity.startImagePagerActivity(context, photoUrls, position, imageSize);
                }
            });
        }
        else
        {
            if (dynamicBean.getPicture0() != null)
            {
                final List<PhotoInfoBean> photos = new ArrayList<>();
                photos.add(new PhotoInfoBean(dynamicBean.getPicture0(), dynamicBean.getSmallpicture0(), 640, 792));

                if (dynamicBean.getPicture1() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture1(), dynamicBean.getSmallpicture1(), 640, 792));
                if (dynamicBean.getPicture2() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture2(), dynamicBean.getSmallpicture2(), 640, 792));
                if (dynamicBean.getPicture3() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture3(), 640, 792));
                if (dynamicBean.getPicture4() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture4(), 640, 792));
                if (dynamicBean.getPicture5() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture5(), 640, 792));
                if (dynamicBean.getPicture6() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture6(), 640, 792));
                if (dynamicBean.getPicture7() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture7(), 640, 792));
                if (dynamicBean.getPicture8() != null)
                    photos.add(new PhotoInfoBean(dynamicBean.getPicture3(), dynamicBean.getSmallpicture8(), 640, 792));

                multiImgView.setVisibility(View.VISIBLE);
                multiImgView.setList(photos);
                multiImgView.setOnItemClickListener(new MultiImageView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(View view, int position)
                    {
                        //imagesize是作为loading时的图片size
                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());

                        List<String> photoUrls = new ArrayList<String>();
                        for(PhotoInfoBean photoInfo : photos)
                        {
                            photoUrls.add(photoInfo.getBig());
                        }
                        ImagePagerActivity.startImagePagerActivity(context, photoUrls, position, imageSize);
                    }
                });
            }
            else
            {
                multiImgView.setVisibility(View.GONE);
            }
        }


        setCommentThumbNum(mCommentBarTV, mThumbBarTV, dynamicBean.getComment_num(), dynamicBean.getZan_num());

        // 获取用户评论列表
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getUserCommentsList(DynamicDetailsActivity.this, YNCommonConfig.GET_USER_COMMENT_LIST_URL, userId, dynamicBean.getId(), isSort, mHandler, YNCommonConfig.GET_USER_COMMENTS_LIST_FLAG, true);
            }
        });

        mCommentAdapter = new CommonAdapter<CommentBean>(this, commentList, R.layout.comment_item)
        {
            @Override
            public void convert(final CommonViewHolder viewHolder, final CommentBean item)
            {
//                commentId = item.getId();
//                String content;
//                if (item.getContent().startsWith("＂") && item.getContent().endsWith("＂"))
//                {
//                    content = item.getContent().substring(1, item.getContent().length() - 1);
//                }
//                else
//                {
//                    content = item.getContent();
//                }
                viewHolder.getView(R.id.multiImageView).setVisibility(View.GONE);

                viewHolder.setImage(DynamicDetailsActivity.this, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_uname, item.getUsername());
                viewHolder.setText(R.id.tv_create_time, DateUtil.timeStamp2String(item.getTime()));
                viewHolder.setText(R.id.tv_praise_num, item.getZanCount() + "");
                viewHolder.setImageResource(R.id.iv_praise, item.getThumb() == 1 ? R.drawable.like_red : R.drawable.like);

                if (AccountUtils.getLoginInfo() && AccountUtils.getAccountBean().getId().equals(item.getUserid()))
                {
                    viewHolder.getView(R.id.iv_praise).setVisibility(View.INVISIBLE);
                    viewHolder.getView(R.id.tv_praise_num).setVisibility(View.INVISIBLE);
                    viewHolder.getView(R.id.iv_comment).setVisibility(View.INVISIBLE);
                }
//                if (item.getCallbackId() != 0)
//                {
//                    viewHolder.setText(R.id.tv_content, "回复" + item.getCallbackUsername() + ":" + item.getContent());
//                    ((YNMyTextView)viewHolder.getView(R.id.tv_content)).setSpecifiedTextsColor("回复" + item.getCallbackUsername() + ":" + item.getContent(), "回复", ContextCompat.getColor(DynamicDetailsActivity.this, R.color.ynkj_black));
//                    ((TextView)viewHolder.getView(R.id.tv_content)).setText(EmojiManager.parse("回复" + item.getCallbackUsername() + ":" + item.getContent(), ((TextView)viewHolder.getView(R.id.tv_content)).getTextSize())) ;
//                    ((YNMyTextView)viewHolder.getView(R.id.tv_content)).setSpecifiedTextsColor("回复" + item.getCallbackUsername() + ":" + item.getContent(), "回复", ContextCompat.getColor(DynamicDetailsActivity.this, R.color.ynkj_black));
//                    ((YNMyTextView)viewHolder.getView(R.id.tv_content)).setSpecifiedTextsColor("回复" + item.getCallbackUsername() + ":" + item.getContent(), item.getCallbackUsername(), ContextCompat.getColor(DynamicDetailsActivity.this, R.color.live_details_text_black));
//                }
//                else
//                {
//                    ((TextView)viewHolder.getView(R.id.tv_content)).setText(EmojiManager.parse(item.getContent(), ((TextView)viewHolder.getView(R.id.tv_content)).getTextSize()));
//                }
                ((TextView)viewHolder.getView(R.id.tv_content)).setText(EmojiManager.parse(item.getContent(), ((TextView)viewHolder.getView(R.id.tv_content)).getTextSize()));
                try
                {
                    EmojiUtil.handlerEmojiText(((TextView)viewHolder.getView(R.id.tv_content)), item.getContent(), DynamicDetailsActivity.this);
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                if (commentList == null)
                    viewHolder.getView(R.id.empty).setVisibility(View.VISIBLE);
                else
                    viewHolder.getView(R.id.empty).setVisibility(View.GONE);


                viewHolder.getView(R.id.iv_head).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        if (YNBaseActivity.isConnectNet)
                        {
                            Intent intent = new Intent();
                            intent.setClass(context, PersonalHomePageActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(YNCommonConfig.USER_ID, item.getUserid());
                            intent.putExtras(bundle);
                            if (AccountUtils.getLoginInfo())
                            {
                                if (AccountUtils.getAccountBean().getId().equals(item.getUserid()))
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, false);
                                }
                                else
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, true);
                                }
                            }
                            else
                            {
                                intent.putExtra(YNCommonConfig.ISSHOW, true);
                            }
                            context.startActivity(intent);
                        }
                        else
                        {
                            YNToastMaster.showToast(context, R.string.no_net);
                        }
                    }
                });

                viewHolder.getView(R.id.iv_comment).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        beReplyUserId = Integer.parseInt(item.getUserid());
                        YNToastMaster.showToast(DynamicDetailsActivity.this, item.getUserid());
                        beReplyName = item.getUsername();
                        mEditTextContent.setHint("回复 " + item.getUsername());
                        mEditTextContent.setFocusableInTouchMode(true);
                        mEditTextContent.setFocusable(true);
                        mEditTextContent.requestFocus();
                        YNCommonUtils.showSoftInput(context, mEditTextContent);
                    }
                });

                viewHolder.getView(R.id.iv_praise).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        commentBean = item;
                        if (AccountUtils.getLoginInfo())
                        {
                            mHandler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().communityCommentsListThumb(DynamicDetailsActivity.this, YNCommonConfig.COMMUNITY_COMMENTS_LIST_THUMB_URL, item.getCid(), userId, item.getId(),
                                            item.getThumb(), mHandler, YNCommonConfig.COMMUNITY_COMMENTS_LIST_THUMB_FLAG, false);
                                }
                            }, 1000);
                        }
                        else
                        {
                            YNToastMaster.showToast(DynamicDetailsActivity.this, R.string.un_login_opreate_notice);
                        }
                    }
                });
            }
        };

//        mCommentAdapter.setCirclePresenter(presenter);
        mCommentLV.setAdapter(mCommentAdapter);

    }

    /**
     * 设置评论、点赞的数量
     * @param comment
     * @param thumb
     * @param comments_count
     * @param thumbs_count
     */
    private void setCommentThumbNum(TextView comment, TextView thumb, int comments_count, int thumbs_count)
    {
        comment.setText("评论 " + comments_count);
        thumb.setText("点赞 " + thumbs_count);
    }

//    private List<ThumbBean> getThumbList()
//    {
//        mThumbList = new ArrayList<>();
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//        mThumbList.add(new ThumbBean());
//
//        return mThumbList;
//    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.iv_head:
                if (YNBaseActivity.isConnectNet)
                {
                    intent.setClass(context, PersonalHomePageActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(YNCommonConfig.USER_ID, dynamicBean.getUserid());
                    intent.putExtras(bundle);
                    if (AccountUtils.getLoginInfo())
                    {
                        if (AccountUtils.getAccountBean().getId().equals(dynamicBean.getUserid()))
                        {
                            intent.putExtra(YNCommonConfig.ISSHOW, false);
                        }
                        else
                        {
                            intent.putExtra(YNCommonConfig.ISSHOW, true);
                        }
                    }
                    else
                    {
                        intent.putExtra(YNCommonConfig.ISSHOW, true);
                    }
                    context.startActivity(intent);
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
                break;

            case R.id.tv_commentBar:
                titleType = 0;
                mCommentBarTV.setTextColor(ContextCompat.getColor(this, R.color.live_details_text_blue));
                mCommentIndicatorIV.setVisibility(View.VISIBLE);
                mThumbBarTV.setTextColor(ContextCompat.getColor(this, R.color.ynkj_black));
                mThumbIndicatorIV.setVisibility(View.INVISIBLE);
                mCommentLV.setAdapter(mCommentAdapter);
                break;

            case R.id.tv_thumbBar:
                titleType = 1;
                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getUserThumbList(DynamicDetailsActivity.this, YNCommonConfig.GET_USER_THUMB_LIST_URL, dynamicBean.getId(),
                                mHandler, YNCommonConfig.GET_USER_THUMB_LIST_FLAG, false);
                    }
                }, 500);
                mCommentBarTV.setTextColor(ContextCompat.getColor(this, R.color.ynkj_black));
                mCommentIndicatorIV.setVisibility(View.INVISIBLE);
                mThumbBarTV.setTextColor(ContextCompat.getColor(this, R.color.live_details_text_blue));
                mThumbIndicatorIV.setVisibility(View.VISIBLE);
                mCommentLV.setAdapter(mCommentAdapter);
                break;

            case R.id.rl_sort_title:
                if (isSort == 1)
                    isSort = 0;
                else
                    isSort = 1;
                mSortIV.setImageResource(isSort == 1 ? R.drawable.comment_hot : R.drawable.comment_time);
                mSortTitleTV.setText(isSort == 1 ? "按热度" : "按时间");
                // 获取用户评论列表
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getUserCommentsList(DynamicDetailsActivity.this, YNCommonConfig.GET_USER_COMMENT_LIST_URL, userId, dynamicBean.getId(), isSort, mHandler, YNCommonConfig.GET_USER_COMMENTS_LIST_FLAG, false);
                    }
                });
                break;

/*            case R.id.iv_comment:
                if (ll_input_bar.getVisibility() == View.VISIBLE)
                {
                    updateEditTextBodyVisible(View.GONE, null, "");
                }
                else
                {
                    updateEditTextBodyVisible(View.VISIBLE, null, "");
                }
                break;*/

          /*  case R.id.iv_praise:
                mPraiseIV.setImageResource(isThumb ? R.drawable.like_red : R.drawable.like_big);
                mPraiseIV.startAnimation(AnimationUtils.loadAnimation(this, R.anim.thumb_anim));
                isThumb = !isThumb;
                break;*/

            case R.id.iv_more:
//                if (item.getUserid().equals(AccountUtils.getAccountBean().getId()))
//                {
                    dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.delete_dynamic_notice), false, new YNCommonDialog.CustomDialogListener() {
                        @Override
                        public void OnClick(View view)
                        {
                            switch (view.getId())
                            {
                                case R.id.btnCancel:
                                    dialog.dismiss();
                                    break;

                                case R.id.btnConfirm:
                                    dialog.dismiss();
                                    mHandler.postDelayed(new Runnable()
                                    {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance().deletePersonalDynamic(context, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_URL, dynamicBean.getId(), mHandler, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_FLAG, true);
                                        }
                                    }, 1000);
                                    break;
                            }
                        }
                    });
                    dialog.show();
//                }
                break;

            case R.id.tv_focus_on:
                if (AccountUtils.getLoginInfo())
                {
                    if (dynamicBean.getIs_attention() == 1)
                    {
                        dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.cancel_attention_user), false, new YNCommonDialog.CustomDialogListener()
                        {
                            @Override
                            public void OnClick(View view)
                            {
                                switch (view.getId())
                                {
                                    case R.id.btnCancel:
                                        dialog.dismiss();
                                        break;

                                    case R.id.btnConfirm:
                                        dialog.dismiss();
                                        mHandler.postDelayed(new Runnable()
                                        {
                                            @Override
                                            public void run()
                                            {
                                                UserHttpUtils.newInstance().cancelAttentionUser(context, YNCommonConfig.CANCEL_ATTENTION_USER_URL, userId, dynamicBean.getUserid(), mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, false);
                                            }
                                        }, 500);
                                        break;
                                }
                            }
                        });
                        dialog.show();
                    }
                    else
                    {
                        mHandler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().attentionUser(context, YNCommonConfig.ATTENTION_USER_URL, userId, dynamicBean.getUserid(), mHandler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                            }
                        }, 500);
                    }
                }
                else
                {

                }
                break;

            case R.id.iv_thumb:
                if (AccountUtils.getLoginInfo())
                {
                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userThumbUp(DynamicDetailsActivity.this, YNCommonConfig.COMMUNITY_USER_THUMB_URL, userId, dynamicBean.getId(), dynamicBean.getThumb(), mHandler, YNCommonConfig.COMMUNITY_USER_THUMB_FLAG, false);
                        }
                    }, 1000);
                }
                else
                {
                    YNToastMaster.showToast(this, R.string.un_login_opreate_notice);
                }
                break;
        }
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public void onRefresh()
    {
        // 获取用户评论列表
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getUserCommentsList(DynamicDetailsActivity.this, YNCommonConfig.GET_USER_COMMENT_LIST_URL, userId, dynamicBean.getId(), isSort, mHandler, YNCommonConfig.ON_REFRESH, false);
            }
        });
    }

    @Override
    public void onLoadMore()
    {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mCommentLV.stopRefresh();
        mCommentLV.stopLoadMore();
        mCommentLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void onEmojiClick(Emoji emoji)
    {
        if (emoji != null)
        {
            int index = mEditTextContent.getSelectionStart();
            Editable editable = mEditTextContent.getEditableText();
            if (index < 0) {
                editable.append(emoji.getContent());
            } else {
                editable.insert(index, emoji.getContent());
            }
            displayEditText();
        }
    }

    private void displayEditText() {
        try {
            EmojiUtil.handlerEmojiEditText(mEditTextContent, mEditTextContent.getText().toString(), this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onEmojiDelete()
    {
        String text = mEditTextContent.getText().toString();
        if (text.isEmpty()) {
            return;
        }
        if ("]".equals(text.substring(text.length() - 1, text.length()))) {
            int index = text.lastIndexOf("[");
            if (index == -1) {
                int action = KeyEvent.ACTION_DOWN;
                int code = KeyEvent.KEYCODE_DEL;
                KeyEvent event = new KeyEvent(action, code);
                mEditTextContent.onKeyDown(KeyEvent.KEYCODE_DEL, event);
                displayEditText();
                return;
            }
            mEditTextContent.getText().delete(index, text.length());
            displayEditText();
            return;
        }
        int action = KeyEvent.ACTION_DOWN;
        int code = KeyEvent.KEYCODE_DEL;
        KeyEvent event = new KeyEvent(action, code);
        mEditTextContent.onKeyDown(KeyEvent.KEYCODE_DEL, event);
        displayEditText();
    }

}
