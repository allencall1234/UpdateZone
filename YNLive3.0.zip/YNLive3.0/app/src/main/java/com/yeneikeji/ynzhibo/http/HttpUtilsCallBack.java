package com.yeneikeji.ynzhibo.http;

/**
 * Created by Administrator on 2017/5/8.
 */
public interface HttpUtilsCallBack
{
    /**
     * 请求成功，返回正常的数据时回调的方法
     * @param result 返回信息
     */
    void onSuccess(String result);

    /**
     * 请求失败、拦截到错误等，回调的方法
     */
    void onError();

}
