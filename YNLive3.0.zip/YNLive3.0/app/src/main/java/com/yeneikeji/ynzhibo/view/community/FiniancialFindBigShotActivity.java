package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;
import com.yeneikeji.ynzhibo.widget.weelwight.CenterTextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;
import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/*
* 发现经融页顶部的大咖页面
* */
public class FiniancialFindBigShotActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener,SmoothListView.ISmoothListViewListener

{
    private SmoothListView mSmoothListView;
    private  List<FindCategaryBean> data1s=new ArrayList<>();
    private  List<FindCategaryBean> data2s=new ArrayList<>();;
    private ListViewAdapter adapter;
    private  String userid;
    private String       toBuyArticalaid;
    private String       toBuyArticalCoin;//记录要买文章的费用，以便更新本地保存的用户余额状态
    private YNPayDialog buytDialog;
    private YNPayDialog followDialog;
    private String       anchorFollowId;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.BIG_SHOT_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {

                                    JSONArray array = jsonObject.getJSONArray("data1");
                                    Type      type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    List<FindCategaryBean>   data1= YNJsonUtil.JsonToLBean(array.toString(),
                                                                    type);
                                    if(data1!=null&&data1.size()>8) {
                                        for (int a = 0; a < 8; a++) {
                                            data1s.add(data1.get(a));
                                        }
                                    }else if(data1!=null){
                                        data1s=data1;
                                    }
                                    //列表数据
                                    JSONArray array2 = jsonObject.getJSONArray("data2");
                                    Type      type2  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    data2s = YNJsonUtil.JsonToLBean(array2.toString(),
                                                                    type2);
                                    mSmoothListView.addHeaderView(addHeadView());
                                     adapter=new ListViewAdapter(data2s);
                                    mSmoothListView.setAdapter(adapter);
                                }
                            } catch (JSONException e) {
                                mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }

                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    break;
                case YNCommonConfig.ON_REFRESH:
                    //记得清空 防止出现重复视图
                    if(data1s!=null){
                        data1s.removeAll(data1s);
                        mSmoothListView.removeHeaderView(mHeadView);
                    }
                    if(data2s!=null){
                        data2s.removeAll(data2s);
                    }

                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                mEmpty.setVisibility(View.GONE);
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    //顶部数据
                                    JSONArray array = jsonObject.getJSONArray("data1");
                                    Type      type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    List<FindCategaryBean>   data1= YNJsonUtil.JsonToLBean(array.toString(),
                                                                                           type);
                                    if(data1!=null&&data1.size()>8) {
                                        for (int a = 0; a < 8; a++) {
                                            data1s.add(data1.get(a));
                                        }
                                    }else if(data1!=null){
                                        data1s=data1;
                                    }
                                    //列表数据
                                    JSONArray array2 = jsonObject.getJSONArray("data2");
                                    Type      type2  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    data2s = YNJsonUtil.JsonToLBean(array2.toString(),
                                                                    type2);

                                    mSmoothListView.addHeaderView(addHeadView());
                                    if(data2s!=null) {
                                        adapter = new ListViewAdapter(data2s);
                                        mSmoothListView.setAdapter(adapter);
                                        adapter.notifyDataSetChanged();
                                    }else{
                                        mEmpty.setVisibility(View.VISIBLE);
                                    }
                                }
                            } catch (JSONException e) {
                                mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }
                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    mSmoothListView.stopRefresh();
                    break;
                //购买文章
                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 102) {
                            //购买成功
                            Toast.makeText(FiniancialFindBigShotActivity.this, "购买成功", Toast.LENGTH_SHORT)
                                 .show();
                            for (FindCategaryBean bean :data2s)
                            {
                                if (toBuyArticalaid.equals(bean.getId()))
                                {
                                    bean.setIs_purchase(1);
                                    //刷新数据
                                    adapter.updataData(data2s);
                                    //更新用户余额值
                                    UserInfoBean userInfoBean = AccountUtils.getAccountBean();
                                    userInfoBean.setCurrentCoin(userInfoBean.getCurrentCoin()-Integer.parseInt(toBuyArticalCoin));
                                    AccountUtils.saveAccountBean(userInfoBean);
                                    //跳转到文章详情页面
                                    Intent intent = new Intent(FiniancialFindBigShotActivity.this, ArticalDetailsActivity.class);
                                    intent.putExtra("aid", toBuyArticalaid);
                                    startActivity(intent);
                                    break;
                                }
                            }
                        }
                    }else
                    {
                        YNToastMaster.showToast(FiniancialFindBigShotActivity.this, "购买失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;
                //添加关注和取消关注
                case YNCommonConfig.ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43) {
                            //刷新数据
                            for (FindCategaryBean findCategaryBean : data2s)
                            {
                                if (findCategaryBean.getUserid().equals(anchorFollowId))
                                {
                                    findCategaryBean.setIs_attention(1);
                                }
                            }
                            adapter.updataData(data2s);
                        }

                    } else {
                        YNToastMaster.showToast(FiniancialFindBigShotActivity.this, getString(R.string.request_fail));
                    }
                    break;
                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13) {
                            //刷新数据
                            for (FindCategaryBean findCategaryBean : data2s)
                            {
                                if (findCategaryBean.getUserid().equals(anchorFollowId))
                                {
                                    findCategaryBean.setIs_attention(0);
                                }
                            }
                            adapter.updataData(data2s);
                            //弹出取消成功提示
                            YNToastMaster.showToast(FiniancialFindBigShotActivity.this, baseBean.getInfo());
                        }

                    } else {
                        YNToastMaster.showToast(FiniancialFindBigShotActivity.this, getString(R.string.request_fail));
                    }
                    break;
            }
        }

    };
    private RelativeLayout mEmpty;
    private View mHeadView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finiancial_find_big_shot);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("大咖");
        mSmoothListView = (SmoothListView) findViewById(R.id.smooth_listView);
        mSmoothListView.setLoadMoreEnable(false);
        mEmpty = (RelativeLayout) findViewById(R.id.empty);

        initData();
    }

    //加载网络数据
    private void initData() {
        if(AccountUtils.getLoginInfo()){
            userid=AccountUtils.getAccountBean().getId();
        }else{
            userid="";
        }
        //判断是否有网络
        if(YNBaseActivity.isConnectNet) {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getBigShotList(FiniancialFindBigShotActivity.this,
                                                 YNCommonConfig.GET_BIG_SHOT_URL,
                                                 userid,
                                                 mHandler,
                                                 YNCommonConfig.BIG_SHOT_FLAG,
                                                 true);
                }
            });
        }else{
            Toast.makeText(FiniancialFindBigShotActivity.this, "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }

    //添加头部view
    private View addHeadView() {
        mHeadView = View.inflate(this, R.layout.head_grideview, null);
        GridView gridView= (GridView) mHeadView.findViewById(R.id.gridleview);
        if(data1s!=null) {
            MyAdapter adapter = new MyAdapter(data1s);
            gridView.setAdapter(adapter);
        }
        return mHeadView;

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mSmoothListView.setSmoothListViewListener(this);
        mEmpty.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.empty:
                onRefresh();
                break;

        }
    }
//刷新数据
    @Override
    public void onRefresh() {
        //判断是否有网络
        if(YNBaseActivity.isConnectNet) {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getBigShotList(FiniancialFindBigShotActivity.this,
                                                 YNCommonConfig.GET_BIG_SHOT_URL,
                                                 userid,
                                                 mHandler,
                                                 YNCommonConfig.ON_REFRESH,
                                                 true);
                }
            });
        }else{
            Toast.makeText(FiniancialFindBigShotActivity.this, "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onLoadMore() {

    }
//gridleview的适配器
    class  MyAdapter extends BaseAdapter{
    private List<FindCategaryBean> datas;
    public MyAdapter(List<FindCategaryBean> datas) {
        this.datas = datas;
    }

    @Override
    public int getCount() {
        if(datas!=null){
            return  datas.size();
        }
        return 0;
    }
    @Override
    public FindCategaryBean getItem(int position) {
        if(datas!=null){
            return datas.get(position);
        }
        return null;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
             convertView=  View.inflate(FiniancialFindBigShotActivity.this,R.layout.grideview_item,null);
            YNCircleImageView      headiv           = (YNCircleImageView) convertView.findViewById(R.id.big_shot_grideview_item_iv);
            CenterTextView         tvName           = (CenterTextView) convertView.findViewById(R.id.author_name);
            final FindCategaryBean findCategaryBean = datas.get(position);
            YNImageLoaderUtil.setImage(FiniancialFindBigShotActivity.this, headiv, findCategaryBean.getIcon());
            tvName.setText(findCategaryBean.getUsername());

            headiv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(FiniancialFindBigShotActivity.this,FindAnchorHomeActivity.class);
                    intent.putExtra("userId",findCategaryBean.getUserid());
                    startActivity(intent);
                }
            });
        }
        return convertView;
    }
}
    //下面listview适配器
    class ListViewAdapter extends BaseAdapter{
        private List<FindCategaryBean> datas;

        public ListViewAdapter(List<FindCategaryBean> datas) {
            this.datas = datas;
        }
        public void updataData( List<FindCategaryBean> data){
            this.datas = data;
            notifyDataSetChanged();
        }
        @Override
        public int getCount() {
            if(datas!=null){
                return  datas.size();
            }
            return 0;
        }

        @Override
        public FindCategaryBean getItem(int position) {
            if(datas!=null){
                return datas.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView( int position, View convertView, ViewGroup parent) {
            ViewHolder holder=null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView=View.inflate(FiniancialFindBigShotActivity.this,R.layout.bigshot_listview_item,null);
                holder.headIv= (YNCircleImageView) convertView.findViewById(R.id.find_financial_listview_leftIvItem);
                holder.addFollow= (TextView) convertView.findViewById(R.id.add_fllow);
                holder.rightRl= (RelativeLayout) convertView.findViewById(R.id.rigth_relativell);
                holder.authorName=(TextView) convertView.findViewById(R.id.find_big_shot_author_name);
                holder.content=(TextView) convertView.findViewById(R.id.middle_content);
                holder.readPeople=(TextView) convertView.findViewById(R.id.hao_many_people_readed);
                holder.publishTime=(TextView) convertView.findViewById(R.id.publish_time);
                holder.paycoin=(TextView) convertView.findViewById(R.id.paycoin);
                convertView.setTag(holder);
            }else{
                holder= (ViewHolder) convertView.getTag();
            }
            final FindCategaryBean findCategaryBean = datas.get(position);
            YNImageLoaderUtil.setImage(FiniancialFindBigShotActivity.this, holder.headIv,findCategaryBean.getIcon());
            holder.authorName.setText(findCategaryBean.getUsername());
            holder.content.setText(findCategaryBean.getTitle());
            holder.readPeople.setText(findCategaryBean.getView()+"人阅读");
            holder.publishTime.setText(timeStamp2StringSHort(findCategaryBean.getTime()));
            //是否需要付费判断
            if(!findCategaryBean.getPayCoin().equals("0")||findCategaryBean.getIs_purchase()==0){
                holder.paycoin.setVisibility(View.VISIBLE);
                holder.paycoin.setText(findCategaryBean.getPayCoin()+"金币");
            }else{
                holder.paycoin.setVisibility(View.GONE);
            }
            //未关注
            if(findCategaryBean.getIs_attention()==0){
                holder.addFollow.setText("关注");
               holder.addFollow.setBackgroundResource(R.drawable.corners_red);
                holder.addFollow.setTextColor(ContextCompat.getColor(FiniancialFindBigShotActivity.this, R.color.ynkj_red));
            }else{
                holder.addFollow.setText("已关注");
               holder.addFollow.setBackgroundResource(R.drawable.corners_darkgray);
                holder.addFollow.setTextColor(ContextCompat.getColor(FiniancialFindBigShotActivity.this, R.color.ynkj_darkgray));
            }
            //点击头像
            holder.headIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(FiniancialFindBigShotActivity.this,FindAnchorHomeActivity.class);
                    intent.putExtra("userId",findCategaryBean.getUserid());
                    startActivity(intent);

                }
            });
            //点击关注按钮
            holder.addFollow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (AccountUtils.getLoginInfo()) {
                         //记录点击主播的id
                        anchorFollowId=findCategaryBean.getUserid();
                        if (findCategaryBean.getIs_attention() == 1) {
                            //弹出dialog提示用户
                            showFollowDialog(anchorFollowId);
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().attentionUser(FiniancialFindBigShotActivity.this, YNCommonConfig.ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), anchorFollowId, mHandler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                                }
                            });
                        }
                    }
                    else {
                        Intent intent = new Intent(mContext, YNLoginActivity.class);
                        mContext.startActivity(intent);

                    }

                }
            });
            //跳转到文章详情
            holder.rightRl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (findCategaryBean
                                    .getIs_pay()
                                    .equals("0")||findCategaryBean.getIs_purchase()==1)
                    {
                        Intent intent = new Intent(mContext, ArticalDetailsActivity.class);
                        intent.putExtra("aid",
                                        findCategaryBean
                                                    .getId());
                        startActivity(intent);
                    } else {
                        //登录了才能判断
                        if(AccountUtils.getLoginInfo()){
                            //需要购买,如果是自己发表的文章那个就不需要支付了
                            if(AccountUtils.getAccountBean().getId().equals(findCategaryBean.getUserid())){
                                Intent intent = new Intent(FiniancialFindBigShotActivity.this, ArticalDetailsActivity.class);
                                intent.putExtra("aid", findCategaryBean.getId());
                                startActivity(intent);
                            }else {
                                showBuyDialog(findCategaryBean.getPayCoin(),findCategaryBean.getId());
                            }

                        }else{
                            //跳转到登录界面
                            Intent intent = new Intent(FiniancialFindBigShotActivity.this, YNLoginActivity.class);
                            startActivity(intent);
                        }
                    }

                }
            });

            return convertView;
        }
        class ViewHolder{
            private YNCircleImageView headIv;
            private TextView          addFollow;
            private RelativeLayout    rightRl;
            private TextView          authorName;
            private TextView          content;
            private TextView          readPeople;
            private TextView          publishTime;
            private TextView          paycoin;
        }
        public void showBuyDialog(final String payCoin, final String aid) {
            toBuyArticalaid = aid;
            toBuyArticalCoin=payCoin;
            buytDialog = new YNPayDialog.Builder(FiniancialFindBigShotActivity.this)
                    .setHeight(0.3f)  //屏幕高度*0.3
                    .setWidth(0.65f)  //屏幕宽度*0.65
                    .setTitleVisible(true)
                    .setTitleText("温馨提示")
                    .setTitleTextColor(R.color.black_light)
                    .setContentText("此文章需要付费" + payCoin + "金币，是否付费阅读？")
                    .setContentTextColor(R.color.black_light)
                    .setLeftButtonText("取消")
                    .setLeftButtonTextColor(R.color.ynkj_black)
                    .setRightButtonText("确定")
                    .setRightButtonTextColor(R.color.live_details_text_blue)
                    .setCanceledOnTouchOutside(false)
                    .setOnclickListener(new IDialogOnClickListener() {
                        @Override
                        public void clickTopLeftButton(View view) {

                        }

                        @Override
                        public void clickTopRightButton(View view) {

                        }
                        //取消
                        @Override
                        public void clickBottomLeftButton(View view) {

                            buytDialog.dismiss();
                        }
                        //确定
                        @Override
                        public void clickBottomRightButton(View view) {
                            if (AccountUtils.getLoginInfo()) {
                                //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                                if (AccountUtils.getAccountBean()
                                                .getCurrentCoin() > Integer.parseInt(payCoin))
                                {

                                    toBuyArticalaid = aid;
                                    mHandler.post(new Runnable() {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance()
                                                         .buyArticle(FiniancialFindBigShotActivity.this,
                                                                     YNCommonConfig.BUY_ARTICLE_URL,
                                                                     aid,
                                                                    AccountUtils.getAccountBean().getId(),
                                                                     Integer.parseInt(payCoin),
                                                                     mHandler,
                                                                     YNCommonConfig.BUY_ARTICLE_FLAG,
                                                                     true);
                                        }
                                    });
                                    buytDialog.dismiss();

                                } else {
                                    Toast.makeText(mContext, "余额不足，请先充值再购买哦", Toast.LENGTH_SHORT)
                                         .show();
                                }
                            }else {
                                Toast.makeText(mContext, "请先登录哦，亲", Toast.LENGTH_SHORT)
                                     .show();
                                Intent intent = new Intent(mContext, YNLoginActivity.class);
                                mContext.startActivity(intent);
                            }
                            buytDialog.dismiss();
                        }
                        @Override
                        public void clickBottomButton(View view) {

                        }
                    })
                    .build();
            buytDialog.show();

        }
    }
      private void showFollowDialog(final String anchorFollowId) {
        followDialog= new YNPayDialog.Builder(FiniancialFindBigShotActivity.this)
                .setHeight(0.3f)  //屏幕高度*0.3
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("取消关注后你将会错过主播的精彩内容哦")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener(){
                    @Override
                    public void clickTopLeftButton(View view) {

                    }
                    @Override
                    public void clickTopRightButton(View view) {

                    }

                    @Override
                    public void clickBottomLeftButton(View view) {
                        followDialog.dismiss();
                    }

                    @Override
                    public void clickBottomRightButton(View view) {
                        //弹出dialog
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                UserHttpUtils.newInstance().cancelAttentionUser(FiniancialFindBigShotActivity.this, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), anchorFollowId, mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, false);

                            }
                        });
                        followDialog.dismiss();
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        followDialog.show();

    }
}