package com.yeneikeji.ynzhibo.view.live;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.cloud.media.player.IMediaPlayer;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.FullScreenUtils;
import com.yeneikeji.ynzhibo.utils.SharedPrefsStore;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.videoplayer.AdvancedMediaController;
import com.yeneikeji.ynzhibo.widget.videoplayer.BDCloudVideoView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class AdvancedPlayActivity extends YNBaseActivity implements IMediaPlayer.OnPreparedListener,
        IMediaPlayer.OnCompletionListener, IMediaPlayer.OnErrorListener,
        IMediaPlayer.OnInfoListener, IMediaPlayer.OnBufferingUpdateListener,
        BDCloudVideoView.OnPlayerStateListener
{
    private static final String TAG = "AdvancedPlayActivity";

    /**
     * 您的AK 请到http://console.bce.baidu.com/iam/#/iam/accesslist获取
     */
//    private String ak = "d913bf52f6494265a19eadf460e7aa3a"; // 请录入您的AK !!!

    private RecordVideoBean info;
    private ArrayList<RecordVideoBean> playList;
    private int position;
    /**
     * drm版权保护 drmToken的生成与使用方式，请联系百度客服。 使用时，搜索该类中涉及drmToken的地方，酌情修改。
     */
    // private String drmToken =
    // "100a44b2c672011782cc64152dd71b4f9ca7821ea46191ce71e003eb5039468b_vod-gaqrms5ix6xad5yk_1471004113";

    private BDCloudVideoView mVV = null;
    private AdvancedMediaController mediaController = null;
    private RelativeLayout headerBar = null;
    private RelativeLayout fullHeaderRl = null;
    private RelativeLayout fullControllerRl = null;
    private RelativeLayout normalHeaderRl = null;
    private RelativeLayout normalControllerRl = null;

    private RelativeLayout mViewHolder = null;
    private TextView mTVRelease = null;

    private Timer barTimer;
    private volatile boolean isFullScreen = false;
    private boolean isShowRelease = false;

    private YNPayDialog updateVideoDialog;

    /**
     * 记录播放位置
     */
    private int mLastPos = 0;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.RELEASE_VIDEO_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(AdvancedPlayActivity.this, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        YNToastMaster.showToast(AdvancedPlayActivity.this, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    mTVRelease.setClickable(true);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // 设置状态栏颜色
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = this.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            // finally change the color
            window.setStatusBarColor(0xff282828);
        }
        /**
         * 防闪屏
         */
        getWindow().setFormat(PixelFormat.TRANSLUCENT);

        setContentView(R.layout.activity_advanced_video_playing);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);

        position = getIntent().getIntExtra(YNCommonConfig.POSITION, position);
        playList = (ArrayList<RecordVideoBean>) getIntent().getSerializableExtra("List<RecordVideoBean>");
        isShowRelease = getIntent().getBooleanExtra(YNCommonConfig.ISSHOW, false);
//        info = (RecordVideoBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
        info = playList.get(position);
        initUI();
    }

    /**
     * 初始化界面
     */
    private void initUI() {
        mViewHolder = (RelativeLayout) findViewById(R.id.view_holder);
        mediaController = (AdvancedMediaController) findViewById(R.id.media_controller_bar);
        fullHeaderRl = (RelativeLayout) findViewById(R.id.rl_fullscreen_header);
        fullControllerRl = (RelativeLayout) findViewById(R.id.rl_fullscreen_controller);
        normalHeaderRl = (RelativeLayout) findViewById(R.id.rl_normalscreen_header);
        normalControllerRl = (RelativeLayout) findViewById(R.id.rl_normalscreen_controller);
        headerBar = (RelativeLayout) findViewById(R.id.rl_header_bar);

        mediaController.setVisibility(View.GONE);

        /**
         * 设置ak
         */
        BDCloudVideoView.setAK(YNCommonConfig.AK);

        mVV = new BDCloudVideoView(this);
        /**
         * 注册listener
         */
        mVV.setOnPreparedListener(this);
        mVV.setOnCompletionListener(this);
        mVV.setOnErrorListener(this);
        mVV.setOnInfoListener(this);
        mVV.setOnBufferingUpdateListener(this);
        mVV.setOnPlayerStateListener(this);

        if (SharedPrefsStore.isPlayerFitModeCrapping(getApplicationContext())) {
            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
        } else {
            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        }

        RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(-1, -1);
        rllp.addRule(RelativeLayout.CENTER_IN_PARENT);
        mViewHolder.addView(mVV, rllp);

        mediaController.setMediaPlayerControl(mVV);

        mVV.setLogEnabled(false);
//        mVV.setMaxProbeTime(1 * 1000); // 设置首次缓冲的最大时长
        
        mVV.setVideoPath(playList.get(position).getPlayableUrlList());
//        mVV.setVideoPath("rtmp://www.yeneilive.com/YNLive/96017525693");
        // 初始化好之后立即播放（您也可以在onPrepared回调中调用该方法）
        mVV.start();
        
        initOtherUI();
    }

    private void initOtherUI() {
        // header
        final ImageButton ibBack = (ImageButton) this.findViewById(R.id.ibtn_back);
        ibBack.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }

        });
        RelativeLayout rlback = (RelativeLayout) this.findViewById(R.id.rl_back);
        rlback.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                ibBack.performClick();
            }

        });
        TextView tvTitle = (TextView) this.findViewById(R.id.tv_top_title);
        tvTitle.setText(info.getTitle());
//        final ImageButton ibScreen = (ImageButton) this.findViewById(R.id.ibtn_screen_control);
//        ibScreen.setOnClickListener(new OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                if (isFullScreen) {
//                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
////                    FullScreenUtils.toggleHideyBar(AdvancedPlayActivity.this);
//                    // to mini size, to portrait
//                    fullHeaderRl.removeAllViews();
//                    fullControllerRl.removeAllViews();
//                    normalHeaderRl.addView(headerBar);
//                    normalControllerRl.addView(mediaController);
//                    isFullScreen = false;
//                    ibScreen.setBackgroundResource(R.drawable.btn_to_fullscreen);
//                } else {
//                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
////                    FullScreenUtils.toggleHideyBar(AdvancedPlayActivity.this);
//                    normalHeaderRl.removeAllViews();
//                    normalControllerRl.removeAllViews();
//                    fullHeaderRl.addView(headerBar);
//                    fullControllerRl.addView(mediaController);
//
//                    isFullScreen = true;
//                    ibScreen.setBackgroundResource(R.drawable.btn_to_mini);
//                    hideOuterAfterFiveSeconds();
//                }
//            }
//
//        });

        mTVRelease = (TextView) this.findViewById(R.id.tv_release);
        if (isShowRelease)
            mTVRelease.setVisibility(View.VISIBLE);
        else
            mTVRelease.setVisibility(View.GONE);
        mTVRelease.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mTVRelease.setClickable(false);
                updateVideoDialog = new YNPayDialog.Builder(AdvancedPlayActivity.this)
                        .setTitleText("")
                        .setContentText("您确定要上传此视频?")
                        .setContentTextSize(18)
                        .setCanceledOnTouchOutside(false)
                        .setRightButtonTextColor(R.color.live_details_text_blue)
                        .setOnclickListener(new IDialogOnClickListener()
                        {
                            @Override
                            public void clickTopLeftButton(View view)
                            {

                            }

                            @Override
                            public void clickTopRightButton(View view)
                            {

                            }

                            @Override
                            public void clickBottomLeftButton(View view)
                            {
                                updateVideoDialog.dismiss();
                            }

                            @Override
                            public void clickBottomRightButton(View view)
                            {
                                updateVideoDialog.dismiss();
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().releaseVideo(AdvancedPlayActivity.this, YNCommonConfig.RELEASE_VIDEO_URL, AccountUtils.getAccountBean().getId(), info.getMediaId(),
                                                mHandler, YNCommonConfig.RELEASE_VIDEO_FLAG, true);
                                    }
                                });
                            }

                            @Override
                            public void clickBottomButton(View view)
                            {

                            }
                        })
                        .build();
                updateVideoDialog.show();
            }
        });

        mediaController.setFullScreenButtonListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (isFullScreen) {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    FullScreenUtils.toggleHideyBar(AdvancedPlayActivity.this);
                    // to mini size, to portrait
                    fullHeaderRl.removeAllViews();
                    fullControllerRl.removeAllViews();
                    normalHeaderRl.addView(headerBar);
                    normalControllerRl.addView(mediaController);
                    isFullScreen = false;
                    mediaController.getFullScreenButton().setBackgroundResource(R.drawable.btn_to_fullscreen);
                } else {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    FullScreenUtils.toggleHideyBar(AdvancedPlayActivity.this);
                    normalHeaderRl.removeAllViews();
                    normalControllerRl.removeAllViews();
                    fullHeaderRl.addView(headerBar);
                    fullControllerRl.addView(mediaController);

                    isFullScreen = true;
                    mediaController.getFullScreenButton().setBackgroundResource(R.drawable.btn_to_mini);
                    hideOuterAfterFiveSeconds();
                }
            }
        });

        mediaController.setNextListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // fetch the next video. 为了demo的简便性，仅从主页列表获取
                if (playList == null) {
                    playList = SharedPrefsStore.getAllMainVideoFromSP(getApplicationContext());
                }
                int i = 0;
                int length = playList.size();
                for (i = 0; i < length; ++i) {
                    RecordVideoBean fInfo = playList.get(i);
                    if (fInfo.getPlayableUrlList().equals(info.getPlayableUrlList()) && fInfo.getTitle().equals(info.getTitle())) {
                        break;
                    }
                }
                if (i == length - 1) {
                    // is already the last one
                    YNToastMaster.showToast(getApplicationContext(), "已经是最后一个", Toast.LENGTH_SHORT, Gravity.CENTER);
                } else if (i < length - 1) {
                    // set the next info
                    info = playList.get(i + 1);
                    tryToPlayOther();
                    mediaController.clearViewContent();
                } else {
                    // i >= length, should not come in
                    Log.d(TAG, "i >= length, should not come in");
                }
            }

        });

        mediaController.setPreListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // fetch the pre video. 为了demo的简便性，仅从主页列表获取
                if (playList == null) {
                    playList = SharedPrefsStore.getAllMainVideoFromSP(getApplicationContext());
                }
                int i = 0;
                int length = playList.size();
                for (i = 0; i < length; ++i) {
                    RecordVideoBean fInfo = playList.get(i);
                    if (fInfo.getPlayableUrlList().equals(info.getPlayableUrlList()) && fInfo.getTitle().equals(info.getTitle())) {
                        break;
                    }
                }
                if (i == 0) {
                    // is already the first one
                    YNToastMaster.showToast(getApplicationContext(), "已经是第一个", Toast.LENGTH_SHORT, Gravity.CENTER);
                } else if (i < length) {
                    // set the next info
                    info = playList.get(i - 1);
                    tryToPlayOther();
                    mediaController.clearViewContent();
                } else {
                    // i >= length, should not come in
                    Log.d(TAG, "i >= length, should not come in");
                }
            }

        });

        mediaController.setDownloadListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
//                if (info.getUrl().startsWith("file://")) {
//                    Toast.makeText(AdvancedPlayActivity.this, "该资源已经是本地文件", Toast.LENGTH_SHORT).show();
//                    return;
//                } else if (!info.getUrl().endsWith(".m3u8")) {
//                    Toast.makeText(AdvancedPlayActivity.this, "抱歉，当前仅支持m3u8资源的下载", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                VideoDownloadManager downloadManagerInstance = VideoDownloadManager
//                        .getInstance(AdvancedPlayActivity.this, MainActivity.SAMPLE_USER_NAME);
//                DownloadableVideoItem item = downloadManagerInstance
//                        .getDownloadableVideoItemByUrl(info.getUrl());
//                if (item != null) {
//                    // already
//                    Toast.makeText(AdvancedPlayActivity.this, "该资源已经在缓存列表，请到「本地缓存」查看", Toast.LENGTH_SHORT).show();
//                } else {
//                    SharedPrefsStore.addToCacheVideo(AdvancedPlayActivity.this, info);
//                    SampleObserver sampleObs = new SampleObserver();
//                    DownloadObserverManager.addNewObserver(info.getUrl(), sampleObs);
//                    downloadManagerInstance.startOrResumeDownloader(info.getUrl(), sampleObs);
//                    Toast.makeText(AdvancedPlayActivity.this, "开始缓存，可到「本地缓存」查看进度", Toast.LENGTH_SHORT).show();
//                }
            }

        });

        if (!SharedPrefsStore.isDefaultPortrait(this)) {
            mediaController.getFullScreenButton().performClick();
        }
    }

    /**
     * 播放下一个视频源
     *
     * 下一个视频源可以是：
     * 一个全新的视频：反注释下面的reSetRender，清除上一个播放源的最后一帧；
     * 同一视频的另一种分辨率的新链接：1、在stopPlayback之前拿到当前播放位置；2、反注释setInitPlayPosition设置位置；
     */
    private void tryToPlayOther() {
        mVV.stopPlayback(); // 释放上一个视频源
//        mVV.setInitPlayPosition(1 * 1000); // 指定初始播放位置，单位为毫秒；
//        mVV.reSetRender(); // 清除上一个播放源的最后遗留的一帧
        mVV.setVideoPath(info.getPlayableUrlList());
        mVV.start();
    }

    boolean isPausedByOnPause = false;

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        Log.v(TAG, "onPause");

        // 当home键切出，想暂停视频的话，反注释下面的代码。同时要反注释onResume中的代码
//        if (mVV.isPlaying()) {
//            isPausedByOnPause = true;
//            mVV.pause();
//        }

    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        Log.v(TAG, "onResume");

        // 当home键切出，暂停了视频此时想回复的话，反注释下面的代码
//        if (isPausedByOnPause) {
//            isPausedByOnPause = false;
//            mVV.start();
//        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v(TAG, "onStop");
        // 在停止播放前 你可以先记录当前播放的位置,以便以后可以续播
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mVV != null) {
            mVV.stopPlayback(); // 释放播放器资源
            mVV.release(); // 释放播放器资源和显示资源
        }
        
        if (mediaController != null) {
            mediaController.release();
        }
        
        Log.v(TAG, "onDestroy");
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    /**
     * 检测'点击'空白区的事件，若播放控制控件未显示，设置为显示，否则隐藏。
     * 
     * @param v
     */
    public void onClickEmptyArea(View v) {
//        if (!isFullScreen) {
//            return;
//        }
        if (barTimer != null) {
            barTimer.cancel();
            barTimer = null;
        }
        if (this.mediaController != null) {
            if (mediaController.getVisibility() == View.VISIBLE) {
                mediaController.hide();
                headerBar.setVisibility(View.GONE);
            } else {
                mediaController.show();
                headerBar.setVisibility(View.VISIBLE);
                hideOuterAfterFiveSeconds();
            }
        }
    }

    private void hideOuterAfterFiveSeconds() {
//        if (!isFullScreen) {
//            return;
//        }
        if (barTimer != null) {
            barTimer.cancel();
            barTimer = null;
        }
        barTimer = new Timer();
        barTimer.schedule(new TimerTask() {

            @Override
            public void run() {
//                if (!isFullScreen) {
//                    return;
//                }
                if (mediaController != null) {
                    mediaController.getMainThreadHandler().post(new Runnable() {

                        @Override
                        public void run() {
                            mediaController.hide();
                            headerBar.setVisibility(View.GONE);
                        }

                    });
                }
            }

        }, 5 * 1000);

    }

    @Override
    public boolean onInfo(IMediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public boolean onError(IMediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public void onCompletion(IMediaPlayer mp) {
    }

    @Override
    public void onPrepared(IMediaPlayer mp) {
        
    }

    @Override
    public void onBufferingUpdate(IMediaPlayer mp, int percent) {
//        Log.d(TAG, "onBufferingUpdate percent=" + percent);
        if (mediaController != null && mVV != null) {
            mediaController.onTotalCacheUpdate(percent * mVV.getDuration() / 100);
        }
    }

    @Override
    public void onPlayerStateChanged(BDCloudVideoView.PlayerState nowState) {
        if (mediaController != null) {
            mediaController.changeState();
        }
    }
}
