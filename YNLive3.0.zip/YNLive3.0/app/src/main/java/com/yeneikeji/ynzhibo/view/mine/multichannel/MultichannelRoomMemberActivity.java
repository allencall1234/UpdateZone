package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RoomOwnerBean;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 多通通房间成员列表、
 * Created by Administrator on 2017/7/30.
 */
public class MultichannelRoomMemberActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private LinearLayout mLLMemberList;
    private LinearLayout mLLPriorityList;
    private TextView mTVMemberTitle;
    private TextView mTVPriorityTitle;
    private YNMyListView mLVMember;
    //private YNMyListView mLVPriority;
    private List<RoomOwnerBean> mMemberList = new ArrayList<>();
    private CommonAdapter mMemberAdapter;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_FLAG:
                    if (msg.obj != null)
                    {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 27)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray jsonArray = jsonObject.optJSONArray("data");
                            if (jsonArray != null)
                            {
                                Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                mMemberList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                mMemberAdapter.updateListView(mMemberList);
                            }
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                    break;
                //解绑子房间
                case YNCommonConfig.ENTER_CHILD_ROOM_UNBIND_FLAG:
                    Intent data =new Intent();
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("jjj",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            //解绑成功
                            data.putExtra("result", 28);
                            setResult(0x12,data);
                            Toast.makeText(context, "解绑成功", Toast.LENGTH_SHORT)
                                 .show();
                            finish();
                        }else{
                            data.putExtra("result", 27);
                            setResult(0x12,data);
                            Toast.makeText(context, "解绑失败", Toast.LENGTH_SHORT)
                                 .show();
                            finish();
                          }
                        }
                    break;
                //绑定情况
                case 1:


                break;
            }
            super.handleMessage(msg);
        }
    };
    private YNPayDialog mUnBindDialog;
    private String mRoomId;
    private String mUserId;
    private TextView mIntroduction;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichannel_live_room);
        initView();
        addEvent();
        settingDo();
    }
    @Override
    protected void initView()
    {

        boolean booleanExtra = getIntent().getBooleanExtra(YNCommonConfig.TITLE, false);
        mRoomId = getIntent().getStringExtra("roomid");
        mUserId = getIntent().getStringExtra("userid");
        mIntroduction = (TextView) findViewById(R.id.introduction);
    if(booleanExtra){
        configTopBarCtrollerWithTitle(mRoomId);
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setVisibility(View.VISIBLE);
       getRightTV().setText("解绑");
        getRightTV().setOnClickListener(this);
        getMultichannelRoomInfo(mUserId);
       } else {
        configTopBarCtrollerWithTitle("多通道直播房间");
        getRightTV().setVisibility(View.GONE);
        mIntroduction.setText("绑定情况");

    }
        mLLMemberList = (LinearLayout) findViewById(R.id.ll_member_list);
        mLLPriorityList = (LinearLayout) findViewById(R.id.ll_live_priority_list);
        mTVMemberTitle = (TextView) mLLMemberList.findViewById(R.id.tv_multichannel_title);
        mTVPriorityTitle = (TextView) mLLPriorityList.findViewById(R.id.tv_multichannel_title);
        mLVMember = (YNMyListView) mLLMemberList.findViewById(R.id.lv_multichannel_room);
       /* mTVMemberTitle.setText("成员列表");
        mTVPriorityTitle.setText("直播优先级");*/
    }
    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);

    }
    @Override
    protected void settingDo() 
    {
        mMemberAdapter = new CommonAdapter<RoomOwnerBean>(this, mMemberList, R.layout.item_multichannel_room) {
            @Override
            public void convert(CommonViewHolder viewHolder, RoomOwnerBean item)
            {
                if ("2".equals(item.getType()))
                {
                    viewHolder.setText(R.id.tv_role_name, "房主");
                    viewHolder.setText(R.id.tv_username, item.getUsername());
                }
                if ("1".equals(item.getType()))
                {
                    viewHolder.setText(R.id.tv_role_name, "副房主");
                    viewHolder.setText(R.id.tv_username, item.getUsername());
                }
                if ("0".equals(item.getType()))
                {
                    viewHolder.setText(R.id.tv_role_name, "房管");
                    viewHolder.setText(R.id.tv_username, item.getUsername());
                }
            }
        };
        mLVMember.setAdapter(mMemberAdapter);
       // mLVMember.setAdapter(mMemberAdapter);
    }

    /**
     * 房主进入多通道房间
     */
    private void getMultichannelRoomInfo(final String userid)
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
//                UserHttpUtils.newInstance().deputyOwnerManagerEnterIntoMultichannelRoom(MultichannelRoomMemberActivity.this, YNCommonConfig.DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_URL, AccountUtils.getAccountBean().getId(), mHandler,
//                        YNCommonConfig.DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_FLAG, true);

                UserHttpUtils.newInstance().deputyOwnerManagerEnterIntoMultichannelRoom(MultichannelRoomMemberActivity.this, YNCommonConfig.DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_URL, userid, mHandler,
                        YNCommonConfig.DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_FLAG, true);
            }
        });
    }
    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //解绑
            case R.id.star_1_com_topbar_tv_right:
                //弹出dialog
                mUnBindDialog = new YNPayDialog.Builder(MultichannelRoomMemberActivity.this)
                        .setContentText("您确定解绑"+mRoomId+"房间吗")
                        .setTitleVisible(true)
                        .setTitleText("")
                        .setContentTextSize(18)
                        .setRightButtonTextColor(R.color.ynkj_red)
                        .setCanceledOnTouchOutside(false)
                        .setOnclickListener(new IDialogOnClickListener() {
                            @Override
                            public void clickTopLeftButton(View view) {

                            }

                            @Override
                            public void clickTopRightButton(View view) {

                            }
                          //取消
                            @Override
                            public void clickBottomLeftButton(View view) {

                                mUnBindDialog.dismiss();
                            }
                           //确定
                            @Override
                            public void clickBottomRightButton(View view) {
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().EnterChildRoomUnbind(MultichannelRoomMemberActivity.this, YNCommonConfig.ENTER_CHILD_ROOM_UNBIND_URL, mUserId, mHandler,
                                                                                         YNCommonConfig.ENTER_CHILD_ROOM_UNBIND_FLAG, true);
                                    }
                                });
                                mUnBindDialog.dismiss();
                            }
                            @Override
                            public void clickBottomButton(View view) {

                            }
                        })      .build();
                mUnBindDialog.show();
                break;
        }
    }
}
