package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import cn.smssdk.EventHandler;

/**
 * 忘记密码界面
 */
public class YNForgetActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EventHandler eventHandler;
    private Handler handler;
    private RelativeLayout mRLForgetPassNotice;
    private TextView mTVNotice;
    private TextView txtIdentify;
    private EditText edtPhoneNum,edtCode;
    private TextView btnNext;
    private String phone;
    private String verificationCode;
    private int time = 60;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget_password);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.forgetpassword));

        mRLForgetPassNotice = (RelativeLayout) findViewById(R.id.rl_forget_pass_notice);
        mTVNotice = (TextView) findViewById(R.id.tv_notice);
        txtIdentify = (TextView) findViewById(R.id.txtIdentify);
        btnNext = (TextView) findViewById(R.id.btnNext);
        edtPhoneNum = (EditText) findViewById(R.id.edtPhoneNum);
        edtCode = (EditText) findViewById(R.id.edtCode);

    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        txtIdentify.setOnClickListener(new MyOnClickListener());
        btnNext.setOnClickListener(new MyOnClickListener());
    }

    @Override
    protected void settingDo()
    {
        handler = new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                super.handleMessage(msg);
                switch (msg.what)
                {
                    case YNCommonConfig.CODE_ING://已发送,倒计时
                        txtIdentify.setClickable(false);
                        txtIdentify.setText(time + "秒");
                        time--;
                        break;

                    case YNCommonConfig.CODE_REPEAT://重新发送
                        txtIdentify.setClickable(true);
                        txtIdentify.setText("重新发送");
                        break;

                    case YNCommonConfig.USER_FORGET_PASSWORD_FLAG:
                        if (msg.obj != null)
                        {
                            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                            if (baseBean.getCode() == 6)
                            {
                                txtIdentify.setClickable(false);
                                verificationCode = YNCommonUtils.getRandomSixNumber();
                                // 获取验证码
                                handler.postDelayed(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().userGetWebChineseSMSCode(YNForgetActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, phone, "验证码:" + verificationCode + "，你正在进行设置修改业内直播账号的手机号，此验证码10分钟内有效", handler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                                    }
                                }, 500);
                                time = 60;
                                txtIdentify.setClickable(false);
                                StartCountTime();
                            }
                            else
                            {
                                mRLForgetPassNotice.setVisibility(View.VISIBLE);
                                mTVNotice.setText("该用户未注册");
                            }

//                            YNToastMaster.showToast(YNForgetActivity.this, baseBean.getInfo());
                        }
                        else
                        {
                            YNToastMaster.showToast(YNForgetActivity.this, getString(R.string.request_fail));
                        }
//                        if (msg.obj != null)
//                        {
//                            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                            if (baseBean.getCode() == 6)
//                            {
//                                // 获取手机号
//                                String phoneNum = edtPhoneNum.getText().toString();
//                                // 跳转至设置密码界面
//                                Intent intent = new Intent(getApplicationContext(), YNSetPasswordActivity.class);
//                                // 保存手机号用于传递至下一界面
//                                intent.putExtra(YNCommonConfig.PHONE_NUMBER, phoneNum);
//                                // 用于标识下一界面 true为登录时忘记密码，不需输入原密码；false为修改密码，需输入原密码
//                                intent.putExtra(YNCommonConfig.FORGET_PASS, true);
//                                startActivity(intent);
////                                myApp.finishActivity(YNLoginActivity.class);
//                                finish();
//                            }
//                            else if (baseBean.getCode() == 0)
//                            {
//                                SMSSDK.getVerificationCode("86", phone);
//                                time = 60;
//                                txtIdentify.setClickable(false);
//                                new Thread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        for (int i = 60; i > 0; i--)
//                                        {
//                                            handler.sendEmptyMessage(YNCommonConfig.CODE_ING);
//                                            if (i <= 0)
//                                            {
//                                                break;
//                                            }
//                                            try
//                                            {
//                                                Thread.sleep(1000);
//                                            }
//                                            catch (InterruptedException e)
//                                            {
//                                                e.printStackTrace();
//                                            }
//                                        }
//                                        handler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
//                                    }
//                                }).start();
//                            }
//
//                            YNToastMaster.showToast(YNForgetActivity.this, baseBean.getInfo());
//                        }
//                        else
//                        {
//                            YNToastMaster.showToast(YNForgetActivity.this, getString(R.string.request_fail));
//                        }
                        break;

                    case YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG:
                        if (msg.obj != null)
                        {
                            mRLForgetPassNotice.setVisibility(View.VISIBLE);
                            if ("1".equals(msg.obj.toString()))
                                mTVNotice.setText("验证码已发送至" + phone);
                            else
                                mTVNotice.setText("验证码获取失败");
                        }
                        break;
                }
            }
        };
//        initSMSSDK();
    }

    /*private void initSMSSDK()
    {
        eventHandler = new EventHandler()
        {
            @Override
            public void afterEvent(int event, int result, Object data) {
                Message msg = new Message();
                msg.arg1 = event;
                msg.arg2 = result;
                msg.obj = data;
                msg.what = YNCommonConfig.SMSDDK_HANDLER;
                handler.sendMessage(msg);
            }
        };
        // 注册回调监听接口
        SMSSDK.registerEventHandler(eventHandler);

    }*/

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                Intent intent = new Intent(YNForgetActivity.this, YNLoginActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }

    private void StartCountTime() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                for (int i = 60; i > 0; i--)
                {
                    handler.sendEmptyMessage(YNCommonConfig.CODE_ING);
                    if (i <= 0)
                    {
                        break;
                    }
                    try
                    {
                        Thread.sleep(1000);
                        handler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    private class MyOnClickListener implements View.OnClickListener
    {
        @Override
        public void onClick(View v)
        {
            phone = edtPhoneNum.getText().toString();
            switch (v.getId())
            {
                case R.id.txtIdentify://获取验证码
                    if (TextUtils.isEmpty(phone) || (!YNCommonUtils.isCellPhone(phone)))
                    {
                        mRLForgetPassNotice.setVisibility(View.VISIBLE);
                        return;
                    }
                    else
                    {
                        mRLForgetPassNotice.setVisibility(View.GONE);
                    }
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userForgetPassword(YNForgetActivity.this, YNCommonConfig.USER_FORGET_PASSWORD_URL,
                                    phone, handler, YNCommonConfig.USER_FORGET_PASSWORD_FLAG, false);
                        }
                    }, 500);

//                    new AlertDialog.Builder(YNForgetActivity.this)
//                            .setTitle("发送短信")
//                            .setMessage("我们将把验证码发送到以下号码:\n"+"+86:"+phone)
//                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int which)
//                                {
//                                    SMSSDK.getVerificationCode("86", phone);
//                                    time = 60;
//                                    txtIdentify.setClickable(false);
//                                    new Thread(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            for (int i = 60; i > 0; i--) {
//                                                handler.sendEmptyMessage(YNCommonConfig.CODE_ING);
//                                                if (i <= 0) {
//                                                    break;
//                                                }
//                                                try {
//                                                    Thread.sleep(1000);
//                                                } catch (InterruptedException e) {
//                                                    e.printStackTrace();
//                                                }
//                                            }
//                                            handler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
//                                        }
//                                    }).start();
//                                }
//                            }) .create().show();
                    break;

                case R.id.btnNext:
                    if (TextUtils.isEmpty(phone) || (!YNCommonUtils.isCellPhone(phone)))
                    {
                        mRLForgetPassNotice.setVisibility(View.VISIBLE);
                        mTVNotice.setText("请填写正确手机号码");
                        return;
                    }
                    if (TextUtils.isEmpty(edtCode.getText().toString()))
                    {
                        mRLForgetPassNotice.setVisibility(View.VISIBLE);
                        mTVNotice.setText("请输入验证码");
                        return;
                    }
                    if (!verificationCode.equals(edtCode.getText().toString()))
                    {
                        mRLForgetPassNotice.setVisibility(View.VISIBLE);
                        mTVNotice.setText("验证码不匹配");
                        return;
                    }

                    // 跳转至设置密码界面
                    Intent intent = new Intent(getApplicationContext(), YNSetPasswordActivity.class);
                    // 保存手机号用于传递至下一界面
                    intent.putExtra(YNCommonConfig.PHONE_NUMBER, phone);
                    // 用于标识下一界面 true为登录时忘记密码，不需输入原密码；false为修改密码，需输入原密码
                    intent.putExtra(YNCommonConfig.FORGET_PASS, true);
                    startActivity(intent);
                    finish();

//                    handler.postDelayed(new Runnable()
//                    {
//                        @Override
//                        public void run()
//                        {
//                            UserHttpUtils.newInstance().userForgetPassword(YNForgetActivity.this, YNCommonConfig.USER_FORGET_PASSWORD_URL, edtPhoneNum.getText().toString(),
//                                    handler, YNCommonConfig.USER_FORGET_PASSWORD_FLAG);
//                        }
//                    }, 500);
                    break;

                default:
                    break;
            }
        }
    }

}
