package com.yeneikeji.ynzhibo.view.live;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompatSideChannelService;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.tb.emoji.Emoji;
import com.tb.emoji.EmojiUtil;
import com.tb.emoji.FaceFragment;
import com.umeng.socialize.media.Base;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.listener.SoftKeyBoardListener;
import com.yeneikeji.ynzhibo.model.AskQuestionBean;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.view.mine.foldline.AmountView;
import com.yeneikeji.ynzhibo.widget.AddMinusView;
import com.yeneikeji.ynzhibo.widget.ChatListView;
import com.yeneikeji.ynzhibo.widget.badgeview.BadgeTextView;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 提问界面
 * Created by Administrator on 2017/5/18.
 */
public class AskQuestionFragment extends BaseFragment implements View.OnClickListener, FaceFragment.OnEmojiClickListener
{
    private LinearLayout mLLAskQuestion;
//    private SmoothListView mAskListView;
    private PullToRefreshLayout mRefreshView;
    private RelativeLayout mRefreshHead;
    private YNMyListView mAskListView;
    private LinearLayout mLLInputBar;
    private LinearLayout mLLEdit;
    private LinearLayout mEditContentLL;
    private EditText mEditTextContent;
//    private ImageView mEmojiBtn;
//    private ImageButton mIBAdd;
//    private ImageButton mIBMinus;
//    private ImageButton mIBReward;
    private AddMinusView mLLReward;
//    private AmountView mLLReward;
    private EditText mETRewardNum;
    private TextView sendBtn;
    private RelativeLayout mLLEmpty;
//    private FrameLayout emojiBoard;

    private CommonAdapter mAskAdapter;
    private List<AskQuestionBean> mAskQuestionList = new ArrayList<>();
    private LiveRoomBean liveRoomBean;
    private String askContent;
    private int rewardCoin = 1;
    private String userId;
    private String userName;
    private float currentCoin;// 当前金币

    public static final String MESSAGE_RECEIVED_ACTION = "MESSAGE_REFRESH_ASK_LIST_ACTION";
    private MessageReceiver mRefreshAskListMessageReceiver;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.LIVE_ROOM_ASK_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNLogUtil.e("tag", msg.obj.toString());
                        if (baseBean.getCode() == 101)
                        {
                            mEditTextContent.setText("");
                            AccountUtils.getAccountBean().setCurrentCoin(AccountUtils.getAccountBean().getCurrentCoin() - rewardCoin);
                            rewardCoin = 1;
                            mETRewardNum.setText(rewardCoin + "");
                            mLLEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                AskQuestionBean askQuestion = YNJsonUtil.JsonToBean(jsonObject.getString("data").toString(), AskQuestionBean.class);
                                mAskQuestionList.add(askQuestion);
                                mAskListView.setTranscriptMode(2);
                                mAskAdapter.updateListView(mAskQuestionList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                    }
                    else
                    {

                    }
                    break;

                case YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                Type type = new TypeToken<List<AskQuestionBean>>() {}.getType();
                                if (array != null)
                                {
                                    mAskQuestionList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mAskAdapter.updateListView(mAskQuestionList);
                                    /*List<AskQuestionBean> mAskList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    for (AskQuestionBean askQuestionBean : mAskList)
                                    {
                                        mAskQuestionList.add(askQuestionBean);
                                        if (!TextUtils.isEmpty(askQuestionBean.getReply()))
                                        {
                                            AskQuestionBean askQuestion = new AskQuestionBean();
                                            askQuestion.setId(askQuestionBean.getId());
                                            askQuestion.setUserid(askQuestionBean.getHostId());
                                            askQuestion.setContent(askQuestionBean.getReply());
                                            askQuestion.setUsername(liveRoomBean.getUsername());
                                            askQuestion.setPayCoin("0");
                                            mAskQuestionList.add(askQuestion);
                                        }
                                    }*/

                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mLLEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        mLLEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mLLEmpty.setVisibility(View.GONE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                Type type = new TypeToken<List<AskQuestionBean>>() {}.getType();
                                if (array != null)
                                {
                                    mAskQuestionList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mAskAdapter.updateListView(mAskQuestionList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mLLEmpty.setVisibility(View.VISIBLE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                        }
                    }
                    else
                    {
                        mLLEmpty.setVisibility(View.VISIBLE);
                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                    }
                    break;

                case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                currentCoin = Float.parseFloat(jsonObject.getString("data"));
                                AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                    }
                    else
                    {
//                    YNToastMaster.showToast(getContext(), getString(R.string.request_fail));
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }
        return R.layout.fragment_ask_question;
    }

    @Override
    protected void onResumeLazy()
    {
//        if (AccountUtils.getLoginInfo())
//            loginRefreshUI();

        registerMessageReceiver();
        super.onResumeLazy();
    }

    @Override
    protected void initView()
    {
        mLLAskQuestion = (LinearLayout) findViewById(R.id.ll_ask_question);
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mRefreshHead = (RelativeLayout) findViewById(R.id.head_view);
        mAskListView = (YNMyListView) findViewById(R.id.lv_ask);
//        mLLRoot = (LinearLayout) findViewById(R.id.ll_root);
//        mAskListView = (SmoothListView) findViewById(R.id.lv_ask);
        mLLInputBar = (LinearLayout) findViewById(R.id.ll_input_ask);
        mEditContentLL = (LinearLayout) findViewById(R.id.ll_ask);
        mEditTextContent = (EditText) findViewById(R.id.tv_editor);
//        mEmojiBtn = (ImageView) findViewById(R.id.iv_emoji_btn);
//        mIBReward = (ImageButton) findViewById(R.id.ib_reward);
        mLLReward = (AddMinusView) findViewById(R.id.reward_num_view);
        mETRewardNum = (EditText) mLLReward.findViewById(R.id.et_reward_num);
//        mIBAdd = (ImageButton) findViewById(R.id.ib_add);
//        mIBMinus = (ImageButton) findViewById(R.id.ib_minus);
        sendBtn = (TextView) findViewById(R.id.tv_send);
//        emojiBoard = (FrameLayout) findViewById(R.id.framelayout_emoji);
        mLLEdit = (LinearLayout) findViewById(R.id.ll_edit);
        mLLEmpty = (RelativeLayout) findViewById(R.id.empty);

        mRefreshHead.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.transparent));

//        FaceFragment faceFragment = FaceFragment.Instance();
//        getChildFragmentManager().beginTransaction().add(R.id.framelayout_emoji, faceFragment).commit();

//        if (AccountUtils.getLoginInfo())
//        {
//            userId = AccountUtils.getAccountBean().getId();
//            userName = AccountUtils.getAccountBean().getUsername();
//
//            if (userId.equals(liveRoomBean.getUserid()))
//            {
//                mLLEdit.setVisibility(View.GONE);
//            }
//        }

//        mETRewardNum.setText(rewardCoin + "");
        mLLReward.setRewardMaxCoin(100000);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
//        view.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
//                if (mLLInputBar.getVisibility() == View.VISIBLE) {
//                    mLLEdit.setVisibility(View.VISIBLE);
//                    mLLInputBar.setVisibility(View.GONE);
//                    YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
//                }
//            }
//        });
//        softKeyboardListnenr();
    }

    @Override
    protected void onPauseLazy() {
        this.getActivity().unregisterReceiver(mRefreshAskListMessageReceiver);
        super.onPauseLazy();
    }

    /**
     * 软键盘显示与隐藏的监听
     */
    private void softKeyboardListnenr() {
        SoftKeyBoardListener.setListener(getActivity(), new SoftKeyBoardListener.OnSoftKeyBoardChangeListener() {
            @Override
            public void keyBoardShow(int height) {/*软键盘显示：执行隐藏title动画，并修改listview高度和装载礼物容器的高度*/
                ((YNLiveDetailsActivity)getActivity()).hideTopBar();
            }
            @Override
            public void keyBoardHide(int height) {/*软键盘隐藏：隐藏聊天输入框并显示聊天按钮，执行显示title动画，并修改listview高度和装载礼物容器的高度*/
//                if (mEmojiBtn.isSelected() == true)
//                {
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
//                }
//                else
//                {
//                    mLLInputBar.setVisibility(View.GONE);
//                    mLLEdit.setVisibility(View.VISIBLE);
                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
//                }
            }
        });
    }


    @Override
    protected void loadData()
    {
        mLLAskQuestion.setOnClickListener(this);
//        sendBtn.setOnClickListener(this);
        mLLEdit.setOnClickListener(this);
//        mLLRoot.setOnClickListener(this);

        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                Intent msgIntent = new Intent(LiveLayerFragment.MESSAGE_RECEIVED_ACTION);
                msgIntent.putExtra(YNCommonConfig.TITLE, true);
                getContext().sendBroadcast(msgIntent);

                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveRoomAskList(getActivity(), YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_URL, userId, liveRoomBean.getUserid(), mHandler,
                                YNCommonConfig.ON_REFRESH, false, 500);
                    }
                });
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });

        mLLReward.setOnAmountChangeListener(new AddMinusView.OnRewardNumChangeListener()
        {
            @Override
            public void onRewardNumChange(View view, int rewardNum)
            {
                rewardCoin = rewardNum;
            }
        });

/*        mLLReward.setOnAmountChangeListener(new AmountView.OnAmountChangeListener() {
            @Override
            public void onAmountChange(View view, int amount)
            {
                rewardCoin = amount;
            }
        });*/

        mAskListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if (mLLInputBar.getVisibility() == View.VISIBLE)
                {
                    YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
                    mLLInputBar.setVisibility(View.GONE);
                    mLLEdit.setVisibility(View.VISIBLE);
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
                }
            }
        });

        mEditTextContent.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
//                emojiBoard.setVisibility(View.GONE);
//                mEmojiBtn.setSelected(false);
            }
        });

        mEditTextContent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus)
            {
                mEditContentLL.setSelected(hasFocus);
//                emojiBoard.setVisibility(View.GONE);
//                mEmojiBtn.setSelected(false);
            }
        });

        mEditTextContent.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s)
            {
//                sendBtn.setEnabled(!s.toString().isEmpty());
            }
        });

//        mEmojiBtn.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
//                emojiBoard.setVisibility(emojiBoard.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
//                mEmojiBtn.setSelected(emojiBoard.getVisibility() == View.VISIBLE);
//                YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
//            }
//        });

        mEditTextContent.setOnKeyListener(new View.OnKeyListener()
        {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)
                {
                    if (liveRoomBean.getLiving() == 0)
                    {
                        YNToastMaster.showToast(getContext(), "主播不在线,无法提问", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        askQuestion();
                    }
                }

                return false;
            }
        });

       /* mETRewardNum.setOnKeyListener(new View.OnKeyListener()
        {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                if (keyCode == KeyEvent.KEYCODE_ENTER)
                {
                    askQuestion();
                }

                return false;
            }
        });*/

       /* sendBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (AccountUtils.getLoginInfo())
                {
                    //发布提问
                    askContent = mEditTextContent.getText().toString();
                    if (!TextUtils.isEmpty(mETRewardNum.getText().toString()))
                    {
                        rewardCoin = Integer.parseInt(mETRewardNum.getText().toString());
                    }

                    if(TextUtils.isEmpty(askContent))
                    {
                        YNToastMaster.showToast(getActivity(), "提问不能为空！");
                        return;
                    }

                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().liveRoomAsk(getActivity(), YNCommonConfig.LIVE_ROOM_ASK_URL, userId, liveRoomBean.getUserid(), askContent, rewardCoin, mHandler, YNCommonConfig.LIVE_ROOM_ASK_FLAG, false);
                        }
                    });
                    emojiBoard.setVisibility(View.GONE);
                    mEmojiBtn.setSelected(false);
                    YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), R.string.un_login_opreate_notice);
                }
            }
        });*/

        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();

            if (userId.equals(liveRoomBean.getUserid()))
            {
                mLLEdit.setVisibility(View.GONE);
            }

            getLiveRoomAskList();
        }

        mAskAdapter = new CommonAdapter<AskQuestionBean>(getActivity(), mAskQuestionList, R.layout.item_ask_question)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, AskQuestionBean item)
            {
                if (item.getPayCoin() > 0)
                {
                    viewHolder.getView(R.id.tv_gold_num).setVisibility(View.VISIBLE);
                }
                else
                {
                    viewHolder.getView(R.id.tv_gold_num).setVisibility(View.GONE);
                }
                if (item.getType() == 1)
                    viewHolder.setText(R.id.tv_username, "我 : ");
                else
                    viewHolder.setText(R.id.tv_username, item.getUsername() + " : ");
                viewHolder.setText(R.id.tv_content, item.getContent());
                viewHolder.setText(R.id.tv_gold_num, "[" + item.getPayCoin() + "金币]");
            }
        };

        mAskListView.setAdapter(mAskAdapter);

    }

    private void registerMessageReceiver()
    {
        mRefreshAskListMessageReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(MESSAGE_RECEIVED_ACTION);
        getActivity().registerReceiver(mRefreshAskListMessageReceiver, filter);
    }

    // 接收消息
    private class MessageReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(final Context context, final Intent intent)
        {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction()))
            {
                getLiveRoomAskList();
            }
        }
    }

    /** 直播间获取提问列表 */
    public void getLiveRoomAskList()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomAskList(getActivity(), YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_URL, userId, liveRoomBean.getUserid(), mHandler,
                        YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_FLAG, true, 500);
//                UserHttpUtils.newInstance().getLiveRoomAskList(getActivity(), YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_URL, "43", "15", mHandler,
//                        YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_FLAG, false);
            }
        });
    }

    /** 直播间提问 */
    private void askQuestion()
    {
//        boolean flag = false;
        if (AccountUtils.getLoginInfo())
        {
            //发布提问
            askContent = mEditTextContent.getText().toString().trim();
//            rewardCoin = Integer.parseInt(mETRewardNum.getText().toString());
//            if (!TextUtils.isEmpty(mETRewardNum.getText().toString().trim()) && Integer.parseInt(mETRewardNum.getText().toString().trim()) >= 0)
//            {
//                rewardCoin = Integer.parseInt(mETRewardNum.getText().toString());
//                flag = true;
//            }

//            if (flag)
//            {
                if(TextUtils.isEmpty(askContent) || askContent.isEmpty() || askContent == null)
                {
                    YNToastMaster.showToast(getActivity(), "提问不能为空！");
                }
                else
                {
                    if (rewardCoin > 0)
                    {
                        if (AccountUtils.getAccountBean().getCurrentCoin() >= rewardCoin)
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().liveRoomAsk(getActivity(), YNCommonConfig.LIVE_ROOM_ASK_URL, userId, liveRoomBean.getUserid(), askContent, rewardCoin, 1,
                                            mHandler, YNCommonConfig.LIVE_ROOM_ASK_FLAG, false, 500);
                                }
                            });
//                    emojiBoard.setVisibility(View.GONE);
//                    mEmojiBtn.setSelected(false);
                            YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
                        }
                        else
                        {
                            YNToastMaster.showToast(getActivity(), "您的余额不足，请及时充值");
                        }
                    }
                    else
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().liveRoomAsk(getActivity(), YNCommonConfig.LIVE_ROOM_ASK_URL, userId, liveRoomBean.getUserid(), askContent, rewardCoin, 1,
                                        mHandler, YNCommonConfig.LIVE_ROOM_ASK_FLAG, false, 500);
                            }
                        });
//                    emojiBoard.setVisibility(View.GONE);
//                    mEmojiBtn.setSelected(false);
                        YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
                    }
                }
//            }
        }
        else
        {
            Intent intent = new Intent(getActivity(), YNLoginActivity.class);
            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//            startActivity(intent);
        }
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.ll_edit:
                mLLEdit.setVisibility(View.GONE);
                mLLInputBar.setVisibility(View.VISIBLE);
                mEditTextContent.requestFocus();
                mEditTextContent.requestFocusFromTouch();

                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        YNCommonUtils.showSoftInput(getActivity(), mEditTextContent);
                    }
                }, 200);
//                ((YNLiveDetailsActivity)getActivity()).hideTopBar();
                break;

            case R.id.ll_ask_question:
//                if (mLLInputBar.getVisibility() == View.VISIBLE)
//                {
//                    YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
//                    mLLInputBar.setVisibility(View.GONE);
//                    mLLEdit.setVisibility(View.VISIBLE);
////                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
//                }
                break;

           /* case R.id.ib_add:
                rewardCoin ++ ;
                mETRewardNum.setText(rewardCoin + "");
                break;

            case R.id.ib_minus:
                rewardCoin -- ;
                if (rewardCoin < 0)
                {
                    mIBMinus.setClickable(false);
                }
                else
                {
                    mIBMinus.setClickable(true);
                    mETRewardNum.setText(rewardCoin + "");
                }
                break;*/
        }
    }

    public void hideKeyBoard()
    {
        if (mLLInputBar.getVisibility() == View.VISIBLE)
        {
            YNCommonUtils.hideSoftInput(getActivity(), mEditTextContent);
            mLLInputBar.setVisibility(View.GONE);
            mLLEdit.setVisibility(View.VISIBLE);
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
        }
    }

    @Override
    public void onEmojiClick(Emoji emoji)
    {
        if (emoji != null)
        {
            int index = mEditTextContent.getSelectionStart();
            Editable editable = mEditTextContent.getEditableText();
            if (index < 0) {
                editable.append(emoji.getContent());
            } else {
                editable.insert(index, emoji.getContent());
            }
            displayEditText();
        }
    }

    private void displayEditText() {
        try {
            EmojiUtil.handlerEmojiEditText(mEditTextContent, mEditTextContent.getText().toString(), getActivity());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onEmojiDelete()
    {
        String text = mEditTextContent.getText().toString();
        if (text.isEmpty()) {
            return;
        }
        if ("]".equals(text.substring(text.length() - 1, text.length()))) {
            int index = text.lastIndexOf("[");
            if (index == -1) {
                int action = KeyEvent.ACTION_DOWN;
                int code = KeyEvent.KEYCODE_DEL;
                KeyEvent event = new KeyEvent(action, code);
                mEditTextContent.onKeyDown(KeyEvent.KEYCODE_DEL, event);
                displayEditText();
                return;
            }
            mEditTextContent.getText().delete(index, text.length());
            displayEditText();
            return;
        }
        int action = KeyEvent.ACTION_DOWN;
        int code = KeyEvent.KEYCODE_DEL;
        KeyEvent event = new KeyEvent(action, code);
        mEditTextContent.onKeyDown(KeyEvent.KEYCODE_DEL, event);
        displayEditText();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == YNCommonConfig.ACTIVITY_RESULT)
        {
            loginRefreshUI();
        }
    }

    private void loginRefreshUI()
    {
        if (AccountUtils.getLoginInfo())
        {
            Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
            intent.putExtra("liveRoom", true);
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);

            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();

            if (userId.equals(liveRoomBean.getUserid()))
            {
                mLLEdit.setVisibility(View.GONE);
            }

            mHandler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getCurrentGoldCoin(getActivity(), YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, mHandler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

                }
            });

            getLiveRoomAskList();
        }
    }

}
