package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.live.AdvancedPlayActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/*
* 这是我的直播视频的类
* mComeFrom 2代表充我的直播跳转进来
* mComeFrom 1代表从发表文章里面选择视频进来
*
* */
public class MyLiveVideoActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private ExpandableListView mExpListView;
    private List<RecordVideoBean>     mRecordVideoBeans;
    private int mComeFrom;
    private boolean mShowDelete;
    private  ArrayList<List<RecordVideoBean>>  datas    =new ArrayList();
    private  ArrayList<RecordVideoBean> oneWeek  =new ArrayList();
    private  ArrayList<RecordVideoBean> oneMonth =new ArrayList();
    private  ArrayList<RecordVideoBean> oneMore  =new ArrayList();
    private  ArrayList<RecordVideoBean> playList  =new ArrayList();
    private ExpandableAdapter        mAdapter;
    private boolean mChildernHasSelect;
    private  int   mPassPosition ;
    private Handler                             mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_MY_LIVE_VIDEOLIST_FLAG:

                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            JSONObject jsonObject = null;
                            try
                            {
                               jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("data");
                                Type     type  = new TypeToken<List<RecordVideoBean>>() {}.getType();
                                mRecordVideoBeans = YNJsonUtil.JsonToLBean(array.toString(),
                                                                              type);
                                // settingDo();
                              //  Gson gson=new Gson();
                               // mRecordVideoBean=  gson.fromJson(msg.obj.toString(),RecordVideoBean.class);
                                //获取当前的时间，封装不同时间段的bean
                                long currentTime = System.currentTimeMillis()/1000;
                                for (int i=0;i<mRecordVideoBeans.size();i++){
                                    String publishedTime = mRecordVideoBeans.get(i)
                                                                      .getPublishTime();
                                    int publishTime = Integer.parseInt(publishedTime);

                                    if((currentTime-publishTime)<=604800){
                                        oneWeek.add(mRecordVideoBeans.get(i));

                                    }
                                    if(604800<(currentTime-publishTime)&&(currentTime-publishTime)<=2678400){
                                        oneMonth.add(mRecordVideoBeans.get(i));
                                    }
                                    if((currentTime-publishTime)>2678400){
                                        oneMore.add(mRecordVideoBeans.get(i));
                                    }
                                }
                                datas.add(oneWeek);
                                datas.add(oneMonth);
                                datas.add(oneMore);

                                playList.addAll(oneWeek);
                                playList.addAll(oneMonth);
                                playList.addAll(oneMore);
                                mAdapter =new ExpandableAdapter(MyLiveVideoActivity.this, datas);
                                mExpListView.setAdapter(mAdapter);
                                 /*保存视频的集合*/
                               /* saveData.addAll(oneWeek);
                                saveData.addAll(oneMonth);
                                saveData.addAll(oneMore);
                                LiveVideoRecordDao.saveVideoList(saveData);*/
                            }
                            catch (Exception e)
                            {

                                e.printStackTrace();
                            }
                        }

                    }
                    else
                    {

                    }
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_live_video);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        mComeFrom = getIntent().getIntExtra("comeFrom", 0);
        initView();
        addEvent();

    }

    protected void initView()
    {
        configTopBarCtrollerWithTitle("我的直播视频");
//        getRightTV().setVisibility(View.VISIBLE);
//        getRightTV().setText("选择");
//        getRightTV().setTextColor(Color.parseColor("#2699FB"));
        mExpListView = (ExpandableListView) findViewById(R.id.my_live_video_expandlistview);
        //请求数据
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().myVideoList(MyLiveVideoActivity.this, YNCommonConfig.MY_LIVE_VIDEO_URL,
                                                        AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.GET_MY_LIVE_VIDEOLIST_FLAG, true);
            }
        }, 1000);
    }

    protected void addEvent()
    {
        mExpListView.setGroupIndicator(null);
        getLeftBtn().setOnClickListener(this);
//        getRightTV().setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mShowDelete = !mShowDelete;
//                if (mShowDelete) {
//                    getRightTV().setText("取消");
//                    getRightTV().setTextColor(Color.parseColor("#ffffff"));
//
//                } else {
//                    getRightTV().setText("选择");
//                    getRightTV().setTextColor(Color.parseColor("#2699FB"));
//                }
//            }
//
//        });




            mExpListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent,
                                            View v,
                                            int groupPosition,
                                            int childPosition,
                                            long id)
                {
                        switch (groupPosition) {
                            case 0:
                                mPassPosition = childPosition;
                                break;
                            case 1:
                                mPassPosition = datas.get(0)
                                                     .size() + childPosition;
                                break;
                            case 2:
                                mPassPosition = datas.get(0)
                                                     .size() + datas.get(1)
                                                                    .size() + childPosition;
                                break;
                        }
                    //从我的视频过来的点击可以播放
                    if (mComeFrom==2) {
                        Intent intent = new Intent(MyLiveVideoActivity.this, AdvancedPlayActivity.class);
                        intent.putExtra("position", mPassPosition);
                        intent.putExtra(YNCommonConfig.ISSHOW, true);
                        intent.putExtra("List<RecordVideoBean>", playList);
                        startActivity(intent);
                    }else{
                        //选择上传的视频
                        Intent intent=new Intent();
                        intent.putExtra("videoData", playList.get(mPassPosition));
                        setResult(YNCommonConfig.SELECT_VEDIO_REQUES_CODE,intent);
                        finish();
                    }
                    return true;
                }

            });
        }


    protected void settingDo()
    {


    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
     class ExpandableAdapter extends BaseExpandableListAdapter {
         private  int   selectPosition ;
         private List<List<RecordVideoBean>> mdatas;
         private Context                            mContext;
         public ExpandableAdapter(Context context, List<List<RecordVideoBean>> datas) {

             mContext = context;
             this.mdatas = datas;
     }

         @Override
         public int getGroupCount() {
             if (mdatas != null) {
                 return mdatas.size();
             }
             return 0;
         }

         @Override
         public int getChildrenCount(int groupPosition) {
             if (mdatas.get(groupPosition)!= null) {
                 return mdatas.get(groupPosition).size();

             }
             return 0;
         }
         @Override
         public List<RecordVideoBean> getGroup(int groupPosition) {
             if (mdatas != null) {
                 return mdatas.get(groupPosition);
             }
             return null;

         }

         @Override
         public RecordVideoBean getChild(int groupPosition, int childPosition) {
             if (mdatas.get(groupPosition) != null) {
                 return mdatas.get(groupPosition).get(childPosition);

             }
             return null;
         }

         @Override
         public long getGroupId(int groupPosition) {
             return groupPosition;
         }

         @Override
         public long getChildId(int groupPosition, int childPosition) {
             return childPosition;
         }

         @Override
         public boolean hasStableIds() {
             return true;
         }

         @Override
         public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent)
         {
             View        view   = convertView;
             GroupHolder holder = null;
             if (view == null) {
                 holder = new GroupHolder();
                 view = LayoutInflater.from(mContext)
                                      .inflate(R.layout.livevideo_group_expandlistview, null);
                 holder.groupName = (TextView) view.findViewById(R.id.tv_group_name);
                 holder.arrow = (ImageView) view.findViewById(R.id.videogroup_iv_arrow);
                 view.setTag(holder);
             } else {
                 holder = (GroupHolder) view.getTag();
             }
             switch (groupPosition) {
                 case 0:
                     holder.groupName.setText("本周");
                      break;
                 case 1:
                     holder.groupName.setText("本月");
                     break;
                 case 2:
                     holder.groupName.setText("更多");
                     break;
             }

             //判断是否已经打开列表
             if (isExpanded) {
                 holder.arrow.setBackgroundResource(R.drawable.report_list_open);
             } else {
                 holder.arrow.setBackgroundResource(R.drawable.report_list_close);
             }

             return view;
         }

         @Override
         public View getChildView(final int groupPosition,
                                  final int childPosition,
                                  boolean isLastChild,
                                  View convertView,
                                  ViewGroup parent)
         {
             View        view           = convertView;
             ChildHolder holder         = null;

             if (view == null) {
                 holder = new ChildHolder();
                 view = LayoutInflater.from(mContext)
                                      .inflate(R.layout.livevideo_child_expandlistview_item, null);
                 holder.image = (ImageView) view.findViewById(R.id.video_imag);
                 holder.childnumb = (TextView) view.findViewById(R.id.video_numb);
                 holder.childtime = (TextView) view.findViewById(R.id.video_time);
                 holder.checbox= (CheckBox) view.findViewById(R.id.select_video_checkbox);
                 holder.rightRl= (RelativeLayout) view.findViewById(R.id.right_relativelayout);
               /*  holder.image.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         switch (groupPosition) {
                             case 0:
                                 selectPosition=childPosition;
                                  break;
                             case 1:
                                 selectPosition=mdatas.get(0).size()+childPosition;
                             break;
                             case 2:
                                 selectPosition=mdatas.get(0).size()+mdatas.get(1).size()+childPosition;
                             break;
                         }
                         Intent intent=new Intent(MyLiveVideoActivity.this, AdvancedPlayActivity.class);
                         intent.putExtra("position",selectPosition);
                         intent.putExtra("List<RecordVideoBean>",  playList);
                         startActivity(intent);

                     }
                 });
                 holder.rightRl.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         switch (groupPosition) {
                             case 0:

                                 break;
                             case 1:

                                 break;
                             case 2:

                                 break;
                         }

                     }
                 });*/
                /* if(mShowDelete){
                     holder.checbox.setVisibility(View.VISIBLE);
                 }else{
                     holder.checbox.setVisibility(View.GONE);
                 }*/
                 /*view.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         isselect=!isselect;
                         if(isselect){
                             finalHolder.checbox.setVisibility(View.VISIBLE);
                         }else{
                             finalHolder.checbox.setVisibility(View.GONE);
                         }
                     }
                 });*/
                 view.setTag(holder);
             } else {
                 holder = (ChildHolder) view.getTag();
             }
             YNImageLoaderUtil.setImage(mContext,  holder.image,mdatas.get(groupPosition).get(childPosition).getThumbnailList());
             holder.childtime.setText(DateUtil.timeStamp2StringSHort(mdatas.get(groupPosition).get(childPosition).getPublishTime()));
             holder.childnumb.setText(DateUtil.timeTick2DateHour(mdatas.get(groupPosition).get(childPosition).getPublishTime()) + "点场");
             // RecordVideoBean.DataBean dataBean = getChild(groupPosition, childPosition);
             return view;
         }

         @Override
         public boolean isChildSelectable(int groupPosition, int childPosition) {
             return true;
         }


         class GroupHolder {
             public TextView  groupName;
             public ImageView arrow;
         }

         class ChildHolder {
             private RelativeLayout rightRl;
             private CheckBox checbox;
             public ImageView image;
             public TextView childnumb;
             public TextView childtime;

         }


     }
}


