package com.yeneikeji.ynzhibo.utils;

import android.text.TextUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期处理工具类
 * Created by Administrator on 2016/12/1.
 */
public class DateUtil
{
    /**
     * 获得当前时间
     * @return
     */
    public static String getNowDate() {
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return sDateFormat.format(new java.util.Date());
    }

    /**
     * 获得当前年月日
     * @return
     */
    public static String getYearMonthDay()
    {
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd");
        return sDateFormat.format(new java.util.Date());
    }

    /**
     * 获取时间差
     * @param startDate
     * @param endDate
     * @return
     */
    public static String getIntervalTime(Date startDate, Date endDate)
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");
        String intervalTime = (startDate.getTime() - endDate.getTime()/1000/60/60) + ":" + (startDate.getTime() - endDate.getTime()/1000/60) + ":"
                + (startDate.getTime() - endDate.getTime()/1000);
        return  intervalTime;
    }

    /**
     *  将当前日期转换为字符串
     * @param timeTick
     * @return
     */
    public static String timeTick2Date(long timeTick) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");
        Long time = new Long(timeTick);
        String d = format.format(time);
        return d;
    }

    /**
     *  将当前日期转换为字符串年月日时分
     * @param timeTick
     * @return
     */
    public static String timeTick2DateNotSec(String timeTick)
    {
        String time = null;
        if (timeTick != null || !TextUtils.isEmpty(timeTick))
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            long lcc_time = Long.valueOf(timeTick);
            time = sdf.format(new Date(lcc_time * 1000L));
        }
        return time;
    }

    /**
     *  将当前日期转换为字符小时
     * @param timeTick
     * @return
     */
    public static String timeTick2DateHour(String timeTick)
    {
        String time = null;
        if (timeTick != null || !TextUtils.isEmpty(timeTick))
        {
            SimpleDateFormat sdf = new SimpleDateFormat("HH");
            long lcc_time = Long.valueOf(timeTick);
            time = sdf.format(new Date(lcc_time * 1000L));
        }
        else
        {
            time = "0";
        }
        return time;
    }

    /**
     *  将当前日期转换为字符串时分秒
     * @param timeTick
     * @return
     */
    public static String timeTick2DateForShow(long timeTick) {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        long lcc_time = Long.valueOf(timeTick);
        String time = format.format(new Date(lcc_time));
        return time;
    }

    /**
     *  将当前日期转换为字符串时分
     * @param timeTick
     * @return
     */
    public static String timeTick2DateHourMinute(String timeTick)
    {
        String time = null;
        if (timeTick != null || !TextUtils.isEmpty(timeTick))
        {
            SimpleDateFormat format = new SimpleDateFormat("HH:mm");
            long lcc_time = Long.valueOf(timeTick);
            time = format.format(new Date(lcc_time * 1000L));
        }
        return time;
    }
    /**
     *  将当前日期转换为字符串月日
     * @param timeTick
     * @return
     */
    public static String timeTick2DateOnly(long timeTick) {
        SimpleDateFormat format = new SimpleDateFormat("MM-dd");
        Long time = new Long(timeTick);
        String d = format.format(time);
        // Date date = format.parse(d);
        return d;
    }

    public static String timeTick2String(long timeTick) {
        SimpleDateFormat format = new SimpleDateFormat("HH小时mm分钟ss秒");
        Long time = new Long(timeTick);
        String d = format.format(time);
        return d;
    }

    /**
     * 将时间戳转换为长字符串
     * @param timeStamp
     * @return
     */
    public static String timeStamp2String(String timeStamp)
    {
        String time = null;
        if (timeStamp != null || !TextUtils.isEmpty(timeStamp))
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");
            long lcc_time = Long.valueOf(timeStamp);
            time = sdf.format(new Date(lcc_time * 1000L));
        }
        return time;
    }

    /**
     * 将时间戳转换为短字符串
     * @param timeStamp
     * @return
     */
    public static String timeStamp2StringSHort(String timeStamp)
    {
        String time = null;
        if (!TextUtils.isEmpty(timeStamp))
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            long lcc_time = Long.valueOf(timeStamp);
            time = sdf.format(new Date(lcc_time * 1000L));
        }
        return time;
    }
    /**
     * 得到昨天的日期
     * @return
     */
    public static String getYestoryDate()
    {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    /**
     * 得到今天的日期
     * @return
     */
    public static  String getTodayDate()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        return date;
    }


    /**
     * 得到日期   yyyy-MM-dd
     * @param timeStamp  时间戳
     * @return
     */
    public static String formatDate(long timeStamp)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(timeStamp * 1000);
        return date;
    }

    /**
     * 得到时间  HH:mm:ss
     * @param timeStamp 时间戳
     * @return
     */
    public static String getTime(long timeStamp)
    {
        String time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = sdf.format(timeStamp * 1000);
        String[] split = date.split("\\s");
        if ( split.length > 1 )
        {
            time = split[1];
        }
        return time;
    }

    /**
     * 将一个时间戳转换成提示性时间字符串，如刚刚，1秒前
     * @param timeStamp
     * @return
     */
    public static String convertTimeToFormat(long timeStamp)
    {
        long curTime =System.currentTimeMillis() / (long) 1000 ;
        long time = curTime - timeStamp;

        if (time < 60 && time >= 0)
        {
            return "刚刚";
        }
        else if (time >= 60 && time < 3600)
        {
            return time / 60 + "分钟前";
        }
        else if (time >= 3600 && time < 3600 * 24)
        {
            return time / 3600 + "小时前";
        }
        else if (time >= 3600 * 24 && time < 3600 * 24 * 30)
        {
            return time / 3600 / 24 + "天前";
        }
        else if (time >= 3600 * 24 * 30 && time < 3600 * 24 * 30 * 12)
        {
            return time / 3600 / 24 / 30 + "个月前";
        }
        else if (time >= 3600 * 24 * 30 * 12)
        {
            return time / 3600 / 24 / 30 / 12 + "年前";
        }
        else
        {
            return "刚刚";
        }
    }

    /**
     * 将一个时间戳转换成提示性时间字符串，(多少分钟)
     *
     * @param timeStamp
     * @return
     */
    public static String timeStampToFormat(long timeStamp) {
        long curTime =System.currentTimeMillis() / (long) 1000 ;
        long time = curTime - timeStamp;
        return time / 60 + "";
    }

    /**
     * 将字符串转为时间戳
     * @param user_time
     * @return
     */
    public static String timeToTimeStamp(String user_time)
    {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH时mm分ss秒");
        Date d;
        try
        {
            d = sdf.parse(user_time);
            long l = d.getTime();
            String str = String.valueOf(l);
            re_time = str.substring(0, 10);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }
        return re_time;
    }

}
