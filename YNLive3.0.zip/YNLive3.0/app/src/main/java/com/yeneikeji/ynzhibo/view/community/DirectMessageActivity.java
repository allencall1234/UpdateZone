package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.ChatAdapter;
import com.yeneikeji.ynzhibo.model.ChatEntity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.List;

public class DirectMessageActivity extends YNBaseTopBarActivity {

    private List<ChatEntity> mChatData;
    private ChatAdapter mChatAdapter;
    private ListView lvChat;
    private ImageView imgBack;
    private LinearLayout llInputBar;
    private ImageView imageView;
    private TextView txtSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_message);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        initData();
        setListener();
    }


    private void initData() {
        for (int i = 0; i < 6; i++) {
            ChatEntity entity = new ChatEntity();
            entity.setmText("对话" + i);
            if (i % 2 == 1) {
                entity.setmType(0);
                entity.setmPic(R.drawable.pic01);
            } else {
                entity.setmType(1);
                entity.setmPic(R.drawable.pic02);
            }

            mChatData.add(entity);
        }
        mChatAdapter = new ChatAdapter(this, mChatData);
        lvChat.setAdapter(mChatAdapter);
    }

    public void initView() {
        lvChat = (ListView) findViewById(R.id.lvChat);
        mChatData = new ArrayList<>();
        imgBack = (ImageView) findViewById(R.id.imgBack);

        llInputBar = (LinearLayout) findViewById(R.id.ll_input_bar);
        imageView = (ImageView) findViewById(R.id.imageView);

        txtSend = (TextView) findViewById(R.id.txtSend);
    }

    private void setListener() {
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
