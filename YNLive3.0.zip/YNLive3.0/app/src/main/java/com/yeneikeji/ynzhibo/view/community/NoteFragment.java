package com.yeneikeji.ynzhibo.view.community;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNFragmentAdapter;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;

import java.util.ArrayList;
import java.util.List;

/**这是发现主播主页笔记碎片
 * Created by Administrator on 2017/6/27.
 */

public class NoteFragment extends BaseFragment implements View.OnClickListener
{
    private ViewPager mViewPager;
    private ArrayList<Fragment> fragments;
    private String[] tabTitle = null;
    private RadioGroup mRadioGroup;
    private RadioButton mTotalArtical;
    private RadioButton mBuyedArtical;

    private YNFragmentAdapter mFragmentAdapter;
    private String userId;
    private int homePageFlag;
    private boolean isSetNoteColor = false;

    @Override
    protected void initView()
    {
        mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        mTotalArtical = (RadioButton) findViewById(R.id.total_artical);
        mBuyedArtical = (RadioButton) findViewById(R.id.have_buyed_artical);

        mViewPager = (ViewPager) findViewById(R.id.note_view_pager);
        tabTitle = getResources().getStringArray(R.array.anchorHomeNoteTitle);

        if (homePageFlag == 1)
        {
            if (isSetNoteColor)
                setPortraitFullScreenNoteColor();
            else
                setPortraitScreenNoteColor();
        }
        else
        {
            setPortraitFullScreenNoteColor();
        }
    }

    /**
     * 设置竖屏全屏笔记全部已购颜色
     */
    private void setPortraitFullScreenNoteColor()
    {
        ColorStateList csl = ContextCompat.getColorStateList(getContext(), R.color.top_most_new_font);
        mTotalArtical.setTextColor(csl);
        mBuyedArtical.setTextColor(csl);
        mTotalArtical.setBackgroundResource(R.drawable.anchor_home_top_left);
        mBuyedArtical.setBackgroundResource(R.drawable.anchor_home_top_right);
    }

    /**
     * 设置竖屏笔记全部已购颜色
     */
    private void setPortraitScreenNoteColor()
    {
        ColorStateList csl = ContextCompat.getColorStateList(getContext(), R.color.live_room_top_font);
        mTotalArtical.setTextColor(csl);
        mBuyedArtical.setTextColor(csl);
        mTotalArtical.setBackgroundResource(R.drawable.live_room_top_left);
        mBuyedArtical.setBackgroundResource(R.drawable.live_room_top_right);
    }

    @Override
    protected int getLayout() {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            userId = bundle.getString(YNCommonConfig.USER_ID);
            homePageFlag = bundle.getInt(YNCommonConfig.HOME_PAGE_FLAG);
            isSetNoteColor = bundle.getBoolean(YNCommonConfig.ISSHOW);
        }
        return R.layout.anchorhome_fragment_note;
    }

    @Override
    protected void loadData()
    {
        mTotalArtical.setOnClickListener(this);
        mBuyedArtical.setOnClickListener(this);

        addFragment();

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position,
                                       float positionOffset,
                                       int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position) {

                switch (position) {
                    case 0:
                        mTotalArtical.setChecked(true);
                        mBuyedArtical.setChecked(false);
                        break;
                    case 1:
                        mTotalArtical.setChecked(false);
                        mBuyedArtical.setChecked(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    /*添加全部和已购碎片碎片*/
    private void addFragment()
    {
        fragments = new ArrayList();
        fragments.clear();//清空
        int count =  tabTitle.length;
        Bundle bundle = new Bundle();
        bundle.putString(YNCommonConfig.USER_ID, userId);
        bundle.putInt(YNCommonConfig.HOME_PAGE_FLAG, homePageFlag);
        bundle.putBoolean(YNCommonConfig.ISSHOW, isSetNoteColor);
        for(int i = 0; i< count; i++)
        {
            NoteListFragment fragment= new NoteListFragment();
            fragment.setmTag(i);
            fragment.setArguments(bundle);
            fragments.add(fragment);
        }

        mFragmentAdapter = new YNFragmentAdapter(getChildFragmentManager(), fragments, tabTitle);
        mViewPager.setAdapter(mFragmentAdapter);

//        AdapterFragment adapter = new AdapterFragment(getActivity().getSupportFragmentManager(),fragments);
//        mViewPager.setAdapter(adapter);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.total_artical :
                mViewPager.setCurrentItem(0);
                break;

            case R.id.have_buyed_artical:
                mViewPager.setCurrentItem(1);
                break;
        }
    }

    class AdapterFragment extends FragmentPagerAdapter
    {
        private List<Fragment> mFragments;

        public AdapterFragment(FragmentManager fm, List<Fragment> mFragments)
        {
            super(fm);
            this.mFragments = mFragments;
        }

        @Override
        public Fragment getItem(int position) {//必须实现
            return mFragments.get(position);
        }

        @Override
        public int getCount() {//必须实现
            return mFragments.size();
        }
    }


}
