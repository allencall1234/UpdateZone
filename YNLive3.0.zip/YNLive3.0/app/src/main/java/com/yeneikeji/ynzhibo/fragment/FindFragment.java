package com.yeneikeji.ynzhibo.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.community.FamilyEducationFindFragment;
import com.yeneikeji.ynzhibo.view.community.FinancialFindFragment;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.view.community.PointActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.FixedIndicatorView;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 发现界面
 * Created by Administrator on 2016/11/7.
 */
public class FindFragment extends YNBaseFragment
        implements View.OnClickListener
{
    private static final String TAG = "FindFragment";

    private ImageView mIVReleaseDynamic;
    private ViewPager mViewPager;
    private RadioGroup mRadioGroup;
    private RadioButton mRBHeart, mRBFans;
    private LinearLayout mLayoutLoading;
    private List<Fragment> list;
    private FixedIndicatorView mFindTabs;
    private ViewPager mFindViewPager;

    private ArrayList<Fragment> fragments;
    private String[] tabTitle = null;
    //private YNFragmentAdapter      mAdapter;
    private ImageView          mTopPersonnalIv;
    private Intent             mIntent;
    private ImageView          mEditIv;
    private YNCircleImageView  mHeadView;
    private PersonInfoBean     mPersonInfoBean;
    private IndicatorViewPager indicatorViewPager;
    private MyAdapter          mAdapter;
    @Override
    public String getFragmentName() {
        return TAG;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_find, container, false);
      //  AutoUtils.auto(view);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    protected void initView(View view) {
        //用户信息
        mPersonInfoBean = AccountUtils.getLocalPerson();
        mHeadView = (YNCircleImageView) view.findViewById(R.id.top_head_iv);
        mFindTabs = (FixedIndicatorView) view.findViewById(R.id.find_fragment_tabs);
        mFindViewPager = (ViewPager) view.findViewById(R.id.find_fragment_view_pager);
        tabTitle = getResources().getStringArray(R.array.findColumnTitles);
        mTopPersonnalIv = (ImageView) view.findViewById(R.id.top_head_iv);
        mEditIv = (ImageView) view.findViewById(R.id.edit);

        float   unSelectSize  = 15;
        float    selectSize    = 15;
        int      selectColor   = Color.parseColor("#1694ff");
        int      unSelectColor = Color.BLACK;
        ColorBar line1         = new ColorBar(getActivity(), Color.parseColor("#1694ff"), 5);
        line1.setWidth(UIUtils.dp2px(getActivity(), 55));
        line1.setHeight(UIUtils.dp2px(getActivity(), 3));
        mFindTabs.setScrollBar(line1);
        mFindTabs.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mFindViewPager.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mFindTabs, mFindViewPager);




    }

    @Override
    public void onResume() {
        if (AccountUtils.getLoginInfo()) {
            loginRefreshUI();
        }else
            unLoginRefreshUI();
            super.onResume();
    }
    @Override
    protected void settingDo() {
 if(AccountUtils.getLoginInfo()) {
    YNImageLoaderUtil.setImage(getActivity(), mHeadView, mPersonInfoBean.getIcon());
    mHeadView.setVisibility(View.VISIBLE);
    mEditIv.setVisibility(View.VISIBLE);

}
        addFragment();
    }

    private void addFragment() {
        fragments = new ArrayList<Fragment>();
        int count = tabTitle.length;
        for (int i = 0; i < count; i++) {
            if (i == 0) {
                FinancialFindFragment fragment = new FinancialFindFragment();
                fragments.add(fragment);
            } else {
                FamilyEducationFindFragment fragment = new FamilyEducationFindFragment();
                fragments.add(fragment);
            }
        }
        /*mAdapter = new YNFragmentAdapter(getFragmentManager(), fragments, tabTitle);
        mFindViewPager.setAdapter(mAdapter);
        mFindTabs.setupWithViewPager(mFindViewPager, true);
        UIUtils.dynamicSetTabLayoutMode(mFindTabs);*/
        mAdapter = new MyAdapter(getChildFragmentManager());
        mAdapter.setFragments(fragments);
        indicatorViewPager.setAdapter(mAdapter);

    }

    @Override
    protected void addEvents() {
        mTopPersonnalIv.setOnClickListener(this);
        mEditIv.setOnClickListener(this);

    }

      @Override
      public void onClick(View v)
      {
          mIntent = new Intent();
          switch (v.getId())
          {
              case R.id.top_head_iv:
                  if (YNBaseActivity.isConnectNet)
                  {
                      if (AccountUtils.getLoginInfo())
                      {
                          mIntent.setClass(mContext, FindAnchorHomeActivity.class);
                          mIntent.putExtra("userId", AccountUtils.getAccountBean().getId());
                          startActivity(mIntent);
                      }
                      else
                      {
                          mIntent.setClass(mContext, YNLoginActivity.class);
                          startActivity(mIntent);
                      }
                  }
                  else
                  {
                      YNToastMaster.showToast(mContext, R.string.no_net);
                  }
                  break;
              //跳转到观点界面
              case R.id.edit :
                  mIntent=new Intent(mContext,PointActivity.class);
                  startActivity(mIntent);
              break;
          }
      }
    @Override
    public void loginRefreshUI() {
        //获取用户基本信息
        mPersonInfoBean = AccountUtils.getLocalPerson();
        //用户的验证状态信息获取，只有用户是主播而且登录了才会显示发表文章
        UserInfoBean userStatus = AccountUtils.getAccountBean();
        if(userStatus!=null&&userStatus.getCheck_status() ==0){
            mEditIv.setVisibility(View.VISIBLE);
        }else{
            mEditIv.setVisibility(View.GONE);
        }

        YNImageLoaderUtil.setImage(getActivity(), mHeadView, mPersonInfoBean.getIcon());
        mHeadView.setVisibility(View.VISIBLE);


    }

    @Override
    public void unLoginRefreshUI() {
        mHeadView.setVisibility(View.GONE);
        mEditIv.setVisibility(View.GONE);
    }
    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter
    {
        private List<Fragment> fragments = new ArrayList<>();
        public MyAdapter(FragmentManager fragmentManager)
        {
            super(fragmentManager);
        }

        public void setFragments( List<Fragment> fragments)
        {
            this.fragments = fragments;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return tabTitle.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container)
        {
            if (convertView == null)
            {
                convertView = LayoutInflater.from(mContext).inflate(R.layout.tab_textview, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabTitle[position]);
            return convertView;
        }


        @Override
        public Fragment getFragmentForPage(int position)
        {
            return fragments.get(position);
        }
    }
}
