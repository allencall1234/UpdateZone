package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.UIUtils;

/**
 * 加载弹出框工具类
 * Created by Administrator on 2016/8/4.
 */
public class YNLoadingDialog
{
    private View view;
    private Dialog dialog;
    private ImageView mImageView;
    private TextView mLoadingTv;

    public YNLoadingDialog(Builder builder)
    {
        dialog = new Dialog(builder.context, R.style.LoadingDialogStyle);
        view = LayoutInflater.from(builder.context).inflate(R.layout.loading_dialog, null);
//        AutoUtils.auto(view);
//        view.setBackgroundColor(ContextCompat.getColor(builder.context, R.color.ynkj_activity_bg));
        mLoadingTv = (TextView) view.findViewById(R.id.loadingTv);
        mImageView = (ImageView) view.findViewById(R.id.loadingIv);
        mLoadingTv.setText(builder.getLoadingInfo());
        dialog.setContentView(view);

     /*   Window window = dialog.getWindow();
        WindowManager m = ((Activity) builder.context).getWindowManager();
        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
        WindowManager.LayoutParams lp = window.getAttributes();

        lp.height = (int) builder.context.getResources().getDimension(R.dimen.listview_item_height4); // 高度设置
        lp.width = (int) (d.getWidth() * 0.65); // 宽度设置为屏幕的0.6
        lp.alpha = 0.8f; // 透明度*/

//        Window window = dialog.getWindow();
//        WindowManager.LayoutParams lp =  window.getAttributes();
//        window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
//        lp.gravity = Gravity.CENTER;
//        lp.height = UIUtils.dp2px(builder.context, ScreenSizeUtil.getScreenHigh(builder.context)) ; // 高度设置
//        lp.width = UIUtils.dp2px(builder.context, ScreenSizeUtil.getScreenWidth(builder.context));
//        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
//        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
//        window.setAttributes(lp);

        if (builder.getHeight() > 0)
        {
            Window window = dialog.getWindow();
            WindowManager.LayoutParams lp =  window.getAttributes();
            window.setGravity(Gravity.CENTER);
            lp.y = builder.getHeight();
            window.setAttributes(lp);
        }

        mImageView.setBackgroundResource(R.drawable.frame);
        AnimationDrawable background = (AnimationDrawable) mImageView.getBackground();
        background.setOneShot(false);
        if(background.isRunning())//是否正在运行？
        {
            background.stop();//停止
        }
        background.start();//启动
    }

    /**
     * 隐藏dialog
     * */
    public void dismiss()
    {
        dialog.dismiss();
    }

    /**
     * 显示dialog
    * */
    public void show()
    {
        dialog.show();
    }

    /*****dialog不可被点击****/
    public void setClick(boolean isClick)
    {
        dialog.setCanceledOnTouchOutside(isClick);
    }

    public static class Builder
    {
        private Context context;
        private String loadingInfo;
        private boolean flag;
        private int height;

        public YNLoadingDialog builder()
        {
            return  new YNLoadingDialog(this);
        }

        public Builder(Context context, String loadingInfo)
        {
            this.context = context;
            this.loadingInfo = loadingInfo;
            flag = true;//ture:点击可关闭  false：点击不可关闭
        }

        public Builder(Context context){
            this.context = context;
            flag = true;//ture:点击可关闭  false：点击不可关闭
            loadingInfo = "正在加载...";
        }

        public boolean isFlag() {
            return flag;
        }

        public Builder setFlag(boolean flag) {
            this.flag = flag;
            return this;
        }

        public String getLoadingInfo() {
            return loadingInfo;
        }

        public Builder setLoadingInfo(String loadingInfo) {
            this.loadingInfo = loadingInfo;
            return this;
        }

        public int getHeight() {
            return height;
        }

        public Builder setHeight(int height) {
            this.height = height;
            return this;
        }
    }

}
