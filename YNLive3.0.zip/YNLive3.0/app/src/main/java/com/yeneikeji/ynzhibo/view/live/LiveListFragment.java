package com.yeneikeji.ynzhibo.view.live;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.database.WatchRecordDao;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/20.
 */
public class LiveListFragment extends BaseFragment implements View.OnClickListener
{
//    private SmoothListView mLiveListView;
    private PullToRefreshLayout mRefreshView;
    private RelativeLayout mRLHeadView;
    private TextView mTVState;
    private RecyclerView mRecyclerView;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;

//    private CommonAdapter mLiveTypeAdapter;
//    private CommonAdapter mLiveListAdapter;
    private CommonRecyclerViewAdapter mLiveListAdapter;
    private List<LiveRoomBean> liveRoomList = new ArrayList<>();
    private YNLoadingDialog loadingDialog;
    private YNCommonDialog comDialog;

    private String userId;
    private String mTag;
    private int typeTag;

    private YNPayDialog noticeDialog;
    private WatchRecordDao watchRecordDao;

    private boolean isFirst = true;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
               case YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG:
                   isFirst = false;
                   if (msg.obj != null)
                   {
                       BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                       if (bean.getCode() == 28)
                       {
                           mRLEmpty.setVisibility(View.GONE);
                           mRecyclerView.setVisibility(View.VISIBLE);
                           try
                           {
                               JSONObject jsonObject = new JSONObject(msg.obj.toString());
                               JSONArray array = jsonObject.getJSONArray("data");
                               Type type = new TypeToken<List<LiveRoomBean>>() {}.getType();
                               liveRoomList = YNJsonUtil.JsonToLBean(array.toString(), type);
                               mLiveListAdapter.updateListView(liveRoomList);
                           }
                           catch (JSONException e)
                           {
                               e.printStackTrace();
                           }
                       }
                       else
                       {
                           mRecyclerView.setVisibility(View.GONE);
                           mRLEmpty.setVisibility(View.VISIBLE);
                       }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                   }
                   else
                   {
                       mRecyclerView.setVisibility(View.GONE);
                       mRLEmpty.setVisibility(View.VISIBLE);
                       YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                   }
                   break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("data");
                                Type type = new TypeToken<List<LiveRoomBean>>() {
                                }.getType();
                                liveRoomList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mLiveListAdapter.updateListView(liveRoomList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
//                            mRecyclerView.setVisibility(View.GONE);
//                            mRLEmpty.setVisibility(View.VISIBLE);
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mRecyclerView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
//                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    public void setmTag(String mTag) {
        this.mTag = mTag;
    }

    @Override
    protected int getLayout()
    {
        return R.layout.fragment_live_list;
    }

    @Override
    protected void onResumeLazy()
    {
//        if (!NetUtils.isConnected(getContext()))
//        {
//            mTVRefreshNet.setVisibility(View.VISIBLE);
//            mIVEmpty.setImageResource(R.drawable.network_wrong);
//            mTVEmpty.setText("请检查您的手机是否联网");
//        }
//        else
//        {
//            mTVRefreshNet.setVisibility(View.GONE);
//            mIVEmpty.setImageResource(R.drawable.blank);
//            mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");
//        }

        if (mTag.equals(getString(R.string.tab2)))
            typeTag = 1;
        if (mTag.equals(getString(R.string.tab3)))
            typeTag = 2;

        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();

        if (!NetUtils.isConnected(getContext()))
        {
            mRLEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");

            if (isFirst)
            {
                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, typeTag, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                    }
                }, 1000);
            }
            else
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, typeTag, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
                    }
                });
            }
        }
        super.onResumeLazy();
    }

    @Override
    protected void initView()
    {
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mRLHeadView = (RelativeLayout) mRefreshView.findViewById(R.id.head_view);
        mTVState = (TextView) mRLHeadView.findViewById(R.id.state_tv);
        mRecyclerView = (RecyclerView) findViewById(R.id.mRecyclerView);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) findViewById(R.id.tv_refresh_net);

//        mTVEmpty.setText("暂时没有直播~");
        mTVState.setTextColor(ContextCompat.getColor(getContext(), R.color.live_hot_text_color));
        mRecyclerView.setVisibility(View.GONE);
        mRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

    }

    @Override
    protected void loadData()
    {
        watchRecordDao = new WatchRecordDao(getContext());
        mRLEmpty.setOnClickListener(this);
        mTVRefreshNet.setOnClickListener(this);

        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, typeTag, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
                    }
                });
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });

        mLiveListAdapter = new CommonRecyclerViewAdapter<LiveRoomBean>(getContext(), new ArrayList<LiveRoomBean>(), R.layout.recommented_grideview_item)
        {
            @Override
            public void convert(CommonRecyclerViewHolder holder, LiveRoomBean data, int position)
            {
                holder.setImage(getContext(), R.id.iv_img, data.getPicture());
                holder.setImage(getContext(), R.id.iv_head, data.getIcon());
                holder.setText(R.id.tv_user_name, data.getUsername());
                holder.setText(R.id.tv_watch_number, data.getLiveCount() + "");
                holder.setText(R.id.tv_areas_of_expertise, data.getTitle());
                holder.setImageResource(R.id.iv_sex, data.getSex() == 2 ? R.drawable.icon_boy : R.drawable.icon_girl);

                holder.setText(R.id.tv_live_type, data.getTag2());
//                if (typeTag == 1)
//                   holder.setText(R.id.tv_live_type, "金融");
//                else
//                   holder.setText(R.id.tv_live_type, "家教");

                if (data.getLiving() == 1)
                {
                    if (data.getLive_status() == 2)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_pay);
                    }
                    if (data.getLock() == 1)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_encrypt);
                    }
                    if (data.getLive_status() != 2 && data.getLock() != 1)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_live);
                    }
                }
                else
                {
                    holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_rest);
                }
            }

        };

        mLiveListAdapter.setOnItemClickListener(new CommonRecyclerViewAdapter.OnItemClickListener()
        {
            @Override
            public void OnItemClickListener(View view, final int position)
            {
             /*   if (NetUtils.isConnected(getContext()))
                {
                    if (!NetUtils.isWifi(getContext()))
                    {
                        comDialog = new YNCommonDialog(getContext(), R.style.transparentFrameWindowStyle, "您当前处于非WIFI环境下，是否要观看直播？", false, new YNCommonDialog.CustomDialogListener()
                        {
                            @Override
                            public void OnClick(View view)
                            {
                                switch (view.getId())
                                {
                                    case R.id.btnCancel:
                                        comDialog.dismiss();
                                        break;

                                    case R.id.btnConfirm:
                                        comDialog.dismiss();
                                        Intent intent = new Intent(getContext(),    YNLiveDetailsActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                        break;
                                }
                            }
                        });
                        comDialog.show();
                    }
                    else
                    {
                        Intent intent = new Intent(getContext(), YNLiveDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }*/
                if (NetUtils.isConnected(getContext()))
                {
                    if (!NetUtils.isWifi(getContext()))
                    {
                        noticeDialog = new YNPayDialog.Builder(getContext())
                                .setContentText("您当前处于非WIFI环境下，是否要观看直播？")
                                .setRightButtonTextColor(R.color.ynkj_red)
                                .setCanceledOnTouchOutside(false)
                                .setOnclickListener(new IDialogOnClickListener()
                                {
                                    @Override
                                    public void clickTopLeftButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickTopRightButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickBottomLeftButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                    }

                                    @Override
                                    public void clickBottomRightButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                        watchRecordDao.insertWatchRecord(liveRoomList.get(position));
                                        Intent intent = new Intent(getContext(), YNLiveDetailsActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void clickBottomButton(View view)
                                    {

                                    }
                                })
                                .build();
                        noticeDialog.show();
                    }
                    else
                    {
                        watchRecordDao.insertWatchRecord(liveRoomList.get(position));
                        Intent intent = new Intent(getContext(), YNLiveDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
                else
                {
//                    NetUtils.openSetting(getContext());
                    YNToastMaster.showToast(getContext(), "网络未连接", Toast.LENGTH_SHORT, Gravity.CENTER);
                }
            }
        });
        mRecyclerView.setAdapter(mLiveListAdapter);

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.tv_refresh_net:
            case R.id.empty:
                if (NetUtils.isConnected(getContext()))
                {
                    mRLEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");

                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, typeTag, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                        }
                    }, 1000);
                }
//                else
//                {
//                    YNToastMaster.showToast(getContext(), "网络未连接");
//                }
                break;
        }
    }

}
