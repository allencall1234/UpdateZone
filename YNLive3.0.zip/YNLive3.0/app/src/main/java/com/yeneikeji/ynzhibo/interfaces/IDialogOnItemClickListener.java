package com.yeneikeji.ynzhibo.interfaces;

import android.widget.Button;

/**
 * Created by Administrator on 2016/12/1.
 */
public interface IDialogOnItemClickListener
{
    void onItemClick(Button button, int position);
}
