package com.yeneikeji.ynzhibo.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/8/4.
 */
public class YNGuideActivity extends Activity
{
    private ViewPager mPageVP;// 引导页

    private List<ImageView> mImageViewList;

    MainPageAdapter mainPageAdapter;

    private TextView mSkip;// 跳过

    private TextView mIntoBtn;// 进入

    private Context mContext;

    private MyCount myCount;

   /* private int[] iamges = { R.drawable.bg_activity_page_1,
            R.drawable.bg_activity_page_2, R.drawable.bg_activity_page_3,
            R.drawable.bg_activity_page_4 };*/

    private int[] iamges = { R.drawable.loading_1, R.drawable.loading_2, R.drawable.loading_3};

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view = getLayoutInflater().inflate(R.layout.activity_guide, null);
//        AutoUtils.auto(view);
        setContentView(view);
        mContext = this;
        initUI();
        settingDo();
    }

    private void initUI()
    {
        mPageVP = (ViewPager) findViewById(R.id.vp_activity_guide);
        mIntoBtn = (TextView) findViewById(R.id.btn_activity_guide);
        mSkip = (TextView) findViewById(R.id.tv_skip);

        myCount = new MyCount(10000, 1000);// 创建一个倒计时 总时长10秒 间隔1秒
        myCount.start();// 开启倒计时
        mSkip.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                myCount.cancel();// 点击之后跳过
                startActivity(new Intent(YNGuideActivity.this, YNMainTabActivity.class));
                finish();
            }
        });

        mIntoBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                // 点击进入按钮后取消倒计时
                myCount.cancel();
                Intent intent = new Intent(mContext, YNMainTabActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void settingDo()
    {
        ImageView mImageView;
        mImageViewList = new ArrayList<ImageView>();
        for (int i = 0; i < iamges.length; i++)
        {
            mImageView = new ImageView(this);
            mImageViewList.add(mImageView);
        }

        mainPageAdapter = new MainPageAdapter();
        mPageVP.setAdapter(mainPageAdapter);
        mPageVP.setCurrentItem(0);
        mPageVP.setOnPageChangeListener(new ViewPager.OnPageChangeListener()
        {
            @Override
            public void onPageSelected(int arg0) {
                if (arg0 == mImageViewList.size() - 1)
                    mIntoBtn.setVisibility(View.VISIBLE);
                else
                    mIntoBtn.setVisibility(View.GONE);
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {

            }
        });
    }

    /* 定义一个倒计时的内部类 */
    class MyCount extends CountDownTimer {
        /**
         *
         * @param millisInFuture
         *            持续时长
         * @param countDownInterval
         *            间隔时长
         */
        public MyCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        /**
         * 在倒计时结束时调用
         */
        @Override
        public void onFinish()
        {
            startActivity(new Intent(YNGuideActivity.this, YNMainTabActivity.class));
            finish();
        }

        /**
         * 每间隔countDownInterval会调用一次
         *
         * @param millisUntilFinished
         *            已经过去了多长时间
         */
        @Override
        public void onTick(long millisUntilFinished) {
            mSkip.setText("跳过" + millisUntilFinished / 1000 + "s");
        }
    }

    class MainPageAdapter extends PagerAdapter
    {
        @Override
        public int getCount()
        {
            return mImageViewList.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {

            return arg0 == arg1;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(mImageViewList.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position)
        {
            ImageView view;
            int count = getCount();

            view = mImageViewList.get(position);

            view.setImageBitmap(YNBitMapUtil.readBitMap(mContext, iamges[position % count]));
            view.setScaleType(ImageView.ScaleType.FIT_XY);

            container.addView(mImageViewList.get(position), 0);
            return mImageViewList.get(position);
        }
    }
}
