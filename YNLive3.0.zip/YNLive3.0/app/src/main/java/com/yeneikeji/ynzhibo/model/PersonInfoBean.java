package com.yeneikeji.ynzhibo.model;

/**
 * 个人资料实体类
 */
public class PersonInfoBean
{
    /**
     * headPicPath : http://www.bejson.com
     * birthday : 2016年12月25日
     * nickName : 喵喵
     * sex : 1
     * describe : 啦啦啦啦啦啦啦啦
     */
    private String icon;
    private String date;
    private String username;
    private int sex;
    private String describes;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getDescribe() {
        return describes;
    }

    public void setDescribe(String describe) {
        this.describes = describe;
    }
}
