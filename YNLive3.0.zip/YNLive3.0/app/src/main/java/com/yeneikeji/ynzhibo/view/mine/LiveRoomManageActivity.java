package com.yeneikeji.ynzhibo.view.mine;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.TimePickerView;
import com.bigkoo.pickerview.listener.CustomListener;
import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 房间管理界面
 * Created by Administrator on 2017/6/8.
 */
public class LiveRoomManageActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private TextView mTVLiveAddress;
    private RelativeLayout mRLRateAddress;
    private TextView mTVRateAddress;
    private TextView mAginRateCode;
    private TextView mTVRoomId;
    private TextView mTVRoomName;
    private EditText mETSetPass;
    private TextView mTVPassSubmit;
//    private RadioGroup mRGConditions;
//    private RadioButton mRBAll,mRBMembers,mRBPay;
    private CheckBox mCBAll, mCBMembers, mCBPay;
    private TextView mTVChooseTime;
    private TextView mTVConditionsSubmit;
    private YNMyListView mLVMyManager;
//    private YNMyListView mLVMyVideo;
    private TextView mTVManagerEmpty;
//    private TextView mTVVideoEmpty;
    private TextView mShowHide;
    private TimePickerView pvCustomTime;
    private RelativeLayout mRLPayNumber;
    private EditText mETPayNumber;
    private RelativeLayout mRLEndTime;
    private TextView txtName;
    private TextView txtIdentifyInfo;
    private RelativeLayout mRLRoomNotice;
    private TextView mTVRoomNotice;

    private CommonAdapter mManagerAdapter;
    private CommonAdapter mRecodeVideoAdapter;
    private List<ChatRoomUserBean> mManagerList = new ArrayList<>();
    private List<RecordVideoBean> mVideoList = new ArrayList<>();

//    private boolean isShowHide;
    private int managerIndex;
    private Date mEndDate;
    private int conditionsStatus = 0;
    private String noticeContent;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                if (jsonArray == null)
                                {
                                    mTVManagerEmpty.setVisibility(View.VISIBLE);
                                }
                                else
                                {
                                    Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                                    mManagerList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    mManagerAdapter.updateListView(mManagerList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mTVManagerEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, R.string.request_fail);
                        mTVManagerEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

               /* case YNCommonConfig.MY_RECORD_VIDEO_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type = new TypeToken<List<RecordVideoBean>>() {}.getType();
                                    mVideoList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mRecodeVideoAdapter.updateListView(mVideoList);
                                }

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mTVVideoEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, R.string.request_fail);
                        mTVVideoEmpty.setVisibility(View.VISIBLE);
                    }
                    break;*/

                case YNCommonConfig.DELETE_ROOM_MANAGE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 54)
                        {
                            if (mManagerList.isEmpty())
                            {
                                mLVMyManager.setVisibility(View.GONE);
                                mTVManagerEmpty.setVisibility(View.VISIBLE);
                            }


                            mManagerList.remove(managerIndex);
                            mManagerAdapter.notifyDataSetChanged();
                        }
                    }
                    break;

                case YNCommonConfig.UPDATE_STREAMING_CODE_FLAG:
                    mAginRateCode.setFocusable(true);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 88)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                AccountUtils.getUserStatus().setPush_address(jsonObject.getJSONObject("0").getString("push_address"));
                                AccountUtils.getUserStatus().setPlay_address(jsonObject.getJSONObject("0").getString("play_address"));
                                mTVRateAddress.setText(YNCommonUtils.interceptionString(jsonObject.getJSONObject("0").getString("push_address")));
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(LiveRoomManageActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.SET_LIVE_ROOM_PASS_FLAG:
                    mTVPassSubmit.setClickable(true);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(LiveRoomManageActivity.this, baseBean.getInfo());
                        if (baseBean.getCode() == 85)
                        {
                            mTVPassSubmit.setVisibility(View.GONE);
                            mTVConditionsSubmit.setVisibility(View.GONE);
//                            mRBAll.setChecked(true);
                            mCBAll.setChecked(true);
                            mCBAll.setClickable(false);
                            mCBMembers.setClickable(false);
                            mCBPay.setClickable(false);
                            mRLPayNumber.setVisibility(View.GONE);
                            mRLEndTime.setVisibility(View.GONE);
                            AccountUtils.getAccountBean().setLock(1);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                mETSetPass.setText("......");
                                YNCommonUtils.hideSoftInput(LiveRoomManageActivity.this, view);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.LIVE_ROOM_PAY_FLAG:
                    mTVConditionsSubmit.setClickable(true);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);

                        YNToastMaster.showToast(LiveRoomManageActivity.this, baseBean.getInfo());
                        if (baseBean.getCode() == 85)
                        {
                            if (conditionsStatus == 0)
                            {
                                AccountUtils.getAccountBean().setLive_status(0);
                            }
                            if (conditionsStatus == 1)
                            {
                                AccountUtils.getAccountBean().setLive_status(1);
                            }
                            if (conditionsStatus == 2)
                            {
                                AccountUtils.getAccountBean().setLive_status(2);
                            }

                            mETSetPass.setClickable(false);
                            mTVConditionsSubmit.setVisibility(View.GONE);
                            mETSetPass.setText("");
                            mETPayNumber.setClickable(false);
                            mTVPassSubmit.setVisibility(View.GONE);
                            finish();
                        }

                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_manage);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getResources().getString(R.string.room_manage));

        mTVLiveAddress = (TextView) findViewById(R.id.tv_live_address);
        mRLRateAddress = (RelativeLayout) findViewById(R.id.rl_update_rate_address);
        mTVRateAddress = (TextView) findViewById(R.id.tv_rate_address);
        mAginRateCode = (TextView) findViewById(R.id.tv_again_get);
        txtName = (TextView) findViewById(R.id.txtName);
        txtIdentifyInfo = (TextView) findViewById(R.id.txtIdentifyInfo);
        mTVRoomName = (TextView) findViewById(R.id.tv_room_name);
        mTVRoomId = (TextView) findViewById(R.id.tv_room_id);
        mETSetPass = (EditText) findViewById(R.id.et_set_pass);
        //直播间密码提交
        mTVPassSubmit = (TextView) findViewById(R.id.tv_pass_submit);

        mCBAll = (CheckBox) findViewById(R.id.cb_all);
        mCBMembers = (CheckBox) findViewById(R.id.cb_members);
        mCBPay = (CheckBox) findViewById(R.id.cb_pay);
//        mRGConditions = (RadioGroup) findViewById(R.id.rg_conditions);
//        mRBAll = (RadioButton) mRGConditions.findViewById(R.id.rb_all);
//        mRBMembers = (RadioButton) mRGConditions.findViewById(R.id.rb_members);
//        mRBPay = (RadioButton) mRGConditions.findViewById(R.id.rb_pay);
        mTVChooseTime = (TextView) findViewById(R.id.tv_choose_time);
        mLVMyManager = (YNMyListView) findViewById(R.id.lv_my_manager);
//        mLVMyVideo = (YNMyListView) findViewById(R.id.lv_my_video);
        mTVManagerEmpty = (TextView) findViewById(R.id.tv_manager_empty);
//        mTVVideoEmpty = (TextView) findViewById(R.id.tv_video_empty);
        mShowHide = (TextView) findViewById(R.id.tv_show_hide);
        mETPayNumber = (EditText) findViewById(R.id.et_pay_number);
        mRLPayNumber = (RelativeLayout) findViewById(R.id.rl_pay_number);
        mRLEndTime = (RelativeLayout) findViewById(R.id.rl_end_time);
        //直播间收费提交
        mTVConditionsSubmit = (TextView) findViewById(R.id.tv_conditions_submit);
        mRLRoomNotice = (RelativeLayout) findViewById(R.id.rl_room_notice);
        mTVRoomNotice = (TextView) findViewById(R.id.tv_room_notice);

        initCustomTimePicker();
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mShowHide.setOnClickListener(this);
        mAginRateCode.setOnClickListener(this);
        mTVPassSubmit.setOnClickListener(this);
        mTVChooseTime.setOnClickListener(this);
        mTVConditionsSubmit.setOnClickListener(this);
        mRLRoomNotice.setOnClickListener(this);

        mCBAll.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                mCBAll.setChecked(isChecked);
                if (isChecked)
                {
                    conditionsStatus = 0;
                    mCBMembers.setChecked(false);
                    mCBPay.setChecked(false);
                }
                else
                {
                    conditionsStatus = -1;
                }
            }
        });

        mCBMembers.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                mCBMembers.setChecked(isChecked);
                if (isChecked)
                {
                    conditionsStatus = 1;
                    mCBAll.setChecked(false);
                    mCBPay.setChecked(false);
                }
                else
                {
                    conditionsStatus = -1;
                }
            }
        });

        mCBPay.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                mCBPay.setChecked(isChecked);
                if (isChecked)
                {
                    conditionsStatus = 2;
                    mRLPayNumber.setVisibility(View.VISIBLE);
                    mRLEndTime.setVisibility(View.VISIBLE);
                    mCBAll.setChecked(false);
                    mCBMembers.setChecked(false);
                }
                else
                {
                    conditionsStatus = -1;
                    mRLPayNumber.setVisibility(View.GONE);
                    mRLEndTime.setVisibility(View.GONE);
                }
            }
        });

//        mRGConditions.setOnCheckedChangeListener(new RadioGroup.IOnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId)
//            {
//
//                switch (checkedId)
//                {
//                    case R.id.rb_all:
//                        conditionsStatus = 0;
//                        mRLPayNumber.setVisibility(View.GONE);
//                        mRLEndTime.setVisibility(View.GONE);
//                        mTVPassSubmit.setVisibility(View.GONE);
//
//                        break;
//
//                    case R.id.rb_members:
//                        conditionsStatus = 1;
//                        mRLPayNumber.setVisibility(View.GONE);
//                        mRLEndTime.setVisibility(View.GONE);
//                        break;
//
//                    case R.id.rb_pay:
//                        conditionsStatus = 2;
//                        mRLPayNumber.setVisibility(View.VISIBLE);
//                        mRLEndTime.setVisibility(View.VISIBLE);
//                        break;
//                }
//
//                mETSetPass.setText("");
//
//            }
//        });
    }

    @Override
    protected void settingDo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().queryChatRoomManagerInfo(LiveRoomManageActivity.this, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_URL,
                        AccountUtils.getAccountBean().getRoom_id(), mHandler, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG, false);
            }
        });

//        mHandler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().myRecordVideoList(LiveRoomManageActivity.this, YNCommonConfig.MY_RECORD_VIDEO_LIST_URL,
//                        AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.MY_RECORD_VIDEO_LIST_FLAG, false);
//            }
//        });

        mTVLiveAddress.setText(YNCommonUtils.interceptionLiveAddressString(AccountUtils.getAccountBean().getPush_address()));
        mTVRateAddress.setText(YNCommonUtils.interceptionString(AccountUtils.getAccountBean().getPush_address()));
        txtName.setText(YNCommonUtils.hideName(AccountUtils.getAccountBean().getRealname()));
        txtIdentifyInfo.setText(YNCommonUtils.hideIDCenterNumber(AccountUtils.getAccountBean().getId_card()));
        mTVRoomName.setText("房间名称: " + AccountUtils.getAccountBean().getTitle());
        mTVRoomId.setText("房间ID: " + AccountUtils.getAccountBean().getRoom_id());

        if (AccountUtils.getAccountBean().getLock() == 1)
        {
            mETSetPass.setClickable(false);
            mETSetPass.setFocusable(false);
            mETSetPass.setText("......");
            mTVPassSubmit.setVisibility(View.INVISIBLE);
            mTVConditionsSubmit.setVisibility(View.GONE);
//            mRGConditions.setFocusable(false);
//            mRBAll.setFocusable(false);
//            mRBMembers.setFocusable(false);
//            mRBPay.setFocusable(false);
            mCBAll.setClickable(false);
            mCBMembers.setClickable(false);
            mCBPay.setClickable(false);
        }
        else
        {
            if (AccountUtils.getAccountBean().getLive_status() == 2)
            {
                mTVPassSubmit.setVisibility(View.INVISIBLE);
                mTVConditionsSubmit.setVisibility(View.INVISIBLE);
                mCBPay.setChecked(true);
                mCBPay.setClickable(false);
                mCBAll.setClickable(false);
                mCBMembers.setClickable(false);
//            mRBPay.setChecked(true);
                mETSetPass.setClickable(false);
                mETPayNumber.setClickable(false);
                mTVChooseTime.setClickable(false);
                mETPayNumber.setText(AccountUtils.getAccountBean().getPayCoin() + "");
                mTVChooseTime.setText(DateUtil.timeStamp2String(AccountUtils.getAccountBean().getExptime()));
            }
            if (AccountUtils.getAccountBean().getLive_status() == 0)
            {
//            mRBAll.setChecked(true);
                mCBAll.setChecked(true);
//                mCBAll.setClickable(false);
//                mCBMembers.setClickable(false);
//                mCBPay.setClickable(false);
            }
            if (AccountUtils.getAccountBean().getLive_status() == 1)
            {
//            mRBMembers.setChecked(true);
                mCBMembers.setChecked(true);
//                mCBMembers.setClickable(false);
//                mCBAll.setClickable(false);
//                mCBPay.setClickable(false);
            }
        }

        mManagerAdapter = new CommonAdapter<ChatRoomUserBean>(this, mManagerList, R.layout.manager_item)
        {
            @Override
            public void convert(final CommonViewHolder viewHolder, final ChatRoomUserBean item)
            {
                viewHolder.setText(R.id.tv_manager_nickname, item.getUsername());
                viewHolder.setText(R.id.tv_manager_id, item.getId());

                viewHolder.getView(R.id.tv_cancel).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        managerIndex = viewHolder.getPosition();
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().deleteRoomManager(LiveRoomManageActivity.this, YNCommonConfig.DELETE_ROOM_MANAGE_URL, AccountUtils.getUserStatus().getRoom_id(),
                                        item.getUserid(), mHandler, YNCommonConfig.DELETE_ROOM_MANAGE_FLAG, true);
                            }
                        });
                    }
                });
            }
        };

        mLVMyManager.setAdapter(mManagerAdapter);

//        mRecodeVideoAdapter = new CommonAdapter<RecordVideoBean>(this, mVideoList, R.layout.video_item)
//        {
//            @Override
//            public void convert(CommonViewHolder viewHolder, RecordVideoBean item)
//            {
//                viewHolder.setImage(LiveRoomManageActivity.this, R.id.iv_video, item.getThumbnailList());
//                viewHolder.setText(R.id.tv_video_title, item.getTitle());
//                viewHolder.setText(R.id.tv_video_time, item.getCreateTime());
//            }
//        };
//
//        mLVMyVideo.setAdapter(mRecodeVideoAdapter);

//        for (RecordVideoBean recordVideo : mVideoList)
//        {
//            YNLogUtil.i("cdy12345", mVideoList.size() + "");
//            SharedPrefsStore.addToMainVideo(this, recordVideo);
//        }

//        YNLogUtil.i("cdy12345", SharedPrefsStore.getAllMainVideoFromSP(this).size() + "");

//        mLVMyVideo.setOnItemClickListener(new AdapterView.OnItemClickListener()
//        {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
//            {
//                Intent intent = new Intent(MyLiveActivity.this, AdvancedPlayActivity.class);
//                intent.putExtra(YNCommonConfig.POSITION, position);
//                Bundle bundle = new Bundle();
//                bundle.putSerializable("List<RecordVideoBean>", (Serializable)mVideoList);
//                intent.putExtras(bundle);
//                startActivity(intent);
//            }
//        });
    }

    private void initCustomTimePicker() {
        // 注意：自定义布局中，id为 optionspicker 或者 timepicker 的布局以及其子控件必须要有，否则会报空指针
        // 具体可参考demo 里面的两个自定义布局
        //因为系统Calendar的月份是从0-11的,所以如果是调用Calendar的set方法来设置时间,月份的范围也要是从0-11
        //控制时间范围(如果不设置范围，则使用默认时间1900-2100年，此段代码可注释)
        Calendar selectedDate = Calendar.getInstance();//系统当前时间
        Calendar startDate = Calendar.getInstance();
        startDate.set(2014, 1, 23);
        Calendar endDate = Calendar.getInstance();
        endDate.set(2027, 2, 28);
        //时间选择器 ，自定义布局
        pvCustomTime = new TimePickerView.Builder(this, new TimePickerView.OnTimeSelectListener()
        {
            @Override
            public void onTimeSelect(Date date, View v)
            {
                mEndDate = date;
                //选中事件回调
                mTVChooseTime.setText(getTime(date));
            }
        })
                /*.setType(TimePickerView.Type.ALL)//default is all
                .setCancelText("Cancel")
                .setSubmitText("Sure")
                .setContentSize(18)
                .setTitleSize(20)
                .setTitleText("Title")
                .isCyclic(true)// default is false
                .setTitleColor(Color.BLACK)
               /*.setDividerColor(Color.WHITE)//设置分割线的颜色
                .setTextColorCenter(Color.LTGRAY)//设置选中项的颜色
                .setLineSpacingMultiplier(1.6f)//设置两横线之间的间隔倍数
                .setTitleBgColor(Color.DKGRAY)//标题背景颜色 Night mode
                .setBgColor(Color.BLACK)//滚轮背景颜色 Night mode
                .setSubmitColor(Color.WHITE)
                .setCancelColor(Color.WHITE)*/
               /*.gravity(Gravity.RIGHT)// default is center*/
                .setDate(selectedDate)
                .setRangDate(startDate,endDate)
                .setLayoutRes(R.layout.pickerview_custom_time, new CustomListener()
                {
                    @Override
                    public void customLayout(View v) {
                        final TextView tvSubmit = (TextView) v.findViewById(R.id.tv_finish);
                        ImageView ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
                        tvSubmit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvCustomTime.returnData();
                            }
                        });
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvCustomTime.dismiss();
                            }
                        });
                    }
                })
                .setDividerColor(Color.BLACK)
                .build();

    }

    private String getTime(Date date) {//可根据需要自行截取数据显示
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return format.format(date);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                YNCommonUtils.hideSoftInput(this, view);
                break;

            case R.id.tv_show_hide:
                if (mRLRateAddress.getVisibility() == View.VISIBLE)
                {
                    mRLRateAddress.setVisibility(View.GONE);
                    mShowHide.setText("查看");
                }
                else
                {
                    mRLRateAddress.setVisibility(View.VISIBLE);
                    mShowHide.setText("收起");
                }
                break;

            case R.id.tv_again_get:
                mAginRateCode.setClickable(false);
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().updateStreamingCode(LiveRoomManageActivity.this, YNCommonConfig.UPDATE_STREAMING_CODE_URL, AccountUtils.getAccountBean().getId(),
                                mHandler, YNCommonConfig.UPDATE_STREAMING_CODE_FLAG, false);
                    }
                });
                break;

            case R.id.tv_pass_submit:
                if (TextUtils.isEmpty(mETSetPass.getText().toString()))
                {
                    YNToastMaster.showToast(this, "密码不能为空");
                    return;
                }
                mTVPassSubmit.setClickable(false);
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().setLiveRoomPass(LiveRoomManageActivity.this, YNCommonConfig.SET_LIVE_ROOM_PASS_URL, AccountUtils.getAccountBean().getId(),
                                mETSetPass.getText().toString(), mHandler, YNCommonConfig.SET_LIVE_ROOM_PASS_FLAG, true);
                    }
                });
                break;

            case R.id.tv_choose_time:
                if (pvCustomTime != null)
                {
                    pvCustomTime.show(); //弹出自定义时间选择器
                }
                break;

            case R.id.tv_conditions_submit:
                if (conditionsStatus < 0)
                {
                    YNToastMaster.showToast(LiveRoomManageActivity.this, "直播权限未设置", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (mRLPayNumber.getVisibility() == View.VISIBLE)
                {
                    if (TextUtils.isEmpty(mETPayNumber.getText().toString()))
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, "支付金币不能为空");
                        return;
                    }
                    if (mEndDate == null)
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, "请选择时间");
                        return;
                    }
                    Date curDate = new Date(System.currentTimeMillis());//获取当前时间
                    if (mEndDate.after(curDate))
                    {
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().setLiveRoomPay(LiveRoomManageActivity.this, YNCommonConfig.LIVE_ROOM_PAY_URL, AccountUtils.getAccountBean().getId(),
                                        mTVChooseTime.getText().toString(), conditionsStatus, Integer.parseInt(mETPayNumber.getText().toString()), mHandler, YNCommonConfig.LIVE_ROOM_PAY_FLAG, false);
                            }
                        });

                    }
                    else
                    {
                        YNToastMaster.showToast(LiveRoomManageActivity.this, "时间小于当前系统时间", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                }
                else
                {
                    mTVConditionsSubmit.setClickable(false);
                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().setLiveRoomPay(LiveRoomManageActivity.this, YNCommonConfig.LIVE_ROOM_PAY_URL, AccountUtils.getAccountBean().getId(), "", 0,
                                    conditionsStatus, mHandler, YNCommonConfig.LIVE_ROOM_PAY_FLAG, true);
                        }
                    });
                }
                break;

            case R.id.rl_room_notice:
                Intent intent = new Intent(this, WriteExperienceActivity.class);
                intent.putExtra(YNCommonConfig.TITLE, getString(R.string.room_notice));
                intent.putExtra(YNCommonConfig.OBJECT, noticeContent);
                startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null)
            return;

        switch (requestCode)
        {
            case YNCommonConfig.ACTIVITY_RESULT:
                if (resultCode == YNCommonConfig.ACTIVITY_RESULT)
                {
                    noticeContent = data.getStringExtra(YNCommonConfig.OBJECT);
                }
                break;
        }

        mTVRoomNotice.setText(noticeContent);

    }

}
