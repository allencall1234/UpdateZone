package com.yeneikeji.ynzhibo.model;

import java.util.List;

/*
 *  @项目名：  YNZhiBo 
 *  @包名：    com.yeneikeji.ynzhibo.model
 *  @文件名:   CurrentMonthTestBean
 *  @创建者:   lxy
 *  @创建时间:  2017/4/27 21:27
 *  @描述：
 */
public class CurrentMonthTestBean {
    private static final String TAG = "CurrentMonthTestBean";
    public String         name;
    public List<GiftBean> datas;
}
