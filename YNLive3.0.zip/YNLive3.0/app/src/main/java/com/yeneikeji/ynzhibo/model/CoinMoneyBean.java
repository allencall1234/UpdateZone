package com.yeneikeji.ynzhibo.model;

/**
 * 金币充值实体类
 * Created by Administrator on 2016/11/9.
 */
public class CoinMoneyBean
{
    private int goldNum;
    private int coinMoney;

    public CoinMoneyBean()
    {

    }

    public CoinMoneyBean(int goldNum, int coinMoney) {
        this.goldNum = goldNum;
        this.coinMoney = coinMoney;
    }

    public int getGoldNum() {
        return goldNum;
    }

    public void setGoldNum(int goldNum) {
        this.goldNum = goldNum;
    }

    public int getCoinMoney() {
        return coinMoney;
    }

    public void setCoinMoney(int coinMoney) {
        this.coinMoney = coinMoney;
    }
}
