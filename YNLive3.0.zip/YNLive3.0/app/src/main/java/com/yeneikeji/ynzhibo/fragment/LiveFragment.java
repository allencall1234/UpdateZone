package com.yeneikeji.ynzhibo.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.view.live.LiveListFragment;
import com.yeneikeji.ynzhibo.view.live.RecommendFragment;
import com.yeneikeji.ynzhibo.view.live.YNSearchActivity;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.Indicator;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 直播首界面(带分类)
 * Created by Administrator on 2016/12/22.
 */
public class LiveFragment extends YNBaseTopBarFragment implements View.OnClickListener
{
    private Activity mActivity;
//    private Toolbar toolbar;
//    private ImageView mSearch;
    private ViewPager mLiveVP;
    private Indicator mIndicator;
//    private TabLayout tabs;
    private IndicatorViewPager indicatorViewPager;

//    private YNFragmentAdapter mAdapter;
    private MyAdapter mAdapter;

    /** Tab标题 */
    private  String[] tabTitle =  null;

    private ArrayList<Fragment> fragments;

    public static final String TAG = "LiveFragment";

    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
        this.mActivity = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_live, container, false);
        setHasOptionsMenu(true);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void initView(View view)
    {
        configTopBarCtrollerWithTitle(view, getResources().getString(R.string.app_name));
        getRightBtn().setVisibility(View.VISIBLE);
        getRightBtn().setImageResource(R.drawable.btn_search_selector);
        tabTitle = getResources().getStringArray(R.array.LiveColumnTitles);

//        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        mLiveVP = (ViewPager) view.findViewById(R.id.view_pager);
        mIndicator = (Indicator) view.findViewById(R.id.fragment_tabmain_indicator);
//        mSearch = (ImageView) view.findViewById(R.id.iv_search);
//        tabs = (TabLayout) view.findViewById(R.id.tabs);

//        tabs.setTabMode (TabLayout.MODE_SCROLLABLE);
//        tabs.setTabGravity(TabLayout.GRAVITY_FILL);
        float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#1694ff");
        int unSelectColor = Color.parseColor("#333333");
        ColorBar line1 = new ColorBar(getActivity(), Color.parseColor("#1694ff"), 5);
        line1.setWidth(UIUtils.dp2px(getActivity(), 55));
        line1.setHeight(UIUtils.dp2px(getActivity(), 2));
        mIndicator.setScrollBar(line1);
        mIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mLiveVP.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mIndicator, mLiveVP);

    }

    @Override
    protected void addEvents()
    {
        getRightBtn().setOnClickListener(this);
//        mSearch.setOnClickListener(this);
//        mLiveVP.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//        });
    }

    @Override
    protected void settingDo()
    {
        addFragment();
    }

    /**
     * 初始化Fragment
     */
    private void addFragment()
    {
        fragments = new ArrayList<Fragment>();
        fragments.clear();//清空
        int count =  tabTitle.length;
        for(int i = 0; i< count; i++)
        {
            if (i == 0)
            {
                RecommendFragment fragment= new RecommendFragment();
                fragments.add(fragment);
            }
            else
            {
                LiveListFragment fragment= new LiveListFragment();
                fragment.setmTag(tabTitle[i]);
                fragments.add(fragment);
            }

        }


        mAdapter = new MyAdapter(getChildFragmentManager());
        mAdapter.setFragments(fragments);
        indicatorViewPager.setAdapter(mAdapter);
//        mAdapter = new YNFragmentAdapter(getFragmentManager(), fragments, tabTitle);
//        mAdapter = new YNFragmentAdapter(getFragmentManager(), tabTitle);
//        mLiveVP.setOffscreenPageLimit(count);
//        mLiveVP.setAdapter(mAdapter);
//        tabs.setupWithViewPager(mLiveVP, true);
//        UIUtils.dynamicSetTabLayoutMode(tabs);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            //查询界面
            case R.id.star_1_com_topbar_iv_right:
                Intent intent = new Intent();
                intent.setClass(mContext, YNSearchActivity.class);
                startActivity(intent);
                break;

          /*  case R.id.iv_search:
                Intent intent = new Intent();
                intent.setClass(mContext, YNSearchActivity.class);
                startActivity(intent);
                break;*/
        }
    }

    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter
    {
        private List<Fragment> fragments = new ArrayList<>();
        public MyAdapter(FragmentManager fragmentManager)
        {
            super(fragmentManager);
        }

        public void setFragments( List<Fragment> fragments)
        {
            this.fragments = fragments;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return tabTitle.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container)
        {
            if (convertView == null)
            {
                convertView = LayoutInflater.from(mContext).inflate(R.layout.tab_textview, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabTitle[position]);
            return convertView;
        }


        @Override
        public Fragment getFragmentForPage(int position)
        {
            return fragments.get(position);
        }
    }

}
