package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNGridViewAdapter;
import com.yeneikeji.ynzhibo.adapter.YNWatchRecordAdapter;
import com.yeneikeji.ynzhibo.database.WatchRecordDao;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.ISelectChangeCallBack;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.live.YNLiveDetailsActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 观看记录界面
 */
public class YNRecordActivity extends YNBaseTopBarActivity implements View.OnClickListener, ISelectChangeCallBack
{
    private ListView mLVWatchRecord;
    private LinearLayout ll_menu;
    private TextView mTVSelectAll, mTVDelete;
    private TextView mTVEmpty;

    private WatchRecordDao watchRecordDao;
    private YNWatchRecordAdapter mWatchRecordAdapter;
    private List<LiveRoomBean> mWatchRecordList = new ArrayList<>();

    private boolean isSelectedAll = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ynrecord);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getResources().getString(R.string.watch_record));
        getRightBtn().setVisibility(View.VISIBLE);
        YNGridViewAdapter.setIsShow(false);

        mLVWatchRecord = (ListView) findViewById(R.id.lv_watch_record);
        mTVSelectAll = (TextView) findViewById(R.id.tv_select_all);
        mTVDelete = (TextView) findViewById(R.id.tv_delete);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);
        ll_menu = (LinearLayout) findViewById(R.id.ll_menu);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
        mTVSelectAll.setOnClickListener(this);
        mTVDelete.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        watchRecordDao = new WatchRecordDao(this);

        mWatchRecordAdapter = new YNWatchRecordAdapter(this, mWatchRecordList, this);
        mLVWatchRecord.setAdapter(mWatchRecordAdapter);

        mLVWatchRecord.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(YNRecordActivity.this, YNLiveDetailsActivity.class);
                intent.putExtra(YNCommonConfig.OBJECT, mWatchRecordList.get(position));
                startActivity(intent);
            }
        });

        getWatchRecordData();
    }

    private void getWatchRecordData()
    {
        mWatchRecordList.clear();
        mWatchRecordList = watchRecordDao.getWatchRecordList();

        if (mWatchRecordList.isEmpty())
        {
            mTVEmpty.setVisibility(View.VISIBLE);
        }
        else
        {
            mTVEmpty.setVisibility(View.GONE);
        }

        mWatchRecordAdapter.updateData(mWatchRecordList);

    }

   /* public void setShowSelected(boolean flag)
    {
        if(mWatchRecordAdapter!= null)
        {
            mWatchRecordAdapter.setShowSelected(flag);
            mWatchRecordAdapter.notifyDataSetChanged();
        }
    }

    public void setAllSelected(boolean flag)
    {
        if(flag)
        {
            if(mWatchRecordAdapter!= null)
            {
                Map<Integer, Boolean> selectedItem = mWatchRecordAdapter.getSelectedItem();
                for (int i = 0; i < selectedItem.size(); i++)
                {
                    selectedItem.put(i,true);
                }
                mWatchRecordAdapter.setSelectedItem(selectedItem);
                mWatchRecordAdapter.notifyDataSetChanged();
            }
        }
        else
        {
            if(mWatchRecordAdapter!= null)
            {
                Map<Integer, Boolean> selectedItem = mWatchRecordAdapter.getSelectedItem();
                for (int i = 0; i < selectedItem.size(); i++)
                {
                    selectedItem.put(i,false);
                }
                mWatchRecordAdapter.setSelectedItem(selectedItem);
                mWatchRecordAdapter.notifyDataSetChanged();
            }
        }
    }*/

    public void delete()
    {
        Map<Integer, Boolean> selectedItem = mWatchRecordAdapter.getSelectedItem();
        for (int i = mWatchRecordList.size() - 1; i >= 0; i--)
        {
            if(selectedItem.get(i))
            {
                watchRecordDao.deleteWatchRecord(mWatchRecordList.get(i).getRoom_id());
                mWatchRecordList.remove(i);
                selectedItem.remove(i);
            }
        }

        mWatchRecordAdapter.setSelectedItem(selectedItem);
        mWatchRecordAdapter.updateData(mWatchRecordList);
    }


    @Override
    public void onClick(View v)
    {
        Map<Integer, Boolean> isSelected = null;
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.star_1_com_topbar_iv_right:
                ll_menu.setVisibility((ll_menu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
                getRightBtn().setVisibility(View.GONE);
                getRightTV().setVisibility(View.VISIBLE);
                getRightTV().setText(R.string.cancel);
                mWatchRecordAdapter.setShowSelected(true);
                mWatchRecordAdapter.notifyDataSetChanged();
                break;

            case R.id.star_1_com_topbar_tv_right:
                ll_menu.setVisibility((ll_menu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
                getRightBtn().setVisibility(View.VISIBLE);
                getRightTV().setVisibility(View.GONE);
                mWatchRecordAdapter.setShowSelected(false);
                mWatchRecordAdapter.notifyDataSetChanged();
                break;

            case R.id.tv_select_all:
                if(isSelectedAll)
                {
                    isSelected = mWatchRecordAdapter.getSelectedItem();
                    for (int i = 0; i < isSelected.size(); i++)
                    {
                        isSelected.put(i,false);
                    }
                    mWatchRecordAdapter.setSelectedItem(isSelected);
                    mWatchRecordAdapter.notifyDataSetChanged();
                    mTVSelectAll.setText("全选");
                    mTVDelete.setText("删除");
                    isSelectedAll = false;
                }
                else
                {
                    isSelected = mWatchRecordAdapter.getSelectedItem();
                    for (int i = 0; i < isSelected.size(); i++)
                    {
                        isSelected.put(i,true);
                    }
                    mWatchRecordAdapter.setSelectedItem(isSelected);
                    mWatchRecordAdapter.notifyDataSetChanged();
                    mTVSelectAll.setText("取消全选");
                    mTVDelete.setText("删除("+isSelected.size()+")");
                    isSelectedAll = true;
                }
                break;

            case R.id.tv_delete:
                if (mWatchRecordAdapter.getSelectedItem().size() > 0)
                {
                    if (isSelectedAll)
                    {
                        watchRecordDao.deleteAllRecord();
                        getWatchRecordData();
                    }
                    else
                    {
                        delete();
                    }

                    ll_menu.setVisibility(View.GONE);
                    getRightBtn().setVisibility(View.VISIBLE);
                    getRightTV().setVisibility(View.GONE);
                    mTVDelete.setText("删除(0)");
                    mWatchRecordAdapter.setShowSelected(false);
                    mWatchRecordAdapter.notifyDataSetChanged();
                }
                break;
        }
    }

    @Override
    public void onSelectedSizeChange(Map<Integer, Boolean> isSelected)
    {
        int checkedSize = 0;
        if(isSelected!= null && isSelected.size()>0)
        {
            for (int i = 0; i < isSelected.size() ; i++)
            {
                if(isSelected.get(i)){
                    checkedSize++;
                }
            }
        }

        if(checkedSize == isSelected.size())
        {
            mTVSelectAll.setText("取消全选");
            isSelectedAll= true;
        }
        else
        {
            mTVSelectAll.setText("全选");
            isSelectedAll = false;
        }
        mTVDelete.setText("删除("+checkedSize+")");

        if(checkedSize == 0)
        {
            mTVDelete.setText("删除(0)");
        }
    }
}
