package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/*
* 这是充值详情页面
* */
public class YNGoldCoinDetails
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yngold_coin_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("充值详情");

    }
    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (view.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                Toast.makeText(context, "我被打了", Toast.LENGTH_SHORT)
                     .show();
                finish();
                break;
        }

    }
}
