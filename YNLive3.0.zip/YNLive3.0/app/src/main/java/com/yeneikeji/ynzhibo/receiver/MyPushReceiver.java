package com.yeneikeji.ynzhibo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.yeneikeji.ynzhibo.fragment.MineFragment;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.live.LiveLayerFragment;
import com.yeneikeji.ynzhibo.view.live.PushStreamingActivity;
import com.yeneikeji.ynzhibo.view.live.YNLiveDetailsActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

import cn.jpush.android.api.JPushInterface;

/**
 *  自定义推送接收器
 *  如果不定义这个 Receiver，则：
 * 1) 默认用户会打开主界面
 * 2) 接收不到自定义消息
 * 极光推送类型：0、系统通知 1、开播通知 2、评论消息 3、关注消息 4、点赞消息 5、系统消息
 * Created by Administrator on 2017/4/26.
 */
public class MyPushReceiver extends BroadcastReceiver
{
    private static final String TAG = "JPush";

    @Override
    public void onReceive(Context context, Intent intent)
    {
        Bundle bundle = intent.getExtras();
        YNLogUtil.d(TAG, "[MyReceiver] onReceive - " + intent.getAction() + ", extras: " + printBundle(bundle));

        if (JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())) {
            String regId = bundle.getString(JPushInterface.EXTRA_REGISTRATION_ID);
            YNLogUtil.d(TAG, "[MyReceiver] 接收Registration Id : " + regId);
            //send the Registration Id to your server...

        } else if (JPushInterface.ACTION_MESSAGE_RECEIVED.equals(intent.getAction())) {
            YNLogUtil.d(TAG, "[MyReceiver] 接收到推送下来的自定义消息: " + bundle.getString(JPushInterface.EXTRA_MESSAGE));
            processCustomMessage(context, bundle);

        } else if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent.getAction())) {
            YNLogUtil.d(TAG, "[MyReceiver] 接收到推送下来的通知");
            int notifactionId = bundle.getInt(JPushInterface.EXTRA_NOTIFICATION_ID);
            YNLogUtil.d(TAG, "[MyReceiver] 接收到推送下来的通知的ID: " + notifactionId);
            processNotification(context, bundle);


        } else if (JPushInterface.ACTION_NOTIFICATION_OPENED.equals(intent.getAction()))
        {
            YNLogUtil.d(TAG, "[MyReceiver] 用户点击打开了通知");
            openNotification(context, bundle);

        } else if (JPushInterface.ACTION_RICHPUSH_CALLBACK.equals(intent.getAction())) {
            YNLogUtil.d(TAG, "[MyReceiver] 用户收到到RICH PUSH CALLBACK: " + bundle.getString(JPushInterface.EXTRA_EXTRA));
            //在这里根据 JPushInterface.EXTRA_EXTRA 的内容处理代码，比如打开新的Activity， 打开一个网页等..

        } else if(JPushInterface.ACTION_CONNECTION_CHANGE.equals(intent.getAction())) {
            boolean connected = intent.getBooleanExtra(JPushInterface.EXTRA_CONNECTION_CHANGE, false);
            YNLogUtil.w(TAG, "[MyReceiver]" + intent.getAction() +" connected state change to "+connected);
        } else {
            YNLogUtil.d(TAG, "[MyReceiver] Unhandled intent - " + intent.getAction());
        }
    }

    // 打印所有的 intent extra 数据
    private static String printBundle(Bundle bundle) {
        StringBuilder sb = new StringBuilder();
        for (String key : bundle.keySet()) {
            if (key.equals(JPushInterface.EXTRA_NOTIFICATION_ID)) {
                sb.append("\nkey:" + key + ", value:" + bundle.getInt(key));
            }else if(key.equals(JPushInterface.EXTRA_CONNECTION_CHANGE)){
                sb.append("\nkey:" + key + ", value:" + bundle.getBoolean(key));
            } else if (key.equals(JPushInterface.EXTRA_EXTRA)) {
                if (TextUtils.isEmpty(bundle.getString(JPushInterface.EXTRA_EXTRA))) {
                    YNLogUtil.i(TAG, "This message has no Extra data");
                    continue;
                }

                try {
                    JSONObject json = new JSONObject(bundle.getString(JPushInterface.EXTRA_EXTRA));
                    Iterator<String> it =  json.keys();

                    while (it.hasNext()) {
                        String myKey = it.next().toString();
                        sb.append("\nkey:" + key + ", value: [" +
                                myKey + " - " +json.optString(myKey) + "]");
                    }
                } catch (JSONException e) {
                    YNLogUtil.e(TAG, "Get message extra JSON error!");
                }

            } else {
                sb.append("\nkey:" + key + ", value:" + bundle.getString(key));
            }
        }
//        YNLogUtil.e(TAG, bundle.getString(JPushInterface.EXTRA_EXTRA));
//        YNLogUtil.e(TAG, bundle.getString(JPushInterface.EXTRA_MESSAGE));
//        YNLogUtil.e(TAG, bundle.getString(JPushInterface.EXTRA_ALERT));
//        YNLogUtil.e(TAG, sb.toString());
        return sb.toString();
    }

    /**
     * 处理推送的通知
     * @param context
     * @param bundle
     */
    private void processNotification(Context context, Bundle bundle)
    {
        {
            String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
            if (!TextUtils.isEmpty(extras))
            {
                try
                {
                    JSONObject extraJson = new JSONObject(extras);
                    int msgType = extraJson.optInt("type");
                    if (msgType == 10)
                    {
                        Intent loginNotification = new Intent(YNBaseActivity.MESSAGE_RECEIVED_ACTION);
                        loginNotification.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        loginNotification.putExtra(YNCommonConfig.KEY_EXTRAS, bundle.getString(JPushInterface.EXTRA_ALERT));
                        loginNotification.putExtra(YNCommonConfig.TITLE, msgType);
                        context.sendBroadcast(loginNotification);
                    }
                }
                catch (JSONException e)
                {

                }
            }

        }
    }

    /**
     * 打开通知
     * 推送类型：0、系统通知  1、开播通知  10、登录通知  11、充值通知
     * @param context
     * @param bundle
     */
    private void openNotification(Context context, Bundle bundle)
    {
        String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
        String notificationType;
        LiveRoomBean liveRoomBean;
        try
        {
            JSONObject extrasJson = new JSONObject(extras);
            notificationType = extrasJson.optString("type");
            liveRoomBean = YNJsonUtil.JsonToBean(extrasJson.getString("txt"), LiveRoomBean.class);
        }
        catch (Exception e)
        {
            YNLogUtil.w(TAG, "Unexpected: extras is not a valid json");
            return;
        }

        if ("1".equals(notificationType))
        {
            Intent mIntent = new Intent(context, YNLiveDetailsActivity.class);
            mIntent.putExtra(YNCommonConfig.OBJECT, liveRoomBean);
            mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(mIntent);
        }
    }

    /**
     * 处理推送的消息
     * 推送类型：2、评论消息  3、关注消息  4、点赞消息  5、系统消息  6、提问消息  7、回复消息  8、普通房间邀请房管消息  9、接受/拒绝(普通房间)  12、邀请认证主播  13、邀请子房间房主  14、接收/拒绝(子房间的房管) 15、子房间的房管邀请
     * @param context
     * @param bundle
     */
    private void processCustomMessage(Context context, Bundle bundle)
    {

        String message = bundle.getString(JPushInterface.EXTRA_MESSAGE);
        String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
        Intent msgIntent = null;
//        Intent msgCountIntent = new Intent(MineFragment.MESSAGE_RECEIVED_ACTION);
//        context.sendBroadcast(msgCountIntent, null);
        if (!TextUtils.isEmpty(extras))
        {
            try
            {
                JSONObject extraJson = new JSONObject(extras);
                int msgType = extraJson.optInt("type");
                if (msgType == 6)
                {
                    msgIntent = new Intent(PushStreamingActivity.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.sendBroadcast(msgIntent);
                }
                if (msgType == 7)
                {
                    msgIntent = new Intent(LiveLayerFragment.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.sendBroadcast(msgIntent);
                }
                if (msgType == 8 || msgType == 12 || msgType == 13 || msgType == 15)
                {
                    msgIntent = new Intent(YNBaseActivity.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    msgIntent.putExtra(YNCommonConfig.KEY_MESSAGE, message);
                    msgIntent.putExtra(YNCommonConfig.KEY_EXTRAS, extras);
                    msgIntent.putExtra(YNCommonConfig.TITLE, msgType);
                    context.sendBroadcast(msgIntent);
                }
               /* if (msgType == 12)
                {
                    msgIntent = new Intent(YNBaseActivity.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    msgIntent.putExtra(YNCommonConfig.KEY_MESSAGE, message);
                    msgIntent.putExtra(YNCommonConfig.KEY_EXTRAS, extras);
                    msgIntent.putExtra(YNCommonConfig.TITLE, msgType);
                    context.sendBroadcast(msgIntent);
                }
                if (msgType == 13)
                {
                    msgIntent = new Intent(YNBaseActivity.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    msgIntent.putExtra(YNCommonConfig.KEY_MESSAGE, message);
                    msgIntent.putExtra(YNCommonConfig.KEY_EXTRAS, extras);
                    msgIntent.putExtra(YNCommonConfig.TITLE, msgType);
                    context.sendBroadcast(msgIntent);
                }*/
         /*       if (msgType == 10)
                {
                    msgIntent = new Intent(YNBaseActivity.MESSAGE_RECEIVED_ACTION);
                    msgIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    msgIntent.putExtra(YNCommonConfig.TITLE, msgType);
                    context.sendOrderedBroadcast(msgIntent, null);
                }*/
            }
            catch (JSONException e)
            {

            }
        }
    }

    /**
     * 处理自定义消息
     * @param context
     * @param bundle
     */
  /*  private void processCustomMessage(Context context, Bundle bundle)
    {
        String title = bundle.getString(JPushInterface.EXTRA_TITLE);
        String message = bundle.getString(JPushInterface.EXTRA_MESSAGE);
        if (StringUtils.isEmpty(title))
        {
            YNLogUtil.w(TAG, "Unexpected: empty title (friend). Give up");
            return;
        }

        boolean needIncreaseUnread = true;

        if (title.equalsIgnoreCase(Config.myName))
        {
            YNLogUtil.d(TAG, "Message from myself. Give up");
            needIncreaseUnread = false;
            if (!Config.IS_TEST_MODE)
            {
                return;
            }
        }

        String channel = null;
        String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
        try {
            JSONObject extrasJson = new JSONObject(extras);
            channel = extrasJson.optString(Constants.KEY_CHANNEL);
        } catch (Exception e) {
            YNLogUtil.w(TAG, "Unexpected: extras is not a valid json", e);
        }

        // Send message to UI (Webview) only when UI is up
        if (!Config.isBackground) {
            Intent msgIntent = new Intent(MainActivity.MESSAGE_RECEIVED_ACTION);
            msgIntent.putExtra(Constants.KEY_MESSAGE, message);
            msgIntent.putExtra(Constants.KEY_TITLE, title);
            if (null != channel) {
                msgIntent.putExtra(Constants.KEY_CHANNEL, channel);
            }

            JSONObject all = new JSONObject();
            try {
                all.put(Constants.KEY_TITLE, title);
                all.put(Constants.KEY_MESSAGE, message);
                all.put(Constants.KEY_EXTRAS, new JSONObject(extras));
            } catch (JSONException e) {
            }
            msgIntent.putExtra("all", all.toString());

            context.sendBroadcast(msgIntent);
        }

        String chatting = title;
        if (!StringUtils.isEmpty(channel)) {
            chatting = channel;
        }

        String currentChatting = MyPreferenceManager.getString(Constants.PREF_CURRENT_CHATTING, null);
        if (chatting.equalsIgnoreCase(currentChatting)) {
            Logger.d(TAG, "Is now chatting with - " + chatting + ". Dont show notificaiton.");
            needIncreaseUnread = false;
            if (!Config.IS_TEST_MODE) {
                return;
            }
        }

        if (needIncreaseUnread) {
            unreadMessage(title, channel);
        }

        NotificationHelper.showMessageNotification(context, nm, title, message, channel);
    }*/

    // When received message, increase unread number for Recent Chat
/*    private void unreadMessage(final String friend, final String channel)
    {
        new Thread()
        {
            public void run()
            {
                String chattingFriend = null;
                if (StringUtils.isEmpty(channel))
                {
                    chattingFriend = friend;
                }

                Map<String, String> params = new HashMap<String, String>();
                params.put("udid", Config.udid);
                params.put("friend", chattingFriend);
                params.put("channel_name", channel);

                try
                {
                    HttpHelper.post(Constants.PATH_UNREAD, params);
                }
                catch (Exception e)
                {
                    YNLogUtil.e(TAG, "Call pushtalk api to report unread error", e);
                }
            }
        }.start();
    }*/

}

