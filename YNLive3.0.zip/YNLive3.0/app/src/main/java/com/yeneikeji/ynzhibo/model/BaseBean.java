package com.yeneikeji.ynzhibo.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2016/11/16.
 */
public class BaseBean implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String info;
    private int code;


    private List<UserInfoBean> users;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public List<UserInfoBean> getUsers() {
        return users;
    }

    public void setUsers(List<UserInfoBean> users) {
        this.users = users;
    }


}


