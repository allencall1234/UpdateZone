package com.yeneikeji.ynzhibo.model;


import java.io.Serializable;

public class UserInfoBean implements Serializable
{
    /**
     * id : 6
     * phone : 18192870120
     * password : e10adc3949ba59abbe56e057f20f883e
     * username :
     * realname : lalal
     * id_card : 1238947128
     * picture : /Admin/2016-12-27/5861e6bda81f9.jpg
     * type : 0
     * sex : 0
     * icon :
     * register_time : 0
     * describe :
     * report_num : 0
     * account_status : 0
     * user_status : 0
     * check_status : 0
     * room_status :
     * status : 0
     * grade : 1
     * tittle :
     * time : 0
     */
    private String id;
    private String phone;
    private String phone1;
    private String password;
    private String useraccount;// 用户账户
    private String username;
    private String realname;
    private String id_card;
    private String picture;// 直播封面图片
    private String type;
    private String sex;
    private String icon;// 头像
    private String register_time;
    private String describes;
    private String report_num;
    private String status;
    private String grade;// 用户等级
    private String time;
    private int funs_count;
    private int focus_count;
    private int dynamic_count;
    private int is_attention;
//    private int count1;// 关注数量
//    private int count2;// 粉丝数量
//    private int count3;// 动态数量

    private String userId;
    private String blockEndTime;
    private int live_status;
    private int user_status;
    private float payCoin;
    private float incomeCoin;

    private String picture0;
    private String picture1;
    private String picture2;
    private String picture3;
    private String picture4;
    private String picture5;
    private String kind;
    private String experience;
    private int account_status;
    private int check_status;
    private int room_status;
    private String confirm_time;
    private String host_id;
    private String forbid_time;
    private String last_time;
    private String is_lift;
    private String submit_time;
    private String fail_reason;
    private String equipmentId;
    private int read_jbao;
    private float currentCoin;
    private int contribution;
    private int wealth;
    private int zanCount;
    private String room_id;
    private String push_address;
    private int count1;
    private int count2;
    private int count3;

    private int right;
    private int lock;
    private String exptime;
    private String pwd;

    /****/
    private String content;
    private String is_pay;
    private String mediaId;
    private String smallpicture0;
    private String smallpicture1;
    private String smallpicture2;
    private String title;
    private String userid;
    private String view;
    private String send_status;// 是否发送直播通知标识
    private int tag2;// 标签id
    private int classify;// 栏目id



    public UserInfoBean(String id, String userName, String headImgUrl)
    {
        this.id = id;
        this.username = userName;
        this.picture = headImgUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUseraccount() {
        return useraccount;
    }

    public void setUseraccount(String useraccount) {
        this.useraccount = useraccount;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getId_card() {
        return id_card;
    }

    public void setId_card(String id_card) {
        this.id_card = id_card;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getRegister_time() {
        return register_time;
    }

    public void setRegister_time(String register_time) {
        this.register_time = register_time;
    }

    public String getDescribe() {
        return describes;
    }

    public void setDescribe(String describe) {
        this.describes = describe;
    }

    public String getReport_num() {
        return report_num;
    }

    public void setReport_num(String report_num) {
        this.report_num = report_num;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getFuns_count() {
        return funs_count;
    }

    public void setFuns_count(int funs_count) {
        this.funs_count = funs_count;
    }

    public int getFocus_count() {
        return focus_count;
    }

    public void setFocus_count(int focus_count) {
        this.focus_count = focus_count;
    }

    public int getDynamic_count() {
        return dynamic_count;
    }

    public void setDynamic_count(int dynamic_count) {
        this.dynamic_count = dynamic_count;
    }

    public int getIs_attention() {
        return is_attention;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBlockEndTime() {
        return blockEndTime;
    }

    public void setBlockEndTime(String blockEndTime) {
        this.blockEndTime = blockEndTime;
    }

    public int getLive_status() {
        return live_status;
    }

    public void setLive_status(int live_status) {
        this.live_status = live_status;
    }

    public int getUser_status() {
        return user_status;
    }

    public void setUser_status(int user_status) {
        this.user_status = user_status;
    }

    public float getPayCoin() {
        return payCoin;
    }

    public void setPayCoin(float payCoin) {
        this.payCoin = payCoin;
    }

    public float getIncomeCoin() {
        return incomeCoin;
    }

    public void setIncomeCoin(float incomeCoin) {
        this.incomeCoin = incomeCoin;
    }

    public String getPicture0() {
        return picture0;
    }

    public void setPicture0(String picture0) {
        this.picture0 = picture0;
    }

    public String getPicture1() {
        return picture1;
    }

    public void setPicture1(String picture1) {
        this.picture1 = picture1;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getPicture3() {
        return picture3;
    }

    public void setPicture3(String picture3) {
        this.picture3 = picture3;
    }

    public String getPicture4() {
        return picture4;
    }

    public void setPicture4(String picture4) {
        this.picture4 = picture4;
    }

    public String getPicture5() {
        return picture5;
    }

    public void setPicture5(String picture5) {
        this.picture5 = picture5;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public int getAccount_status() {
        return account_status;
    }

    public void setAccount_status(int account_status) {
        this.account_status = account_status;
    }

    public int getCheck_status() {
        return check_status;
    }

    public void setCheck_status(int check_status) {
        this.check_status = check_status;
    }

    public int getRoom_status() {
        return room_status;
    }

    public void setRoom_status(int room_status) {
        this.room_status = room_status;
    }

    public String getConfirm_time() {
        return confirm_time;
    }

    public void setConfirm_time(String confirm_time) {
        this.confirm_time = confirm_time;
    }

    public String getHost_id() {
        return host_id;
    }

    public void setHost_id(String host_id) {
        this.host_id = host_id;
    }

    public String getForbid_time() {
        return forbid_time;
    }

    public void setForbid_time(String forbid_time) {
        this.forbid_time = forbid_time;
    }

    public String getLast_time() {
        return last_time;
    }

    public void setLast_time(String last_time) {
        this.last_time = last_time;
    }

    public String getIs_lift() {
        return is_lift;
    }

    public void setIs_lift(String is_lift) {
        this.is_lift = is_lift;
    }

    public String getSubmit_time() {
        return submit_time;
    }

    public void setSubmit_time(String submit_time) {
        this.submit_time = submit_time;
    }

    public String getFail_reason() {
        return fail_reason;
    }

    public void setFail_reason(String fail_reason) {
        this.fail_reason = fail_reason;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public int getRead_jbao() {
        return read_jbao;
    }

    public void setRead_jbao(int read_jbao) {
        this.read_jbao = read_jbao;
    }

    public float getCurrentCoin() {
        return currentCoin;
    }

    public void setCurrentCoin(float currentCoin) {
        this.currentCoin = currentCoin;
    }

    public int getContribution() {
        return contribution;
    }

    public void setContribution(int contribution) {
        this.contribution = contribution;
    }

    public int getWealth() {
        return wealth;
    }

    public void setWealth(int wealth) {
        this.wealth = wealth;
    }

    public int getZanCount() {
        return zanCount;
    }

    public void setZanCount(int zanCount) {
        this.zanCount = zanCount;
    }

    public String getRoom_id() {
        return room_id;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public String getPush_address() {
        return push_address;
    }

    public void setPush_address(String push_address) {
        this.push_address = push_address;
    }

    public int getCount1() {
        return count1;
    }

    public void setCount1(int count1) {
        this.count1 = count1;
    }

    public int getCount2() {
        return count2;
    }

    public void setCount2(int count2) {
        this.count2 = count2;
    }

    public int getCount3() {
        return count3;
    }

    public void setCount3(int count3) {
        this.count3 = count3;
    }

    public int getRight() {
        return right;
    }

    public void setRight(int right) {
        this.right = right;
    }

    public int getLock() {
        return lock;
    }

    public void setLock(int lock) {
        this.lock = lock;
    }

    public String getExptime() {
        return exptime;
    }

    public void setExptime(String exptime) {
        this.exptime = exptime;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getContent() { return content;}


    /*新增发现主播主页文章内容bean内容
    * */
   /* public void setContent(String content) { this.content = content;}
    public String getIs_pay() { return is_pay;}

    public void setIs_pay(String is_pay) { this.is_pay = is_pay;}

    public String getMediaId() { return mediaId;}

    public void setMediaId(String mediaId) { this.mediaId = mediaId;}
    public String getSmallpicture0() { return smallpicture0;}

    public void setSmallpicture0(String smallpicture0) { this.smallpicture0 = smallpicture0;}

    public String getSmallpicture1() { return smallpicture1;}

    public void setSmallpicture1(String smallpicture1) { this.smallpicture1 = smallpicture1;}

    public String getSmallpicture2() { return smallpicture2;}

    public void setSmallpicture2(String smallpicture2) { this.smallpicture2 = smallpicture2;}
    public String getTitle() { return title;}

    public void setTitle(String title) { this.title = title;}
*/
    public String getUserid() { return userid;}

    public void setUserid(String userid) { this.userid = userid;}

    /*public String getView() { return view;}

    public void setView(String view) { this.view = view;}*/

    public String getSend_status() {
        return send_status;
    }

    public void setSend_status(String send_status) {
        this.send_status = send_status;
    }

    public int getTag2() {
        return tag2;
    }

    public void setTag2(int tag2) {
        this.tag2 = tag2;
    }

    public int getClassify() {
        return classify;
    }

    public void setClassify(int classify) {
        this.classify = classify;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }
}
