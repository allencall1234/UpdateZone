package com.yeneikeji.ynzhibo.model;

/**
 * Created by Administrator on 2017/7/5.
 */
public class AnchorInfoBean extends BaseBean
{
    private int attentions;
    private int funs;
    private float live;
    private float audio;
    private float article;
    private float overall;

    public int getAttentions() {
        return attentions;
    }

    public void setAttentions(int attentions) {
        this.attentions = attentions;
    }

    public int getFuns() {
        return funs;
    }

    public void setFuns(int funs) {
        this.funs = funs;
    }

    public float getLive() {
        return live;
    }

    public void setLive(float live) {
        this.live = live;
    }

    public float getAudio() {
        return audio;
    }

    public void setAudio(float audio) {
        this.audio = audio;
    }

    public float getArticle() {
        return article;
    }

    public void setArticle(float article) {
        this.article = article;
    }

    public float getOverall() {
        return overall;
    }

    public void setOverall(float overall) {
        this.overall = overall;
    }
}
