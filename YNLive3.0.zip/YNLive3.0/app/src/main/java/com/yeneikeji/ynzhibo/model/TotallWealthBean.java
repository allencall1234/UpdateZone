package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * Created by Administrator on 2017/4/27.
 */

public class TotallWealthBean {

    /**
     * code : 28
     * info : 获取数据成功！
     * data : [{"id":"462","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:03","type":"0","username":"bigbaby","wealth":660},{"id":"463","userid":"43","toId":"60","giftName":"中华牌香烟","count":"1","price":"66","time":"2017-04-26 16:05","type":"0","username":"bigbaby","wealth":660},{"id":"464","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:07","type":"0","username":"bigbaby","wealth":660},{"id":"465","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:07","type":"0","username":"bigbaby","wealth":660},{"id":"466","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:07","type":"0","username":"bigbaby","wealth":660},{"id":"467","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:08","type":"0","username":"bigbaby","wealth":660},{"id":"468","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:08","type":"0","username":"bigbaby","wealth":660},{"id":"469","userid":"43","toId":"60","giftName":"鲜花","count":"1","price":"66","time":"2017-04-26 16:08","type":"0","username":"bigbaby","wealth":660},{"id":"470","userid":"43","toId":"60","giftName":"股神称号","count":"1","price":"66","time":"2017-04-26 16:08","type":"0","username":"bigbaby","wealth":660},{"id":"471","userid":"43","toId":"60","giftName":"中华牌香烟","count":"1","price":"66","time":"2017-04-26 16:09","type":"0","username":"bigbaby","wealth":660},{"id":"472","userid":"43","toId":"60","giftName":"股神称号","count":"1","price":"66","time":"2017-04-26 16:09","type":"0","username":"bigbaby","wealth":660},{"id":"474","userid":"43","toId":"60","giftName":"中华牌香烟","count":"1","price":"66","time":"2017-04-26 16:10","type":"0","username":"bigbaby","wealth":660}]
     */

    private int code;
    private String   info;
    private List<DataBean> data;

    public int getCode() { return code;}

    public void setCode(int code) { this.code = code;}

    public String getInfo() { return info;}

    public void setInfo(String info) { this.info = info;}

    public List<DataBean> getData() { return data;}

    public void setData(List<DataBean> data) { this.data = data;}

    public static class DataBean {
        /**
         * id : 462
         * userid : 43
         * toId : 60
         * giftName : 鲜花
         * count : 1
         * price : 66
         * time : 2017-04-26 16:03
         * type : 0
         * username : bigbaby
         * wealth : 660
         */

        private String id;
        private String userid;
        private String toId;
        private String giftName;
        private String count;
        private String price;
        private String time;
        private String type;
        private String username;
        private int    wealth;

        public String getId() { return id;}

        public void setId(String id) { this.id = id;}

        public String getUserid() { return userid;}

        public void setUserid(String userid) { this.userid = userid;}

        public String getToId() { return toId;}

        public void setToId(String toId) { this.toId = toId;}

        public String getGiftName() { return giftName;}

        public void setGiftName(String giftName) { this.giftName = giftName;}

        public String getCount() { return count;}

        public void setCount(String count) { this.count = count;}

        public String getPrice() { return price;}

        public void setPrice(String price) { this.price = price;}

        public String getTime() { return time;}

        public void setTime(String time) { this.time = time;}

        public String getType() { return type;}

        public void setType(String type) { this.type = type;}

        public String getUsername() { return username;}

        public void setUsername(String username) { this.username = username;}

        public int getWealth() { return wealth;}

        public void setWealth(int wealth) { this.wealth = wealth;}
    }
}
