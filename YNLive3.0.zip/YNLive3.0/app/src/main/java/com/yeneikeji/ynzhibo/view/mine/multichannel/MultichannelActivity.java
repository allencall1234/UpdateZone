package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RoomOwnerBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.ChatListView;
import com.yeneikeji.ynzhibo.widget.weelwight.NestedExpandaleListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
* 这是多通道主房间
*
* */
public class MultichannelActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private TextView         addManager;
    //private DragSortListView dragSortListView;
    private TextView mHostName;
    private NestedExpandaleListView  mExpandableListView;
    private ChatListView mListView;
    private RoomOwnerBean       roomOwner       = null;
    private List<Map<String, RoomOwnerBean>> childData1 = new ArrayList();
    private List<Map<String, RoomOwnerBean>> childData2 = new ArrayList();
    private  List<List<Map<String, RoomOwnerBean>>>       groupDatas    =new ArrayList();
    private CommonAdapter mListViewAdapter;
    private MyEpAdapter mExpandableListViewadapter;
    private List<RoomOwnerBean> mDeputyOwnerList=new ArrayList<>();
    private List<RoomOwnerBean> mRoomManageList=new ArrayList<>();
    private List<RoomOwnerBean> mRoomLiveSort=new ArrayList<>();
    //记录职位发生变化的组position
    private  int mGroupPosition;
    //记录职位发生变化的子position
    private  int mChildPosition;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.QUERY_MULTICHANNEL_LIVE_STATE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 27)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                //房主
                                roomOwner = YNJsonUtil.JsonToBean(jsonObject.optString("data1"), RoomOwnerBean.class);
                                mHostName.setText(roomOwner.getUsername());
                                JSONArray deputyOwner = jsonObject.optJSONArray("data2");
                                JSONArray manageList  = jsonObject.optJSONArray("data3");
                                JSONArray liveSort    = jsonObject.optJSONArray("data4");

                                if (deputyOwner != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    mDeputyOwnerList = YNJsonUtil.JsonToLBean(deputyOwner.toString(), type);
                                }
                                if (manageList != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    mRoomManageList = YNJsonUtil.JsonToLBean(manageList.toString(), type);
                                }

                                if (liveSort != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    mRoomLiveSort = YNJsonUtil.JsonToLBean(liveSort.toString(), type);
                                }
                                initData();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;
              //解除职务
                case YNCommonConfig.ENTER_MAIN_ROOM_UNEMPLOYE_FLAG:
                    //223解除失败
                    YNLogUtil.e("code1",msg.obj.toString());
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if(baseBean.getCode()==218){
                            List<Map<String, RoomOwnerBean>> childList = groupDatas.get(mGroupPosition);
                            childList.remove(mChildPosition);
                            mExpandableListViewadapter.upDateList(groupDatas);
                        }else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    break;
                //提拔为副房主
                case YNCommonConfig.ENTER_MAIN_ROOM_UPEMPLOYE_FLAG:
                    //219提拔失败
                    YNLogUtil.e("code2",msg.obj.toString());
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if(baseBean.getCode()==218){
                            List<Map<String, RoomOwnerBean>> childList0 = groupDatas.get(0);
                            childList0.add(groupDatas.get(1).get(mChildPosition));
                            List<Map<String, RoomOwnerBean>> childList1 = groupDatas.get(1);
                            childList1.remove(mChildPosition);
                            mExpandableListViewadapter.upDateList(groupDatas);
                        }else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    break;
                //降级
                case YNCommonConfig.ENTER_MAIN_ROOM_DOWNEMPLOYE_FLAG:
                    //221提拔失败
                    YNLogUtil.e("code3",msg.obj.toString());
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if(baseBean.getCode()==218){
                            List<Map<String, RoomOwnerBean>> childList3 = groupDatas.get(1);
                            childList3.add(groupDatas.get(0).get(mChildPosition));
                            List<Map<String, RoomOwnerBean>> childList2 = groupDatas.get(0);
                            childList2.remove(mChildPosition);
                            mExpandableListViewadapter.upDateList(groupDatas);
                        }else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private RoomOwnerBean mRoomOwner;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichannel);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }
    @Override
    protected void initView() {


           /* configTopBarCtrollerWithTitle("多通道直播房间");
            mRoomOwner = (RoomOwnerBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
            mDeputyOwnerList = (List<RoomOwnerBean>) getIntent().getSerializableExtra(
                    "deputyOwnerList");
            mRoomManageList = (List<RoomOwnerBean>) getIntent().getSerializableExtra("manageList");
            if(mRoomLiveSort!=null){
                mRoomLiveSort.removeAll(mRoomLiveSort);
            }
            mRoomLiveSort = (List<RoomOwnerBean>) getIntent().getSerializableExtra("roomLiveSort");
            initData();*/

            configTopBarCtrollerWithTitle("主房间");
            getMainRoomInfo();

        //自定义可嵌套scrollview的Expandlistvie
        addManager= (TextView) findViewById(R.id.tv_add_manager);
        mExpandableListView = (NestedExpandaleListView ) findViewById(R.id.expandableListView);
        mExpandableListView.setGroupIndicator(null);
        //房主名称
        mHostName = (TextView) findViewById(R.id.room_host_name);
    }

    //初始化数据
    private void initData() {
//        mHostName.setText(mRoomOwner.getUsername());
        //封装副房主
        if(mDeputyOwnerList!=null&&mDeputyOwnerList.size()>0) {
            for (int i = 0; i < mDeputyOwnerList.size(); i++) {
                HashMap child = new HashMap();
                child.put(YNCommonConfig.SELECT_VIDEO_FLAG, mDeputyOwnerList.get(i));
                childData1.add(child);
            }
        }
        //封装管理员
        if(mRoomManageList!=null&&mRoomManageList.size()>0) {
            for (int i = 0; i < mRoomManageList.size(); i++) {
                HashMap child = new HashMap();
                child.put(YNCommonConfig.SELECT_VIDEO_FLAG, mRoomManageList.get(i));
                childData2.add(child);
            }
        }
        groupDatas.add(childData1);
        groupDatas.add(childData2);

        mExpandableListViewadapter = new MyEpAdapter(this, groupDatas);
        mExpandableListView.setAdapter(mExpandableListViewadapter);
        //直播排序
        if(mRoomLiveSort!=null) {
            mListViewAdapter = new CommonAdapter<RoomOwnerBean>(this,
                                                                mRoomLiveSort,
                                                                R.layout.sort_list_item)
            {
                @Override
                public void convert(CommonViewHolder viewHolder, RoomOwnerBean item) {

                }
            };
            mListView.setAdapter(mListViewAdapter);
        }
    }

    private void getMainRoomInfo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().queryMultiChannelLiveState(MultichannelActivity.this, YNCommonConfig.ENTER_INTO_MAIN_ROOM_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.QUERY_MULTICHANNEL_LIVE_STATE_FLAG, true);
            }
        });
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        addManager.setOnClickListener(this);

    }

    @Override
    protected void settingDo() {

    }
    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.tv_add_manager:
                intent.setClass(this, CreateSubRoomActivity.class);
                intent.putExtra(YNCommonConfig.TITLE, true);

                    intent.putExtra(YNCommonConfig.OBJECT,
                                    AccountUtils.getAccountBean()
                                                .getId());
               /* }
                else
                {
                    intent.putExtra(YNCommonConfig.OBJECT,
                                    mRoomOwner.getId());
                }*/
                startActivity(intent);
                break;
        }
    }

    class MyEpAdapter extends BaseExpandableListAdapter {

        private  List<List<Map<String, RoomOwnerBean>>>       mdatas       =new ArrayList();
        private Context                                      mContext;
        public MyEpAdapter(Context context,  List<List<Map<String, RoomOwnerBean>>>  datas)
        {
            mContext = context;
            this.mdatas = datas;
        }

        public void upDateList(List<List<Map<String, RoomOwnerBean>>> list) {
            this.mdatas = list;
            notifyDataSetChanged();
        }

        @Override
        public int getGroupCount() {
            if (mdatas != null) {
                return mdatas.size();
            }
            return 0;
        }
        @Override
        public int getChildrenCount(int groupPosition) {
            if (mdatas != null) {
                return mdatas.get(groupPosition)
                             .size();
            }
            return 0;
        }
        @Override
        public String getGroup(int groupPosition) {
            return " ";
        }

        @Override
        public RoomOwnerBean getChild(int groupPosition, int childPosition)
        {
            if (mdatas.get(groupPosition) != null) {
                return mdatas.get(groupPosition)
                             .get(childPosition).get(YNCommonConfig.SELECT_VIDEO_FLAG);
            }
            return null;
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent)
        {
            View                             view   = convertView;
            GroupHolder holder = null;
            if (view == null) {
                holder = new GroupHolder();
                view = LayoutInflater.from(mContext)
                                     .inflate(R.layout.mulchannel_expandlist_group, null);
                holder.groupName = (TextView) view.findViewById(R.id.tv_group_name);
                holder.arrow = (ImageView) view.findViewById(R.id.iv_arrow);
                view.setTag(holder);
            } else {
                holder = (GroupHolder) view.getTag();
            }
            //判断是否已经打开列表
            if (isExpanded) {
                holder.arrow.setBackgroundResource(R.drawable.arrow_up);
            } else {
                holder.arrow.setBackgroundResource(R.drawable.arrow_down);
            }
            switch (groupPosition) {
                case 0:
                    if(mdatas.get(0)!=null){
                        holder.groupName.setText("副房主("+mdatas.get(0).size()+")");
                    }else{
                        holder.groupName.setText("副房主");
                    }
                    break;
                case 1:
                    if(mdatas.get(1)!=null){
                        holder.groupName.setText("管理员("+mdatas.get(1).size()+")");
                    }else{
                        holder.groupName.setText("管理员");
                    }

                    break;
            }

            return view;
        }
        @Override
        public View getChildView(final int groupPosition,
                                 final int childPosition,
                                 boolean isLastChild,
                                 View convertView,
                                 ViewGroup parent)
        {
            convertView = LayoutInflater.from(mContext)
                                     .inflate(R.layout.mulchannei_expandlist_child_item, null);
           TextView  childName = (TextView) convertView.findViewById(R.id.tv_child_name);
               // SwipeDragLayout swipeLayout = (SwipeDragLayout) convertView.findViewById(R.id.swipeDragLayout);
                //解除职务
                TextView tvUnemploy= (TextView) convertView.findViewById(R.id.tv_unemploy);
                 //降级
              TextView tvDownEmployer= (TextView) convertView.findViewById(R.id.tv_down_employer);
                //提拔为副房主
                TextView tvFuRoomManager= (TextView) convertView.findViewById(R.id.tv_go_fu_roomManager);

                switch (groupPosition) {
                    case 0:
                        tvFuRoomManager.setVisibility(View.GONE);
                        tvDownEmployer.setVisibility(View.VISIBLE);
                         break;
                    case 1:
                        tvFuRoomManager.setVisibility(View.VISIBLE);
                        tvDownEmployer.setVisibility(View.GONE);
                        break;
                }
             /*  //解除职务
                tvUnemploy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mGroupPosition=groupPosition;
                        mChildPosition=childPosition;
                                List<Map<String, RoomOwnerBean>> childList = mdatas.get(groupPosition);
                        final Map<String, RoomOwnerBean>         RoomOwnerBeanMap = childList.get(childPosition);

                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().getEmployeChange(MultichannelActivity.this, YNCommonConfig.ENTER_MAIN_ROOM_UNEMPLOY_URL,RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getUserid(),RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getType(), mHandler, YNCommonConfig.ENTER_MAIN_ROOM_UNEMPLOYE_FLAG, true);
                            }
                        });
                    }
                });
            //提拔为副房主
                tvFuRoomManager.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mGroupPosition=groupPosition;
                        mChildPosition=childPosition;
                        List<Map<String, RoomOwnerBean>> childList1 = mdatas.get(groupPosition);
                        final Map<String, RoomOwnerBean>     RoomOwnerBeanMap = childList1.get(
                                childPosition);
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().getEmployeChange(MultichannelActivity.this, YNCommonConfig.ENTER_MAIN_ROOM_UPEMPLOY_URL, RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getUserid(),RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getType(), mHandler, YNCommonConfig.ENTER_MAIN_ROOM_UPEMPLOYE_FLAG, true);
                            }
                        });
                    }
                });
            //降级
                tvDownEmployer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mGroupPosition=groupPosition;
                        mChildPosition=childPosition;

                        List<Map<String, RoomOwnerBean>> childList1 = mdatas.get(groupPosition);
                        final Map<String, RoomOwnerBean>       RoomOwnerBeanMap = childList1.get(
                                childPosition);
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().getEmployeChange(MultichannelActivity.this, YNCommonConfig.ENTER_MAIN_ROOM_DOWNEMPLOY_URL, RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getUserid(),RoomOwnerBeanMap.get(YNCommonConfig.SELECT_VIDEO_FLAG).getType(), mHandler, YNCommonConfig.ENTER_MAIN_ROOM_DOWNEMPLOYE_FLAG, true);
                            }
                        });
                    }
                });*/

            if(mdatas!=null&&mdatas.get(groupPosition).get(childPosition).get(YNCommonConfig.SELECT_VIDEO_FLAG).getUsername()!=null){
                childName.setText(mdatas.get(groupPosition).get(childPosition).get(YNCommonConfig.SELECT_VIDEO_FLAG).getUsername());
            }
            return convertView;
        }
        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        class GroupHolder {
            public TextView  groupName;
            public ImageView arrow;
        }
    }

}
