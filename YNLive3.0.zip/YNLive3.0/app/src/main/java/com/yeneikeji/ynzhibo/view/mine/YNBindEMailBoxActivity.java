package com.yeneikeji.ynzhibo.view.mine;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 绑定邮箱界面
 * Created by Administrator on 2016/10/26.
 */
public class YNBindEMailBoxActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mETBindEmail;
    private TextView mTVFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_emailbox);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
       settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.bind_email));

        mETBindEmail = (EditText) findViewById(R.id.edtEmail);
        mTVFinish = (TextView) findViewById(R.id.tv_finish);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mTVFinish.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken()
                        ,InputMethodManager.HIDE_NOT_ALWAYS);
                finish();
                break;

            case R.id.tv_finish:
                // 判断是否是邮箱
                if (!YNCommonUtils.isEmail(mETBindEmail.getText().toString()))
                {
                    YNToastMaster.showToast(this, "邮箱格式不正确！");
                    return;
                }

//                createFinishDialog();
                break;
        }
    }

    /**
     * 创建提交弹出框
     */
    private void createFinishDialog()
    {
        View view = getLayoutInflater().inflate(R.layout.realname_dialog, null);
        TextView mTVNotice = (TextView) view.findViewById(R.id.tv_notice);
        Button mBtnConfirm = (Button) view.findViewById(R.id.btn_confirm);

        mTVNotice.setText("邮件已发送，请前往邮箱验证");
        final Dialog dialog = new Dialog(this, R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();

        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay(); // 为获取屏幕宽、高

        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);

        WindowManager.LayoutParams wl = window.getAttributes();

        wl.width =  (int) (d.getWidth() *0.8);

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);

        mBtnConfirm.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                finish();
            }
        });

        dialog.show();

    }
}
