package com.yeneikeji.ynzhibo.model;



public class UserStatusBean extends BaseBean
{
    /**
     * id : 6
     * phone : 18192870120
     * password : e10adc3949ba59abbe56e057f20f883e
     * username :
     * realname :
     * date :
     * id_card : 123456789963852741
     * picture : /Admin/2017-01-04/586ca12a62af7.jpg
     * type : 0
     * sex : 1
     * icon : http://www.yeneilive.cn/yeneilive/Uploads/Admin/2017-01-04/586c9e8e07f84.jpg
     * register_time : 1482456186
     * describe :
     * report_num : 0
     * account_status : 0
     * user_status : 0
     * check_status : 0
     * room_status : 0
     * grade : 1
     * tittle :
     * confirm_time : 0
     * host_id : 0
     * forbid_time :
     * last_time :
     * is_lift : 0
     * submit_time :
     * fail_reason : 0
     * equipmentId ：
     * room_id :
     * push_address :
     * play_address :
     * userid :
     */

    private String pid;
    private String id;
    private String userid;
    private String phone;
    private String phone1;
    private String password;
    private String username;
    private String realname;
    private String date;
    private String id_card;
    private String picture;// 直播封面
    private String type;
    private String sex;
    private String icon;// 用户头像
    private String register_time;
    private String report_num;
    private String account_status;
    private String check_status;
    private String room_status;
    private String grade;
    private String title;// 直播标题
    private String confirm_time;
    private String host_id;
    private String forbid_time;
    private String last_time;
    private String is_lift;
    private String submit_time;
    private String fail_reason;
    private String equipmentId;
    private String room_id;// 房间id
    private String push_address;// 推流地址
    private String play_address;// 播放地址
//    private int code;// 串流码

    // 直播标签
    private int tag;
//    private int tag1;// 最热
//    private int tag2;// 投资
//    private int tag3;// 实时解盘
//    private int tag4;// 商品期货
//    private int tag5;// 保险理财
    private int count;// 在线观看数量
    private int equipment;// 标识是移动端还是PC端

    private String attentionid;
    private String describes;
    private int user_status;
    private String liveStatus;
    private String content;
    private int living_status;
    private int is_sort;

    public String getSend_status() {
        return send_status;
    }

    public void setSend_status(String send_status) {
        this.send_status = send_status;
    }

    //发送开播通知状态;
    private String send_status;
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId_card() {
        return id_card;
    }

    public void setId_card(String id_card) {
        this.id_card = id_card;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getRegister_time() {
        return register_time;
    }

    public void setRegister_time(String register_time) {
        this.register_time = register_time;
    }

    public String getReport_num() {
        return report_num;
    }

    public void setReport_num(String report_num) {
        this.report_num = report_num;
    }

    public String getAccount_status() {
        return account_status;
    }

    public void setAccount_status(String account_status) {
        this.account_status = account_status;
    }

    public String getCheck_status() {
        return check_status;
    }

    public void setCheck_status(String check_status) {
        this.check_status = check_status;
    }

    public String getRoom_status() {
        return room_status;
    }

    public void setRoom_status(String room_status) {
        this.room_status = room_status;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getConfirm_time() {
        return confirm_time;
    }

    public void setConfirm_time(String confirm_time) {
        this.confirm_time = confirm_time;
    }

    public String getHost_id() {
        return host_id;
    }

    public void setHost_id(String host_id) {
        this.host_id = host_id;
    }

    public String getForbid_time() {
        return forbid_time;
    }

    public void setForbid_time(String forbid_time) {
        this.forbid_time = forbid_time;
    }

    public String getLast_time() {
        return last_time;
    }

    public void setLast_time(String last_time) {
        this.last_time = last_time;
    }

    public String getIs_lift() {
        return is_lift;
    }

    public void setIs_lift(String is_lift) {
        this.is_lift = is_lift;
    }

    public String getSubmit_time() {
        return submit_time;
    }

    public void setSubmit_time(String submit_time) {
        this.submit_time = submit_time;
    }

    public String getFail_reason() {
        return fail_reason;
    }

    public void setFail_reason(String fail_reason) {
        this.fail_reason = fail_reason;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getRoom_id() {
        return room_id;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public String getPush_address() {
        return push_address;
    }

    public void setPush_address(String push_address) {
        this.push_address = push_address;
    }

    public String getPlay_address() {
        return play_address;
    }

    public void setPlay_address(String play_address) {
        this.play_address = play_address;
    }

/*        @Override
    public int getCode() {
        return code;
    }

    @Override
    public void setCode(int code) {
        this.code = code;
    }*/

    //    public int getTag1() {
//        return tag1;
//    }
//
//    public void setTag1(int tag1) {
//        this.tag1 = tag1;
//    }
//
//    public int getTag2() {
//        return tag2;
//    }
//
//    public void setTag2(int tag2) {
//        this.tag2 = tag2;
//    }
//
//    public int getTag3() {
//        return tag3;
//    }
//
//    public void setTag3(int tag3) {
//        this.tag3 = tag3;
//    }
//
//    public int getTag4() {
//        return tag4;
//    }
//
//    public void setTag4(int tag4) {
//        this.tag4 = tag4;
//    }
//
//    public int getTag5() {
//        return tag5;
//    }
//
//    public void setTag5(int tag5) {
//        this.tag5 = tag5;
//    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getEquipment() {
        return equipment;
    }

    public void setEquipment(int equipment) {
        this.equipment = equipment;
    }

    public String getAttentionid() {
        return attentionid;
    }

    public void setAttentionid(String attentionid) {
        this.attentionid = attentionid;
    }

    public String getDescribe() {
        return describes;
    }

    public void setDescribe(String describe) {
        this.describes = describe;
    }

    public int getUser_status() {
        return user_status;
    }

    public void setUser_status(int user_status) {
        this.user_status = user_status;
    }

    public String getLiveStatus() {
        return liveStatus;
    }

    public void setLiveStatus(String liveStatus) {
        this.liveStatus = liveStatus;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public int getLiving_status() {
        return living_status;
    }

    public void setLiving_status(int living_status) {
        this.living_status = living_status;
    }

    public int getIs_sort() {
        return is_sort;
    }

    public void setIs_sort(int is_sort) {
        this.is_sort = is_sort;
    }
}
