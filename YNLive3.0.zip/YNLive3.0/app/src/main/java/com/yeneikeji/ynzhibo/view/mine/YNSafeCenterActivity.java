
package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 安全中心界面
 */
public class YNSafeCenterActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout mRLUpdatePass, mRLBindMailBox;
    private TextView mTVPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_safe_center);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.safecenter));

        mRLUpdatePass = (RelativeLayout) findViewById(R.id.rl_update_pass);
        mRLBindMailBox = (RelativeLayout) findViewById(R.id.rl_bind_mailbox);
        mTVPhoneNumber = (TextView) findViewById(R.id.tv_phone_number);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLUpdatePass.setOnClickListener(this);
        mRLBindMailBox.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.rl_update_pass:
                intent.setClass(this, YNSetPasswordActivity.class);
                intent.putExtra(YNCommonConfig.PHONE_NUMBER, mTVPhoneNumber.getText().toString());
                intent.putExtra(YNCommonConfig.FORGET_PASS, false);
                startActivity(intent);
                break;

            case R.id.rl_bind_mailbox:
                intent.setClass(this, YNBindEMailBoxActivity.class);
                startActivity(intent);
                break;
        }
    }
}
