package com.yeneikeji.ynzhibo.view;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNIndexEditText;
import com.yeneikeji.ynzhibo.common.YNTopBarControl;

/**
 * Created by Administrator on 2016/10/19.
 */
public class YNBaseTopBarActivity extends YNBaseActivity
{
    private YNTopBarControl mTopBarControl;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
    }

    @Override
    protected void initView()
    {

    }

    @Override
    protected void addEvent() {

    }

    @Override
    protected void settingDo() {

    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    /**
     * 必须在setContentView调用后才能使用
     */
    protected void configTopBarCtrollerWithTitle(String title)
    {
        mTopBarControl = (YNTopBarControl) findViewById(R.id.yn_topbar_lo_panel);
        mTopBarControl.titleTv.setText(title);
        mTopBarControl.rightItemIv.setVisibility(View.GONE);
    }

    public void subTitleStyle(String title, String subTitle)
    {
        mTopBarControl = (YNTopBarControl) findViewById(R.id.yn_topbar_lo_panel);
        mTopBarControl.titleTv.setText(title);
        mTopBarControl.subTitleTv.setVisibility(View.VISIBLE);
        mTopBarControl.subTitleTv.setText(subTitle);
    }

    protected ImageView getLeftBtn()
    {
        return  mTopBarControl.leftItemIv;
    }

    protected ImageView getRightBtn()
    {
        return  mTopBarControl.rightItemIv;
    }

    protected TextView getTitleTxt()
    {
        return mTopBarControl.titleTv;
    }

    protected TextView getLeftTV()
    {
        return mTopBarControl.leftItemTv;
    }

    protected TextView getRightTV()
    {
        return mTopBarControl.rightItemTv;
    }

    protected ViewGroup getLeftBtnLL()
    {
        return mTopBarControl.leftItemBtn;
    }

//    protected ViewGroup getRightBtnLL()
//    {
//        return mTopBarControl.rightItemBtn;
//    }

    protected YNIndexEditText getSearchET()
    {
        return mTopBarControl.searchEt;
    }

    protected ViewGroup getCenterLL()
    {
        return  mTopBarControl.centerItemBtn;
    }

}
