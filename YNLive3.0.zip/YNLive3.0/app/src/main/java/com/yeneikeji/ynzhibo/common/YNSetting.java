package com.yeneikeji.ynzhibo.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.yeneikeji.ynzhibo.http.YNCommonConfig;

/**
 * 设置
 * Created by Administrator on 2016/10/27.
 */
public class YNSetting extends YNCommonConfig
{
    private static YNSetting current = null;
    private static Object mLock = new Object();

    public static void init(Context context) {
        synchronized (mLock) {
            if (current == null) {
                current = new YNSetting(context);
            }
        }
    }

    public static YNSetting getInstance() {
        synchronized (mLock) {
            if (current == null) {
                throw new NullPointerException("Setting is not int");
            }
            return current;
        }
    }

    public static YNSetting getInstance(Context context) {
        synchronized (mLock) {
            if (current == null) {
                current = new YNSetting(context);
            }
            return current;
        }
    }

    private SharedPreferences mSpref = null;
    private Context mContext;
    private boolean isEnableNotification;

    public YNSetting(Context context) {
        mContext = context;
        mSpref = PreferenceManager.getDefaultSharedPreferences(context);

        isEnableNotification = mSpref.getBoolean(ENABLE_NOTIFICATION_KEY, true);
    }

    /**
     * 是否打开推送功能
     */
    public void setEnableNotificaction(boolean enable) {
        isEnableNotification = enable;
        mSpref.edit().putBoolean(ENABLE_NOTIFICATION_KEY, enable).commit();
    }

    public boolean isEnableNotification() {
        return isEnableNotification;
    }

}
