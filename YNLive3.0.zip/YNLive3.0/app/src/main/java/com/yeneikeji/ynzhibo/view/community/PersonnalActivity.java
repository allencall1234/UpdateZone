package com.yeneikeji.ynzhibo.view.community;

import android.os.Bundle;
import android.view.View;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

public class PersonnalActivity
        extends YNBaseTopBarActivity

{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view =View.inflate(this, R.layout.activity_personnal, null);
        AutoUtils.auto(view);//放在加载布局的前面
        setContentView(view);
    }
}
