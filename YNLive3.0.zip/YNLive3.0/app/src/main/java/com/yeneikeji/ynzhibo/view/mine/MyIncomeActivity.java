package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNMagicScrollView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserWealthBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.view.LineChartView;

/**
 * 我的收益界面
 * Created by Administrator on 2016/11/10.
 */
public class MyIncomeActivity extends YNBaseTopBarActivity implements View.OnClickListener {
    private TextView mTotalIncomeTxt;
    private TextView mTheMonthIncomeTxt;
    private YNMagicScrollView mScrollView;

    /**
     * 收益体现协议 勾选
     */
    // private ImageView mAgreementIV;
    private boolean isAgreement = true;
    // private TextView mIncomeAgreementTxt;
    private RelativeLayout mExchangeDetailsRL;
    private ImageView imgBack;
    private ImageView imgQuestion;
    private TextView mMontnWealth;
    private TextView mHoleWealth;
    private UserWealthBean userWealthBean;
    private  TextView mBtnWithdrawCash;
    private int mostHight;
    private int pontMostHight;
    private List<UserWealthBean> myWealth = new ArrayList<>();
    /********折线图 star********/

    private String[]                 date         = {"1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"};//X轴的标注
    private int[]                    score   ;//图表的数据点
    private List<PointValue> mPointValues = new ArrayList<PointValue>();
    private List<AxisValue>  mAxisXValues = new ArrayList<AxisValue>();
    /********折线图 end********/
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_MY_WEALTH_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                Gson       gson       =new Gson();
                                userWealthBean = gson.fromJson(msg.obj.toString(), UserWealthBean.class);
                                if(userWealthBean.getData()!=null) {
                                    //总收益
                                    if(userWealthBean.getData().getSum()>0){
                                        mTotalIncomeTxt.setText(""+userWealthBean.getData().getSum());
                                    }else{
                                        mTotalIncomeTxt.setText("0");
                                    }
                                }else{
                                    mTotalIncomeTxt.setText("0");
                                }
                                //本月收益
                                if(userWealthBean.getData()!=null) {
                                    if(userWealthBean.getData().getSum()>0){
                                        mTheMonthIncomeTxt.setText("" + userWealthBean.getData().getCurrentsum());
                                    }else{
                                        mTheMonthIncomeTxt.setText("0");
                                    }

                                }else{
                                    mTheMonthIncomeTxt.setText("0");
                                }
                                if(userWealthBean.getData()
                                                 .getYeIncome()
                                                 .get(0)!=null&&userWealthBean.getData().getYeIncome().get(0).getMoIncome().size()>0) {
                                    List<UserWealthBean.DataBean.YeIncomeBean.MoIncomeBean> moIncomes = userWealthBean.getData()
                                                                                                                      .getYeIncome()
                                                                                                                      .get(0)
                                                                                                                      .getMoIncome();
                                    score=new int[moIncomes.size()];
                                    for(int a=0;a<moIncomes.size();a++){
                                        score[a]=moIncomes.get(a).getSum();
                                    }
                                }
                                getAxisXLables();//获取x轴的标注
                                getAxisPoints();//获取坐标点
                                initLineChart();//初始化


                            } catch (Exception e) {

                                e.printStackTrace();
                            }

                        } else {

                        }
                    } else {

                    }
                    break;
            }
        }
    };
    private int mCurrentMonth;
    private LineChartView mLineChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_income);
        tintManager.setStatusBarTintColor(Color.rgb(30, 144, 255));
        initView();

        addEvent();
    }
    @Override
    protected void initView() {
        /***获取但钱月份***/
        Calendar calendar =Calendar.getInstance();
        //获得当前时间的月份，月份从0开始所以结果要加1
        mCurrentMonth = calendar.get(Calendar.MONTH);
        /***折线图**/
        mLineChart = (LineChartView)findViewById(R.id.line_chart);
        /***折线图**/
        Rect fram = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(fram);
        YNCommonConfig.mWinheight = fram.height();

        mScrollView = (YNMagicScrollView) findViewById(R.id.magic_scrollview);
        mExchangeDetailsRL = (RelativeLayout) findViewById(R.id.rl_exchange_details);

        mTheMonthIncomeTxt = (TextView) findViewById(R.id.tv_theMonth_income);
        mTotalIncomeTxt = (TextView) findViewById(R.id.tv_total_income);
        //mAgreementIV = (ImageView) findViewById(R.id.iv_agree);
        //  mIncomeAgreementTxt = (TextView) findViewById(R.id.tv_income_agreement);
        //  mBtnGoldExchange = (TextView) findViewById(R.id.btn_exchange_gold);
        mMontnWealth = (TextView) findViewById(R.id.month_wealth);
        mHoleWealth = (TextView) findViewById(R.id.hole_wealth);
        //结算财富
         mBtnWithdrawCash = (TextView) findViewById(R.id.settlement_of_wealth);

        /*mGoldIncomeTxt.setValue(4787900);
        mCashIncomeTxt.setValue(47879);*/
        imgBack = (ImageView) findViewById(R.id.imgBack);
        imgQuestion = (ImageView) findViewById(R.id.imgQuestion);

        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getMyWealthIncome(MyIncomeActivity.this,
                                                YNCommonConfig.GET_MYWEALTH_INCOMING_URL,
                                                AccountUtils.getAccountBean()
                                                            .getId(),
                                                (mCurrentMonth+1),
                                                handler,
                                                YNCommonConfig.GET_MY_WEALTH_FLAG,false);
            }
        });
    }

    @Override
    protected void addEvent() {
        imgBack.setOnClickListener(this);
        imgQuestion.setOnClickListener(this);
        //mScrollView.AddListener(mGoldIncomeTxt);
        //mScrollView.AddListener(mCashIncomeTxt);
        //财富收益统计的Textview
        //mExchangeDetailsRL.setOnClickListener(this);
        //        mBtnGoldExchange.setOnClickListener(this);
        //        mBtnWithdrawCash.setOnClickListener(this);
        //   mAgreementIV.setOnClickListener(this);
        //        mIncomeAgreementTxt.setOnClickListener(this);
        mMontnWealth.setOnClickListener(this);
        mHoleWealth.setOnClickListener(this);

        mTheMonthIncomeTxt.setOnClickListener(this);
        mTotalIncomeTxt.setOnClickListener(this);
        mBtnWithdrawCash.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.imgBack:
                finish();
                break;

            case R.id.imgQuestion:
                break;

            case R.id.rl_exchange_details:
                intent.setClass(this, YNGoldCoinRecordActivity.class);
                startActivity(intent);
                break;

          /*  case R.id.btn_exchange_gold:
                intent.setClass(this, GoldExchangeActivity.class);
                startActivity(intent);
                break;*/

            case R.id.settlement_of_wealth:
                intent.setClass(this, SettlementWealthActivity.class);
                startActivity(intent);
                break;

           /* case R.id.iv_agree:
                if (isAgreement == false) {
                    mAgreementIV.setImageResource(R.drawable.circle_blue);
                    isAgreement = true;
                } else {
                    mAgreementIV.setImageResource(R.drawable.circle_gray);
                    isAgreement = false;
                }
                break;

            case R.id.tv_income_agreement:
                intent.setClass(this, AgreementActivity.class);
                intent.putExtra(YNCommonConfig.AGREEMENT, getString(R.string.agreement_txt));
                startActivity(intent);
                break;*/
            //月收入
            case R.id.tv_theMonth_income:
                intent=new Intent(this,MonthWealthActivity.class);
                startActivity(intent);
                break;
            //总收入
            case R.id.tv_total_income:
                intent=new Intent(this,TotalWealthIncome.class);
                intent.putExtra("total",""+(userWealthBean.getData().getSum()));
                startActivity(intent);
                break;
        }
    }


    private void getAxisXLables(){
        for (int i = 0; i < date.length; i++) {
            mAxisXValues.add(new AxisValue(i).setLabel(date[i]));
        }
    }
    /**
     * 图表的每个点的显示
     */
    private void getAxisPoints() {
        for (int i = 0; i < score.length; i++) {
            mPointValues.add(new PointValue(i, score[i]));
        }
    }
    private void initLineChart(){
        Line       line  = new Line(mPointValues).setColor(Color.parseColor("#2399dc"));  //折线的颜色（橙色）
        List<Line> lines = new ArrayList<Line>();
        line.setShape(ValueShape.CIRCLE);//折线图上每个数据点的形状  这里是圆形 （有三种 ：ValueShape.SQUARE  ValueShape.CIRCLE  ValueShape.DIAMOND）
        line.setCubic(false);//曲线是否平滑，即是曲线还是折线
        line.setFilled(false);//是否填充曲线的面积
        line.setHasLabels(true);//曲线的数据坐标是否加上备注
        //      line.setHasLabelsOnlyForSelected(true);//点击数据坐标提示数据（设置了这个line.setHasLabels(true);就无效）
        line.setHasLines(true);//是否用线显示。如果为false 则没有曲线只有点显示
        line.setHasPoints(true);//是否显示圆点 如果为false 则没有原点只有点显示（每个数据点都是个大的圆点）
        lines.add(line);
        LineChartData data = new LineChartData();
        data.setLines(lines);

        //坐标轴
        Axis axisX = new Axis(); //X轴
        axisX.setHasTiltedLabels(false);  //X坐标轴字体是斜的显示还是直的，true是斜的显示
        axisX.setTextColor(Color.BLACK);  //设置字体颜色
        //axisX.setName("date");  //表格名称
        axisX.setTextSize(10);//设置字体大小
        axisX.setMaxLabelChars(8); //最多几个X轴坐标，意思就是你的缩放让X轴上数据的个数7<=x<=mAxisXValues.length
        axisX.setValues(mAxisXValues);  //填充X轴的坐标名称
        data.setAxisXBottom(axisX); //x 轴在底部
        //data.setAxisXTop(axisX);  //x 轴在顶部
        axisX.setHasLines(true); //x 轴分割线

        // Y轴是根据数据的大小自动设置Y轴上限(在下面我会给出固定Y轴数据个数的解决方案)
        Axis axisY = new Axis();  //Y轴
        axisY.setName("");//y轴标注
        axisY.setTextSize(8);//设置字体大小
        data.setAxisYLeft(axisY);  //Y轴设置在左边
        //data.setAxisYRight(axisY);  //y轴设置在右边

        axisY.setMaxLabelChars(6);//max label length, for example 60
        List<AxisValue> values = new ArrayList<>();
        Arrays.sort(score);
      int mostBigNumb = score[score.length - 1];
        String vertical=""+mostBigNumb;
                       /*优化最高点坐标*/
        switch (vertical.length()) {
            case 1:
                mostHight=10;
                break;
            case 2:
                mostHight=100;
                break;
            case 3:
                mostHight=((mostBigNumb/100)+1)*100;
                break;
            case 4:
                mostHight=(mostBigNumb/1000+1)*1000;
                break;
            case 5:
                mostHight=(mostBigNumb/10000+1)*10000;
                break;
            case 6:
                mostHight=(mostBigNumb/100000+1)*100000;
                break;
            case 7:
                mostHight=(mostBigNumb/1000000+1)*1000000;
                break;
            case 8:
                mostHight=(mostBigNumb/10000000+1)*10000000;
                break;
            case 9:
                mostHight=(mostBigNumb/100000000+1)*100000000;
                break;
            case 10:
                mostHight=(mostBigNumb/1000000000+1)*1000000000;
                break;
        }
        //求出最大值
        for(int i =0; i <=mostHight; i+=mostHight/5){
            AxisValue value = new AxisValue(i);
            String label = ""+i;
            value.setLabel(label);
            values.add(value);
        }
        axisY.setValues(values);

        //设置行为属性，支持缩放、滑动以及平移
        mLineChart.setInteractive(true);
        mLineChart.setZoomType(ZoomType.HORIZONTAL);
        mLineChart.setMaxZoom((float) 2);//最大方法比例
        mLineChart.setContainerScrollEnabled(true, ContainerScrollType.HORIZONTAL);
        mLineChart.setLineChartData(data);
        mLineChart.setVisibility(View.VISIBLE);


    }

}
