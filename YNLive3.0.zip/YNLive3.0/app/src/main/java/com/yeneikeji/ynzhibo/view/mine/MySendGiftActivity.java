package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MySendGiftActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private PullToRefreshLayout mRefreshView;
    private TextView mTVMyContribution;
    private YNMyListView mLVMySendGift;

    private CommonAdapter mGiftAdapter;

    private List<GiftBean> giftList = new ArrayList<>();
    private int giftType;
    private String mContributionNumb;
    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_MY_CONTRIBUTION_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                mTVMyContribution.setText(mContributionNumb);
                                JSONArray array;
                                if (giftType == 0)
                                {
                                    array = jsonObject.getJSONObject("data").getJSONObject("gift").getJSONArray("0");
                                }
                                else
                                {
                                    array = jsonObject.getJSONObject("data").getJSONObject("zan").getJSONArray("0");
                                }
                                Type type = new TypeToken<List<GiftBean>>() {}.getType();
                                giftList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mGiftAdapter.updateListView(giftList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    else
                    {

                    }
                    break;

            }
            super.handleMessage(msg);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_my_send_gift,null);
        //  AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        giftType = getIntent().getIntExtra(YNCommonConfig.TITLE, giftType);
        mContributionNumb = getIntent().getStringExtra(YNCommonConfig.CONTRIBUTIN_NUMB_FLAG);
        configTopBarCtrollerWithTitle(giftType == 0 ? "我送出的礼物" : "我的点赞");
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mTVMyContribution = (TextView) findViewById(R.id.tv_my_contribution_value);
        mLVMySendGift = (YNMyListView) findViewById(R.id.lv_my_send_gift);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {

            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });

        mLVMySendGift.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                GiftBean giftBean = giftList.get(position);
                Intent intent = new Intent(MySendGiftActivity.this, MonthWealthDetailActivity.class);
                intent.putExtra(YNCommonConfig.TITLE, giftType);
                intent.putExtra(YNCommonConfig.OBJECT, giftBean);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void settingDo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getMyContributionList(MySendGiftActivity.this, YNCommonConfig.GET_MY_CONTRIBUTION_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.GET_MY_CONTRIBUTION_FLAG, false);
            }
        });

        mGiftAdapter = new CommonAdapter<GiftBean>(this, giftList, R.layout.item_my_gift)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, GiftBean item)
            {
                viewHolder.setText(R.id.tv_gift_name, item.getGiftName());
                viewHolder.setText(R.id.tv_gift_time, item.getTime());
                viewHolder.setText(R.id.tv_gift_price, ""+item.getContribution());
            }
        };

        mLVMySendGift.setAdapter(mGiftAdapter);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;


        }
    }
}
