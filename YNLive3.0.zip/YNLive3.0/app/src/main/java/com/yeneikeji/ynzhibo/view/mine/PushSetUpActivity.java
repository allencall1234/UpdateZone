package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.PushSetUpBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.SpUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 推送设置界面
 * Created by Administrator on 2017/7/7.
 */
public class PushSetUpActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private static final String TAG = "PushSetUpActivity";
    private CheckBox                     mCBSystemPush;
    private ListView                     mLVAnchorPush;
    private TextView                     pushTvWarn;
    private CommonAdapter<PushSetUpBean> mPushSetUpAdapter;
    private List<PushSetUpBean> mPushSetUpList = new ArrayList<>();
    private String mUserId;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_SETUP_PUSH_FLAGE:
                    if (msg.obj != null) {
//                        YNLogUtil.e(TAG, " msg.obj---***------  " + msg.obj);
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  jsonArray  = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<PushSetUpBean>>() {}.getType();
                                mPushSetUpList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                mPushSetUpAdapter.updateListView(mPushSetUpList);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push_setting);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.push_setting));
        mCBSystemPush = (CheckBox) findViewById(R.id.cb_system_switch);
        mLVAnchorPush = (ListView) findViewById(R.id.lv_anchor_push);
        pushTvWarn = (TextView) findViewById(R.id.push_play_warn);
        pushSetUpCbAndTvWarnStatus(SpUtils.getChecked(this, "isChecked"));


    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mCBSystemPush.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                pushSetUpCbAndTvWarnStatus(isChecked);
                SpUtils.putChecked(PushSetUpActivity.this, "isChecked", isChecked);
            }
        });


    }

    private void pushSetUpCbAndTvWarnStatus(boolean isChecked) {
        if (isChecked) {
            pushTvWarn.setText(getString(R.string.push_on));
            mLVAnchorPush.setVisibility(View.VISIBLE);
            mLVAnchorPush.setEmptyView(findViewById(R.id.empty));
        } else {
            pushTvWarn.setText(getString(R.string.push_off));
            mLVAnchorPush.setVisibility(View.GONE);
            findViewById(R.id.empty).setVisibility(View.GONE);
        }
        mCBSystemPush.setChecked(isChecked);
    }


    private void initData() {

        if (YNBaseActivity.isConnectNet) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    UserHttpUtils.newInstance()
                                 .getSetUpPushList(PushSetUpActivity.this,
                                                   YNCommonConfig.SETUP_PUSH_LIST_URL,
                                                   mUserId,
                                                   mHandler,
                                                   YNCommonConfig.GET_SETUP_PUSH_FLAGE,
                                                   false);
                }
            });
        }

    }

    @Override
    protected void settingDo()
    {
        if (AccountUtils.getLoginInfo()) {
            mUserId = AccountUtils.getAccountBean()
                                  .getId();
        }

        initData();
//        YNLogUtil.e(TAG, " --mPushSetUpList - " + mPushSetUpList);
        mPushSetUpAdapter = new CommonAdapter<PushSetUpBean>(this,
                                                             mPushSetUpList,
                                                             R.layout.push_setup_layout_item)
        {

            @Override
            public void convert(CommonViewHolder viewHolder, final PushSetUpBean item) {
                viewHolder.setText(R.id.push_tv_name, item.getUsername());
                viewHolder.setText(R.id.push_tv_type, item.getKind());
                YNCircleImageView imgHead = viewHolder.getView(R.id.push_iv_head);
                YNImageLoaderUtil.setImage(context, imgHead, item.getIcon());
                final CheckBox cb = viewHolder.getView(R.id.push_cb_item);
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if (isChecked) {
                            item.setStatus("1");
                        } else {
                            item.setStatus("0");
                        }
//                      YNLogUtil.e(TAG," isChecked " + isChecked + ", " + item.getStatus()+" ," +item.getAttentionid());
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                UserHttpUtils.newInstance()
                                             .getSetUpPushOpenOrClose(PushSetUpActivity.this,
                                                                      YNCommonConfig.SETUP_PUSH_OPEN_OR_CLOSE,
                                                                      mUserId,
                                                                      item.getAttentionid(),
                                                                      "1", //局部设置推送接口
                                                                      item.getStatus(),
                                                                      mHandler,
                                                                      YNCommonConfig.GET_SETUP_PUSH_OPEN_OR_CLOSE_FLAG,
                                                                      false);
                            }
                        });

                    }
                });

                if(item.getStatus().equals("1")){
                    item.setChecked(true);
                }else if(item.getStatus().equals("0")){
                    item.setChecked(false);
                }
                cb.setChecked(item.isChecked());
//                YNLogUtil.e(TAG, " XXXXXXXX : " + item.getStatus()+ " , " + item.isChecked() + " , " + item.getAttentionid());
            }
        };
        mLVAnchorPush.setAdapter(mPushSetUpAdapter);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
}
