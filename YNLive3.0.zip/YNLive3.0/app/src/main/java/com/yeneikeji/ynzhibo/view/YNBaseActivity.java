package com.yeneikeji.ynzhibo.view;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNSetting;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.receiver.MyReceiver;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.ActivityCollector;
import com.yeneikeji.ynzhibo.utils.SystemBarTintManager;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.view.mine.YNRealNameActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNManagerNoticeDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

/**
 * Created by Administrator on 2016/8/5.
 */
public abstract class YNBaseActivity extends FragmentActivity
{
    private static final String TAG = "YNBaseActivity";
    private YNApplication myApp  = null;
    public static boolean isConnectNet;
    public static final int COMPULSORY_DOWNLINE_FLAE = 0X115;

    public Context context;
    public View view;

    /**** 辨别手机分辨率 ***/
    public Display display;
    public int screenWidth;
    public int screenHeight;

    public YNSetting mSettings = null;
    private MyReceiver myReceiver;
    public SystemBarTintManager tintManager;

    //for receive customer msg from jpush server
    private MessageReceiver mInvitationMessageReceiver;
    public static final String MESSAGE_RECEIVED_ACTION = "MESSAGE_INVITATION_MANAGER_ACTION";

    private YNManagerNoticeDialog managerNoticeDialog;
    private int isAcceptInvitation = -1;


    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);

                        YNToastMaster.showToast(context, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        YNToastMaster.showToast(context, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;

                case YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);

                        YNToastMaster.showToast(context, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        YNToastMaster.showToast(context, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;

                case YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);

                        YNToastMaster.showToast(context, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        YNToastMaster.showToast(context, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;

                case YNCommonConfig.USER_LOGIN_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 5)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                UserInfoBean infoBean = YNJsonUtil.JsonToBean(object.getString("data"), UserInfoBean.class);
                                // 将登陆成功后返回的用户信息类保存
                                infoBean.setPassword(AccountUtils.getAccountBean().getPassword());
                                AccountUtils.saveAccountBean(infoBean);
                                // 设置状态为登陆状态，保存标志位
                                AccountUtils.saveLogin(true);
                                PersonInfoBean personInfoBean = YNJsonUtil.JsonToBean(object.getString("data"), PersonInfoBean.class);
                                AccountUtils.saveLocalPerson(personInfoBean);
                                JPushInterface.init(getApplicationContext());

                                mHandler.postDelayed(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        if (!AccountUtils.getAccountBean().getId().equals(AccountUtils.getSetAlias()))
                                            setAlias(AccountUtils.getAccountBean().getId());

                                    }
                                }, 10000);

                                Intent intent = new Intent(context, YNMainTabActivity.class);
//                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.SET_JPUSH_ALIAS:
                    // 调用 JPush 接口来设置别名。
                    JPushInterface.setAliasAndTags(getApplicationContext(),
                            (String) msg.obj,
                            null,
                            mAliasCallback);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        YNApplication.getInstance().setMHandler(mHandler);
        YNApplication.getInstance().setSHandler(sHandler);
        ActivityCollector.addActivity(this);
//        透明状态栏
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //透明导航栏
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        context = this;
        // 添加Activity到堆栈（注：每个Activity都要添加到堆栈）
        myApp.getInstance().addActivity(this);

        mSettings = YNSetting.getInstance(getApplicationContext());
        // 默认软键盘不弹出
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

//        requestWindowFeature(Window.FEATURE_NO_TITLE);// 无标题

        // 方法1 Android获得屏幕的宽和高
        Display mDisplay = ((Activity) context).getWindowManager()
                .getDefaultDisplay();
        screenWidth = mDisplay.getWidth();
        screenHeight = mDisplay.getHeight();
        YNCommonConfig.ScreenWidth = screenWidth;
        YNCommonConfig.ScreenHeight = screenHeight;

//        ScreenSizeUtil.getAndroiodScreenProperty(this);

//        DisplayMetrics metric = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(metric);
//        int width = metric.widthPixels;  // 屏幕宽度（像素）
//        int height = metric.heightPixels;  // 屏幕高度（像素）
//        float density = metric.density;  // 屏幕密度（0.75 / 1.0 / 1.5）
//        double diagonalPixels = Math.sqrt(Math.pow(width, 2)+Math.pow(height, 2)) ;
//        YNCommonConfig.screenSize = diagonalPixels/(160 * density) ;

       // YNCommonConfig.screenSize = ScreenSizeUtil.getScreenInch(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            setTranslucentStatus(true);
        }

        tintManager = new SystemBarTintManager(this);
        tintManager.setStatusBarTintEnabled(true);

        view = this.getWindow().getDecorView();
      //  AutoUtils.setSize(this, false, 750, 1334);
        myReceiver = new MyReceiver();

        registerDateTransReceiver();
        registerMessageReceiver();

    }

    @TargetApi(19)
    public void setTranslucentStatus(boolean on) {
        Window win = getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        final int bits = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    private void registerDateTransReceiver()
    {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(myReceiver, filter);
    }

    /** 初始化界面 */
     protected void initView()
     {

     }

    /** 添加事件 */
    protected void addEvent()
    {

    }

    /** 做事情 */
    protected void settingDo()
    {

    }

    /** 请求权限 */
    protected void requestPermissions()
    {

    }

    /** 检查是否有该权限 */
    protected boolean checkPermissions()
    {
        return false;
    }

    /** 需要获取的权限 */
    protected void getPermissions()
    {

    }

    private void registerMessageReceiver()
{
    mInvitationMessageReceiver = new MessageReceiver();
    IntentFilter filter = new IntentFilter();
    filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
    filter.addAction(MESSAGE_RECEIVED_ACTION);
    registerReceiver(mInvitationMessageReceiver, filter);
}

    // 接收消息
    private class MessageReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(final Context context, final Intent intent)
        {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction()))
            {
                int msgType = intent.getIntExtra(YNCommonConfig.TITLE, 0);
                final String extras = intent.getStringExtra(YNCommonConfig.KEY_EXTRAS);
               /* if (msgType == 8)
                {
                    unregisterReceiver(mInvitationMessageReceiver);
                    mInvitationMessageReceiver = null;
                    try
                    {
                        JSONObject extraJson = new JSONObject(extras);
                        final MessageBean msgBean = YNJsonUtil.JsonToBean(extraJson.optString("txt").toString(), MessageBean.class);
                        if (managerNoticeDialog == null)
                        {
                            managerNoticeDialog = new YNManagerNoticeDialog.Builder(context)
                                    .setMsgBean(msgBean)
                                    .setWidth(0.8f)
                                    .setHeight(0.4f)
                                    .setCanceledOnTouchOutside(false)
                                    .setOnclickListener(new IDialogOnClickListener()
                                    {

                                        @Override
                                        public void clickTopLeftButton(View view)
                                        {

                                        }

                                        @Override
                                        public void clickTopRightButton(View view)
                                        {
                                            managerNoticeDialog.dismiss();
                                            managerNoticeDialog = null;
                                            registerMessageReceiver();
                                        }

                                        @Override
                                        public void clickBottomLeftButton(View view)
                                        {
                                            isAcceptInvitation = 0;
                                            managerNoticeDialog.dismiss();
                                            managerNoticeDialog = null;
                                            registerMessageReceiver();
                                            mHandler.post(new Runnable()
                                            {
                                                @Override
                                                public void run()
                                                {
                                                    UserHttpUtils.newInstance().agreeBecomingRoomManager(context, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                            mHandler, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG, false);
                                                }
                                            });
                                        }

                                        @Override
                                        public void clickBottomRightButton(View view)
                                        {
                                            isAcceptInvitation = 1;
                                            managerNoticeDialog.dismiss();
                                            managerNoticeDialog = null;
                                            registerMessageReceiver();
                                            mHandler.post(new Runnable()
                                            {
                                                @Override
                                                public void run()
                                                {
                                                    UserHttpUtils.newInstance().agreeBecomingRoomManager(context, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                            mHandler, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG, false);
                                                }
                                            });
                                        }

                                        @Override
                                        public void clickBottomButton(View view)
                                        {
                                            managerNoticeDialog.dismiss();
                                            managerNoticeDialog = null;
                                            registerMessageReceiver();
                                            Intent intent1 = new Intent(context, FindAnchorHomeActivity.class);
                                            intent1.putExtra("userId", msgBean.getUserid());
                                            startActivity(intent1);
                                        }
                                    }).build();
                            managerNoticeDialog.show();
                        }
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }*/
                if (msgType == 10)
                {

                    unregisterReceiver(mInvitationMessageReceiver);
                    mInvitationMessageReceiver = null;
                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            setAlias("");
                        }
                    });

                    AccountUtils.saveLogin(false);
                    Intent i = new Intent(context, YNMainTabActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);

                    Message msg = Message.obtain();
                    msg.obj = extras;
                    msg.what = COMPULSORY_DOWNLINE_FLAE;
                    YNApplication.getInstance().getOHandler().sendMessage(msg);
                }
                else
                {
                    invitationDialog(msgType, extras);
                }

//                StringBuilder showMsg = new StringBuilder();
//                showMsg.append(KEY_MESSAGE + " : " + messge + "\n");
//                if (!TextUtils.isEmpty(extras))
//                {
//                    showMsg.append(KEY_EXTRAS + " : " + extras + "\n");
//                }
//                YNLogUtil.i("cdy123", showMsg.toString());
            }
        }
    }

    /**
     * 邀请
     * @param msgType
     * @param extras
     */
    private void invitationDialog(final int msgType, String extras)
    {
        unregisterReceiver(mInvitationMessageReceiver);
        mInvitationMessageReceiver = null;
        try
        {
            JSONObject extraJson = new JSONObject(extras);
            final MessageBean msgBean = YNJsonUtil.JsonToBean(extraJson.optString("txt").toString(), MessageBean.class);
            String invitationContent = "";
            if (managerNoticeDialog == null)
            {
                if (msgType == 8)
                {
                    invitationContent = "邀请你担任他的直播间管理员";
                }
                if (msgType == 12)
                {
                    invitationContent = "邀请你认证主播";
                }
                if (msgType == 13)
                {
                    invitationContent = "邀请你担任他的子房间房主";
                }
                if (msgType == 14)
                {
                    invitationContent = "邀请你担任子房间管理员";
                }

                managerNoticeDialog = new YNManagerNoticeDialog.Builder(context)
                        .setMsgBean(msgBean)
                        .setWidth(0.8f)
                        .setHeight(0.4f)
                        .setInvitationContent(invitationContent)
                        .setCanceledOnTouchOutside(false)
                        .setOnclickListener(new IDialogOnClickListener()
                        {

                            @Override
                            public void clickTopLeftButton(View view)
                            {

                            }

                            @Override
                            public void clickTopRightButton(View view)
                            {
                                managerNoticeDialog.dismiss();
                                managerNoticeDialog = null;
                                registerMessageReceiver();
                            }

                            @Override
                            public void clickBottomLeftButton(View view)
                            {
                                isAcceptInvitation = 0;
                                managerNoticeDialog.dismiss();
                                managerNoticeDialog = null;
                                registerMessageReceiver();
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        if (msgType == 8)
                                        {
                                            UserHttpUtils.newInstance().agreeBecomingRoomManager(context, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG, true);
                                        }
                                        if (msgType == 12)
                                        {
                                            managerNoticeDialog.dismiss();
                                            managerNoticeDialog = null;
                                            registerMessageReceiver();
                                        }
                                        if (msgType == 13)
                                        {
                                            UserHttpUtils.newInstance().agreeChildRoomOwnerInvitation(context, YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG, true);
                                        }
                                        if (msgType == 15)
                                        {
                                            UserHttpUtils.newInstance().agreeMultichannelRoomManagerInvitation(context, YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG, true);
                                        }
                                    }
                                });
                            }

                            @Override
                            public void clickBottomRightButton(View view)
                            {
                                isAcceptInvitation = 1;
                                managerNoticeDialog.dismiss();
                                managerNoticeDialog = null;
                                registerMessageReceiver();
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        if (msgType == 8)
                                        {
                                            UserHttpUtils.newInstance().agreeBecomingRoomManager(context, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG, true);
                                        }
                                        if (msgType == 12)
                                        {
                                            Intent intent = new Intent(context, YNRealNameActivity.class);
                                            startActivity(intent);
                                        }
                                        if (msgType == 13)
                                        {
                                            UserHttpUtils.newInstance().agreeChildRoomOwnerInvitation(context, YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG, true);
                                        }
                                        if (msgType == 15)
                                        {
                                            UserHttpUtils.newInstance().agreeMultichannelRoomManagerInvitation(context, YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_URL, msgBean.getId(), msgBean.getUserid(), AccountUtils.getAccountBean().getId(), isAcceptInvitation,
                                                    mHandler, YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG, true);
                                        }

                                    }
                                });
                            }

                            @Override
                            public void clickBottomButton(View view)
                            {
                                managerNoticeDialog.dismiss();
                                managerNoticeDialog = null;
                                registerMessageReceiver();
                                Intent intent1 = new Intent(context, FindAnchorHomeActivity.class);
                                intent1.putExtra("userId", msgBean.getUserid());
                                startActivity(intent1);
                            }
                        }).build();
                managerNoticeDialog.show();
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    private Handler sHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            registerMessageReceiver();
        }
    };


    // 这是来自 JPush Example 的设置别名的 Activity 里的代码。一般 App 的设置的调用入口，在任何方便的地方调用都可以。
    private void setAlias(String alias)
    {
        // 调用 Handler 来异步设置别名
        mHandler.sendMessage(mHandler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, alias));
    }

    private final TagAliasCallback mAliasCallback = new TagAliasCallback() {

        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs ;
            switch (code) {
                case 0:
                    logs = "Set tag and alias success";
                    AccountUtils.saveSetAlias(alias);
                    // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
                    break;

                case 6002:
                    logs = "Failed to set alias and tags due to timeout. Try again after 60s.";
                    // 延迟 60 秒来调用 Handler 设置别名
                    mHandler.sendMessageDelayed(mHandler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, alias), 1000 * 60);
                    break;

                default:
                    logs = "Failed with errorCode = " + code;
            }
        }
    };

    private Date getCurentTime()
    {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(0);
        calendar.add(Calendar.HOUR_OF_DAY, -8);
        Date time = calendar.getTime();
        return time;
    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        ActivityCollector.removeActivity(this);
        unregisterReceiver(myReceiver);
        if (mInvitationMessageReceiver != null)
           unregisterReceiver(mInvitationMessageReceiver);

        /** 主动调用gc回收 */
        System.gc();
    }

    /**
     * 登录成功后刷新ui的方法
     */
    public abstract void loginRefreshUI();

    /**
     * 未登录刷新ui的方法
     */
    public abstract void unLoginRefreshUI();


}
