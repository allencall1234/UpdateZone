package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.umeng.socialize.utils.SocializeUtils;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

/**
 * 自定义直播对话框
 */
public class YNChatRoomAlertDialog implements View.OnClickListener
{
    private TextView mAddRoomManageer;
    private TextView mManagerCount;
    private ImageButton mCloseIBtn;
    private ImageView mHeadImg;
    private ImageView mImgLevel;
    private TextView mUName;
    private TextView mRoomId;
    private TextView mIntroduce;
    private TextView mFollowCount;
    private TextView mFansCount;
    private TextView mSign;
    private LinearLayout mLLBottomBtn;
    private Button mReportBtn;
    private Button mStopSpeakBtn;
    private Button mFollowBtn;
    private View mLineView;
    private Dialog mDialog;
    private View mDialogView;
    private Builder mBuilder;

    public YNChatRoomAlertDialog(Builder builder)
    {
        this.mBuilder = builder;
        mDialog = new Dialog(mBuilder.getContext(), R.style.NormalDialogStyle);
        mDialogView = View.inflate(mBuilder.getContext(), R.layout.live_details_dialog, null);
//        AutoUtils.auto(mDialogView);
        mAddRoomManageer = (TextView) mDialogView.findViewById(R.id.tv_report);
        mManagerCount = (TextView) mDialogView.findViewById(R.id.tv_manager_num);
        mCloseIBtn = (ImageButton) mDialogView.findViewById(R.id.ib_close);
        mHeadImg = (ImageView) mDialogView.findViewById(R.id.iv_hostImg);
        mImgLevel = (ImageView) mDialogView.findViewById(R.id.iv_level);
        mUName = (TextView) mDialogView.findViewById(R.id.tv_hostName);
        mRoomId = (TextView) mDialogView.findViewById(R.id.tv_live_room_id);
        mIntroduce = (TextView) mDialogView.findViewById(R.id.tv_userIntroduce);
        mFollowCount = (TextView) mDialogView.findViewById(R.id.tv_followNum);
        mFansCount = (TextView) mDialogView.findViewById(R.id.tv_fansNum);
        mSign = (TextView) mDialogView.findViewById(R.id.tv_sign);
        mLLBottomBtn = (LinearLayout) mDialogView.findViewById(R.id.ll_bottom_btn);
        mReportBtn = (Button) mDialogView.findViewById(R.id.btn_report);
        mStopSpeakBtn = (Button) mDialogView.findViewById(R.id.btn_stop_speak);
        mFollowBtn = (Button) mDialogView.findViewById(R.id.btn_follow);
        mLineView = mDialogView.findViewById(R.id.line_view);
        mDialogView.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(mBuilder.getContext()) * builder.getHeight()));
        mDialog.setContentView(mDialogView);

        Window dialogWindow = mDialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtil.getScreenWidth(mBuilder.getContext()) * builder.getWidth());
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialogWindow.setAttributes(lp);

        initDialog(builder);
    }

    private void initDialog(Builder builder)
    {

        mDialog.setCanceledOnTouchOutside(builder.isTouchOutside());

        if (builder.getChatRoomUserBean() == null)
        {
            mHeadImg.setImageResource(R.drawable.hand_little);
            mUName.setText(builder.getChatRoomUserBean().getUsername());
            mIntroduce.setText("--" );
            mFollowCount.setText("关注：--" );
            mFansCount.setText("粉丝：--" );
        }

//        if (TextUtils.isEmpty(builder.getChatRoomUserBean().getIcon()))
//            mHeadImg.setImageResource(R.drawable.hand_little);
//        else
        YNImageLoaderUtil.setImage(builder.getContext(), mHeadImg, builder.getChatRoomUserBean().getIcon());

//        if (builder.getLevel() > 10)
//        {
//            mImgLevel.setImageResource(R.drawable.crown);
//        }

        mUName.setText(builder.getChatRoomUserBean().getUsername());
        mIntroduce.setText("  " + builder.getChatRoomUserBean().getDescribe());
        mFollowCount.setText("关注：" + builder.getChatRoomUserBean().getAttention_count());
        mFansCount.setText("粉丝：" + builder.getChatRoomUserBean().getFuns_count());
//        mSign.setText(builder.getSign());

        mAddRoomManageer.setText("设置房管");
        mAddRoomManageer.setVisibility(View.INVISIBLE);
        mLLBottomBtn.setVisibility(View.GONE);
        mFollowBtn.setText(builder.getContext().getString(R.string.report));
        mAddRoomManageer.setOnClickListener(this);
        mCloseIBtn.setOnClickListener(this);
        mReportBtn.setOnClickListener(this);
        mStopSpeakBtn.setOnClickListener(this);
        mFollowBtn.setOnClickListener(this);

        if (builder.isShowManagerCount())
        {
            mManagerCount.setVisibility(View.VISIBLE);
            mManagerCount.setText(builder.getChatRoomUserBean().getManage_count() + "/" + 4);
        }

        if (builder.isAllGone())
        {
            mUName.setText(builder.getChatRoomUserBean().getIs_selfManage()== 1 ? builder.getChatRoomUserBean().getUsername() + "(房管)" : builder.getChatRoomUserBean().getUsername());
            mUName.setText(builder.getChatRoomUserBean().getIs_myselfHost() == 1 ? builder.getChatRoomUserBean().getUsername() + "(主播)" : builder.getChatRoomUserBean().getUsername());
            mAddRoomManageer.setVisibility(View.INVISIBLE);
            mLLBottomBtn.setVisibility(View.GONE);
            mLineView.setVisibility(View.GONE);
            mFollowBtn.setVisibility(View.GONE);
            return;
        }
        if (builder.isLiveHost())
        {
            mAddRoomManageer.setVisibility(View.VISIBLE);
            mUName.setText(builder.getChatRoomUserBean().getIs_manage()== 1 ? builder.getChatRoomUserBean().getUsername() + "(房管)" : builder.getChatRoomUserBean().getUsername());
            mAddRoomManageer.setText(builder.getChatRoomUserBean().getIs_manage() == 1 ? "取消房管" : "设置房管");
            mReportBtn.setText(builder.getChatRoomUserBean().getReport() == 1 ? "已举报" : "举报");
            mReportBtn.setTextColor(builder.getChatRoomUserBean().getReport() == 1 ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.live_hot_text_color));
            mStopSpeakBtn.setText(builder.getChatRoomUserBean().getIs_say() == 1 ? "取消禁言" : "禁言");
            mLLBottomBtn.setVisibility(View.VISIBLE);
            mFollowBtn.setVisibility(View.GONE);
            mFollowBtn.setText("关注");
            return;
        }
        if (builder.isRoomManager())
        {
            if (builder.isBeClickedManager())
            {
                mUName.setText(builder.getChatRoomUserBean().getUsername() + "(房管)");
                mAddRoomManageer.setVisibility(View.INVISIBLE);
                mLLBottomBtn.setVisibility(View.GONE);
                mLineView.setVisibility(View.VISIBLE);
                mFollowBtn.setVisibility(View.VISIBLE);
                mFollowBtn.setText(builder.getChatRoomUserBean().getReport() == 1 ? "已举报" : "举报");
                mFollowBtn.setTextColor(builder.getChatRoomUserBean().getReport() == 1 ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.live_hot_text_color));
            }
            if (builder.isBeClickedLiveHost())
            {
                mUName.setText(builder.getChatRoomUserBean().getUsername() + "(主播)");
                mAddRoomManageer.setVisibility(View.INVISIBLE);
                mLLBottomBtn.setVisibility(View.GONE);
                mLineView.setVisibility(View.VISIBLE);
                mFollowBtn.setVisibility(View.VISIBLE);
                mFollowBtn.setText(builder.getChatRoomUserBean().getReport() == 1 ? "已举报" : "举报");
                mFollowBtn.setTextColor(builder.getChatRoomUserBean().getReport() == 1 ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.live_hot_text_color));
            }
            if (!builder.isBeClickedManager() && !builder.isBeClickedLiveHost())
            {
                mAddRoomManageer.setVisibility(View.INVISIBLE);
                mLLBottomBtn.setVisibility(View.VISIBLE);
                mStopSpeakBtn.setText(builder.getChatRoomUserBean().getIs_say() == 1 ? "取消禁言" : "禁言");
                mFollowBtn.setVisibility(View.GONE);
            }
            return;
        }
        if (builder.isBeClickedManager())
        {
            mUName.setText(builder.getChatRoomUserBean().getUsername() + "(房管)");
            mAddRoomManageer.setVisibility(View.INVISIBLE);
            mLLBottomBtn.setVisibility(View.GONE);
            mLineView.setVisibility(View.VISIBLE);
            mFollowBtn.setVisibility(View.VISIBLE);
            mFollowBtn.setText(builder.getChatRoomUserBean().getReport() == 1 ? "已举报" : "举报");
            mFollowBtn.setTextColor(builder.getChatRoomUserBean().getReport() == 1 ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.live_hot_text_color));
        }
        if (builder.isBeClickedLiveHost())
        {
            mUName.setText(builder.getChatRoomUserBean().getUsername() + "(主播)");
            mAddRoomManageer.setVisibility(View.INVISIBLE);
            mLLBottomBtn.setVisibility(View.GONE);
            mLineView.setVisibility(View.VISIBLE);
            mFollowBtn.setVisibility(View.VISIBLE);
            mFollowBtn.setText(builder.getChatRoomUserBean().getReport() == 1 ? "已举报" : "举报");
            mFollowBtn.setTextColor(builder.getChatRoomUserBean().getReport() == 1 ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.live_hot_text_color));
        }
    }

    @Override
    public void onClick(View view)
    {
        int i = view.getId();
        if (i == R.id.tv_report && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickTopLeftButton(mAddRoomManageer);
            return;
        }

        if (i == R.id.ib_close && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickTopRightButton(mCloseIBtn);
            return;
        }

        if (i == R.id.btn_report && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickBottomLeftButton(mReportBtn);
            return;
        }

        if (i == R.id.btn_stop_speak && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickBottomRightButton(mStopSpeakBtn);
            return;
        }

        if (i == R.id.btn_follow && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickBottomButton(mFollowBtn);
            return;
        }
    }

    public void show() {
        YNCommonUtils.safeShowDialog(mDialog);
//        mDialog.show();
    }

    public void dismiss() {

        YNCommonUtils.safeCloseDialog(mDialog);
//        mDialog.dismiss();
    }

    public static class Builder
    {
        private ChatRoomUserBean chatRoomUserBean;
        private boolean isAllGone;
        private boolean isRoomManager;
        private boolean isLiveHost;
        private boolean beClickedLiveHost;
        private boolean beClickedManager;
        private boolean isShowManagerCount;

        private IDialogOnClickListener onclickListener;
        private boolean isTouchOutside;
        private float height;
        private float width;
        private Context mContext;

        public Builder(Context context)
        {
            mContext = context;

            onclickListener = null;
            isTouchOutside = true;
            height = 0.23f;
            width = 0.65f;
            isRoomManager = false;
            isLiveHost = false;
            isAllGone = false;
            beClickedLiveHost = false;
            beClickedManager = false;
            isShowManagerCount = false;
        }

        public Context getContext()
        {
            return mContext;
        }

        public ChatRoomUserBean getChatRoomUserBean() {
            return chatRoomUserBean;
        }

        public Builder setChatRoomUserBean(ChatRoomUserBean chatRoomUserBean) {
            this.chatRoomUserBean = chatRoomUserBean;
            return this;
        }

        public boolean isBeClickedLiveHost() {
            return beClickedLiveHost;
        }

        public Builder setBeClickedLiveHost(boolean beClickedLiveHost) {
            this.beClickedLiveHost = beClickedLiveHost;
            return this;
        }

        public boolean isBeClickedManager() {
            return beClickedManager;
        }

        public Builder setBeClickedManager(boolean beClickedManager) {
            this.beClickedManager = beClickedManager;
            return this;
        }

        public IDialogOnClickListener getOnclickListener() {
            return onclickListener;
        }

        public Builder setOnclickListener(IDialogOnClickListener onclickListener) {
            this.onclickListener = onclickListener;
            return this;
        }

        public boolean isTouchOutside() {
            return isTouchOutside;
        }

        public Builder setCanceledOnTouchOutside(boolean isTouchOutside) {

            this.isTouchOutside = isTouchOutside;
            return this;
        }

        public float getHeight() {
            return height;
        }

        public Builder setHeight(float height) {
            this.height = height;
            return this;
        }

        public float getWidth() {
            return width;
        }

        public Builder setWidth(float width) {
            this.width = width;
            return this;
        }

        public boolean isRoomManager()
        {
            return isRoomManager;
        }

        public Builder setRoomManager(boolean roomManager)
        {
            this.isRoomManager = roomManager;
            return this;
        }

        public boolean isLiveHost()
        {
            return isLiveHost;
        }

        public Builder setLiveHost(boolean liveHost)
        {
            this.isLiveHost = liveHost;
            return this;
        }

        public boolean isAllGone() {
            return isAllGone;
        }

        public Builder setAllGone(boolean allGone) {
            this.isAllGone = allGone;
            return this;
        }

        public boolean isShowManagerCount()
        {
            return isShowManagerCount;
        }

        public Builder setShowManagerCount(boolean showManagerCount) {
            this.isShowManagerCount = showManagerCount;
            return this;
        }

        public YNChatRoomAlertDialog build() {

            return new YNChatRoomAlertDialog(this);
        }
    }

}
