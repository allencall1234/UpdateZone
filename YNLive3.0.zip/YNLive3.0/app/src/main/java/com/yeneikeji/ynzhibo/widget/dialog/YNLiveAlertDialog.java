package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.AnchorInfoBean;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;

/**
 * 自定义直播对话框
 */
public class YNLiveAlertDialog implements View.OnClickListener
{
    private TextView mReport;
    private ImageButton mCloseIBtn;
    private ImageView mHeadImg;
    private TextView mUName;
    private TextView mLiveType;
    private TextView mRoomId;
    private TextView mFollowCount;
    private TextView mFansCount;
    private TextView mIntroduce;
    private RatingBar mComprehensiveScore;
    private TextView mTotalScore;
    private ProgressBar mPBLiveVideo;
    private TextView mLiveVideoScore;
    private ProgressBar mPBLiveNote;
    private TextView mLiveNoteScore;
    private ProgressBar mPBLiveVoice;
    private TextView mLiveVoiceScore;
    private Button mFollowBtn;
    private View mLineView;
    private Dialog mDialog;
    private View mDialogView;
    private Builder mBuilder;

    public YNLiveAlertDialog(Builder builder) {

        this.mBuilder = builder;
        mDialog = new Dialog(mBuilder.getContext(), R.style.NormalDialogStyle);
        mDialogView = View.inflate(mBuilder.getContext(), R.layout.live_details_live_host_dialog, null);
//        AutoUtils.auto(mDialogView);
        mReport = (TextView) mDialogView.findViewById(R.id.tv_report);
        mCloseIBtn = (ImageButton) mDialogView.findViewById(R.id.ib_close);
        mHeadImg = (ImageView) mDialogView.findViewById(R.id.iv_hostImg);
        mUName = (TextView) mDialogView.findViewById(R.id.tv_hostName);
        mLiveType = (TextView) mDialogView.findViewById(R.id.tv_live_type);
        mRoomId = (TextView) mDialogView.findViewById(R.id.tv_live_room_id);
        mFollowCount = (TextView) mDialogView.findViewById(R.id.tv_followNum);
        mFansCount = (TextView) mDialogView.findViewById(R.id.tv_fansNum);
        mIntroduce = (TextView) mDialogView.findViewById(R.id.tv_userIntroduce);
        mComprehensiveScore = (RatingBar) mDialogView.findViewById(R.id.ratBar_comprehensive_score);
        mTotalScore = (TextView) mDialogView.findViewById(R.id.tv_total_score);
        mPBLiveVideo = (ProgressBar) mDialogView.findViewById(R.id.pb_live_video_score);
        mLiveVideoScore = (TextView) mDialogView.findViewById(R.id.tv_live_video_score);
        mPBLiveNote = (ProgressBar) mDialogView.findViewById(R.id.pb_live_note_score);
        mLiveNoteScore = (TextView) mDialogView.findViewById(R.id.tv_live_note_score);
        mPBLiveVoice = (ProgressBar) mDialogView.findViewById(R.id.pb_live_voice_score);
        mLiveVoiceScore = (TextView) mDialogView.findViewById(R.id.tv_live_voice_score);
        mFollowBtn = (Button) mDialogView.findViewById(R.id.btn_follow);
        mLineView = mDialogView.findViewById(R.id.line_view);
        mDialogView.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(mBuilder.getContext()) * builder.getHeight()));
        mDialog.setContentView(mDialogView);

        Window dialogWindow = mDialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtil.getScreenWidth(mBuilder.getContext()) * builder.getWidth());
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialogWindow.setAttributes(lp);

        initDialog(builder);
    }

    private void initDialog(Builder builder) {

        mDialog.setCanceledOnTouchOutside(builder.isTouchOutside());

        if (TextUtils.isEmpty(builder.getHeadImgUrl()))
            mHeadImg.setImageResource(R.drawable.pic01);
        else
            YNImageLoaderUtil.setImage(builder.getContext(), mHeadImg, builder.getHeadImgUrl());

        mComprehensiveScore.setClickable(false);
        LayerDrawable ldStars = (LayerDrawable) mComprehensiveScore.getProgressDrawable();
        ldStars.getDrawable(2).setColorFilter(ContextCompat.getColor(mBuilder.getContext(), R.color.ynkj_red), PorterDuff.Mode.SRC_ATOP);
        mRoomId.setVisibility(View.VISIBLE);
        mUName.setText(builder.getuName());
        mLiveType.setText(builder.getLiveType());
        mRoomId.setText("房间ID ：" + builder.getRoomId());
        mIntroduce.setText("  " + builder.getuIntroduce());
        mFollowCount.setText("关注：" + builder.getFollowCount());
        mFansCount.setText("粉丝：" + builder.getFansCount());
//        mFansCount.setVisibility(View.GONE);
        mReport.setVisibility(builder.isHide() ? View.INVISIBLE : View.VISIBLE);
        mLineView.setVisibility(builder.isHide() ? View.GONE : View.VISIBLE);
        mFollowBtn.setVisibility(builder.isHide() ? View.GONE : View.VISIBLE);
        mReport.setText(builder.isReport() ? "已举报" : "举报");
        mFollowBtn.setTextColor(builder.isReport() ? ContextCompat.getColor(builder.getContext(), R.color.followed_txt_color) : ContextCompat.getColor(builder.getContext(), R.color.blue));
        mFollowBtn.setText(builder.isAttention() ? "已关注" : "关注");
        mFollowBtn.setClickable(!builder.isAttention());
        mFollowBtn.setEnabled(!builder.isAttention());
        mFollowBtn.setTextColor(builder.isAttention() ? ContextCompat.getColor(builder.getContext(), R.color.search_txt) : ContextCompat.getColor(builder.getContext(), R.color.live_details_text_blue));
        mHeadImg.setOnClickListener(this);
        mReport.setOnClickListener(this);
        mCloseIBtn.setOnClickListener(this);
        mFollowBtn.setOnClickListener(this);
    }

    public void updateDialog(AnchorInfoBean anchorInfo)
    {
        mFollowCount.setText("关注：" + anchorInfo.getAttentions());
        mFansCount.setText("粉丝：" + anchorInfo.getFuns());
        mComprehensiveScore.setRating(anchorInfo.getOverall());
        mTotalScore.setText(anchorInfo.getOverall() + "");
        mPBLiveVideo.setProgress((int)(100 * anchorInfo.getLive() / 5));
        mLiveVideoScore.setText(anchorInfo.getLive() + "");
        mPBLiveNote.setProgress((int)(100 * anchorInfo.getArticle() / 5));
        mLiveNoteScore.setText(anchorInfo.getArticle() + "");
        mPBLiveVoice.setProgress((int)(100 * anchorInfo.getAudio()) / 5);
        mLiveVoiceScore.setText(anchorInfo.getAudio() + "");
    }

    @Override
    public void onClick(View view) {

        int i = view.getId();
        if (i == R.id.tv_report && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickTopLeftButton(mReport);
            return;
        }

        if (i == R.id.ib_close && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickTopRightButton(mCloseIBtn);
            return;
        }

        if (i == R.id.iv_hostImg && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickBottomLeftButton(mHeadImg);
            return;
        }

        if (i == R.id.btn_follow && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomButton(mFollowBtn);
            return;
        }

    }

    public void show() {

        mDialog.show();
    }

    public void dismiss() {

        mDialog.dismiss();
    }

    public static class Builder
    {
        private boolean isHide;
        private String headImgUrl;
        private String uName;
        private String roomId;
        private String uIntroduce;
        private int followCount;
        private int fansCount;
        private String liveType;
        private boolean isAttention;
        private boolean isReport;
        private AnchorInfoBean anchorInfo;
//        private double overallScore;
//        private double videoScore;
//        private double noteScore;
//        private double audioScore;

        private IDialogOnClickListener onclickListener;
        private boolean isTouchOutside;
        private float height;
        private float width;
        private Context mContext;

        public Builder(Context context)
        {
            mContext = context;

            headImgUrl = "";
            uName = "张三丰";
            roomId = "12345";
            uIntroduce = "职业投资人，私募背景，十年股市投资经验，实战派，关注经济动态，把握新闻热点，擅于从基本面捕捉投资机会。";
            followCount = 500;
            fansCount = 500;
            liveType = "股票期权";
            onclickListener = null;
            isTouchOutside = true;
            height = 0.23f;
            width = 0.65f;
            isHide = false;
            isAttention = false;
            isReport = false;
            anchorInfo = null;
//            overallScore = 0.0;
//            videoScore = 0.0;
//            audioScore = 0.0;
        }

        public Context getContext()
        {
            return mContext;
        }

        public String getHeadImgUrl() {
            return headImgUrl;
        }

        public Builder setHeadImgUrl(String headImgUrl) {
            this.headImgUrl = headImgUrl;
            return this;
        }

        public String getuName() {
            return uName;
        }

        public Builder setuName(String uName) {
            this.uName = uName;
            return this;
        }

        public String getRoomId() {
            return roomId;
        }

        public Builder setRoomId(String roomId) {
            this.roomId = roomId;
            return this;
        }

        public String getuIntroduce() {
            return uIntroduce;
        }

        public Builder setuIntroduce(String uIntroduce) {
            this.uIntroduce = uIntroduce;
            return this;
        }

        public int getFollowCount() {
            return followCount;
        }

        public Builder setFollowCount(int followCount) {
            this.followCount = followCount;
            return this;
        }

        public int getFansCount() {
            return fansCount;
        }

        public Builder setFansCount(int fansCount) {
            this.fansCount = fansCount;
            return this;
        }

        public String getLiveType() {
            return liveType;
        }

        public Builder setLiveType(String liveType) {
            this.liveType = liveType;
            return this;
        }

        public boolean isReport() {
            return isReport;
        }

        public Builder setReport(boolean report) {
            this.isReport = report;
            return this;
        }

        public IDialogOnClickListener getOnclickListener() {
            return onclickListener;
        }

        public Builder setOnclickListener(IDialogOnClickListener onclickListener) {
            this.onclickListener = onclickListener;
            return this;
        }

        public boolean isTouchOutside() {
            return isTouchOutside;
        }

        public Builder setCanceledOnTouchOutside(boolean isTouchOutside) {

            this.isTouchOutside = isTouchOutside;
            return this;
        }

        public float getHeight() {
            return height;
        }

        public Builder setHeight(float height) {
            this.height = height;
            return this;
        }

        public float getWidth() {
            return width;
        }

        public Builder setWidth(float width) {
            this.width = width;
            return this;
        }

        public boolean isHide() {
            return isHide;
        }

        public Builder setHide(boolean hide) {
            this.isHide = hide;
            return this;
        }

        public boolean isAttention() {
            return isAttention;
        }

        public Builder setAttention(boolean attention)
        {
            this.isAttention = attention;
            return this;
        }

        public AnchorInfoBean getAnchorInfo() {
            return anchorInfo;
        }

        public Builder setAnchorInfo(AnchorInfoBean anchorInfo) {
            this.anchorInfo = anchorInfo;
            return this;
        }

        /*        public double getOverallScore() {
            return overallScore;
        }

        public Builder setOverallScore(double overallScore) {
            this.overallScore = overallScore;
            return this;
        }

        public double getVideoScore() {
            return videoScore;
        }

        public Builder setVideoScore(double videoScore) {
            this.videoScore = videoScore;
            return this;
        }

        public double getNoteScore() {
            return noteScore;
        }

        public Builder setNoteScore(double noteScore) {
            this.noteScore = noteScore;
            return this;
        }

        public double getAudioScore() {
            return audioScore;
        }

        public Builder setAudioScore(double audioScore) {
            this.audioScore = audioScore;
            return this;
        }*/

        public YNLiveAlertDialog build() {

            return new YNLiveAlertDialog(this);
        }
    }

}
