package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.model.CoinMoneyBean;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonAnimDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;

import java.util.ArrayList;
import java.util.List;

/**
 *  金币兑换界面
 * Created by Administrator on 2016/11/10.
 */
public class GoldExchangeActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private TextView mBalanceTxt;// 账户RMB余额
    private ListView mGoldCoinNumLV;

    private BaseAdapter mAdapter;
    private List<CoinMoneyBean> goldExchangeList;
    private CoinMoneyBean bean;

    private YNLoadingDialog dialog;
    private YNCommonDialog comDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gold_exchange);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.exchange_gold));

        mBalanceTxt = (TextView) findViewById(R.id.tv_balance);
        mGoldCoinNumLV = (ListView) findViewById(R.id.myListView);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);

    }

    @Override
    protected void settingDo()
    {
        mBalanceTxt.setText(getString(R.string.rmb) + 782.63);
        mAdapter = new CommonAdapter<CoinMoneyBean>(this, getGoldExchangeList(), R.layout.gold_exchange_item) {
            @Override
            public void convert(CommonViewHolder viewHolder, CoinMoneyBean item)
            {
                viewHolder.setText(R.id.tv_gold, item.getGoldNum() + getString(R.string.gold));
                viewHolder.setText(R.id.tv_money, getString(R.string.rmb) + item.getCoinMoney() + getString(R.string.rmb_unit));
            }
        };

        mGoldCoinNumLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                bean = goldExchangeList.get(position);
                // 判断账户金额是否足够兑换等额金币
                if (682.73 <bean.getCoinMoney())
                {
                    YNToastMaster.showToast(GoldExchangeActivity.this, getString(R.string.exchange_gold_error) + bean.getGoldNum() + getString(R.string.gold) + "！");
                    return;
                }
                createDialog();
            }
        });

        mGoldCoinNumLV.setAdapter(mAdapter);
    }

    private void createDialog()
    {
        comDialog = new YNCommonDialog(this, R.style.transparentFrameWindowStyle, "确定兑换" + bean.getCoinMoney() + "元金币吗？", bean.getCoinMoney() + "", getResources().getColor(R.color.ynkj_red), false, new YNCommonDialog.CustomDialogListener()
        {
            @Override
            public void OnClick(View view)
            {
                switch (view.getId())
                {
                    case R.id.btnCancel:
                        comDialog.dismiss();
                        break;

                    case R.id.btnConfirm:
                        comDialog.dismiss();
                        // 需要服务器传递兑换结果标识
                        boolean flag = true;
                        if (flag)
                        {
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run()
                                {
                                    dialog.dismiss();
                                    createFinishDialog();
                                }

                            }, 5000);
                        }
                        else
                        {

                        }
                        break;
                }
            }
        });

        comDialog.show();
    }

    /**
     * 创建兑换结果弹出框
     */
    private void createFinishDialog()
    {
        YNCommonAnimDialog dialog = new YNCommonAnimDialog(this, R.style.transparentFrameWindowStyle, R.drawable.exchange_ok, getString(R.string.exchange_gold_success), false, new YNCommonAnimDialog.CustomDialogListener() {
            @Override
            public void OnClick(View view)
            {
                finish();
            }
        });

    }

    private List<CoinMoneyBean> getGoldExchangeList()
    {
        goldExchangeList = new ArrayList<>();
        goldExchangeList.add(new CoinMoneyBean(800, 8));
        goldExchangeList.add(new CoinMoneyBean(3000, 30));
        goldExchangeList.add(new CoinMoneyBean(40000, 400));
        goldExchangeList.add(new CoinMoneyBean(500000, 5000));
        goldExchangeList.add(new CoinMoneyBean(6000000, 60000));

        return goldExchangeList;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
}
