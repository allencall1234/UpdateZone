/*
package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.UserBean;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

import java.util.ArrayList;
import java.util.List;

*/
/**
 * Created by Administrator on 2016/11/30.
 *//*

public class FoundListView extends LinearLayout
{
    private OnItemClickListener onItemClickListener;
    private List<UserBean> mDatas;
    private LayoutInflater layoutInflater ;

    public FoundListView(Context context)
    {
        super(context);
    }

    public FoundListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FoundListView(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context, attrs, defStyleAttr);
    }

    public OnItemClickListener getOnItemClickListener() {
        return onItemClickListener;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setDatas(List<UserBean> datas)
    {
        if(datas == null )
        {
            datas = new ArrayList<UserBean>();
        }
        mDatas = datas;
        YNLogUtil.i("foundList", mDatas.toString());
        notifyDataSetChanged();
    }

    public List<UserBean> getDatas()
    {
        return mDatas;
    }

    public void notifyDataSetChanged()
    {
        removeAllViews();
        if(mDatas == null || mDatas.size() == 0)
        {
            return;
        }
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        for(int i=0; i<mDatas.size(); i++)
        {
            final int index = i;
            View view = getView(index);
            if(view == null)
            {
                throw new NullPointerException("listview item layout is null, please check getView()...");
            }

            addView(view, index, layoutParams);
        }
    }

    private View getView(final int position)
    {
        if(layoutInflater == null)
        {
            layoutInflater = LayoutInflater.from(getContext());
        }
        View convertView = layoutInflater.inflate(R.layout.fragment_follow_item, null, false);

        final UserBean bean = mDatas.get(position);
        ImageView iv_head = (ImageView) findViewById(R.id.iv_head);
        ImageView iv_level = (ImageView) findViewById(R.id.iv_level);
        TextView tv_userName = (TextView) findViewById(R.id.tv_userName);
        TextView tv_userIntroduce = (TextView) findViewById(R.id.tv_userIntroduce);
        TextView tv_livingState = (TextView) findViewById(R.id.tv_livingState);
        TextView tv_focus_on = (TextView) findViewById(R.id.tv_focus_on);

        iv_level.setImageResource(bean.getLevel() >= 5 ? R.drawable.crown : R.drawable.star3x);
        tv_userName.setText(bean.getUserName());
        tv_userIntroduce.setText(bean.getIntroduce());
        tv_livingState.setVisibility(GONE);
        tv_focus_on.setVisibility(VISIBLE);

        return convertView;
    }

    public static interface OnItemClickListener{
        public void onItemClick(int position);
    }

    public static interface OnItemLongClickListener{
        public void onItemLongClick(int position);
    }
}
*/
