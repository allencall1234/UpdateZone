package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * Created by Administrator on 2017/5/22.
 */

public class ArticalDetailsBean {
    private int code;
    private String   info;
    private DataBean data;
    private Object   data1;

    public int getCode() { return code;}

    public void setCode(int code) { this.code = code;}

    public String getInfo() { return info;}

    public void setInfo(String info) { this.info = info;}

    public DataBean getData() { return data;}

    public void setData(DataBean data) { this.data = data;}

    public Object getData1() { return data1;}

    public void setData1(Object data1) { this.data1 = data1;}

    public static class DataBean {
        private String id;
        private String            userid;
        private String            title;
        private int            kind;

        public String getDescribe0() {
            return describe0;
        }

        public void setDescribe0(String describe0) {
            this.describe0 = describe0;
        }

        public String getDescribe1() {
            return describe1;
        }

        public void setDescribe1(String describe1) {
            this.describe1 = describe1;
        }

        public String getDescribe2() {
            return describe2;
        }

        public void setDescribe2(String describe2) {
            this.describe2 = describe2;
        }

        public int getIs_comment() {
            return is_comment;
        }

        public void setIs_comment(int is_comment) {
            this.is_comment = is_comment;
        }

        private String describe0;
        private String describe1;
        private String describe2;

        private String            content;
        private String            picture0;
        private String            picture1;
        private String            picture2;
        private String            smallpicture0;
        private String            smallpicture1;
        private String            smallpicture2;
        private String            mediaId;
        private String            is_pay;
        private String            payCoin;
        private String            view;
        private String            time;

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        private String icon;
        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        private String username;
        private int    good;
        private int    middle;
        private int    bad;
        private int    all;
        private int    is_comment;

        public double getGoodRat() {
            return goodRat;
        }

        public void setGoodRat(double goodRat) {
            this.goodRat = goodRat;
        }

        private double            goodRat;
        private List<PictureBean> picture;

        public String getId() { return id;}

        public void setId(String id) { this.id = id;}

        public String getUserid() { return userid;}

        public void setUserid(String userid) { this.userid = userid;}

        public String getTitle() { return title;}

        public void setTitle(String title) { this.title = title;}

        public int getKind() { return kind;}

        public void setKind(int kind) { this.kind = kind;}

        public String getContent() { return content;}

        public void setContent(String content) { this.content = content;}

        public String getPicture0() { return picture0;}

        public void setPicture0(String picture0) { this.picture0 = picture0;}

        public String getPicture1() { return picture1;}

        public void setPicture1(String picture1) { this.picture1 = picture1;}

        public String getPicture2() { return picture2;}

        public void setPicture2(String picture2) { this.picture2 = picture2;}

        public String getSmallpicture0() { return smallpicture0;}

        public void setSmallpicture0(String smallpicture0) { this.smallpicture0 = smallpicture0;}

        public String getSmallpicture1() { return smallpicture1;}

        public void setSmallpicture1(String smallpicture1) { this.smallpicture1 = smallpicture1;}

        public String getSmallpicture2() { return smallpicture2;}

        public void setSmallpicture2(String smallpicture2) { this.smallpicture2 = smallpicture2;}

        public String getMediaId() { return mediaId;}

        public void setMediaId(String mediaId) { this.mediaId = mediaId;}

        public String getIs_pay() { return is_pay;}

        public void setIs_pay(String is_pay) { this.is_pay = is_pay;}

        public String getPayCoin() { return payCoin;}

        public void setPayCoin(String payCoin) { this.payCoin = payCoin;}

        public String getView() { return view;}

        public void setView(String view) { this.view = view;}

        public String getTime() { return time;}

        public void setTime(String time) { this.time = time;}

        public int getGood() { return good;}

        public void setGood(int good) { this.good = good;}

        public int getMiddle() { return middle;}

        public void setMiddle(int middle) { this.middle = middle;}

        public int getBad() { return bad;}

        public void setBad(int bad) { this.bad = bad;}
        public int getAll() { return all;}
        public void setAll(int all) { this.all = all;}

        public int getis_comment() { return is_comment;}

        public void setis_comment(int is_comment) { this.is_comment = is_comment;}


        public List<PictureBean> getPicture() { return picture;}

        public void setPicture(List<PictureBean> picture) { this.picture = picture;}

        public static class PictureBean {
            /**
             * big : https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bce364ce10.png
             * small : https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591bce364ce10.png
             */

            private String big;
            private String small;

            public String getBig() { return big;}

            public void setBig(String big) { this.big = big;}

            public String getSmall() { return small;}

            public void setSmall(String small) { this.small = small;}
        }
    }
}
