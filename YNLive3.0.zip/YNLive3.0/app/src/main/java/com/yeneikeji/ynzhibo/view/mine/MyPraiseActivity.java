package com.yeneikeji.ynzhibo.view.mine;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

public class MyPraiseActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private ImageView mIvBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_praise);
        initView();
        addEvent();
    }
    public void initView()
    {
        mIvBack = (ImageView) findViewById(R.id.iv_myPraise_back);
    }

    public void addEvent() {
        mIvBack.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_myPraise_back:
                finish();
                break;
            default:
                break;
        }
    }
}
