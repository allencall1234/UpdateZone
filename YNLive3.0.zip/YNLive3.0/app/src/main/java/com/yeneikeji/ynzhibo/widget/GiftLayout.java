package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.utils.UIUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 自定义礼物选择界面
 * Created by Administrator on 2016/12/14.
 */
public class GiftLayout extends LinearLayout
{
    private static final String TAG = "GiftLayout";
    private static final int ROW = 2;
    private static final int COLUMN = 4;
//    private int lastPressIndex = 0;
    // 标识当前是第几页
    private int viewPagerFlag = -1;

    private Context context;
    private ViewPager viewPager;
    private Indicator indicator;

    private OnGiftItemClickListener listener;
    private GiftBean giftBean;
    private int index;

    public interface OnGiftItemClickListener
    {
        void onClick(int position);
    }

    public GiftLayout(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.gift_layout, this);
        viewPager = (ViewPager) findViewById(R.id.view_pager);
        indicator = new Indicator((ViewGroup) findViewById(R.id.indicator));

        viewPager.setAdapter(new GiftPageAdapter());
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "pos = " + position);
                indicator.setSelected(position);
                viewPagerFlag = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    private int getPageSize()
    {
        //总的页数=总数/每页数量，并取整
        return (int) Math.ceil(DataUtils.getGiftList().size() * 1.0 / (ROW * COLUMN));
    }

    private class GiftPageAdapter extends PagerAdapter
    {
        private ArrayList<View> viewContainer = new ArrayList<>();

        public GiftPageAdapter()
        {
            int pageSize = getPageSize();
            for (int i = 0; i < pageSize; i++)
            {
                final RecyclerView recyclerView = (RecyclerView) LayoutInflater.from(getContext()).inflate(R.layout.gift_recycleview, null);
                recyclerView.setHasFixedSize(true);
                GridLayoutManager manager = new GridLayoutManager(getContext(), COLUMN);
                recyclerView.setLayoutManager(manager);
                GiftRecyclerViewAdapter adapter = new GiftRecyclerViewAdapter(getContext(), DataUtils.getGiftList(), i, ROW * COLUMN);
                recyclerView.setAdapter(adapter);
                adapter.replaceAll(DataUtils.getGiftList());
                viewContainer.add(recyclerView);
            }
        }

        @Override
        public int getCount() {
            return viewContainer.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(viewContainer.get(position));
            return viewContainer.get(position);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object)
        {
            container.removeView((View) object);
        }

        private class GiftRecyclerViewAdapter extends RecyclerView.Adapter<GiftRecyclerViewAdapter.BaseViewHolder>
        {
            private List<GiftBean> dataList;
            private int lastPressIndex = 0;
            private TextView mPaymentTotalTV;
//            private GiftBean giftBean;

            /**
             * 页数下标,从0开始(当前是第几页)
             */
            private int curIndex;
            /**
             * 每一页显示的个数
             */
            private int pageSize;

            public GiftRecyclerViewAdapter(Context context, List<GiftBean> mDatas, int curIndex, int pageSize)
            {
                dataList = mDatas;
                this.curIndex = curIndex;
                this.pageSize = pageSize;
            }

            @Override
            public GiftViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
            {
                return new GiftViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.gift_gridview_item, parent, false));
            }

            /**
             * 先判断数据集的大小是否足够显示满本页？mDatas.size() > (curIndex+1)*pageSize,
             * 如果够，则直接返回每一页显示的最大条目个数pageSize,
             * 如果不够，则有几项返回几,(mDatas.size() - curIndex * pageSize);(也就是最后一页的时候就显示剩余item)
             */
            @Override
            public int getItemCount() {
                return dataList.size() > (curIndex + 1) * pageSize ? pageSize : (dataList.size() - curIndex * pageSize);
            }

            public void replaceAll(List<GiftBean> list)
            {
                dataList.clear();
                if (list != null && list.size() > 0) {
                    dataList.addAll(list);
                }
                notifyDataSetChanged();
            }

            @Override
            public void onBindViewHolder(final BaseViewHolder holder, int position)
            {
                holder.setData(dataList.get(position + curIndex * pageSize));
            }

            public class BaseViewHolder extends RecyclerView.ViewHolder {

                public BaseViewHolder(View itemView) {
                    super(itemView);
                }

                void setData(GiftBean data) {
                }
            }

            private class GiftViewHolder extends BaseViewHolder
            {
//                private FrameLayout fl_gift_bg;
                private LinearLayout ll_gift;
                private ImageView iv_gift;
                private TextView tv_gift_name;
                private TextView tv_gift_count;

                public GiftViewHolder(View view)
                {
                    super(view);
//                    fl_gift_bg = (FrameLayout) view.findViewById(R.id.fl_gift_bg);
                    ll_gift = (LinearLayout) view.findViewById(R.id.ll_gift);
                    iv_gift = (ImageView) view.findViewById(R.id.iv_gift);
                    tv_gift_name = (TextView) view.findViewById(R.id.tv_gift_name);
                    tv_gift_count = (TextView) view.findViewById(R.id.tv_gift_count);

                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                            (LinearLayout.LayoutParams.WRAP_CONTENT),
                    (UIUtils.dp2px(getContext(), 100)));
                    itemView.setLayoutParams(params);

                    itemView.setOnClickListener(new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View v)
                        {
                            Log.e("TAG", "OneViewHolder: ");
                            int position = getAdapterPosition();
                            if (lastPressIndex == position)
                            {
                                lastPressIndex = -1;
                            }
                            else
                            {
                                lastPressIndex = position;
                            }
                            notifyDataSetChanged();
                        }
                    });
                }

                @Override
                void setData(GiftBean data)
                {
                    if (data != null)
                    {
                        iv_gift.setImageResource(data.getGiftId());
                        tv_gift_name.setText(data.getGiftName());
                        tv_gift_count.setText(data.getGiftCount() + "");
                        if (getAdapterPosition() == lastPressIndex)
                        {
                            ll_gift.setSelected(true);
                            giftBean = data;
                            index = lastPressIndex;
                        }
                        else
                        {
                            ll_gift.setSelected(false);
                        }
                    }
                }
            }

        }
    }

    public GiftBean getGiftBean()
    {
        return giftBean;
    }

    public int index()
    {
        return index;
    }

    private class Indicator
    {
        private ViewGroup rootView;
        private ArrayList<ImageView> imageList = new ArrayList<>();

        public Indicator(ViewGroup root) {
            rootView = root;
            int pageSize = getPageSize();
            for (int i = 0; i < pageSize; i++) {
                ImageView imageView = new ImageView(getContext());
                LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                int px = UIUtils.dp2px(getContext(),4);
                params.setMargins(px, 0, px, 0);
                imageView.setLayoutParams(params);
                if (i == 0) {
                    viewPagerFlag = 0;
                    imageView.setImageResource(R.drawable.btn_change_white);
                } else {
                    viewPagerFlag = 1;
                    imageView.setImageResource(R.drawable.btn_change);
                }
                imageList.add(imageView);
                rootView.addView(imageView);
            }
        }

        public void setSelected(int position)
        {
            for (int i = 0; i < imageList.size(); i++)
            {
                if (i != position)
                {
                    imageList.get(i).setImageResource(R.drawable.btn_change);
                }
                else
                {
                    imageList.get(i).setImageResource(R.drawable.btn_change_white);
                }
            }
        }
    }
}
