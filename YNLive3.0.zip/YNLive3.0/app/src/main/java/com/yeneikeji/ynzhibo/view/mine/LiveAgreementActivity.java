package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/*
* 这是直播协议的类
* */
public class LiveAgreementActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private TextView mSignedRule;
    private TextView mMustRule;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_agreement);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("直播协定");
        mSignedRule = (TextView) findViewById(R.id.live_host_signed_rule);
        mMustRule = (TextView) findViewById(R.id.live_host_must_rule);

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mSignedRule.setOnClickListener(this);
        mMustRule.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //主播签约守则
            case R.id.live_host_signed_rule:
                mIntent = new Intent(LiveAgreementActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, "hostSignedRule");
                startActivity(mIntent);
                break;
            //主播直播守则
            case R.id.live_host_must_rule:
                mIntent = new Intent(LiveAgreementActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, "hostMustRule");
                startActivity(mIntent);
                break;


        }
    }
}
