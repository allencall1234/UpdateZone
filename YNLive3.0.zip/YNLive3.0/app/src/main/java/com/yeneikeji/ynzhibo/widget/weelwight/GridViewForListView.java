package com.yeneikeji.ynzhibo.widget.weelwight;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.GridView;

/**
 * Created by Administrator on 2017/6/26.
 * 这是一个自定义可适应listview的grideview(解决gridview作为listview头部view只能显示第一行的问题)
 */

public class GridViewForListView extends GridView {
    public GridViewForListView(Context context) {
        super(context);

    }

    public GridViewForListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2,
                                                     MeasureSpec.AT_MOST);
        super.onMeasure(widthMeasureSpec, expandSpec);
    }
}