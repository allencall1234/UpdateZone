package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * Created by Administrator on 2017/7/25.
 */

public class CalculateBean {

    public int code;
    public DataBean data;
    public String   info;
    public int      submit_status;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getSubmit_status() {
        return submit_status;
    }

    public void setSubmit_status(int submit_status) {
        this.submit_status = submit_status;
    }

    public static class DataBean {

        public int currentsum;
        public int                sum;
        public List<YeIncomeBean> yeIncome;

        public int getCurrentsum() {
            return currentsum;
        }

        public void setCurrentsum(int currentsum) {
            this.currentsum = currentsum;
        }

        public int getSum() {
            return sum;
        }

        public void setSum(int sum) {
            this.sum = sum;
        }

        public List<YeIncomeBean> getYeIncome() {
            return yeIncome;
        }

        public void setYeIncome(List<YeIncomeBean> yeIncome) {
            this.yeIncome = yeIncome;
        }

        public static class YeIncomeBean {
            public int sum;
            public int                year;
            public List<MoIncomeBean> moIncome;

            public int getSum() {
                return sum;
            }

            public void setSum(int sum) {
                this.sum = sum;
            }

            public int getYear() {
                return year;
            }

            public void setYear(int year) {
                this.year = year;
            }

            public List<MoIncomeBean> getMoIncome() {
                return moIncome;
            }

            public void setMoIncome(List<MoIncomeBean> moIncome) {
                this.moIncome = moIncome;
            }

            public static class MoIncomeBean {


                public int month;
                public int sum;

                public int getMonth() {
                    return month;
                }

                public void setMonth(int month) {
                    this.month = month;
                }

                public int getSum() {
                    return sum;
                }

                public void setSum(int sum) {
                    this.sum = sum;
                }
            }
        }
    }
}
