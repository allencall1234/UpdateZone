package com.yeneikeji.ynzhibo.view.live;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.recorder.api.LiveConfig;
import com.baidu.recorder.api.LiveSession;
import com.baidu.recorder.api.LiveSessionHW;
import com.baidu.recorder.api.LiveSessionSW;
import com.baidu.recorder.api.SessionStateListener;
import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;
import com.google.gson.reflect.TypeToken;
import com.tb.emoji.Emoji;
import com.tb.emoji.EmojiUtil;
import com.tb.emoji.FaceFragment;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.ChatListAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewHolder;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.animation.HeartLayout;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.AskQuestionBean;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.rongcloud.message.GiftMessage;
import com.yeneikeji.ynzhibo.widget.ChatListView;
import com.yeneikeji.ynzhibo.widget.LiveLeftGiftView;
import com.yeneikeji.ynzhibo.widget.badgeview.BadgeTextView;
import com.yeneikeji.ynzhibo.widget.dialog.YNLiveAlertDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNChatRoomAlertDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import io.rong.imlib.RongIMClient;
import io.rong.imlib.model.Conversation;
import io.rong.imlib.model.MessageContent;
import io.rong.imlib.model.UserInfo;
import io.rong.message.CommandNotificationMessage;
import io.rong.message.ImageMessage;
import io.rong.message.InformationNotificationMessage;
import io.rong.message.TextMessage;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * 直播界面
 * Created by Administrator on 2016/9/5.
 */
public class PushStreamingActivity extends YNBaseActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener, Handler.Callback, View.OnClickListener, FaceFragment.OnEmojiClickListener {
    private static final String TAG = "PushStreamingActivity";
    private LiveSession mLiveSession = null;

    //    private ImageView mFocusIcon = null;
    private Button mBeautyEffectStateButton = null;
    // 新加布局
    private RelativeLayout mRLStartContainer;// 开始直播布局
    private Button mBtnStartLive = null;
    private Button mBtnClose;
    private TextView mTVCountdown;// 倒计时效果
    private HeartLayout heartLayout;// 心形气泡
    private RelativeLayout mRLHostMsg;// 主播信息
    private TextView mTVTotalWealthValue;
    private TextView mTVRanking;
    private TextView mTVWealthValue;
    private RecyclerView horizontalRecyclerView;// 在线观众
    private ChatListView mChatListView;
    private LinearLayout mLiveButton;
    private RelativeLayout mRLUserList;
    private RelativeLayout mRLContributionList;
    private ListView mContributionList;
    private TextView mTVEmpty;
    private RelativeLayout mRLWatchList;
    private TextView mTVWatchList;
    private RelativeLayout mRLAsk;
    private BadgeTextView mTVAsk;
    private ChatListView mLVLiveQuestion;
    private LiveLeftGiftView leftGiftView;
    private LiveLeftGiftView leftGiftView2;
    private RelativeLayout mRLCloseLiving;
    private LinearLayout mLLCloseLiving;
    // 直播结束界面布局
    private RelativeLayout mRLCover;
    private LinearLayout liveEndLayout;
    private ImageView coverImage;
    // 贡献榜
    private LinearLayout liveContributionList;
    // 问题详情
    private LinearLayout mLiveAskQuestion;
    private EditText mEdit;
    private ImageView mEmojiBtn;
    private FrameLayout emojiBoard;

    private static final int UI_EVENT_RECORDER_CONNECTING = 0;
    private static final int UI_EVENT_RECORDER_STARTED = 1;
    private static final int UI_EVENT_RECORDER_STOPPED = 2;
    private static final int UI_EVENT_SESSION_PREPARED = 3;
    private static final int UI_EVENT_HIDE_FOCUS_ICON = 4;
    private static final int UI_EVENT_RESTART_STREAMING = 5;
    private static final int UI_EVENT_RECONNECT_SERVER = 6;
    private static final int UI_EVENT_STOP_STREAMING = 7;
    private static final int UI_EVENT_SHOW_TOAST_MESSAGE = 8;
    private static final int UI_EVENT_RESIZE_CAMERA_PREVIEW = 9;
    private static final int TEST_EVENT_SHOW_UPLOAD_BANDWIDTH = 10;

    private static final int COUNTDOWN_START_INDEX = 3;
    private static final int COUNTDOWN_END_INDEX = 1;
    private static final int MSG_UPDATE_COUNTDOWN = 11;
    private static final int COUNTDOWN_DELAY = 1000;

    private Handler handler = new Handler(this);
    private Handler mUIEventHandler = null;
    private Random random = new Random();
    private SurfaceView mCameraView = null;
    private MediaRecorder mRecorder;
    private SessionStateListener mStateListener = null;
    private GestureDetectorCompat mDetector = null;

    private boolean isSessionReady = false;
    private boolean isSessionStarted = false;
    private boolean isConnecting = false;
    private boolean needRestartAfterStopped = false;
    //    private boolean isFlashOn = false;
    private boolean hasBueatyEffect = false;
    private boolean isOritationLanscape = false;
    protected boolean isShutDownCountdown = false;
    private boolean processFlag = true; //默认可以点击
    // 显示礼物
    volatile boolean isGiftShowing = false;
    volatile boolean isGift2Showing = false;

    private int mCurrentCamera = -1;
    private int mVideoWidth = 1280;
    private int mVideoHeight = 720;
    private int mFrameRate = 30;
    private int mBitrate = 2100000;
    private ChatListAdapter mChatListAdapter;
    private String beClickedUserId;// 被点击的人的用户id
    // 贡献排行榜
    private CommonRecyclerViewAdapter mUserRankingAdapter;
    private List<ChatRoomUserBean> mUserRankingList = new ArrayList<>();
    // 在线用户
    private CommonAdapter mOnLineUsersAdapter;
    private List<ChatRoomUserBean> mUserValueList = new ArrayList<>();
    // 提问列表
    private CommonAdapter mAskAdapter;
    private List<AskQuestionBean> mAskList = new ArrayList<>();
    private UserStatusBean userStatusBean;
    private String mStreamingUrl = null;
    //    private long startTime;
//    private long endTime;
    private long liveTime;
    private String sign;
    List<UserInfo> toShowList = Collections.synchronizedList(new LinkedList<UserInfo>());
    private ChatRoomUserBean chatRoomUserBean;
    private int contributionListType = 0;
    private int onLineNumber;
    private String replyContent;
    private AskQuestionBean askQuestion;
    // 提问详情中问答列表
    private CommonAdapter mAskDetailsAdapter;
    private List<AskQuestionBean> mAskDetailsList = new ArrayList<>();
    private int askCount;
    CharSequence sysTimeStr;
    private Timer barTimer;

    private YNLiveAlertDialog dialog;
    private YNChatRoomAlertDialog chatRoomDialog;
    private YNPayDialog mLiveRoomWarnDialog;
    private YNPayDialog closeDialog;

    public static final String MESSAGE_RECEIVED_ACTION = "MESSAGE_ASK_ACTION";
    private MessageReceiver mAskMessageReceiver;

    private boolean isMultichannelLiving = false;

    private void initUIEventHandler() {
        mUIEventHandler = new Handler() {
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case UI_EVENT_RECORDER_CONNECTING:
                        isConnecting = true;
//                        mRecorderButton.setBackgroundResource(R.drawable.btn_block_streaming);
//                        mRecorderButton.setPadding(0, 0, 0, 0);
//                        statusView.setText("连接中");
//                        mRecorderButton.setEnabled(false);
                        mBtnStartLive.setEnabled(false);
                        mRLStartContainer.setVisibility(View.GONE);
                        break;

                    case UI_EVENT_RECORDER_STARTED:
                        YNToastMaster.showToast(PushStreamingActivity.this, "直播开始！");
                        serverFailTryingCount = 0;
                        isSessionStarted = true;
                        needRestartAfterStopped = false;
                        isConnecting = false;
//                        mRecorderButton.setBackgroundResource(R.drawable.btn_stop_streaming);
//                        mRecorderButton.setPadding(0, 0, 0, 0);
//                        statusView.setText("停止直播");
                        mRLStartContainer.setVisibility(View.GONE);
                        mRLHostMsg.setVisibility(View.VISIBLE);
                        mLiveButton.setVisibility(View.VISIBLE);
                        mRLUserList.setVisibility(View.VISIBLE);
                        horizontalRecyclerView.setVisibility(View.VISIBLE);
                        heartLayout.setVisibility(View.VISIBLE);
                        mChatListView.setVisibility(View.VISIBLE);

              /*          if (YNBaseActivity.isConnectNet)
                        {
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().pushStreamSuccessRequest(PushStreamingActivity.this, YNCommonConfig.PUSH_STREAM_SUCCESS_REQUEST_URL, userStatusBean.getUserid();, handler, YNCommonConfig.PUSH_STREAM_SUCCESS_REQUEST_FLAG, false);
                                }
                            });
                        }*/

                        startTimer();
//                        if (!TextUtils.isEmpty(AccountUtils.getUserStatus().getPush_address()))
//                        {
//                            handler.postDelayed(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    UserHttpUtils.newInstance().uploadPushAddress(PushStreamingActivity.this, YNCommonConfig.UPLOAD_PUSH_ADDRESS_URL, userStatusBean.getUserid();, YNCommonUtils.interceptionString(AccountUtils.getUserStatus().getPush_address()),
//                                            handler, YNCommonConfig.UPLOAD_PUSH_ADDRESS_FLAG, false);
//                                }
//                            }, 500);
//                        }

                        showMemberList();
//                        addHeartLayout();
                        break;

                    case UI_EVENT_RECORDER_STOPPED:
                        YNLogUtil.i(TAG, "Stopping Streaming succeeded!");
                        serverFailTryingCount = 0;
                        isSessionStarted = false;
                        needRestartAfterStopped = false;
                        isConnecting = false;
//                        mRecorderButton.setBackgroundResource(R.drawable.btn_start_streaming);
//                        mRecorderButton.setPadding(0, 0, 0, 0);
//                        statusView.setText("开始直播");
//                        mRecorderButton.setEnabled(true);
                        mLiveButton.setVisibility(View.GONE);
                        mRLStartContainer.setVisibility(View.GONE);
                        mBtnStartLive.setEnabled(true);
                        break;

                    case UI_EVENT_SESSION_PREPARED:
                        isSessionReady = true;
//                        mLoadingAnimation.setVisibility(View.GONE);
//                        mRecorderButton.setEnabled(true);
                        mBtnStartLive.setEnabled(true);
                        break;

                    case UI_EVENT_HIDE_FOCUS_ICON:
//                        mFocusIcon.setVisibility(View.GONE);
                        break;

                    case UI_EVENT_RECONNECT_SERVER:
                        YNLogUtil.i(TAG, "Reconnecting to server...");
                        if (isSessionReady && mLiveSession != null) {
                            mLiveSession.startRtmpSession(mStreamingUrl);
                        }
                        if (mUIEventHandler != null) {
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);
                        }
                        break;

                    case UI_EVENT_STOP_STREAMING:
                        if (!isConnecting) {
                            YNLogUtil.i(TAG, "Stopping current session...");
                            if (isSessionReady) {
                                mLiveSession.stopRtmpSession();
                            }
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_STOPPED);
                        }
                        break;

                    case UI_EVENT_RESTART_STREAMING:
                        if (!isConnecting) {
                            YNLogUtil.i(TAG, "Restarting session...");
                            isConnecting = true;
                            needRestartAfterStopped = true;
                            if (isSessionReady && mLiveSession != null) {
                                mLiveSession.stopRtmpSession();
                            }
                            if (mUIEventHandler != null) {
                                mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);
                            }

                        }
                        break;

                    case UI_EVENT_SHOW_TOAST_MESSAGE:
                        String text = (String) msg.obj;
                        YNToastMaster.makeText(PushStreamingActivity.this, text, Toast.LENGTH_SHORT).show();
                        break;

                    case UI_EVENT_RESIZE_CAMERA_PREVIEW:
                        String hint = "注意：当前摄像头不支持您所选择的分辨率\n实际分辨率为" + mVideoWidth + "x" + mVideoHeight;
                        YNToastMaster.makeText(PushStreamingActivity.this, hint, Toast.LENGTH_LONG).show();
                        fitPreviewToParentByResolution(mCameraView.getHolder(), mVideoWidth, mVideoHeight);
                        break;

                    case TEST_EVENT_SHOW_UPLOAD_BANDWIDTH:
                        if (mLiveSession != null) {
                            YNLogUtil.d(TAG, "Current upload bandwidth is " + mLiveSession.getCurrentUploadBandwidthKbps()
                                    + " KBps.");
                        }
                        if (mUIEventHandler != null) {
                            mUIEventHandler.sendEmptyMessageDelayed(TEST_EVENT_SHOW_UPLOAD_BANDWIDTH, 2000);
                        }
                        break;

                    case MSG_UPDATE_COUNTDOWN:
                        handleUpdateCountdown(msg.arg1);
                        break;

                    default:
                        break;
                }
                super.handleMessage(msg);
            }
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        /**
         * 防闪屏
         */
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        // 保持屏幕常亮
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_push_streaming);
//        tintManager.setStatusBarTintColor(R.color.transparent);
        registerMessageReceiver();
        LiveKit.addEventHandler(handler);
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {
        userStatusBean = (UserStatusBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
        isMultichannelLiving = getIntent().getBooleanExtra(YNCommonConfig.ISSHOW, isMultichannelLiving);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mVideoWidth = 1280;
        mVideoHeight = 720;
        mFrameRate = 15;
        mBitrate = 1200 * 1000;

        mBtnStartLive = (Button) findViewById(R.id.btn_start_live);
        mBtnStartLive.setEnabled(false);
        mBtnClose = (Button) findViewById(R.id.btn_close);
        mCameraView = (SurfaceView) findViewById(R.id.sv_camera_preview);
//        mFocusIcon = (ImageView) findViewById(R.id.iv_ico_focus);
        mBeautyEffectStateButton = (Button) findViewById(R.id.btn_switch_effect);
        mRLStartContainer = (RelativeLayout) findViewById(R.id.rl_start_container);
        mTVCountdown = (TextView) findViewById(R.id.tv_countdown);

        mRLHostMsg = (RelativeLayout) findViewById(R.id.rl_host_info);
        mTVTotalWealthValue = (TextView) findViewById(R.id.tv_total_wealth_value);
        mTVRanking = (TextView) findViewById(R.id.tv_ranking);
        mTVWealthValue = (TextView) findViewById(R.id.tv_wealth_value);
        horizontalRecyclerView = (RecyclerView) findViewById(R.id.horizontal_recycle_view);
        mChatListView = (ChatListView) findViewById(R.id.chat_listview);
        heartLayout = (HeartLayout) findViewById(R.id.heart_layout);
        mRLUserList = (RelativeLayout) findViewById(R.id.rl_user_list);
        mRLContributionList = (RelativeLayout) findViewById(R.id.rl_contribution_list);
        mRLWatchList = (RelativeLayout) findViewById(R.id.rl_watch_list);
//        mContributionList = (TextView) findViewById(R.id.tv_contribution_list);
        mTVWatchList = (TextView) findViewById(R.id.tv_watch_list);
//        mLiveRoomId = (TextView) findViewById(R.id.tv_live_room_id);
        mRLAsk = (RelativeLayout) findViewById(R.id.rl_ask);
        mTVAsk = (BadgeTextView) findViewById(R.id.tv_ask);
        mLVLiveQuestion = (ChatListView) findViewById(R.id.lv_live_question);

        leftGiftView = (LiveLeftGiftView) findViewById(R.id.left_gift_view1);
        leftGiftView2 = (LiveLeftGiftView) findViewById(R.id.left_gift_view2);

        mRLCloseLiving = (RelativeLayout) findViewById(R.id.rl_close_living);
        mLLCloseLiving = (LinearLayout) findViewById(R.id.ll_close_living);
        mRLCover = (RelativeLayout) findViewById(R.id.rl_cover);
        coverImage = (ImageView) findViewById(R.id.cover_image);
        liveContributionList = (LinearLayout) findViewById(R.id.live_contribution_list);
        liveEndLayout = (LinearLayout) findViewById(R.id.finish_frame);
        mLiveAskQuestion = (LinearLayout) findViewById(R.id.live_ask_list);

        mLiveButton = (LinearLayout) findViewById(R.id.ll_live_button);

        mRLHostMsg.setVisibility(View.INVISIBLE);
        horizontalRecyclerView.setVisibility(View.INVISIBLE);
        mRLCover.setVisibility(View.GONE);

        mBtnClose.setVisibility(View.INVISIBLE);
        mLiveButton.setVisibility(View.INVISIBLE);

        mRecorder = new MediaRecorder();

        mCurrentCamera = LiveConfig.CAMERA_FACING_FRONT;
        mTVAsk.setBadgeShown(false);
//        isFlashOn = false;

   /*     if (userStatusBean.getTag() == 1)
            sign = getString(R.string.tab2);
        if (userStatusBean.getTag() == 2)
            sign = getString(R.string.tab3);
        if (userStatusBean.getTag() == 3)
            sign = getString(R.string.tab4);
        if (userStatusBean.getTag() == 4)
            sign = getString(R.string.tab5);*/

        mStreamingUrl = userStatusBean.getPush_address();
//        mTVTotalWealthValue.setText("+" + userStatusBean.getWealth() );
//        mLiveRoomId.setText("房间ID：" + userStatusBean.getRoom_id());

        initUIEventHandler();
//        mLLChatRoomLoading.setVisibility(View.VISIBLE);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getRongCloudToken(PushStreamingActivity.this, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userStatusBean.getUserid(),
                        userStatusBean.getUsername(), userStatusBean.getIcon(), userStatusBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
            }
        }, 200);

        getWearthSort();

        handler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getContributionValueList(PushStreamingActivity.this, YNCommonConfig.GET_CONTRIBUTION_VALUE_TOP_TWENTY_URL, userStatusBean.getUserid(), 1, handler,
                        YNCommonConfig.GET_CONTRIBUTION_VALUE_TOP_TWENTY_FLAG, false);
            }
        });

//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().queryChatRoomUserList(PushStreamingActivity.this, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, userStatusBean.getRoom_id(),
//                        500, 1, userStatusBean.getUserid();, handler, YNCommonConfig.ON_REFRESH, false);
//            }
//        });

        getAskList();

//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().queryChatRoomManagerInfo(PushStreamingActivity.this, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_URL, userStatusBean.getRoom_id(), handler, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG, false);
//            }
//        });


//        handler.postDelayed(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().queryChatRoomBeBlockedUesrList(PushStreamingActivity.this, YNCommonConfig.QUERY_BE_BLOCKED_USER_URL, handler, YNCommonConfig.QUERY_BE_BLOCKED_USER_FLAG);
//            }
//        }, 500);

        StartLiveThreeSeconds();
        initStateListener();
        initRTMPSession(mCameraView.getHolder());
    }

    /**
     * 连接融云服务器
     *
     * @param token
     */
    private void connectRongYunServers(String token) {
        /**
         * 建立与融云服务器的连接
         * @param token
         */
        LiveKit.connect(token, new RongIMClient.ConnectCallback() {
            @Override
            public void onTokenIncorrect() {
                // 检查appKey与token是否匹配
                YNLogUtil.d(TAG, "connect onTokenIncorrect");
            }

            @Override
            public void onSuccess(String s) {
                YNLogUtil.d(TAG, "connect onSuccess");
                UserInfo userInfo1 = new UserInfo(userStatusBean.getUserid(), userStatusBean.getUsername(), Uri.parse(userStatusBean.getIcon()));
                LiveKit.setCurrentUser(userInfo1);

                joinChatRoom(userStatusBean.getRoom_id(), -1);
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode) {
                // 根据errorCode检查原因
                YNLogUtil.d(TAG, "connect onError = " + errorCode);
            }
        });
    }

    /**
     * 加入融云聊天室
     *
     * @param roomId
     * @param defMessageCount 进入聊天室拉取消息数目，为 -1 时不拉取任何消息，默认拉取 10 条消息。
     */
    private void joinChatRoom(final String roomId, int defMessageCount) {
        LiveKit.joinChatRoom(roomId, defMessageCount, new RongIMClient.OperationCallback() {
            @Override
            public void onSuccess() {
                InformationNotificationMessage sysMsg = InformationNotificationMessage.obtain("系统提示：股市有风险，入市需谨慎!");
                InformationNotificationMessage msg = InformationNotificationMessage.obtain(LiveKit.getCurrentUser().getName() + " 加入聊天室");
                msg.setUserInfo(LiveKit.getCurrentUser());
//                TextMessage content = TextMessage.obtain("0x0x0x1230x0x加入聊天室");
//                LiveKit.sendMessage(content, Conversation.ConversationType.CHATROOM);
                LiveKit.sendMessage(sysMsg, Conversation.ConversationType.CUSTOMER_SERVICE);
                LiveKit.sendMessage(msg, Conversation.ConversationType.CHATROOM);
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode) {
                YNToastMaster.showToast(PushStreamingActivity.this, "网络不稳定，请退出重新进入!");
            }
        });
    }

    /**
     * 获取主播直播间提问列表
     */
    private void getAskList() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getLiveHostLiveRoomAskList(PushStreamingActivity.this, YNCommonConfig.GET_LIVE_HOST_ASK_LIST_URL, userStatusBean.getUserid(), handler,
                        YNCommonConfig.GET_LIVE_HOST_ASK_LIST_FLAG, false);
            }
        });
    }

    /**
     * 获取主播直播财富榜
     */
    private void getWearthSort() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().liveHostGetWealthSort(PushStreamingActivity.this, YNCommonConfig.LIVE_HOST_GET_WEALTH_SORT_URL, userStatusBean.getUserid(), handler,
                        YNCommonConfig.LIVE_HOST_GET_WEALTH_SORT_FLAG, false);
            }
        });
    }

    /**
     * 查询在线人数
     */
    private void queryLiveRoomPersonalNum() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getLiveRoomPersonalNum(PushStreamingActivity.this, YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_URL, userStatusBean.getRoom_id(), 500, 2,
                        handler, YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_FLAG, false);
            }
        });
    }

    @Override
    protected void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkPermissions())
            getPermissions();
    }

    @Override
    protected boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void getPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO}, 22);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {

        if (requestCode == 22)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            } else {
                getPermissions();
                YNToastMaster.showToast(this, "You denied the permission");
            }
            // 用户允许修改权限,0表示允许，-1表示拒绝 PERMISSION_GRANTED = 0, PERMISSION_GRANTED = -1;
            // 授权允许的处理
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
//                YNLogUtil.e("tag", "获取权限成功");
//            else
//                getPermissions();
        }
//        else
//        {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);

//        }
    }

    /**
     * 设置按钮在短时间内被重复点击的有效标识（true表示点击有效，false表示点击无效）
     */
    private synchronized void setProcessFlag() {
        processFlag = false;
    }

    /**
     * 计时线程（防止在一定时间段内重复点击按钮）
     */
    private class TimeThread extends Thread {
        public void run() {
            try {
                sleep(1000);
                processFlag = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 显示直播观众列表
     */
    private void showMemberList() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        horizontalRecyclerView.setLayoutManager(layoutManager);
        horizontalRecyclerView.setAdapter(mUserRankingAdapter);
    }

    @Override
    protected void addEvent() {
        mDetector = new GestureDetectorCompat(this, this);
        mDetector.setOnDoubleTapListener(this);

        mRLHostMsg.setOnClickListener(this);
        mRLContributionList.setOnClickListener(this);
        mRLWatchList.setOnClickListener(this);
        mRLAsk.setOnClickListener(this);
//        mContributionList.setOnClickListener(this);
//        mUserList.setOnClickListener(this);

    }

    @Override
    protected void settingDo()
    {
        requestPermissions();

        showMemberList();

        mChatListAdapter = new ChatListAdapter(this, userStatusBean, mUserRankingAdapter, true);
        mChatListView.setAdapter(mChatListAdapter);

        mUserRankingAdapter = new CommonRecyclerViewAdapter<ChatRoomUserBean>(this, mUserRankingList, R.layout.live_details_recycleview_item) {
            @Override
            public void convert(CommonRecyclerViewHolder holder, ChatRoomUserBean data, int position) {
                if (!mUserRankingList.isEmpty())
                    holder.setImage(PushStreamingActivity.this, R.id.iv_img, data.getIcon());

                if (data.getSort() == 1) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking1);
                }
                if (data.getSort() == 2) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking2);
                }
                if (data.getSort() == 3) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking3);
                }
                if (data.getSort() > 3) {
                    holder.findView(R.id.iv_ranking).setVisibility(GONE);
                }
            }
        };

        mUserRankingAdapter.setOnItemClickListener(new CommonRecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void OnItemClickListener(View view, final int position) {
                beClickedUserId = mUserRankingList.get(position).getUserid();
                if (processFlag) {
                    setProcessFlag();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            UserHttpUtils.newInstance().getChatRoomUserInfo(PushStreamingActivity.this, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, userStatusBean.getRoom_id(), beClickedUserId, userStatusBean.getUserid(),
                                    handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                        }
                    });
                    new TimeThread().start();
                }
            }
        });

        mAskAdapter = new CommonAdapter<AskQuestionBean>(this, mAskList, R.layout.item_ask_question) {
            @Override
            public void convert(CommonViewHolder viewHolder, AskQuestionBean item) {
                viewHolder.getView(R.id.tv_username).setVisibility(View.GONE);
                viewHolder.getView(R.id.tv_gold_num).setVisibility(item.getPayCoin() > 0 ? VISIBLE : GONE);
                viewHolder.setText(R.id.tv_content, item.getSort() + "." + item.getContent());
                ((TextView) viewHolder.getView(R.id.tv_content)).setTextColor(ContextCompat.getColor(PushStreamingActivity.this, item.getIs_read() == 0 ? R.color.ynkj_white : R.color.search_txt));
                viewHolder.setText(R.id.tv_gold_num, "[" + item.getPayCoin() + "]");
            }
        };

        mLVLiveQuestion.setAdapter(mAskAdapter);

        mLVLiveQuestion.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mLVLiveQuestion.setVisibility(GONE);
                askQuestion = mAskList.get(position);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().liveHostReadAsk(PushStreamingActivity.this, YNCommonConfig.LIVE_HOST_READ_ASK_URL, askQuestion.getId(), handler,
                                YNCommonConfig.LIVE_HOST_READ_ASK_FLAG, false);
                    }
                });
                showLiveAskDetails();
            }
        });

        mChatListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (processFlag) {
                    setProcessFlag();
                    if (mChatListAdapter.getMsg().get(position).getContent() instanceof InformationNotificationMessage) {
                        beClickedUserId = mChatListAdapter.getMessage().get(position).getUserInfo().getUserId();
                        // 查询被点击的用户信息
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                UserHttpUtils.newInstance().getChatRoomUserInfo(PushStreamingActivity.this, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, userStatusBean.getRoom_id(),
                                        beClickedUserId, userStatusBean.getId(), handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                            }
                        }, 200);
                    }
                    new TimeThread().start();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        YNLogUtil.d(TAG, "onResume");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        YNLogUtil.d(TAG, "onConfigurationChanged orientation=" + newConfig.orientation);
        super.onConfigurationChanged(newConfig);
    }

    private void initStateListener() {
        mStateListener = new SessionStateListener() {
            @Override
            public void onSessionPrepared(int code) {
                if (code == SessionStateListener.RESULT_CODE_OF_OPERATION_SUCCEEDED) {
                    if (mUIEventHandler != null) {
                        mUIEventHandler.sendEmptyMessage(UI_EVENT_SESSION_PREPARED);
                    }
                    int realWidth = mLiveSession.getAdaptedVideoWidth();
                    int realHeight = mLiveSession.getAdaptedVideoHeight();
                    if (realHeight != mVideoHeight || realWidth != mVideoWidth) {
                        mVideoHeight = realHeight;
                        mVideoWidth = realWidth;
                        mUIEventHandler.sendEmptyMessage(UI_EVENT_RESIZE_CAMERA_PREVIEW);
                    }
                }
            }

            @Override
            public void onSessionStarted(int code) {
                if (code == SessionStateListener.RESULT_CODE_OF_OPERATION_SUCCEEDED) {
                    if (mUIEventHandler != null) {
                        mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_STARTED);
                    }
                } else {
                    Log.e(TAG, "Starting Streaming failed!");
                }
            }

            @Override
            public void onSessionStopped(int code) {
                if (code == SessionStateListener.RESULT_CODE_OF_OPERATION_SUCCEEDED) {
                    if (mUIEventHandler != null) {
                        if (needRestartAfterStopped && isSessionReady) {
                            mLiveSession.startRtmpSession(mStreamingUrl);
                        } else {
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_STOPPED);
                        }
                    }
                } else {
                    Log.e(TAG, "Stopping Streaming failed!");
                }
            }

            @Override
            public void onSessionError(int code) {
                switch (code) {
                    case SessionStateListener.ERROR_CODE_OF_OPEN_MIC_FAILED:
                        Log.e(TAG, "Error occurred while opening MIC!");
                        onOpenDeviceFailed();
                        break;
                    case SessionStateListener.ERROR_CODE_OF_OPEN_CAMERA_FAILED:
                        Log.e(TAG, "Error occurred while opening Camera!");
                        onOpenDeviceFailed();
                        break;
                    case SessionStateListener.ERROR_CODE_OF_PREPARE_SESSION_FAILED:
                        Log.e(TAG, "Error occurred while preparing recorder!");
                        onPrepareFailed();
                        break;
                    case SessionStateListener.ERROR_CODE_OF_CONNECT_TO_SERVER_FAILED:
                        Log.e(TAG, "Error occurred while connecting to server!");
                        if (mUIEventHandler != null) {
                            serverFailTryingCount++;
                            if (serverFailTryingCount > 5) {
                                Message msg = mUIEventHandler.obtainMessage(UI_EVENT_SHOW_TOAST_MESSAGE);
                                msg.obj = "自动重连服务器失败，请检查网络设置";
                                mUIEventHandler.sendMessage(msg);
                                mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_STOPPED);
                            } else {
                                Message msg = mUIEventHandler.obtainMessage(UI_EVENT_SHOW_TOAST_MESSAGE);
                                msg.obj = "连接推流服务器失败，自动重试5次，当前为第" + serverFailTryingCount + "次";
                                mUIEventHandler.sendMessage(msg);
                                mUIEventHandler.sendEmptyMessageDelayed(UI_EVENT_RECONNECT_SERVER, 2000);
                            }

                        }
                        break;
                    case SessionStateListener.ERROR_CODE_OF_DISCONNECT_FROM_SERVER_FAILED:
                        Log.e(TAG, "Error occurred while disconnecting from server!");
                        isConnecting = false;
                        // Although we can not stop session successfully, we still
                        // need to take it as stopped
                        if (mUIEventHandler != null) {
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_STOPPED);
                        }
                        break;
                    default:
                        onStreamingError(code);
                        break;
                }
            }
        };
    }

    int serverFailTryingCount = 0;

    /**
     * 打开设备失败
     */
    private void onOpenDeviceFailed() {
        if (mUIEventHandler != null) {
            Message msg = mUIEventHandler.obtainMessage(UI_EVENT_SHOW_TOAST_MESSAGE);
            msg.obj = "摄像头或MIC打开失败！请确认您已开启相关硬件使用权限！";
            mUIEventHandler.sendMessage(msg);
        }
    }

    /**
     * 录制准备失败
     */
    private void onPrepareFailed() {
        isSessionReady = false;
    }

    int mWeakConnectionHintCount = 0;

    /**
     * 推流失败提示信息
     *
     * @param errno
     */
    private void onStreamingError(int errno) {
        Message msg = mUIEventHandler.obtainMessage(UI_EVENT_SHOW_TOAST_MESSAGE);
        switch (errno) {
            case SessionStateListener.ERROR_CODE_OF_SERVER_INTERNAL_ERROR:
                msg.obj = "因服务器异常，当前直播已经中断！正在尝试重新推流...";
                if (mUIEventHandler != null) {
                    mUIEventHandler.sendMessage(msg);
                    mUIEventHandler.sendEmptyMessage(UI_EVENT_RESTART_STREAMING);
                }
                break;

            case SessionStateListener.ERROR_CODE_OF_WEAK_CONNECTION_ERROR:
                Log.i(TAG, "Weak connection...");
                msg.obj = "当前网络不稳定，请检查网络信号！";
                mWeakConnectionHintCount++;
                if (mUIEventHandler != null) {
                    mUIEventHandler.sendMessage(msg);
                    if (mWeakConnectionHintCount >= 5) {
                        mWeakConnectionHintCount = 0;
                        mUIEventHandler.sendEmptyMessage(UI_EVENT_RESTART_STREAMING);
                    }
                }
                break;

            case SessionStateListener.ERROR_CODE_OF_LOCAL_NETWORK_ERROR:
                Log.i(TAG, "Timeout when streaming...");
                msg.obj = "本地网络错误，请检查当前网络是否畅通！我们正在努力重连...";
                if (mUIEventHandler != null) {
                    mUIEventHandler.sendMessage(msg);
                    mUIEventHandler.sendEmptyMessage(UI_EVENT_RESTART_STREAMING);
                }
                break;

            default:
                Log.i(TAG, "Unknown error when streaming...");
                msg.obj = "未知错误，当前直播已经中断！正在重试！";
                if (mUIEventHandler != null) {
                    mUIEventHandler.sendMessage(msg);
                    mUIEventHandler.sendEmptyMessageDelayed(UI_EVENT_RESTART_STREAMING, 1000);
                }
                break;
        }
    }

    /**
     * 初始化RTMP会话设置
     *
     * @param sh
     */
    private void initRTMPSession(SurfaceHolder sh) {
        int orientation = isOritationLanscape ? LiveConfig.ORIENTATION_LANDSCAPE : LiveConfig.ORIENTATION_PORTRAIT;
        LiveConfig liveConfig = new LiveConfig.Builder().setCameraId(LiveConfig.CAMERA_FACING_FRONT) // 选择摄像头为前置摄像头
                .setCameraOrientation(orientation) // 设置摄像头为竖向
                .setVideoWidth(mVideoWidth) // 设置推流视频宽度, 需传入长的一边
                .setVideoHeight(mVideoHeight) // 设置推流视频高度，需传入短的一边
                .setVideoFPS(mFrameRate) // 设置视频帧率
                .setInitVideoBitrate(mBitrate) // 设置视频码率，单位为bit per seconds
                .setAudioBitrate(64 * 1000) // 设置音频码率，单位为bit per seconds
                .setAudioSampleRate(LiveConfig.AUDIO_SAMPLE_RATE_44100) // 设置音频采样率
                .setGopLengthInSeconds(3) // 设置I帧间隔，单位为秒
//                .setQosEnabled(true) // 开启码率自适应，默认为true，即默认开启
//                .setMinVideoBitrate(200 * 1000) // 码率自适应，最低码率
//                .setMaxVideoBitrate(mBitrate) // 码率自适应，最高码率
//                .setQosSensitivity(5) // 码率自适应，调整的灵敏度，单位为秒，可接受[5, 10]之间的值
//                .setQosEnabled(true) // 开启码率自适应，默认为true，即默认开启
//                .setMinVideoBitrate(200 * 1000) // 码率自适应，最低码率
//                .setMaxVideoBitrate(1024 * 1000) // 码率自适应，最高码率
//                .setQosSensitivity(5) // 码率自适应，调整的灵敏度，单位为秒，可接受[5, 10]之间的整数值
                .build();
        YNLogUtil.d(TAG, "Calling initRTMPSession..." + liveConfig.toString());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            mLiveSession = new LiveSessionHW(this, liveConfig);
        } else {
            mLiveSession = new LiveSessionSW(this, liveConfig);
        }
        mLiveSession.setStateListener(mStateListener);
        mLiveSession.bindPreviewDisplay(sh);
        mLiveSession.prepareSessionAsync();
    }

    /**
     * 退出事件监听
     *
     * @param v
     */
    public void onClickQuit(View v) {
        createCloseLiveDialog();
  /*      if (isSessionStarted) {
            YNToastMaster.makeText(this, "直播过程中不能返回，请先停止直播！", Toast.LENGTH_SHORT).show();
        } else {
            this.finish();
        }*/
    }

    /**
     * 直播间违规弹出框
     */
    private void liveRoomWarnDialog() {
//        mLiveRoomWarnDialog = new YNPayDialog.Builder(this)
        /*mPayDialog = new YNPayDialog.Builder(mContext)
                .setHeight(0.23f)  //屏幕高度*0.23
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("此视频需要付费" + liveRoomBean.getPayCoin() + "金币，是否付费观看直播？")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        mPayDialog.dismiss();
                        getActivity().finish();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        if (AccountUtils.getLoginInfo())
                        {
                            if (currentCoin >= liveRoomBean.getPayCoin())
                            {
                                handler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().watchLiveValidationPayCoin(mContext, YNCommonConfig.WATCH_LIVE_VALIDATION_PAY_COIN_URL, userStatusBean.getUserid();, liveRoomBean.getUserid(),
                                                handler, YNCommonConfig.WATCH_LIVE_VALIDATION_PAY_COIN_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                YNToastMaster.showToast(mContext, "您的余额不足，请及时充值");
                            }
                        }
                        else
                        {
                            YNToastMaster.showToast(mContext, R.string.un_login_opreate_notice);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        mPayDialog.show();*/
    }

    /**
     * 创建直播关闭弹出框
     */
    private void createCloseLiveDialog()
    {
        mRLCloseLiving.setVisibility(VISIBLE);
        Button btnCloseLiving = (Button) mLLCloseLiving.findViewById(R.id.btn_close_living);
        Button btnContinueLiving = (Button) mLLCloseLiving.findViewById(R.id.btn_continue_living);

        btnCloseLiving.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mRLCloseLiving.setVisibility(GONE);
                mLiveSession.stopRtmpSession();

                if (isMultichannelLiving)
                    sendLocalBroadcast();

            /*    handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().stopLive(PushStreamingActivity.this, YNCommonConfig.STOP_LIVE_URL, AccountUtils.getAccountBean().getId(), handler, YNCommonConfig.STOP_LIVE_FLAG, false);
                    }
                }, 500);
*/
                showConfirmCloseLayout();

                LiveKit.quitChatRoom(new RongIMClient.OperationCallback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError(RongIMClient.ErrorCode errorCode) {

                    }
                });

//                onBackPressed();
            }
        });

        btnContinueLiving.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mRLCloseLiving.setVisibility(GONE);
            }
        });

        /*closeDialog = new YNPayDialog.Builder(this)
                .setContentText("您确定要离开吗？")
                .setRightButtonTextColor(R.color.ynkj_red)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }

                    @Override
                    public void clickBottomLeftButton(View view) {
                        closeDialog.dismiss();
                    }

                    @Override
                    public void clickBottomRightButton(View view) {
                        closeDialog.dismiss();
                        mLiveSession.stopRtmpSession();
                        LiveKit.quitChatRoom(new RongIMClient.OperationCallback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError(RongIMClient.ErrorCode errorCode) {

                            }
                        });

                        onBackPressed();
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        closeDialog.show();*/

        /*final AlertDialog closeDialog = new AlertDialog.Builder(this).create();
        closeDialog.show();
        closeDialog.getWindow().setContentView(R.layout.dialog_cleancache);
        TextView tvContent = (TextView) closeDialog.getWindow().findViewById(R.id.tv_content);
        Button btnPositive = (Button) closeDialog.getWindow().findViewById(R.id.btnConfirm);
        Button btnNegative = (Button) closeDialog.getWindow().findViewById(R.id.btnCancel);

        tvContent.setText("您确定要离开吗？" );
        btnPositive.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                closeDialog.dismiss();
                mLiveSession.stopRtmpSession();
                LiveKit.quitChatRoom(new RongIMClient.OperationCallback() {
                    @Override
                    public void onSuccess()
                    {

                    }

                    @Override
                    public void onError(RongIMClient.ErrorCode errorCode)
                    {

                    }
                });

                onBackPressed();
            }
        });
        btnNegative.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                closeDialog.dismiss();
            }
        });*/
    }

    /**
     * 清屏监听
     *
     * @param v
     */
    public void onClickSwitchClear(View v) {
        if (mRLHostMsg.getVisibility() == View.VISIBLE) {
            mRLHostMsg.setVisibility(View.INVISIBLE);
            mChatListView.setVisibility(View.INVISIBLE);
            horizontalRecyclerView.setVisibility(View.INVISIBLE);
            mRLContributionList.setVisibility(View.INVISIBLE);
        } else {
            mRLHostMsg.setVisibility(View.VISIBLE);
            mChatListView.setVisibility(View.VISIBLE);
            horizontalRecyclerView.setVisibility(View.VISIBLE);
            mRLContributionList.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 打开关闭闪光灯监听
     * @param v
     */
/*    public void onClickSwitchFlash(View v) {
        if (mCurrentCamera == LiveConfig.CAMERA_FACING_BACK) {
            mLiveSession.toggleFlash(!isFlashOn);
            isFlashOn = !isFlashOn;
            if (isFlashOn) {
                mFlashStateButton.setBackgroundResource(R.drawable.live_light_switch_selected);
            } else {
                mFlashStateButton.setBackgroundResource(R.drawable.live_light_switch_normal);
            }
        }
    }*/

    /**
     * 切换摄像头监听
     *
     * @param v
     */
    public void onClickSwitchCamera(View v) {
        if (mLiveSession.canSwitchCamera()) {
            if (mCurrentCamera == LiveConfig.CAMERA_FACING_BACK) {
                mCurrentCamera = LiveConfig.CAMERA_FACING_FRONT;
                mLiveSession.switchCamera(mCurrentCamera);
                YNToastMaster.showToast(this, "切换到前置摄像头！", Toast.LENGTH_SHORT, Gravity.CENTER);
//                if (isFlashOn) {
//                    mFlashStateButton.setBackgroundResource(R.drawable.live_camera_switch_selected);
//                }
            } else {
                mCurrentCamera = LiveConfig.CAMERA_FACING_BACK;
                mLiveSession.switchCamera(mCurrentCamera);
                YNToastMaster.showToast(this, "切换到后置摄像头！", Toast.LENGTH_SHORT, Gravity.CENTER);
//                if (isFlashOn) {
//                    mFlashStateButton.setBackgroundResource(R.drawable.live_camera_switch_normal);
//                }
            }
        } else {
            YNToastMaster.showToast(this, "抱歉！该分辨率下不支持切换摄像头！", Toast.LENGTH_SHORT, Gravity.CENTER);
        }
    }

    /**
     * 打开关闭美化效果监听
     *
     * @param v
     */
    public void onClickSwitchBeautyEffect(View v)
    {
        hasBueatyEffect = !hasBueatyEffect;
        mLiveSession.enableDefaultBeautyEffect(hasBueatyEffect);
        mBeautyEffectStateButton
                .setBackgroundResource(hasBueatyEffect ? R.drawable.live_beauty_switch_selected : R.drawable.live_beauty_switch_normal);
        if (hasBueatyEffect)
            YNToastMaster.showToast(this, "打开美颜效果", Toast.LENGTH_SHORT, Gravity.CENTER);
        else
            YNToastMaster.showToast(this, "关闭美颜效果", Toast.LENGTH_SHORT, Gravity.CENTER);
    }

    /**
     * 打开和关闭录音
     * @param v
     *//* public void onClickSwitchVoice(View v)
    {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if(audioManager.isMicrophoneMute())
        {
            audioManager.setMicrophoneMute(false);
            mVoiceButton.setSelected(false);
        }
        else
        {
            audioManager.setMicrophoneMute(true);
            mVoiceButton.setSelected(true);
        }
    }*/


    /**
     * 开始直播监听
     *
     * @param v
     */
    public void onClickStreamingButton(View v) {
        if (!isSessionReady) {
            return;
        }
   /*     if (!isSessionStarted && !TextUtils.isEmpty(mStreamingUrl))
        {
            if (mLiveSession.startRtmpSession(mStreamingUrl))
            {
                mRLStartContainer.setVisibility(View.GONE);
                YNLogUtil.i(TAG, "Starting Streaming in right state!");
            } else {
                YNLogUtil.e(TAG, "Starting Streaming in wrong state!");
            }*/
        new Thread() {
            public void run() {
                int i = COUNTDOWN_START_INDEX;
                do {
                    Message msg = Message.obtain();
                    msg.what = MSG_UPDATE_COUNTDOWN;
                    msg.arg1 = i;
                    mUIEventHandler.sendMessage(msg);
                    i--;
                    try {
                        Thread.sleep(COUNTDOWN_DELAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } while (i >= COUNTDOWN_END_INDEX);
            }
        }.start();
           /* mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);*/
//        }
/*        else
        {
            if (mLiveSession.stopRtmpSession()) {
                YNLogUtil.i(TAG, "Stopping Streaming in right state!");
            } else {
                YNLogUtil.e(TAG, "Stopping Streaming in wrong state!");
            }
            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);
        }*/
    }

    /**
     * 添加点赞动画效果
     */
    public void addHeartLayout() {
        heartLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                int rgb = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));
                heartLayout.addHeart(rgb);
            }
        }, 200);

        /*new Thread(new Runnable()
        {
            @Override
            public void run() {
                while (!PushStreamingActivity.this.isFinishing())
                {
                    PushStreamingActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run()
                        {
                            int rgb = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));
                            heartLayout.addHeart(rgb);
                        }
                    });
                    try {
                        Thread.sleep(new Random().nextInt(400) + 1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();*/
    }

    /**
     * 五秒后隐藏界面上的控件
     */
    private void hideOuterAfterFiveSeconds() {
        if (mBtnClose.getVisibility() == View.VISIBLE)
            mBtnClose.setVisibility(View.INVISIBLE);
        else
            mBtnClose.setVisibility(View.VISIBLE);

        if (mLiveButton.getVisibility() == View.VISIBLE)
            mLiveButton.setVisibility(View.INVISIBLE);
        else
            mLiveButton.setVisibility(View.VISIBLE);

        if (barTimer != null) {
            barTimer.cancel();
            barTimer = null;
        }
        barTimer = new Timer();
        barTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        mBtnClose.setVisibility(View.INVISIBLE);
                        mLiveButton.setVisibility(View.INVISIBLE);
                    }
                });
            }

        }, 5 * 1000);
    }

    /**
     * 三秒动画显示
     */
    private void StartLiveThreeSeconds() {
        new Thread() {
            public void run() {
                int i = COUNTDOWN_START_INDEX;
                do {
                    Message msg = Message.obtain();
                    msg.what = MSG_UPDATE_COUNTDOWN;
                    msg.arg1 = i;
                    mUIEventHandler.sendMessage(msg);
                    i--;
                    try {
                        Thread.sleep(COUNTDOWN_DELAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } while (i >= COUNTDOWN_END_INDEX);
            }
        }.start();
    }

    public void handleUpdateCountdown(final int count) {
        if (mTVCountdown != null) {
            mTVCountdown.setVisibility(View.VISIBLE);
            mTVCountdown.setText(String.format("%d", count));
            ScaleAnimation scaleAnimation =
                    new ScaleAnimation(1.0f, 0f, 1.0f, 0f, Animation.RELATIVE_TO_SELF, 0.5f,
                            Animation.RELATIVE_TO_SELF, 0.5f);
            scaleAnimation.setDuration(COUNTDOWN_DELAY);
            scaleAnimation.setFillAfter(false);
            scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    mTVCountdown.setVisibility(View.VISIBLE);
                    if (count == COUNTDOWN_END_INDEX && !isShutDownCountdown) {
                        mTVCountdown.setVisibility(View.GONE);
//                        YNToastMaster.showToast(PushStreamingActivity.this, "直播开始！");
//                        mRLContributionList.setVisibility(View.VISIBLE);
//                        heartLayout.setVisibility(View.VISIBLE);
//                        mChatListView.setVisibility(View.VISIBLE);
//                        showMemberList();
//                        addHeartLayout();
                        if (!isSessionStarted && !TextUtils.isEmpty(mStreamingUrl)) {
                            if (mLiveSession.startRtmpSession(mStreamingUrl)) {
//                                mRLStartContainer.setVisibility(View.GONE);
                                YNLogUtil.i(TAG, "Starting Streaming in right state!");
                            } else {
                                YNLogUtil.e(TAG, "Starting Streaming in wrong state!");
                            }
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);
                        } else {
                            if (mLiveSession.stopRtmpSession()) {
                                YNLogUtil.i(TAG, "Stopping Streaming in right state!");
                            } else {
                                YNLogUtil.e(TAG, "Stopping Streaming in wrong state!");
                            }
                            mUIEventHandler.sendEmptyMessage(UI_EVENT_RECORDER_CONNECTING);
                        }
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            if (!isShutDownCountdown) {
                mTVCountdown.startAnimation(scaleAnimation);
            } else {
                mTVCountdown.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 开始计时功能
     */
    private void startTimer() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(0);
        calendar.add(Calendar.HOUR_OF_DAY, -8);
        Date time = calendar.getTime();
        liveTime = time.getTime();
        handler.post(timerRunnable);
    }

    /**
     * 循环执行线程
     */
    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(timerRunnable, 1000);
            liveTime += 1000;
            sysTimeStr = DateFormat.format("HH:mm:ss", liveTime);
        }
    };

    /**
     * 直播关闭显示界面
     */
    private void showConfirmCloseLayout() {
//        endTime = System.currentTimeMillis();
//        YNLogUtil.e(TAG, startTime + "");
        //显示封面
        mRLCover.setVisibility(VISIBLE);
        coverImage.setVisibility(View.VISIBLE);
        YNImageLoaderUtil.setImage(this, coverImage, userStatusBean.getPicture());
//        coverImage.setImageResource(R.drawable.pic_one);
//        View view = liveEndLayout.inflate();
        liveEndLayout.setVisibility(View.VISIBLE);
        ImageView mIVHeadImg = (ImageView) liveEndLayout.findViewById(R.id.iv_head_img);
        TextView mTVSign = (TextView) liveEndLayout.findViewById(R.id.tv_sign);
        TextView mTVWatchNumber = (TextView) liveEndLayout.findViewById(R.id.tv_watch_number);
        TextView mTVLiveTime = (TextView) liveEndLayout.findViewById(R.id.tv_live_time);
        TextView followBtn = (TextView) liveEndLayout.findViewById(R.id.btn_live_follow);
        TextView finishBtn = (TextView) liveEndLayout.findViewById(R.id.btn_live_finish);
        YNImageLoaderUtil.setImage(this, mIVHeadImg, userStatusBean.getIcon());
        mTVSign.setText(userStatusBean.getTitle());
        mTVWatchNumber.setText(onLineNumber + "");
//        mTVLiveTime.setText(DateUtil.timeTick2DateForShow(endTime - startTime));
        mTVLiveTime.setText(sysTimeStr);
        followBtn.setText(getString(R.string.finish));
        finishBtn.setVisibility(View.GONE);
        followBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     * 返回键点击处理
     */
    @Override
    public void onBackPressed() {
        if (isSessionStarted) {
            createCloseLiveDialog();
//            mLiveSession.stopRtmpSession();
//            LiveKit.quitChatRoom(new RongIMClient.OperationCallback() {
//                @Override
//                public void onSuccess() {
//
//                }
//
//                @Override
//                public void onError(RongIMClient.ErrorCode errorCode) {
//
//                }
//            });
        } else {
            if (isMultichannelLiving)
                sendLocalBroadcast();

            this.finish();
        }
     /*   if (isSessionStarted) {
            Toast.makeText(this, "直播过程中不能返回，请先停止直播！", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }*/
    }

    private void sendLocalBroadcast()
    {
        Intent intent = new Intent(YNCommonConfig.UNDER_WHEAT_FLAG);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    @Override
    public void onStart() {
        YNLogUtil.i(TAG, "===========> onStart()");
        super.onStart();
    }

    @Override
    protected void onStop() {
        YNLogUtil.i(TAG, "===========> onStop()");
        super.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        YNLogUtil.i(TAG, "===========> onDestroy()");
        unregisterReceiver(mAskMessageReceiver);
        mUIEventHandler.removeCallbacksAndMessages(null);
        if (isSessionStarted) {
            mLiveSession.stopRtmpSession();
            isSessionStarted = false;
        }
        if (isSessionReady) {
            mLiveSession.destroyRtmpSession();
            mLiveSession = null;
            mStateListener = null;
            mUIEventHandler = null;
            isSessionReady = false;
        }
        super.onDestroy();
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (this.mDetector.onTouchEvent(event)) {
            return true;
        }
        // Be sure to call the superclass implementation
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent arg0) {
        return false;
    }

    @Override
    public boolean onFling(MotionEvent arg0, MotionEvent arg1, float arg2, float arg3) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent arg0) {
    }

    @Override
    public boolean onScroll(MotionEvent arg0, MotionEvent arg1, float arg2, float arg3) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent arg0) {
    }

    @Override
    public boolean onSingleTapUp(MotionEvent arg0) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent arg0) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent arg0) {
        if (mLiveSession != null && !mLiveSession.zoomInCamera()) {
            YNLogUtil.e(TAG, "Zooming camera failed!");
            mLiveSession.cancelZoomCamera();
        }
        return true;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent arg0) {
//        if (mLiveButton.getVisibility() == VISIBLE)
//        {
//            mLiveButton.setVisibility(View.GONE);
//        }
//        else
//        {
//            mLiveButton.setVisibility(VISIBLE);
//        }
//        if (mLVLiveQuestion.getVisibility() == VISIBLE)
//        {
//            mLVLiveQuestion.setVisibility(GONE);
//        }
        hideOuterAfterFiveSeconds();
//        if (mLiveSession != null)
//        {
//            mLiveSession.focusToPosition((int) arg0.getX(), (int) arg0.getY());
//            mFocusIcon.setX(arg0.getX() - mFocusIcon.getWidth() / 2);
//            mFocusIcon.setY(arg0.getY() - mFocusIcon.getHeight() / 2);
//            mFocusIcon.setVisibility(View.VISIBLE);
//            mUIEventHandler.sendEmptyMessageDelayed(UI_EVENT_HIDE_FOCUS_ICON, 1000);
//        }
        return true;
    }

    private void fitPreviewToParentByResolution(SurfaceHolder holder, int width, int height) {
        // Adjust the size of SurfaceView dynamically
        int screenHeight = getWindow().getDecorView().getRootView().getHeight();
        int screenWidth = getWindow().getDecorView().getRootView().getWidth();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) { // If
            // portrait,
            // we
            // should
            // swap
            // width
            // and
            // height
            width = width ^ height;
            height = width ^ height;
            width = width ^ height;
        }
        // Fit height
        int adjustedVideoHeight = screenHeight;
        int adjustedVideoWidth = screenWidth;
        if (width * screenHeight > height * screenWidth) { // means width/height
            // >
            // screenWidth/screenHeight
            // Fit width
            adjustedVideoHeight = height * screenWidth / width;
            adjustedVideoWidth = screenWidth;
        } else {
            // Fit height
            adjustedVideoHeight = screenHeight;
            adjustedVideoWidth = width * screenHeight / height;
        }
        holder.setFixedSize(adjustedVideoWidth, adjustedVideoHeight);
    }

    protected synchronized void showLeftGiftVeiw(UserInfo user, GiftBean giftBean) {
        if (!isGift2Showing) {
            showGift2Derect(user, giftBean);
        } else if (!isGiftShowing) {
            showGift1Derect(user, giftBean);
        } else {
            toShowList.add(user);
        }
    }

    private void showGift1Derect(final UserInfo user, final GiftBean giftBean) {
        isGiftShowing = true;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setName(user.getName());
                leftGiftView.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView.setGiftName("送主播" + giftBean.getGiftName());
                leftGiftView.setGiftImageView(giftBean.getGiftId());
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setTranslationY(0);
                ViewAnimator.animate(leftGiftView)
                        .alpha(0, 1)
                        .translationX(-leftGiftView.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop() {
                            @Override
                            public void onStop() {
                                UserInfo user = null;
                                try {
                                    user = toShowList.remove(0);
                                } catch (Exception e) {

                                }
                                if (user != null) {
                                    showGift1Derect(user, giftBean);
                                } else {
                                    isGiftShowing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView.getGiftImageView())
                        .translationX(-leftGiftView.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    private void showGift2Derect(final UserInfo user, final GiftBean giftBean) {
        isGift2Showing = true;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                leftGiftView2.setVisibility(View.VISIBLE);
                leftGiftView2.setName(user.getName());
                leftGiftView2.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView2.setGiftName("送主播" + giftBean.getGiftName());
                leftGiftView2.setGiftImageView(giftBean.getGiftId());
                leftGiftView2.setTranslationY(0);
                ViewAnimator.animate(leftGiftView2)
                        .alpha(0, 1)
                        .translationX(-leftGiftView2.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView2)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView2.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop() {
                            @Override
                            public void onStop() {
                                UserInfo user = null;
                                try {
                                    user = toShowList.remove(0);
                                } catch (Exception e) {

                                }
                                if (user != null) {
                                    showGift2Derect(user, giftBean);
                                } else {
                                    isGift2Showing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView2.getGiftImageView())
                        .translationX(-leftGiftView2.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    @Override
    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case LiveKit.MESSAGE_ARRIVED:
            case LiveKit.MESSAGE_SENT:
                queryLiveRoomPersonalNum();
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message) msg.obj;
                MessageContent content = msgContent.getContent();
                if (content instanceof GiftMessage) {
                    getWearthSort();
                    GiftMessage giftMsg = (GiftMessage) content;
                    if ("0".equals(giftMsg.getType()))
                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                    else
                        addHeartLayout();
                }

                if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage)) {
                    mChatListAdapter.addMessage(content);
                    mChatListAdapter.addMsg(msgContent);
                    mChatListView.setTranscriptMode(2);
                }
                break;

            case LiveKit.MESSAGE_SEND_ERROR:
                break;

           /* case YNCommonConfig.STOP_LIVE_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 49) {
                        try {
                            JSONObject object = new JSONObject(msg.obj.toString());
                            LiveRoomBean liveRoomBean = YNJsonUtil.JsonToBean(object.getString("data"), LiveRoomBean.class);
                            showConfirmCloseLayout(liveRoomBean);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail));
                }
                break;*/

//            case YNCommonConfig.UPLOAD_PUSH_ADDRESS_FLAG:
//                if (msg.obj != null)
//                {
//                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 28)
//                    {
////                        startDate = DateUtil.getYearMonthDay();
//                    }
//                }
//                break;

            case YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG:
//                mLLChatRoomLoading.setVisibility(View.GONE);
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        // 开始直播计时
//                        startTime = System.currentTimeMillis();
                        try {
                            JSONObject object = new JSONObject(msg.obj.toString());
                            String token = object.getString("0");
                            connectRongYunServers(token);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
//                        mLLChatRoomLoading.setVisibility(View.VISIBLE);
//                        mTVLoadingTxt.setText("加入聊天室失败");
                    }
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail), Toast.LENGTH_SHORT, Gravity.CENTER);
//                    mLLChatRoomLoading.setVisibility(View.VISIBLE);
//                    mTVLoadingTxt.setText("加入聊天室失败");
                }
                break;

            case YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                        YNToastMaster.showToast(PushStreamingActivity.this, "禁言成功");
                    else
                        YNToastMaster.showToast(PushStreamingActivity.this, "禁言失败");
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                        YNToastMaster.showToast(PushStreamingActivity.this, "解禁成功");
                    else
                        YNToastMaster.showToast(PushStreamingActivity.this, "解禁失败");
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.REPORT_USER_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNToastMaster.showToast(PushStreamingActivity.this, baseBean.getInfo());
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.DELETE_ROOM_MANAGE_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);

                    YNToastMaster.showToast(PushStreamingActivity.this, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail), Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                break;

            case YNCommonConfig.ADD_ROOM_MANAGE_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNToastMaster.showToast(PushStreamingActivity.this, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail), Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                break;

            case YNCommonConfig.QUERY_BE_BLOCKED_USER_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200) {
                        if (baseBean.getUsers() != null) {
                            for (UserInfoBean userInfoBean : baseBean.getUsers()) {
                                if (userStatusBean.getUserid().equals(userInfoBean.getId())) {
//                                    mTVLoadingTxt.setText("您已被禁言，加入聊天室失败");
                                    break;
                                } else {
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            UserHttpUtils.newInstance().getRongCloudToken(PushStreamingActivity.this, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userStatusBean.getUserid(),
                                                    userStatusBean.getUsername(), userStatusBean.getIcon(), userStatusBean.getHost_id(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
                                        }
                                    }, 200);
                                }
                            }
                        } else {
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    UserHttpUtils.newInstance().getRongCloudToken(PushStreamingActivity.this, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userStatusBean.getUserid(),
                                            userStatusBean.getUsername(), userStatusBean.getIcon(), userStatusBean.getHost_id(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
                                }
                            }, 200);
                        }
                    }
                } else {
//                    mTVLoadingTxt.setText("加入聊天室失败");
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG:
//                if (msg.obj != null)
//                {
//                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 28)
//                    {
//                        try
//                        {
//                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
//                            JSONArray array = jsonObject.getJSONArray("data");
//                            Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
//                            mManagerList = YNJsonUtil.JsonToLBean(array.toString(), type);
//                            mAdapter.updateListView(mManagerList);
//                        }
//                        catch (JSONException e)
//                        {
//                            e.printStackTrace();
//                        }
//                    }
//                }
                break;

            case YNCommonConfig.GET_CONTRIBUTION_VALUE_TOP_TWENTY_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            if (array != null) {
                                Type type = new TypeToken<List<ChatRoomUserBean>>() {
                                }.getType();
                                mUserRankingList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mUserRankingAdapter.updateListView(mUserRankingList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (!mUserValueList.isEmpty()) {
                        mUserValueList.removeAll(mUserValueList);
                        mOnLineUsersAdapter.updateListView(mUserValueList);
                    }

                    if (baseBean.getCode() == 28) {
                        mContributionList.setVisibility(VISIBLE);
                        mTVEmpty.setVisibility(GONE);
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            if (array != null) {
                                Type type = new TypeToken<List<ChatRoomUserBean>>() {
                                }.getType();
                                mUserValueList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mOnLineUsersAdapter.updateListView(mUserValueList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
                        mContributionList.setVisibility(GONE);
                        mTVEmpty.setVisibility(VISIBLE);
                    }
                } else {
                    mContributionList.setVisibility(GONE);
                    mTVEmpty.setVisibility(VISIBLE);
                }
                break;

            case YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            chatRoomUserBean = YNJsonUtil.JsonToBean(jsonObject.get("data").toString(), ChatRoomUserBean.class);
                            createChatRoomDialog(chatRoomUserBean);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            onLineNumber = jsonObject.getInt("total");
                            mTVWatchList.setText("观看 " + onLineNumber);
                            JSONArray array = jsonObject.optJSONArray("data");
                            if (array != null) {
                                Type type = new TypeToken<List<ChatRoomUserBean>>() {
                                }.getType();
                                mUserValueList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mOnLineUsersAdapter.updateListView(mUserValueList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
//                        YNToastMaster.showToast(PushStreamingActivity.this, "直播间暂时无观众在线");
                    }
                }
                break;

           /* case YNCommonConfig.ON_REFRESH:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            onLineNumber = jsonObject.getInt("total");
                            mTVWatchList.setText("观看 " + onLineNumber);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    else
                    {
//                        YNToastMaster.showToast(PushStreamingActivity.this, "直播间暂时无观众在线");
                    }
                }
                break;*/

            case YNCommonConfig.GET_LIVE_HOST_ASK_LIST_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            Type type = new TypeToken<List<AskQuestionBean>>() {
                            }.getType();
                            if (array != null) {
                                mAskList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                askCount = mAskList.size();
                                mTVAsk.setText("向我提问 " + askCount);
                                mAskAdapter.updateListView(mAskList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            Type type = new TypeToken<List<AskQuestionBean>>() {
                            }.getType();
                            if (array != null) {
                                mAskDetailsList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mAskDetailsAdapter.updateListView(mAskDetailsList);
                               /* List<AskQuestionBean> mList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                for (AskQuestionBean askQuestionBean : mList)
                                {
                                    mAskDetailsList.add(askQuestionBean);
                                    if (!TextUtils.isEmpty(askQuestionBean.getReply()))
                                    {
                                        AskQuestionBean askQuestion = new AskQuestionBean();
                                        askQuestion.setId(askQuestionBean.getId());
                                        askQuestion.setUserid(askQuestionBean.getHostId());
                                        askQuestion.setContent(askQuestionBean.getReply());
                                        askQuestion.setUsername("我");
                                        askQuestion.setPayCoin("0");
                                        mAskDetailsList.add(askQuestion);
                                    }
                                }*/

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else {
//                            mRLEmpty.setVisibility(View.VISIBLE);
                    }
                }
                break;

            case YNCommonConfig.LIVE_HOST_READ_ASK_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 114) {
                        for (AskQuestionBean askQuestionBean : mAskList) {
                            if (askQuestionBean.getId().equals(askQuestion.getId())) {
                                askQuestionBean.setIs_read(1);
                                break;
                            }
                        }

                        mAskAdapter.updateListView(mAskList);
                    }

                    YNToastMaster.showToast(PushStreamingActivity.this, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                break;

            case YNCommonConfig.LIVE_ROOM_ASK_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 104) {
                        mEdit.setText("");
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            AskQuestionBean askQuestion = YNJsonUtil.JsonToBean(jsonObject.optString("data"), AskQuestionBean.class);
                      /*      AskQuestionBean reply = new AskQuestionBean();
                            reply.setId(askQuestion.getId());
                            reply.setUserid(askQuestion.getHostId());
                            reply.setUsername("我");
                            reply.setContent(askQuestion.getReply());
                            reply.setPayCoin("0");*/
                            mAskDetailsList.add(askQuestion);
                            mLVLiveQuestion.setTranscriptMode(2);
                            mAskDetailsAdapter.updateListView(mAskDetailsList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    YNToastMaster.showToast(PushStreamingActivity.this, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                break;

            case YNCommonConfig.LIVE_HOST_GET_WEALTH_SORT_FLAG:
                if (msg.obj != null) {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            int totalWealthValue = jsonObject.optJSONObject("data").getInt("wealth");
                            int todayWealthValue = jsonObject.optJSONObject("data").getInt("todayWealth");
                            int sort = jsonObject.optJSONObject("data").getInt("sort");
                            mTVTotalWealthValue.setText(totalWealthValue + "");
                            mTVWealthValue.setText("+" + todayWealthValue);
                            mTVRanking.setText(sort + "");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_FLAG:
                if (msg.obj != null) {
                    YNLogUtil.e("cdy123", msg.obj.toString());
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28) {
                        try {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            onLineNumber = jsonObject.getInt("total");
                            mTVWatchList.setText("观看 " + onLineNumber);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;
        }
        mChatListAdapter.notifyDataSetChanged();
        return false;
    }

   /* private boolean isHavaObject(UserInfo userInfo)
    {
        boolean isHave = false;
        for (UserInfo info : imgUrlList)
        {
            if (userInfo.getUserId().equals(info.getUserId()))
            {
                isHave = true;
                break;
            }
        }
        return isHave;
    }*/

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_contribution_list:
                if (YNBaseActivity.isConnectNet) {
                    showLiveContributionList(true);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            UserHttpUtils.newInstance().getContributionValueList(PushStreamingActivity.this, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL, userStatusBean.getUserid(), contributionListType,
                                    handler, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG, false);
                        }
                    });
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.no_net));
                }
                break;

            /*case R.id.rl_hostMessage:
                dialog = new YNLiveAlertDialog.Builder(this)
                        .setHeight(0.4f)
                        .setWidth(0.8f)
                        .setLevel(20)
                        .setHide(true)
                        .setHeadImgUrl(userStatusBean.getIcon())
                        .setuName(userStatusBean.getUsername())
                        .setRoomId(userStatusBean.getRoom_id())
                        .setuIntroduce(userStatusBean.getTitle())
                        .setFollowCount(userStatusBean.getCount())
                        .setSign(sign)
                        .setCanceledOnTouchOutside(true)
                        .setOnclickListener(new IDialogOnClickListener()
                        {
                            @Override
                            public void clickTopLeftButton(View view)
                            {

                            }

                            @Override
                            public void clickTopRightButton(View view)
                            {
                                dialog.dismiss();
                            }

                            @Override
                            public void clickBottomLeftButton(View view)
                            {

                            }

                            @Override
                            public void clickBottomRightButton(View view)
                            {

                            }

                            @Override
                            public void clickBottomButton(View view)
                            {

                            }
                        }).build();
                dialog.show();
                break;*/

            case R.id.rl_watch_list:
                showLiveContributionList(false);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().queryChatRoomUserList(PushStreamingActivity.this, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, userStatusBean.getRoom_id(),
                                500, 1, userStatusBean.getUserid(), handler, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG, true);
                    }
                });
                break;

            case R.id.rl_ask:
                mLiveButton.setVisibility(View.GONE);
                mTVAsk.setBadgeShown(false);
                if (askCount <= 0)
                {
                    YNToastMaster.showToast(this, "当前无人提问", Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                else
                {
                    if (mLVLiveQuestion.getVisibility() == VISIBLE) {
                        mLVLiveQuestion.setVisibility(GONE);
                    } else {
                        mLVLiveQuestion.setVisibility(VISIBLE);
                        getAskList();
                    }
                }
                break;
        }
    }

    // 显示贡献榜
    private void showLiveContributionList(boolean isShowRadioGroup) {
        mRLCover.setVisibility(VISIBLE);
        liveContributionList.setVisibility(View.VISIBLE);
        coverImage.setVisibility(View.VISIBLE);
//        YNImageLoaderUtil.setBlurImage(this, coverImage, userStatusBean.getPicture());
        ImageView mClose = (ImageView) liveContributionList.findViewById(R.id.iv_close);
        TextView mOnLine = (TextView) liveContributionList.findViewById(R.id.tv_on_line);
        final RadioGroup mCntributionList = (RadioGroup) liveContributionList.findViewById(R.id.rg_list);
//        RadioButton mWeekList = (RadioButton) liveContributionList.findViewById(R.id.rb_week_list);
//        RadioButton mTotalList = (RadioButton) liveContributionList.findViewById(R.id.rb_total_list);
        mContributionList = (ListView) liveContributionList.findViewById(R.id.lv_live_contribution);
        mTVEmpty = (TextView) liveContributionList.findViewById(R.id.tv_empty);
        mCntributionList.setVisibility(isShowRadioGroup ? View.VISIBLE : View.GONE);
        mOnLine.setVisibility(isShowRadioGroup ? View.GONE : View.VISIBLE);

        mClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRLCover.setVisibility(View.INVISIBLE);
                coverImage.setVisibility(View.INVISIBLE);
                liveContributionList.setVisibility(View.INVISIBLE);
            }
        });

        mCntributionList.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_week_list:
                        contributionListType = 0;
                        break;

                    case R.id.rb_total_list:
                        contributionListType = 1;
                        break;
                }
                if (YNBaseActivity.isConnectNet) {
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            UserHttpUtils.newInstance().getContributionValueList(PushStreamingActivity.this, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL, userStatusBean.getUserid(), contributionListType, handler, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG, true);
                        }
                    }, 200);
                } else {
                    YNToastMaster.showToast(PushStreamingActivity.this, getString(R.string.no_net));
                }
            }
        });

        mOnLineUsersAdapter = new CommonAdapter<ChatRoomUserBean>(this, mUserValueList, R.layout.contribution_charts_item) {
            @Override
            public void convert(CommonViewHolder viewHolder, ChatRoomUserBean item) {
                if (item.getSort() == 1) {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.gold);
                }
                if (item.getSort() == 2) {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.silver);
                }
                if (item.getSort() == 3) {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.getView(R.id.tv_ranking).setVisibility(View.GONE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.copper);
                }
                if (item.getSort() > 3) {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.INVISIBLE);
                    viewHolder.getView(R.id.tv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setText(R.id.tv_ranking, item.getSort() + "");
                }

                viewHolder.setImage(PushStreamingActivity.this, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_userName, item.getUsername(), ContextCompat.getColor(PushStreamingActivity.this, R.color.ynkj_white));
                viewHolder.setText(R.id.tv_contribution_num, "贡献  " + item.getTotals(), ContextCompat.getColor(PushStreamingActivity.this, R.color.contribution_charts_orange));
            }
        };

        // 点击用户列表
        mContributionList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
//                createChatRoomDialog(null);
                beClickedUserId = mUserValueList.get(position).getUserid();
                if (processFlag) {
                    setProcessFlag();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            UserHttpUtils.newInstance().getChatRoomUserInfo(PushStreamingActivity.this, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, userStatusBean.getRoom_id(), beClickedUserId, userStatusBean.getUserid(),
                                    handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                        }
                    });
                    new TimeThread().start();
                }
//                creatChatRoomDialog(mUserValueList.get(position));
            }
        });

        mContributionList.setAdapter(mOnLineUsersAdapter);
    }

    // 显示问题详情
    private void showLiveAskDetails() {
        mLiveAskQuestion.setVisibility(VISIBLE);
        mRLCover.setVisibility(VISIBLE);
        ImageView mAskClose = (ImageView) mLiveAskQuestion.findViewById(R.id.iv_close);
        ChatListView mLVAskChat = (ChatListView) mLiveAskQuestion.findViewById(R.id.lv_ask_chat);
//        LinearLayout mLLEdit = (LinearLayout) mLiveAskQuestion.findViewById(R.id.ll_edit);
//        LinearLayout mLLLInputAsk = (LinearLayout) mLiveAskQuestion.findViewById(R.id.ll_input_ask);
//        TextView mEditTextContent = (EditText) mLiveAskQuestion.findViewById(R.id.tv_editor);
//        LinearLayout mEditContentLL = (LinearLayout) mLiveAskQuestion.findViewById(R.id.ll_ask);
//        TextView sendBtn = (TextView) mLiveAskQuestion.findViewById(R.id.tv_send);
//        final EditText mEdit = (EditText) mLiveAskQuestion.findViewById(R.id.tv_editor);
//        final ImageView mEmojiBtn = (ImageView) mLiveAskQuestion.findViewById(R.id.iv_emoji_btn);
//        final FrameLayout emojiBoard = (FrameLayout) mLiveAskQuestion.findViewById(R.id.frameLayout_emoji);
        mEdit = (EditText) mLiveAskQuestion.findViewById(R.id.tv_editor);
        mEmojiBtn = (ImageView) mLiveAskQuestion.findViewById(R.id.iv_emoji_btn);
        emojiBoard = (FrameLayout) mLiveAskQuestion.findViewById(R.id.frameLayout_emoji);

        FaceFragment faceFragment = FaceFragment.Instance();
        getSupportFragmentManager().beginTransaction().add(R.id.frameLayout_emoji, faceFragment).commit();

        mEdit.clearFocus();

        handler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getLiveRoomAskList(PushStreamingActivity.this, YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_URL, askQuestion.getUserid(), askQuestion.getHostId(), handler,
                        YNCommonConfig.GET_LIVE_ROOM_ASK_LIST_FLAG, false, 500);
            }
        });

        mAskDetailsAdapter = new CommonAdapter<AskQuestionBean>(this, mAskDetailsList, R.layout.item_ask_question) {
            @Override
            public void convert(CommonViewHolder viewHolder, AskQuestionBean item) {
                if (item.getPayCoin() > 0)
                    viewHolder.getView(R.id.tv_gold_num).setVisibility(View.VISIBLE);
                else
                    viewHolder.getView(R.id.tv_gold_num).setVisibility(View.GONE);
                if (item.getType() == 1)
                    viewHolder.setText(R.id.tv_username, item.getUsername() + " : ");
                else
                    viewHolder.setText(R.id.tv_username, "我 : ");

                viewHolder.setText(R.id.tv_content, item.getContent());
                viewHolder.setText(R.id.tv_gold_num, "[" + item.getPayCoin() + "金币]");
            }
        };

        mLVAskChat.setAdapter(mAskDetailsAdapter);

        mAskClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRLCover.setVisibility(View.INVISIBLE);
                coverImage.setVisibility(View.INVISIBLE);
                mLiveAskQuestion.setVisibility(View.INVISIBLE);
                YNCommonUtils.hideSoftInput(PushStreamingActivity.this, view);
            }
        });

        mEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emojiBoard.setVisibility(View.GONE);
                mEmojiBtn.setSelected(false);
            }
        });

        mEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                mEdit.setSelected(hasFocus);
                emojiBoard.setVisibility(View.GONE);
                mEmojiBtn.setSelected(false);
            }
        });

        mEmojiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emojiBoard.setVisibility(emojiBoard.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                mEmojiBtn.setSelected(emojiBoard.getVisibility() == View.VISIBLE);
                YNCommonUtils.hideSoftInput(PushStreamingActivity.this, mEdit);
            }
        });

        mEdit.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                    replyQuestion();
                }

                return false;
            }
        });

    }

    /**
     * 回复问题
     */
    private void replyQuestion() {
        //回复
        replyContent = mEdit.getText().toString().trim();
        if (TextUtils.isEmpty(replyContent)) {
            YNToastMaster.showToast(this, "回复内容不能为空！", Toast.LENGTH_SHORT, Gravity.CENTER);
        } else {
            handler.post(new Runnable() {
                @Override
                public void run() {
//                    UserHttpUtils.newInstance().liveHostReplyAsk(PushStreamingActivity.this, YNCommonConfig.LIVE_HOST_REPLY_ASK_URL, askQuestion.getId(), replyContent, handler, YNCommonConfig.LIVE_HOST_REPLY_ASK_FLAG, false);
                    UserHttpUtils.newInstance().liveRoomAsk(PushStreamingActivity.this, YNCommonConfig.LIVE_ROOM_ASK_URL, askQuestion.getUserid(), askQuestion.getHostId(), replyContent, 0, 2, handler, YNCommonConfig.LIVE_ROOM_ASK_FLAG, false, 500);
//                    YNLogUtil.e("123", YNCommonConfig.LIVE_ROOM_ASK_URL + "?userid=" + askQuestion.getUserid() + "&hostId=" + askQuestion.getHostId() + "&content=" + replyContent + "&payCoin=" + 0 + "&type=" + 2);
                }
            });
            emojiBoard.setVisibility(View.GONE);
            mEmojiBtn.setSelected(false);
            YNCommonUtils.hideSoftInput(PushStreamingActivity.this, mEdit);
        }
    }

    @Override
    public void onEmojiClick(Emoji emoji) {
        if (emoji != null) {
            int index = mEdit.getSelectionStart();
            Editable editable = mEdit.getEditableText();
            if (index < 0) {
                editable.append(emoji.getContent());
            } else {
                editable.insert(index, emoji.getContent());
            }
            displayEditText();
        }
    }

    private void displayEditText() {
        try {
            EmojiUtil.handlerEmojiEditText(mEdit, mEdit.getText().toString(), this);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onEmojiDelete() {
        String text = mEdit.getText().toString();
        if (text.isEmpty()) {
            return;
        }
        if ("]".equals(text.substring(text.length() - 1, text.length()))) {
            int index = text.lastIndexOf("[");
            if (index == -1) {
                int action = KeyEvent.ACTION_DOWN;
                int code = KeyEvent.KEYCODE_DEL;
                KeyEvent event = new KeyEvent(action, code);
                mEdit.onKeyDown(KeyEvent.KEYCODE_DEL, event);
                displayEditText();
                return;
            }
            mEdit.getText().delete(index, text.length());
            displayEditText();
            return;
        }
        int action = KeyEvent.ACTION_DOWN;
        int code = KeyEvent.KEYCODE_DEL;
        KeyEvent event = new KeyEvent(action, code);
        mEdit.onKeyDown(KeyEvent.KEYCODE_DEL, event);
        displayEditText();
    }

    /**
     * 创建聊天室弹出框
     */
    private void createChatRoomDialog(final ChatRoomUserBean chatRoomUserBean) {
        boolean isAllGone = false;
        if (userStatusBean.getUserid().equals(beClickedUserId))
            isAllGone = true;

        chatRoomDialog = new YNChatRoomAlertDialog.Builder(this)
                .setHeight(0.4f)
                .setWidth(0.8f)
                .setChatRoomUserBean(chatRoomUserBean)
                .setAllGone(isAllGone)
                .setLiveHost(true)
                .setRoomManager(false)
                .setCanceledOnTouchOutside(true)
                .setShowManagerCount(!isAllGone)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_manage() == 1) {
                            // 取消房管
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    UserHttpUtils.newInstance().deleteRoomManager(PushStreamingActivity.this, YNCommonConfig.DELETE_ROOM_MANAGE_URL, userStatusBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.DELETE_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        } else {
                            // 设置房管
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    UserHttpUtils.newInstance().addRoomManager(PushStreamingActivity.this, YNCommonConfig.ADD_ROOM_MANAGE_URL, beClickedUserId, userStatusBean.getUserid(),
                                            handler, YNCommonConfig.ADD_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickTopRightButton(View view) {
                        chatRoomDialog.dismiss();
                    }

                    @Override
                    public void clickBottomLeftButton(View view) {
                        // 举报
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }

                    @Override
                    public void clickBottomRightButton(View view) {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_say() == 1) {
                            // 删除禁言
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    UserHttpUtils.newInstance().chatRoomCancelGagUser(PushStreamingActivity.this, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_URL, userStatusBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        } else {
                            // 禁言
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    UserHttpUtils.newInstance().chatRoomGagUser(PushStreamingActivity.this, YNCommonConfig.GAG_CHAT_ROOM_USER_URL, userStatusBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view) {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }
                }).build();
        chatRoomDialog.show();
    }

    /**
     * 创建举报弹出框
     */
    private void createReportDialog() {
        View view = getLayoutInflater().inflate(R.layout.report_dialog, null);
        Button mBtnReport1 = (Button) view.findViewById(R.id.btn_report1);
        Button mBtnReport2 = (Button) view.findViewById(R.id.btn_report2);
        Button mBtnReport3 = (Button) view.findViewById(R.id.btn_report3);
        Button mBtnReport4 = (Button) view.findViewById(R.id.btn_report4);
        Button mBtnReport5 = (Button) view.findViewById(R.id.btn_report5);
        Button mBtnCancel = (Button) view.findViewById(R.id.btn_cancel);
        final Dialog dialog = new Dialog(this, R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        mBtnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        mBtnReport1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().reportUser(PushStreamingActivity.this, YNCommonConfig.REPORT_USER_URL, userStatusBean.getUserid(), beClickedUserId,
                                1, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().reportUser(PushStreamingActivity.this, YNCommonConfig.REPORT_USER_URL, userStatusBean.getUserid(), beClickedUserId,
                                2, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().reportUser(PushStreamingActivity.this, YNCommonConfig.REPORT_USER_URL, userStatusBean.getUserid(), beClickedUserId,
                                3, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().reportUser(PushStreamingActivity.this, YNCommonConfig.REPORT_USER_URL, userStatusBean.getUserid(), beClickedUserId,
                                4, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().reportUser(PushStreamingActivity.this, YNCommonConfig.REPORT_USER_URL, userStatusBean.getUserid(), beClickedUserId,
                                5, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });
    }

    private void registerMessageReceiver() {
        mAskMessageReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(MESSAGE_RECEIVED_ACTION);
        registerReceiver(mAskMessageReceiver, filter);
    }

    // 接收消息
    private class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(final Context context, final Intent intent) {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction())) {
                getWearthSort();
                askCount++;
                mTVAsk.setBadgeShown(true);
                mTVAsk.setText("向我提问 " + askCount);
            }
        }
    }
}
