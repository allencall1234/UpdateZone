package com.yeneikeji.ynzhibo.view.live;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewHolder;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNGridView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.database.WatchRecordDao;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 家教界面
 * Created by Administrator on 2017/5/18.
 */
public class TeachActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private YNGridView mGVSubjectType;
    private RelativeLayout mRLHeadView;
    private TextView mTVState;
    private PullToRefreshLayout mRefreshView;
    private RecyclerView mRecyclerView;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;

    private String userId;
    private CommonRecyclerViewAdapter mLiveListAdapter;
    private List<LiveRoomBean> liveRoomList = new ArrayList<>();
    private CommonAdapter mSubjectTypeAdapter;

//    private YNCommonDialog comDialog;
    private YNPayDialog noticeDialog;
    private WatchRecordDao watchRecordDao;

    private boolean isFirst = true;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG:
                    isFirst = false;
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            getNetData(msg.obj.toString());
                        }
                        else
                        {
                            mRecyclerView.setVisibility(View.GONE);
                            mRLEmpty.setVisibility(View.VISIBLE);
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mRecyclerView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(TeachActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                            getNetData(msg.obj.toString());
                        }
                        else
                        {
                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
//                            mRecyclerView.setVisibility(View.GONE);
//                            mRLEmpty.setVisibility(View.VISIBLE);
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mRecyclerView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
//                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view = getLayoutInflater().inflate(R.layout.activity_teach, null);
//        AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle("家教");

        mGVSubjectType = (YNGridView) findViewById(R.id.gv_subject_type);
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mRLHeadView = (RelativeLayout) findViewById(R.id.head_view);
        mTVState = (TextView) mRLHeadView.findViewById(R.id.state_tv);
        mRecyclerView = (RecyclerView) findViewById(R.id.mRecyclerView);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) findViewById(R.id.tv_refresh_net);

        mTVState.setTextColor(ContextCompat.getColor(this, R.color.live_hot_text_color));
        mRecyclerView.setVisibility(View.GONE);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLEmpty.setOnClickListener(this);
        mTVRefreshNet.setOnClickListener(this);

        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(TeachActivity.this, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, 2, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
                    }
                });
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });
    }

    @Override
    protected void onResume()
    {
        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();

        if (!NetUtils.isConnected(this))
        {
            mRLEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");

            if (isFirst)
            {
                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(TeachActivity.this, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, 2, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                    }
                }, 1000);
            }
            else
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(TeachActivity.this, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, 2, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
                    }
                });
            }
        }
        super.onResume();
    }

    @Override
    protected void settingDo()
    {
        watchRecordDao = new WatchRecordDao(this);

        mLiveListAdapter = new CommonRecyclerViewAdapter<LiveRoomBean>(this, new ArrayList<LiveRoomBean>(), R.layout.recommented_grideview_item)
        {
            @Override
            public void convert(CommonRecyclerViewHolder holder, LiveRoomBean data, int position)
            {
                holder.setImage(TeachActivity.this, R.id.iv_img, data.getPicture());
                holder.setImage(TeachActivity.this, R.id.iv_head, data.getIcon());
                holder.setText(R.id.tv_user_name, data.getUsername());
                holder.setText(R.id.tv_watch_number, data.getLiveCount() + "");
                holder.setText(R.id.tv_areas_of_expertise, data.getTitle());
                holder.setText(R.id.tv_live_type, data.getTag2());
                holder.setImageResource(R.id.iv_sex, data.getSex() == 2 ? R.drawable.icon_boy : R.drawable.icon_girl);

                if (data.getLiving() == 1)
                {
                    if (data.getLive_status() == 2)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_pay);
                    }
                    if (data.getLock() == 1)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_encrypt);
                    }
                    if (data.getLive_status() != 2 && data.getLock() != 1)
                    {
                        holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_live);
                    }
                }
                else
                {
                    holder.setImageResource(R.id.iv_living_state, R.drawable.icon_lable_rest);
                }
            }

        };

        mLiveListAdapter.setOnItemClickListener(new CommonRecyclerViewAdapter.OnItemClickListener()
        {
            @Override
            public void OnItemClickListener(View view, final int position)
            {
                if (NetUtils.isConnected(TeachActivity.this))
                {
                    if (!NetUtils.isWifi(TeachActivity.this))
                    {
                        noticeDialog = new YNPayDialog.Builder(TeachActivity.this)
                                .setContentText("您当前处于非WIFI环境下，是否要观看直播？")
                                .setRightButtonTextColor(R.color.ynkj_red)
                                .setCanceledOnTouchOutside(false)
                                .setOnclickListener(new IDialogOnClickListener()
                                {
                                    @Override
                                    public void clickTopLeftButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickTopRightButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickBottomLeftButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                    }

                                    @Override
                                    public void clickBottomRightButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                        watchRecordDao.insertWatchRecord(liveRoomList.get(position));
                                        Intent intent = new Intent(TeachActivity.this, YNLiveDetailsActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void clickBottomButton(View view)
                                    {

                                    }
                                })
                                .build();
                        noticeDialog.show();
                    }
                    else
                    {
                        watchRecordDao.insertWatchRecord(liveRoomList.get(position));
                        Intent intent = new Intent(TeachActivity.this, YNLiveDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, liveRoomList.get(position));
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
                else
                {
//                    NetUtils.openSetting(TeachActivity.this);
                    YNToastMaster.showToast(TeachActivity.this, "网络未连接", Toast.LENGTH_SHORT, Gravity.CENTER);
                }
            }
        });
        mRecyclerView.setAdapter(mLiveListAdapter);

        mSubjectTypeAdapter = new CommonAdapter<GiftBean>(this, DataUtils.getSubjectList(), R.layout.item_subject)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, GiftBean item)
            {
                viewHolder.setImageResource(R.id.iv_subject, item.getGiftId());
                viewHolder.setText(R.id.tv_subject, item.getGiftCode());
            }
        };

        mGVSubjectType.setAdapter(mSubjectTypeAdapter);
    }

    private void getNetData(String jsonString)
    {
        try
        {
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONArray array = jsonObject.optJSONArray("data");
            Type type = new TypeToken<List<LiveRoomBean>>() {}.getType();
            if (array != null)
            {
                liveRoomList = YNJsonUtil.JsonToLBean(array.toString(), type);
                Collections.sort(liveRoomList, new Comparator<LiveRoomBean>(){

                    /*
                     * int compare(LiveRoomBean liveRoom1, LiveRoomBean liveRoom2) 返回一个基本类型的整型，
                     * 返回负数表示：liveRoom1小于liveRoom2，
                     * 返回0 表示：liveRoom1和liveRoom2相等，
                     * 返回正数表示：liveRoom1大于liveRoom2。
                     */
                    public int compare(LiveRoomBean liveRoom1, LiveRoomBean liveRoom2) {

                        if(liveRoom1.getLiving() < liveRoom2.getLiving())
                        {
                            return 1;
                        }
                        if(liveRoom1.getLiving() == liveRoom2.getLiving())
                        {
                            return 0;
                        }
                        return -1;
                    }
                });
                mLiveListAdapter.updateListView(liveRoomList);
            }

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.tv_refresh_net:
            case R.id.empty:
                if (NetUtils.isConnected(this))
                {
                    mRLEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");

                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getLiveHomePageList(TeachActivity.this, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, 1, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                        }
                    }, 1000);
                }
//                else
//                {
//                    YNToastMaster.showToast(TeachActivity.this, "网络未连接");
//                }
                break;
        }
    }
}
