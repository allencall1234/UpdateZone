package com.yeneikeji.ynzhibo.utils;

import android.util.Log;

/**
 * 打印LOG日志工具类
 * Created by Administrator on 2016/8/5.
 */
public class YNLogUtil
{
    private static final String TAG = "LogUtils";

    public static final int VERBOSE = 0;

    public static final int DEBUG = 1;

    public static final int INFO = 2;

    public static final int WARN = 3;

    public static final int ERROR = 4;

    public static final int NOTING = 5 ;

//    private static final boolean LOGGER = true;

    public static void v(String tag, String msg) {
        if (VERBOSE <= NOTING) {
            Log.v(TAG, tag + "-->" + msg);
        }
    }

    public static void d(String tag, String msg) {
        if (DEBUG <= NOTING) {
            Log.d(TAG, tag + "-->" + msg);
        }
    }

    public static void i(String tag, String msg) {
        if (INFO <= NOTING) {
            Log.i(TAG, tag + "-->" + msg);
        }
    }

    public static void w(String tag, String msg) {
        if (WARN <= NOTING) {
            Log.v(TAG, tag + "-->" + msg);
        }
    }

    public static void e(String tag, String msg) {
        if (ERROR <= NOTING) {
            Log.e(TAG, tag + "-->" + msg);
        }
    }

    public static void e(String tag, String msg, Throwable tr) {
        if (ERROR < NOTING) {
            Log.e(TAG, tag + "-->" + msg);
        }
    }
}
