package com.yeneikeji.ynzhibo.view.community;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNPersonalActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.R.id.btn_follow;

/**
 * 个人主页界面
 * Created by Administrator on 2016/11/22.
 */
public class PersonalHomePageActivity extends YNBaseTopBarActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private SmoothListView mPersonalHomePageLV;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private ImageView mHeadImg;
    private ImageView mUserLevel;
    private TextView mNickName;
    private TextView mDescribe;
    private TextView mPersonalDynamicCountTV;
    private TextView mFousOnCount;
    private TextView mFansCount;
    private LinearLayout mFollowMsg;
    private Button mFollowBtn;
    private Button mDirectMsgBtn;
    private LinearLayout llLiving;
    private ImageView imgBack;

    private CommonAdapter<DynamicBean> mAdapter;
    private List<DynamicBean> personalDynamicList;

    private YNCommonDialog dialog;
    private String userId;
    private boolean isShow;
    private TextView txtComment;
    private int totalPages = 0;
    private int curragePage = 0;// 当前页

    private String cId;
    private String mySelfId;
    private UserInfoBean userInfoBean;
    private LiveRoomBean liveRoomBean;
    private int fansCount;
    private int isAttention;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG:
                    loadingDialog.dismiss();
                    getData(msg);
                    break;

                case YNCommonConfig.ON_REFRESH:
                    getData(msg);
                    onStopLoad();
                    break;

                case YNCommonConfig.LOAD_MORE:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("0");
                                for (int i = 0; i < array.length(); i++) {
                                    DynamicBean dynamicBean = YNJsonUtil.JsonToBean(array.getJSONObject(i).toString(), DynamicBean.class);
                                    personalDynamicList.add(dynamicBean);
                                }
                                if (curragePage + 1 >= totalPages)
                                    mPersonalHomePageLV.setLoadMoreEnable(false);
                                else
                                    mPersonalHomePageLV.setLoadMoreEnable(true);

                                mAdapter.setDatas(personalDynamicList);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(PersonalHomePageActivity.this, bean.getInfo());
                    } else {
                        YNToastMaster.showToast(PersonalHomePageActivity.this, getString(R.string.request_fail));
                    }
                    onStopLoad();
                    break;

                case YNCommonConfig.DELETE_PERSONAL_DYNAMIC_FLAG:
                    loadingDialog.dismiss();
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 50) {
                            for (DynamicBean dynamicBean : personalDynamicList) {
                                if (cId.equals(dynamicBean.getId())) {
                                    personalDynamicList.remove(dynamicBean);
                                    mAdapter.notifyDataSetChanged();
                                    break;
                                }
                            }
                        }

                        YNToastMaster.showToast(PersonalHomePageActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(PersonalHomePageActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43) {
                            isAttention = 1;
                            // userInfoBean.setIs_attention(1);
                            mFansCount.setText("粉丝：" + (fansCount + 1));
                            mFollowBtn.setText("已关注");
                            mFollowBtn.setTextColor(ContextCompat.getColor(PersonalHomePageActivity.this, R.color.search_txt));
                            mAdapter.notifyDataSetChanged();
                        }


                        // YNToastMaster.showToast(PersonalHomePageActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(PersonalHomePageActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13) {
                            //userInfoBean.setIs_attention(0);
                            isAttention = 0;
                            mFollowBtn.setText("+关注");
                            mFansCount.setText("粉丝：" + (fansCount - 1));
                            mFollowBtn.setTextColor(ContextCompat.getColor(PersonalHomePageActivity.this, R.color.ynkj_black));
                            mAdapter.notifyDataSetChanged();
                        }
                        //弹出取消成功提示
                        YNToastMaster.showToast(PersonalHomePageActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(PersonalHomePageActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.COMMUNITY_USER_THUMB_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 34) {
                            try {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                int thumb = object.getInt("thumb");
                                int thumb_num = object.getJSONObject("data").getInt("zan_num");
                                String cid = object.getJSONObject("data").getString("id");
                                for (DynamicBean dynamicBean : personalDynamicList) {
                                    if (cid.equals(dynamicBean.getId())) {
                                        dynamicBean.setThumb(thumb);
                                        dynamicBean.setZan_num(thumb_num);
                                        break;
                                    }
                                }
                                mAdapter.notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    } else {

                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private YNLoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_homepage);
        tintManager.setStatusBarTintColor(Color.rgb(68, 154, 237));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {

        isShow = getIntent().getBooleanExtra(YNCommonConfig.ISSHOW, isShow);
        userId = getIntent().getStringExtra(YNCommonConfig.USER_ID);
//        configTopBarCtrollerWithTitle(getString(R.string.personal_homepage));
        llLiving = (LinearLayout) findViewById(R.id.llLiving);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        txtComment = (TextView) findViewById(R.id.txtComment);
        mPersonalHomePageLV = (SmoothListView) findViewById(R.id.lv_personal_homepage);
        mRLEmpty = (RelativeLayout) findViewById(R.id.personal_homepage_empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);

        mPersonalHomePageLV.setVisibility(View.GONE);
        mPersonalHomePageLV.addHeaderView(addHeadView());
        //隐藏顶部视图
        LinearLayout person_home_topView = (LinearLayout) findViewById(R.id.person_home_ll);
        person_home_topView.setVisibility(View.GONE);

        if (isShow) {
            mFollowMsg.setVisibility(View.VISIBLE);
            mFollowBtn.setVisibility(View.VISIBLE);
            mDirectMsgBtn.setVisibility(View.VISIBLE);
//            llLiving.setVisibility(View.VISIBLE);
            txtComment.setVisibility(View.GONE);

        } else {
            txtComment.setVisibility(View.VISIBLE);
//            llLiving.setVisibility(View.GONE);
            mFollowMsg.setVisibility(View.GONE);
            mFollowBtn.setVisibility(View.GONE);
            mDirectMsgBtn.setVisibility(View.GONE);
        }

        if (AccountUtils.getLoginInfo()) {
            mySelfId = AccountUtils.getAccountBean().getId();
        }

    }
    //添加到listview的头部view

    private View addHeadView() {
        View headView = getLayoutInflater().inflate(R.layout.personal_homepage_headview, null);
        mHeadImg = (ImageView) headView.findViewById(R.id.iv_head_img);
        mUserLevel = (ImageView) headView.findViewById(R.id.iv_level);
        mNickName = (TextView) headView.findViewById(R.id.tv_nick_name);
        mDescribe = (TextView) headView.findViewById(R.id.tv_describe);
        mPersonalDynamicCountTV = (TextView) headView.findViewById(R.id.tv_personal_dynamic_count);
        mFousOnCount = (TextView) headView.findViewById(R.id.tv_follow_count);
        mFansCount = (TextView) headView.findViewById(R.id.tv_fans_count);

        mFollowMsg = (LinearLayout) headView.findViewById(R.id.ll_follow_msg);
        mFollowBtn = (Button) headView.findViewById(btn_follow);
        mDirectMsgBtn = (Button) headView.findViewById(R.id.btn_direct_msg);
        mPersonalDynamicCountTV.setVisibility(View.GONE);
        return headView;
    }

    @Override
    protected void addEvent() {
        mPersonalHomePageLV.setSmoothListViewListener(this);
        mPersonalHomePageLV.setLoadMoreEnable(false);
        imgBack.setOnClickListener(this);
        llLiving.setOnClickListener(this);
        txtComment.setOnClickListener(this);
        mFollowBtn.setOnClickListener(this);
        mDirectMsgBtn.setOnClickListener(this);
        mRLEmpty.setOnClickListener(this);

        mHeadImg.setOnClickListener(this);

        mPersonalHomePageLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 2) {
                    if (YNBaseActivity.isConnectNet) {
                        DynamicBean item = personalDynamicList.get(position - 2);
                        Intent intent = new Intent();
                        intent.setClass(PersonalHomePageActivity.this, DynamicDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, item);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    } else {
                        YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.no_net);
                    }
                }
            }
        });
    }

    @Override
    protected void settingDo() {
        loadingDialog = new YNLoadingDialog.Builder(this, getString(R.string.loading_txt)).builder();
        loadingDialog.show();

        initData();
    }

    private void initData() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getPersonalHomePage(PersonalHomePageActivity.this, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_URL, userId, mySelfId, curragePage, mHandler, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG,false);
            }
        }, 500);

        mAdapter = new CommonAdapter<DynamicBean>(this, new ArrayList<DynamicBean>(), R.layout.personal_homepage_item) {
            @Override
            public void convert(CommonViewHolder viewHolder, final DynamicBean item) {
                viewHolder.getView(R.id.tv_focus_on).setVisibility(View.INVISIBLE);
                if (isShow) {
                    viewHolder.getView(R.id.ll_delete).setVisibility(View.GONE);
                } else {
                    viewHolder.getView(R.id.ll_delete).setVisibility(View.VISIBLE);
                    viewHolder.getView(R.id.ll_delete).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog = new YNCommonDialog(PersonalHomePageActivity.this, R.style.transparentFrameWindowStyle, getString(
                                    R.string.delete_dynamic_notice), false, new YNCommonDialog.CustomDialogListener() {
                                @Override
                                public void OnClick(View view) {
                                    switch (view.getId()) {
                                        case R.id.btnCancel:
                                            dialog.dismiss();
                                            break;

                                        case R.id.btnConfirm:
                                            cId = item.getId();
                                            dialog.dismiss();
                                            loadingDialog = new YNLoadingDialog.Builder(context, "正在删除，请稍后...").builder();
                                            loadingDialog.show();
                                            mHandler.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    UserHttpUtils.newInstance().deletePersonalDynamic(PersonalHomePageActivity.this, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_URL, item.getId(), mHandler, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_FLAG,true);
                                                }
                                            }, 1000);
                                            break;
                                    }
                                }
                            });
                            dialog.show();
                        }
                    });
                }

                if (personalDynamicList == null) {
                    viewHolder.getView(R.id.dynamic_item).setVisibility(View.GONE);
                    viewHolder.getView(R.id.personal_homepage_empty).setVisibility(View.VISIBLE);
                } else {
                    viewHolder.getView(R.id.dynamic_item).setVisibility(View.VISIBLE);
                    viewHolder.getView(R.id.personal_homepage_empty).setVisibility(View.GONE);
                }

                if (item.getPicture() != null) {
//                    final String[] imgUrlList = item.getPicture();
                    final List<PhotoInfoBean> photos = new ArrayList<>();

                    for (int i = 0; i < item.getPicture().size(); i++) {
                        photos.add(new PhotoInfoBean(item.getPicture().get(i).getBig(), item.getPicture().get(i).getSmall(), 640, 792));
                    }

                    viewHolder.getView(R.id.multiImgView).setVisibility(View.VISIBLE);
                    ((MultiImageView) viewHolder.getView(R.id.multiImgView)).setList(photos);
                    ((MultiImageView) viewHolder.getView(R.id.multiImgView)).setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            //imagesize是作为loading时的图片size
                            ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());

                            List<String> photoUrls = new ArrayList<String>();
                            for (PhotoInfoBean photoInfo : photos) {
                                photoUrls.add(photoInfo.getBig());
                            }
                            ImagePagerActivity.startImagePagerActivity(context, photoUrls, position, imageSize);
                        }

                    });
                } else {
                    viewHolder.getView(R.id.multiImgView).setVisibility(View.GONE);
                }

                viewHolder.setImage(PersonalHomePageActivity.this, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_uname, item.getUsername());
                viewHolder.setText(R.id.tv_create_time, item.getTime());
                viewHolder.setText(R.id.tv_content, item.getContent());
                viewHolder.setText(R.id.tv_comment_num, item.getComment_num() + "");
                viewHolder.setText(R.id.tv_praise_num, item.getZan_num() + "");
                viewHolder.setImageResource(R.id.iv_praise, item.getThumb() == 1 ? R.drawable.like_red : R.drawable.like);

                viewHolder.getView(R.id.iv_praise).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (YNBaseActivity.isConnectNet) {
                            if (AccountUtils.getLoginInfo()) {
                                mHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        UserHttpUtils.newInstance().userThumbUp(PersonalHomePageActivity.this, YNCommonConfig.COMMUNITY_USER_THUMB_URL, AccountUtils.getAccountBean().getId(), item.getId(),
                                                item.getThumb(), mHandler, YNCommonConfig.COMMUNITY_USER_THUMB_FLAG,true);
                                    }
                                });
                            } else {
                                YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.un_login_opreate_notice);
                            }

                        } else {
                            YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.no_net);
                        }
                    }
                });
            }
        };

        mPersonalHomePageLV.setAdapter(mAdapter);

    }

    private void getData(Message msg) {
        if (msg.obj != null) {
            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
            try {
                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                mPersonalHomePageLV.setVisibility(View.VISIBLE);
                userInfoBean = YNJsonUtil.JsonToBean(jsonObject.getString("0"), UserInfoBean.class);
                liveRoomBean = YNJsonUtil.JsonToBean(jsonObject.getString("data1"), LiveRoomBean.class);
                YNImageLoaderUtil.setImage(this, mHeadImg, userInfoBean.getIcon());
                mNickName.setText(userInfoBean.getUsername());
                mDescribe.setText(userInfoBean.getDescribe());

                if (isShow) {
//                    if (liveRoomBean.getIs_attention() == 1) {
//                        mFollowBtn.setText(getString(R.string.followed));
//
//                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_darkgray));
//                    } else {
//                        mFollowBtn.setText("+关注");
//
//                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_black));
//                    }
                    if (userInfoBean.getUser_status() == 1)
                        llLiving.setVisibility(View.VISIBLE);
                }

                totalPages = UserHttpUtils.newInstance().getTotalPages(userInfoBean.getDynamic_count());
                mFousOnCount.setText("关注：" + userInfoBean.getFocus_count());
                mFansCount.setText("粉丝：" + userInfoBean.getFuns_count());
                fansCount = userInfoBean.getFuns_count();

                if (baseBean.getCode() == 28)
                {
                    isAttention = userInfoBean.getIs_attention();
                    if (userInfoBean.getIs_attention() == 1) {
                        mFollowBtn.setText(getString(R.string.followed));

                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_darkgray));
                    } else {
                        mFollowBtn.setText("+关注");

                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_black));
                    }
                    if (userInfoBean.getUser_status() == 1)
                        llLiving.setVisibility(View.VISIBLE);

                    mPersonalDynamicCountTV.setVisibility(View.VISIBLE);
                    mPersonalDynamicCountTV.setText("动态 (" + userInfoBean.getDynamic_count() + ")");

                    JSONArray array = jsonObject.getJSONArray("data");
                    Type type = new TypeToken<List<DynamicBean>>() {
                    }.getType();
                    personalDynamicList = YNJsonUtil.JsonToLBean(array.toString(), type);
                    if (personalDynamicList != null)
                        mRLEmpty.setVisibility(View.GONE);

                    if (curragePage + 1 >= totalPages)
                        mPersonalHomePageLV.setLoadMoreEnable(false);
                    else
                        mPersonalHomePageLV.setLoadMoreEnable(true);

                    mAdapter.updateListView(personalDynamicList);
                }
                else
                {
                    fansCount = liveRoomBean.getFuns_count();
                    isAttention = liveRoomBean.getIs_attention();
                    mFousOnCount.setText("关注：" + liveRoomBean.getFocus_count());
                    mFansCount.setText("粉丝：" + liveRoomBean.getFuns_count());
                    isAttention = liveRoomBean.getIs_attention();
                    if (liveRoomBean.getIs_attention() == 1) {
                        mFollowBtn.setText(getString(R.string.followed));

                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_darkgray));
                    } else {
                        mFollowBtn.setText("+关注");

                        mFollowBtn.setTextColor(ContextCompat.getColor(this, R.color.ynkj_black));
                    }

                    mRLEmpty.setVisibility(View.VISIBLE);
                    mPersonalDynamicCountTV.setVisibility(View.GONE);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            YNToastMaster.showToast(PersonalHomePageActivity.this, getString(R.string.request_fail));
            mRLEmpty.setVisibility(View.VISIBLE);
            mPersonalDynamicCountTV.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
            case R.id.imgBack:
                finish();
                break;

            case R.id.llLiving:
                if (YNBaseActivity.isConnectNet) {
                    if (isShow) {
                        if (userInfoBean.getLive_status() == 1) {
//                            intent.setClass(PersonalHomePageActivity.this, LiveDetailsActivity.class);
                            intent.putExtra(YNCommonConfig.OBJECT, liveRoomBean);
                            startActivity(intent);
                        } else {
                            YNToastMaster.showToast(PersonalHomePageActivity.this, "主播未开播");
                        }
                    } else {
                        intent.setClass(this, MyCommentActivity.class);
                        startActivity(intent);
                    }
                } else {
                    YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.no_net);
                }
                break;

            case R.id.txtComment:
                if (isShow) {
//                    intent.setClass(this, LiveDetailsActivity.class);
                } else {
                    intent.setClass(this, MyCommentActivity.class);
                }
                startActivity(intent);
                break;

            case btn_follow:
                if (AccountUtils.getLoginInfo()) {/*
                    if (userInfoBean.getIs_attention() == 1)
                    {
                        mHandler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().cancelAttentionUser(PersonalHomePageActivity.this, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), userId, mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG);

                            }
                        }, 1000);*/

                    if (isAttention == 1) {
                        //弹出dialog提示用户
                        //弹出dailog
                        AlertDialog.Builder builder = new AlertDialog.Builder(PersonalHomePageActivity.this);
                        builder.setMessage("确认要取消关注吗？");
                        builder.setTitle("提示");
                        builder.setPositiveButton("确认",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //更新个人对主播关注状态
                                        userInfoBean.setIs_attention(0);
                                        //不刷新出现取消后粉丝数量不对的问题
                                        onRefresh();
                                        //弹出dialog
                                        mHandler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                UserHttpUtils.newInstance().cancelAttentionUser(PersonalHomePageActivity.this, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), userId, mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG,false);

                                            }
                                        }, 500);

                                    }
                                });
                        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();

                    }
                    else
                    {
                        userInfoBean.setIs_attention(1);
                        //不刷新出现粉丝数量不对的问题
                        onRefresh();
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().attentionUser(PersonalHomePageActivity.this, YNCommonConfig.ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), userId, mHandler, YNCommonConfig.ATTENTION_USER_FLAG,false);
                            }
                        });

                    }
                }
                else {
                    YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.un_login_opreate_notice);
                }
                break;

            case R.id.btn_direct_msg:
                if (AccountUtils.getLoginInfo()) {
                    intent.setClass(this, DirectMessageActivity.class);
                    startActivity(intent);
                } else {
                    YNToastMaster.showToast(PersonalHomePageActivity.this, R.string.un_login_opreate_notice);
                }
                break;

            case R.id.personal_homepage_empty:
                mRLEmpty.setVisibility(View.GONE);
                loadingDialog = new YNLoadingDialog.Builder(this, getString(R.string.loading_txt)).builder();
                loadingDialog.show();
                initData();
                break;

            case R.id.iv_head_img:
                if (!isShow) {
                    intent.setClass(this, YNPersonalActivity.class);
                    startActivity(intent);
                }
                break;
        }
    }

    @Override
    public void onRefresh() {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                UserHttpUtils.newInstance().getPersonalHomePage(PersonalHomePageActivity.this, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_URL, userId, AccountUtils.getAccountBean().getId(), curragePage, mHandler, YNCommonConfig.ON_REFRESH,false);
            }
        });
    }

    @Override
    public void onLoadMore() {
        if (curragePage + 1 < totalPages) {
            curragePage++;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    UserHttpUtils.newInstance().getPersonalHomePage(PersonalHomePageActivity.this, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_URL, userId, AccountUtils.getAccountBean().getId(), curragePage, mHandler, YNCommonConfig.LOAD_MORE,false);
                }
            });
        }

    }

    /**
     * 停止刷新
     */
    private void onStopLoad() {
        mPersonalHomePageLV.stopRefresh();
        mPersonalHomePageLV.stopLoadMore();
        mPersonalHomePageLV.setRefreshTime(DateUtil.getNowDate());
    }


}

