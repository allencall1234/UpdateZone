package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.ISelectChangeCallBack;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.Indicator;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 消息中心界面
 */
public class YNMessageCenterActivity extends YNBaseTopBarActivity implements View.OnClickListener, ISelectChangeCallBack
{
    private Indicator mMsgIndicator;
    private ViewPager mViewPager;
    private IndicatorViewPager indicatorViewPager;
    private LinearLayout llMenu;
    private TextView tvSelectAll;
    private TextView tvDelete;
//    private YNFragmentAdapter adapter;
    private MyAdapter mAdapter;
    private List<Fragment> mList;
    private YNMsgContentFragment fg1;
    private YNMsgContentFragment fg2;
    private final String[] TITLES = new String[]{"问答", "系统"};
    private boolean isShow = false;
    private boolean isSelectedAll = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_message_center,null);
       // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        settingDo();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle(getString(R.string.messagecenter));
        getRightBtn().setVisibility(View.VISIBLE);

        mMsgIndicator = (Indicator) findViewById(R.id.fragment_msg_indicator);
        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        llMenu = (LinearLayout) findViewById(R.id.ll_menu);

        tvSelectAll = (TextView) findViewById(R.id.tv_select_all);
        tvDelete = (TextView) findViewById(R.id.tv_delete);

        float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#1694ff");
        int unSelectColor = Color.parseColor("#333333");
        ColorBar line1 = new ColorBar(this, Color.parseColor("#1694ff"), 5);
        line1.setWidth(UIUtils.dp2px(this, 55));
        line1.setHeight(UIUtils.dp2px(this, 2));
        mMsgIndicator.setScrollBar(line1);
        mMsgIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mViewPager.setOffscreenPageLimit(TITLES.length);
        indicatorViewPager = new IndicatorViewPager(mMsgIndicator, mViewPager);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (isShow) {
                    llMenu.setVisibility(View.GONE);
                    getRightBtn().setVisibility(View.VISIBLE);
                    getRightTV().setVisibility(View.GONE);
                    tvSelectAll.setText("全选");
                    isShow = false;
                    fg1.setShowSelected(false);
                    fg2.setShowSelected(false);
                    fg1.setAllSelected(false);
                    fg2.setAllSelected(false);
                    isSelectedAll = false;
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void settingDo()
    {
        mList = new ArrayList<Fragment>();

        fg1 = new YNMsgContentFragment();
        fg1.setMsgType(0);
        fg1.setCallBack(this);
        fg2 = new YNMsgContentFragment();
        fg2.setMsgType(1);
        fg2.setCallBack(this);
        mList.add(fg1);
        mList.add(fg2);

        mAdapter = new MyAdapter(getSupportFragmentManager());
        mAdapter.setFragments(mList);
        indicatorViewPager.setAdapter(mAdapter);
//        adapter = new YNFragmentAdapter(getSupportFragmentManager(), mList, TITLES);
//        mViewPager.setAdapter(mAdapter);

        getRightBtn().setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                getRightBtn().setVisibility(View.GONE);
                getRightTV().setVisibility(View.VISIBLE);
                getRightTV().setText("取消");
                llMenu.setVisibility(llMenu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                isShow = true;

                switch (indicatorViewPager.getCurrentItem())
                {
                    case 0:
                        fg1.setShowSelected(true);
                        break;

                    case 1:
                        fg2.setShowSelected(true);
                        break;
                }
            }
        });

        getRightTV().setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                getRightBtn().setVisibility(View.VISIBLE);
                getRightTV().setVisibility(View.GONE);
                llMenu.setVisibility(View.GONE);
                fg1.setShowSelected(false);
                fg2.setShowSelected(false);
                isShow = false;
            }
        });

        tvSelectAll.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
               if(!isSelectedAll)
               {
                   switch (indicatorViewPager.getCurrentItem())
                   {
                         case 0:
                             fg1.setAllSelected(true);
                             break;

                         case 1:
                             fg2.setAllSelected(true);
                             break;
                   }
                   tvSelectAll.setText("取消全选");
                   isSelectedAll = false;
               }
               else
               {
                   switch (indicatorViewPager.getCurrentItem())
                   {
                       case 0:
                           fg1.setAllSelected(false);
                           break;

                       case 1:
                           fg2.setAllSelected(false);
                           break;
                   }
                   tvSelectAll.setText("全选");
                   isSelectedAll = true;
               }
            }
        });

        tvDelete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                switch (mViewPager.getCurrentItem())
                {
                    case 0:
                        fg1.delete();
                        break;

                    case 1:
                        fg2.delete();
                        fg2.setAllSelected(false);
                        break;
                }
                tvSelectAll.setText("全选");
                tvDelete.setText("删除(0)");
            }
        });
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.star_1_com_topbar_iv_right:
                getRightBtn().setVisibility(View.GONE);
                llMenu.setVisibility(llMenu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                isShow = true;
                break;

        }
    }

    @Override
    public void onSelectedSizeChange(Map<Integer, Boolean> items)
    {
        int count = 0;
        for (int i = 0; i < items.size(); i++)
        {
            if (items.get(i))
            {
                count++;
            }
        }
        tvDelete.setText("删除("+count+")");
        if(count == items.size())
        {
            tvSelectAll.setText("取消全选");
            isSelectedAll = true;
        }
        else
        {
            tvSelectAll.setText("全选");
            isSelectedAll = false;
        }
    }

    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter
    {
        private List<Fragment> fragments = new ArrayList<>();
        public MyAdapter(FragmentManager fragmentManager)
        {
            super(fragmentManager);
        }

        public void setFragments( List<Fragment> fragments)
        {
            this.fragments = fragments;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return TITLES.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container)
        {
            if (convertView == null)
            {
                convertView = getLayoutInflater().inflate(R.layout.tab_textview, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(TITLES[position]);
            return convertView;
        }


        @Override
        public Fragment getFragmentForPage(int position)
        {
            return fragments.get(position);
        }
    }
}
