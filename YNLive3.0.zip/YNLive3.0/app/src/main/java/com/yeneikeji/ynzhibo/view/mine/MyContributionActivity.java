package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class MyContributionActivity extends YNBaseActivity implements View.OnClickListener
{
    private ImageView mIVBack;
    private RelativeLayout mRLMySendGift;
    private RelativeLayout mRLMyPraise;
    private TextView mTVMyContribution;
    private String mGiftNumb="";
    private String mZanNumb="";
    private String mAskNumb="";
    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_MY_CONTRIBUTION_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if(jsonObject.getJSONObject("data")!=null) {
                                    mTVMyContribution.setText(jsonObject.getJSONObject("data")
                                                                        .getInt("sum") + "");
                                }else{
                                    mTVMyContribution.setText("0");
                                }
                                //送出的礼物
                                if(jsonObject.getJSONObject("data").getJSONObject("gift")!=null) {
                                    mGiftNumb=""+jsonObject.getJSONObject("data").getJSONObject("gift").getInt("sum");
                                    mSendGiftNumb.setText("+"+mGiftNumb);
                                }
                                //送出的赞
                                if(jsonObject.getJSONObject("data").getJSONObject("zan")!=null) {
                                    mZanNumb=""+jsonObject.getJSONObject("data").getJSONObject("zan").getInt("sum");
                                    mSendZanNumb.setText("+"+mZanNumb);
                                }
                                //其他
                                if(jsonObject.getJSONObject("data").getJSONObject("others")!=null){
                                    mOthersNumb.setText("+"+jsonObject.getJSONObject("data").getJSONObject("others").getInt("sum"));

                                }
                                //提问
                                if(jsonObject.getJSONObject("data").getJSONObject("others").getJSONObject("ask")!=null){
                                    mAskNumb=""+jsonObject.getJSONObject("data").getJSONObject("others").getJSONObject("ask").getInt("sum");
                                    mAskNumb1.setText("+"+mAskNumb);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(MyContributionActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private TextView mSendGiftNumb;
    private TextView mSendZanNumb;
    private RelativeLayout mOthersrl;
    private RelativeLayout mOthersRl;
    private ImageView mIvarrow;
    private boolean isShow;
    private PopupWindow mPopuwindow;
    private TextView mOthersNumb;
    private TextView mAskNumb1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_my_contribution,null);
        // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(30, 144, 255));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        mIVBack = (ImageView) findViewById(R.id.iv_back);
        mRLMySendGift = (RelativeLayout) findViewById(R.id.rl_my_send_gift);
        mRLMyPraise = (RelativeLayout) findViewById(R.id.rl_my_praise);
        mTVMyContribution = (TextView) findViewById(R.id.tv_my_contribution);
        mSendGiftNumb = (TextView) findViewById(R.id.my_sendgift_numb);
        mSendZanNumb = (TextView) findViewById(R.id.my_zan_numb);
        mOthersNumb = (TextView) findViewById(R.id.my_others_numb);
        mOthersRl = (RelativeLayout) findViewById(R.id.rl_my_others);
        mIvarrow = (ImageView) findViewById(R.id.iv_my_others_arrow);
        //弹出popuwindow
        View view=   View.inflate(this,R.layout.other_popu_listview_item,null);
        mAskNumb1 = (TextView) view.findViewById(R.id.tv_my_others_ask);
        mPopuwindow = new PopupWindow(view, WindowManager.LayoutParams.MATCH_PARENT,
                                      WindowManager.LayoutParams.WRAP_CONTENT);
        mPopuwindow.setBackgroundDrawable(null);
    }
    @Override
    protected void addEvent()
    {
        mIVBack.setOnClickListener(this);
        mRLMySendGift.setOnClickListener(this);
        mRLMyPraise.setOnClickListener(this);
        mOthersRl.setOnClickListener(this);
    }
    @Override
    protected void settingDo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getMyContributionList(MyContributionActivity.this, YNCommonConfig.GET_MY_CONTRIBUTION_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.GET_MY_CONTRIBUTION_FLAG,false);
            }
        });
    }
    @Override
    public void onClick(View v)
    {
        Intent mIntent;
        switch (v.getId())
        {
            case R.id.iv_back:
                finish();
                break;
            //跳转我送出的礼物
            case R.id.rl_my_send_gift:
                mIntent = new Intent(this, MySendGiftActivity.class);
                mIntent.putExtra(YNCommonConfig.CONTRIBUTIN_NUMB_FLAG,mGiftNumb);
                mIntent.putExtra(YNCommonConfig.TITLE, 0);
                startActivity(mIntent);
                break;

            //跳转我的点赞
            case R.id.rl_my_praise:
                mIntent = new Intent(this, MySendGiftActivity.class);
                mIntent.putExtra(YNCommonConfig.CONTRIBUTIN_NUMB_FLAG,mZanNumb);
                mIntent.putExtra(YNCommonConfig.TITLE, 1);
                startActivity(mIntent);
                break;
            case R.id.rl_my_others:
                isShow=!isShow;
                if(isShow){
                    mPopuwindow.showAsDropDown(mOthersRl);
                    mIvarrow.setImageResource(R.drawable.arrow_up);
                }else{
                    mIvarrow.setImageResource(R.drawable.arrow_down);
                    mPopuwindow.dismiss();
                }
                break;
        }
    }

    @Override
    public void loginRefreshUI() {

    }
    @Override
    public void unLoginRefreshUI() {

    }

}
