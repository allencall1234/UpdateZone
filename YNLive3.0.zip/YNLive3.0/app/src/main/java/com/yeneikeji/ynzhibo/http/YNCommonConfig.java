package com.yeneikeji.ynzhibo.http;

/**
 *  常量
 * Created by Administrator on 2016/8/5.
 */
public class YNCommonConfig
{

    public static String version                        = ""; // 版本号
    public static       int    ScreenWidth              = 0; // 分辨率宽
    public static       int    ScreenHeight             = 0; // 分辨率高
    public static double screenSize;

    public static final String SDCARD_CACHE = "com.ynkj/files/"; // 文件sdk缓存

    /** 主界面tab按钮标识 */
    public static final int BOTTOM_TABLE_ONE = 0;
    public static final int BOTTOM_TABLE_TWO = 1;
    public static final int BOTTOM_TABLE_THREE = 2;
    public static final int BOTTOM_TABLE_FOUR = 3;

    /** 百度云直播播放AK */
    public static final String AK = "d913bf52f6494265a19eadf460e7aa3a";

    /** 融云AppKey */
    public static final String RONG_CLOUD_APP_KEY = "n19jmcy5ndd49";

    /** mob短信 AppKey */
    public static final String MOB_APP_KEY = "1bae823624743";
    public static final String MOB_APP_SECRET = "26c6857ca1932c986688f31d45ec1973";

    /** webchinese短信 AppKey Uid*/
    public static final String WEB_CHINESE_KEY = "335e58ff9e30319066d4";
    public static final String WEB_CHINESE_UID = "业内科技";

    /** QQ平台的密钥 */
    public static final String QQ_APP_ID = "1105984707";
    public static final String QQ_APP_KEY = "j3ipUpMR0HIYFZR0";
    //    public static final String QQ_APP_ID = "1106041772";
    //    public static final String QQ_APP_KEY = "WVsqIcCMw6nE8OC0";

    /** 微信开放平台的密钥 */
    public static final String WX_APP_ID = "wx2fe1f8339f18cb97";
    public static final String WX_APP_SECRET = "7c06d14a3e1eb2d9e5b7c34f9a7085f6";

    /** 支付宝支付业务：入参app_id */
    public static final String ZFB_APP_ID = "";
    /** 支付宝账户登录授权业务：入参pid值 */
    public static final String ZFB_PID = "";
    /** 支付宝账户登录授权业务：入参target_id值 */
    public static final String ZFB_TARGET_ID = "";

    public static final String LIVE_ADDRESS_HEAD = "rtmp://push.livestream.gupiaoask.com/YNLive/";

    /** 腾讯bugly App Id */
    public static final String BUGLY_APP_ID = "6a848985b1";

    /** 上线所需key Start*/
    /** 融云AppKey */
    //    public static final String RONG_CLOUD_APP_KEY = "n19jmcy5ndd49";
    /** 上线所需key End*/

    //    public static String SHARE_URL = "http://上线域名.roomShare.html";
    //    public static String SHARE_TEXT = "欢迎使用【友盟+】社会化组件U-Share，SDK包最小，集成成本最低，助力您的产品开发、运营与推广";
    public static String SHARE_TITLE = "【友盟+】社会化组件U-Share";

    // 网络请求标识
    public static final int LOADING_FAIL = 0x01;

    public static final int NOT_INDICATOR = 0;
    public static final int CIRCLE_INDICATOR = 1;
    public static final int NUM_INDICATOR = 2;
    public static final int NUM_INDICATOR_TITLE = 3;
    public static final int CIRCLE_INDICATOR_TITLE = 4;
    public static final int LEFT = 5;
    public static final int CENTER = 6;
    public static final int RIGHT = 7;

    public static final int INDICATOR_SIZE = 8;
    public static final int PADDING_SIZE = 5;
    public static final int TIME = 2000;
    public static final boolean IS_AUTO_PLAY = true;

    /** 请求CODE */
    public final static int CHANNELREQUEST = 1;
    /** 调整返回的RESULTCODE */
    public final static int CHANNELRESULT = 10;

    public static final int TAKE_PHOTO = 0x01; //拍照
    public static final int CHOOSE_IMAGES = 0x02; //从相册中选择
    public static final int CUT_IMAGES = 0x03;// 裁剪

    public static final String IS_READED = "1";
    public static final String IS_NO_READ = "0";
    public static final String VERIFY_MESSAGE = "8";// 普通房间邀请房管
    public static final String NOTIFYCATION_MESSAGE ="9";
    public static final String SYSTEM_MESSAGE = "5";
    public static final String FOLLOW_MESSAGE ="3";
    public static final String AUTHENTICATION_MESSAGE = "12";
    public static final String ROOM_OWNER_MESSAGE = "13";// 多通道房间邀请子房主
    public static final String MULTICHANNELROOM_INVITATION_MANAGER_MSG = "15";// 多通道房间邀请房管
    public static final String ROOM_CHILD_INVITATION_MANAGER_MESSAGE = "14";

    // temp user id
    public static final String TEMP_USERID = "43";

    public static final int ACTIVITY_RESULT = 0x05;

    /** 刷新加载更多标识 */
    public static final int ON_REFRESH = 0x01;
    public static final int LOAD_MORE = 0x02;

    /**保存头像路径 */
    public static final String PHOTO_DIR = "com.ynkj.zhibo";
    public static final String HEAD_PHOTO_NAME = "head.png";
    public static final String COVER_PHOTO_NAME = "cover.png";

    /**传递电话号码标识 */
    public static final String PHONE_NUMBER = "phone_number";

    /**设置中弹出框内容标识 */
    public static final int CACHE = 0x03;
    public static final int QUIT = 0x04;

    public static final String ENABLE_NOTIFICATION_KEY = "enable_notication";

    /** 忘记密码标识 */
    public static final String FORGET_PASS = "forget_pass";

    /** 传递标题标识 */
    public static final String TITLE = "title";

    /** 传递直播间主页和主播个人主页标识 */
    public static final String HOME_PAGE_FLAG = "home_page";

    /** 传递position */
    public static final String POSITION = "position";

    /** 传递对象标识 */
    public static final String OBJECT = "object";

    /** 传递用户userid标识 */
    public static final String USER_ID = "userId";

    /** 界面中某些控件的显示隐藏标识 **/
    public static final String ISSHOW = "isShow";

    /** 编辑评论界面中显示提示信息回复/评论某人标识 */
    public static final String ISCOMMENT = "comment_reply";

    /** 滚动数字所需高度 */
    public static int mWinheight;

    /** 传递协议标识 */
    public static final String AGREEMENT = "agreement";

    /** 标识是有哪个界面进入到登录界面 */
    public static final String INTO_LOGIN_FLAG = "login_flag";

    /** 直播弹幕、礼物标识 */
    public static final String CMD_GIFT = "cmd_gift";
    public static final String EXTRA_IS_BARRAGE_MSG = "is_barrage_msg";

    /** 关注界面标识 */
    public static final String FRAGMENT_FLAG = "FragmentFlag";
    /** 跳转到视频选择页面的标识 */
    public static final String SELECT_VIDEO_FLAG = "comeFrom";
    /** 发现首页跳转页面的标识 */
    public static final String Artical_EXCITING_FLAG = "comeFrom";
    /** 贡献值跳转标识 */
    public static final String CONTRIBUTIN_NUMB_FLAG ="contributionNb" ;
    /** 选择上传视频的请求码 */
    public static final int SELECT_VEDIO_REQUES_CODE = 200;
    /** 发送短信验证码标识 */
    public static final int CODE_ING = 1;   //已发送，倒计时
    public static final int CODE_REPEAT = 2;  //重新发送
    public static final int SMSDDK_HANDLER = 3;  //短信回调
    public static int getVerificationCodeTime = 60;//倒计时60s

    /** 设置极光推送别名handler标识 */
    public static final int SET_JPUSH_ALIAS = 1001;
    public static final int SET_JPUSH_TAG = 1002;

    /** 极光推送消息字段名称 */
    //    public static final String KEY_TITLE = "title";
    public static final String KEY_MESSAGE = "message";
    public static final String KEY_EXTRAS = "extras";
    /** 登录成功后发送的本地广播标识 */
    public static final String UPDATE_USER_STATE_FLAG = "android.intent.action.UPDATE_USER_STATE_BROADCAST";

    /** 下麦发送的本地广播标识 */
    public static final String UNDER_WHEAT_FLAG = "android.intent.action.UPDATE_USER_STATE_BROADCAST";

    public static final String MPUBLIC_KRY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIxObC92Pn9A4edwQFpcBNAde7" +
            "lxSU+NvvYMEBr+mccb2JOkRsukGQ0eFbRldpdGeCgtjCa/ZRRAiWGeStHCwZ1/vU" +
            "thM+DQCggsvJvXuyYD5sY2eR7MnFB/kwKzo0lypq8f6/V7KCwa0PTOuU3tv9eoGB" +
            "4cL3gRnZSCt00hsd3QIDAQAB";
    public static final String MPRIVATE_KRY ="MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMjE5sL3Y+f0Dh53\n" +
            "BAWlwE0B17uXFJT42+9gwQGv6ZxxvYk6RGy6QZDR4VtGV2l0Z4KC2MJr9lFECJYZ\n" +
            "5K0cLBnX+9S2Ez4NAKCCy8m9e7JgPmxjZ5HsycUH+TArOjSXKmrx/r9XsoLBrQ9M\n" +
            "65Te2/16gYHhwveBGdlIK3TSGx3dAgMBAAECgYBduFTElHmFsM7ad9Jf1IUVLZQI\n" +
            "VLld5WG9t9vBLt4NkqbYpWOFodizgtYBJq/tYVJkgTIwZ/d+7hRYBVRTXwBSaBxX\n" +
            "b02P+pr8EYuBJmUKDEzJKDrSy0xCdUkfCTwpJkAvkk79i3zI5AJRqH2hYsus4rnW\n" +
            "0Gsm40+AptgDQDyxIQJBAO+vluYwdRciLc5o93UPPbGw4v3IzRETR2jg0iQSjXhT\n" +
            "oH5F9rwu78az/LSJbZER23nD3viKkV+QxG3ojUUhb6kCQQDWbzTaXM/nhtBA7c6P \n" +
            "XYg1skBYRgS/EalMJ+MZoS90pjmQy7AglhsesaFLi/PN1+0DibecceJQxwvYhgxG\n" +
            "gm0VAkAIIj1MsnhGwLItPwKmxk2hqg8J7baHzc+uj3KSJs8GNlBL+LPWzwD0DUeW\n" +
            "GNPPCHwaNbtrU8h7Jb6EvE+O+QOBAkBl3oK/UeQ622LH1bGRjh+NUtcamHjcxGkn\n" +
            "ErPikx5WTjl+viU39deAZ2Z220/BdFjWm3As1DVtpoHMJTJjtMZZAkEAgSm7s/CB\n" +
            "1VX3NFEQIWow3We+URw7RyohgWET7hdYQ75fWyILjTYi93IVghZRCZ/qbXO5kVUc\n" +
            "JJSTKLgr+/JVdw==";

    /** 各个界面中handle标识 */
    public static final int GET_PULL_LIVE_FLAG = 0x09;
    public static final int GET_PUSH_LIVE_FLAG = 0x10;
    public static final int RELEASE_DYNAMIC_FLAG = 0x11;
    public static final int GET_HOME_PAGE_DYNAMIC_FLAG = 0x12;
    public static final int GET_HOME_PAGE_LIVE_LIST_FLAG = 0x13;
    public static final int GET_MY_ATTENTION_USER_DYNAMIC_LIST_FLAG = 0x14;
    public static final int COMMUNITY_USER_THUMB_FLAG = 0x15;
    public static final int COMMUNITY_USER_COMMENT_FLAG = 0x16;
    public static final int ATTENTION_USER_FLAG = 0x17;
    public static final int GET_PUSH_ADDRESS_FLAG = 0x18;
    public static final int STOP_LIVE_FLAG = 0x19;
    public static final int USER_LOGIN_FLAG = 0x20;
    public static final int USER_REGISTER_FLAG = 0x21;
    public static final int USER_REGISTER_NEXT_STEP_FLAG = 0x22;
    public static final int USER_FORGET_PASSWORD_FLAG = 0x23;
    public static final int USER_RESET_PASSWORD_FLAG = 0x24;
    public static final int USER_UPDATE_PASSWORD_FLAG = 0x25;
    public static final int EDIT_PERSONAL_INFO_FLAG = 0x26;
    public static final int CANCEL_ATTENTION_USER_FLAG = 0x27;
    public static final int PERSONAL_DYNAMIC_HOME_PAGE_FLAG = 0x28;
    public static final int MY_FANS_LIST_FLAG = 0x29;
    public static final int DELETE_PERSONAL_DYNAMIC_FLAG = 0x30;
    public static final int GET_USER_COMMENTS_LIST_FLAG = 0x31;
    public static final int GET_USER_THUMB_LIST_FLAG = 0x32;
    public static final int MY_ATTENTION_LIST_FLAG = 0x33;
    public static final int FEED_BACK_FLAG = 0x34;
    public static final int USER_LIVE_AUTHENTICATION_FLAG = 0x35;
    public static final int GET_USER_STATUS_FLAG = 0x37;
    public static final int UPDATE_LIVE_HOST_INFO_FLAG = 0x38;
    public static final int GET_RONG_CLOUD_TOKEN_FLAG = 0x39;
    public static final int ADD_ROOM_MANAGE_FLAG = 0x40;
    public static final int DELETE_ROOM_MANAGE_FLAG = 0x41;
    public static final int GAG_CHAT_ROOM_USER_FLAG = 0x42;
    public static final int CANCEL_GAG_CHAT_ROOM_USER_FLAG = 0x43;
    public static final int BLOCK_CHAT_ROOM_USER_FLAG = 0x44;
    public static final int UNBBLOCK_CHAT_ROOM_USER_FLAG = 0x45;
    public static final int QUERY_CHAT_ROOM_USER_LIST_FLAG = 0x46;
    public static final int QUERY_BE_BLOCKED_USER_FLAG = 0x47;
    public static final int GET_CHAT_ROOM_USER_INFO_FLAG = 0x48;
    public static final int GET_CHAT_ROOM_MYSELF_INFO_FLAG = 0x49;
    public static final int REPORT_USER_FLAG = 0x50;
    public static final int COMMUNITY_USER_DELETE_COMMENT_FLAG = 0x51;
    public static final int GET_WEB_CHINESE_SMS_CODE_FLAG = 0x52;
    public static final int USER_EXIT_WATCH_LIVE_FLAG = 0x53;
    public static final int COMMUNITY_COMMENTS_LIST_SORT_FLAG = 0x54;
    public static final int COMMUNITY_COMMENTS_LIST_THUMB_FLAG = 0x55;
    public static final int MY_COMMENTS_FLAG = 0x55;
    public static final int QUERY_CHAT_ROOM_MANAGER_INFO_FLAG = 0x56;
    public static final int GET_CONTRIBUTION_VALUE_TOP_TWENTY_FLAG = 0x57;
    public static final int GET_CONTRIBUTION_VALUE_LIST_FLAG = 0x58;
    public static final int APP_EXIT_FLAG = 0x59;
    public static final int LIVE_SEARCH_FLAG = 0x60;
    public static final int MY_RECORD_VIDEO_LIST_FLAG = 0x61;
    public static final int UPDATE_STREAMING_CODE_FLAG = 0x62;
    public static final int SET_LIVE_ROOM_PASS_FLAG = 0x63;
    public static final int LIVE_ROOM_PAY_FLAG = 0x64;
    public static final int LIVE_ROOM_SEND_GIFT_FLAG = 0x65;
    public static final int WATCH_LIVE_VALIDATION_PASS_FLAG = 0x66;
    public static final int WATCH_LIVE_VALIDATION_PAY_COIN_FLAG = 0x67;
    public static final int GET_CURRENT_GOLD_COIN_FLAG = 0x68;
    public static final int GET_MY_WEALTH_FLAG = 0x69;
    public static final int GET_MY_CONTRIBUTION_FLAG = 0x70 ;
    public static final int OPEN_OR_CLOSE_PUSH_FLAG = 0x71 ;
    public static final int GET_MY_MONTNWEALTH_FLAG = 0x72 ;
    public static final int GET_TOTALL_WEALTH_FLAG = 0x73 ;
    public static final int GET_MY_COMMENT_THUMB_MESSAGE_FLAG = 0x74;
    public static final int GET_MY_SYSTEM_MESSAGE_FLAG = 0x75;
    public static final int GET_MEFRAGMENT_CONTRIBUTION_VALUE_LIST_FLAG = 0x76;
    public static final int GET_FIND_FIRST_PAGE_FLAG = 0x77;
    public static final int GET_FIND_PERSONAL_HOME_FLAG = 0x78;
    public static final int GET_ARTICAL_DETAILS_FLAG = 0x79;
    public static final int LIVE_ROOM_ASK_FLAG = 0x80;
    public static final int GET_LIVE_ROOM_ASK_LIST_FLAG = 0X81;
    public static final int GET_LIVE_ROOM_NOTE_FLAG = 0X82;
    public static final int GET_LIVE_ROOM_NOTICE_LIST_FLAG = 0X83;
    public static final int GET_ARTICAL_EVALUATE_FLAG = 0x84;
    public static final int GET_ARTICAL_PUBLISH_FLAG = 0x85;

    public static final int BUY_ARTICLE_FLAG = 0x86;
    public static final int GET_FIND_PERSONAL_HOME_BUYED_FLAG = 0x87 ;
    public static final int GET_LIVE_HOST_ASK_LIST_FLAG = 0x88;
    public static final int GET_MY_LIVE_VIDEOLIST_FLAG = 0x89 ;
    public static final int RELEASE_LIVE_NOTICE_FLAG = 0x90;
    public static final int GET_MY_LIVE_REPORTED_FLAG = 0x91 ;
    public static final int LIVE_HOST_REPLY_ASK_FLAG = 0x92 ;
    public static final int LIVE_HOST_READ_ASK_FLAG = 0x93;
    public static final int USER_AGREE_BECOMING_MANAGER_FLAG = 0x94;
    public static final int LIVE_EVALUATE_FLAG = 0x95;
    public static final int GET_HOME_PAGE_VIDEO_LIST_FLAG = 0x96;
    public static final int GET_HOME_PAGE_AUDIO_LIST_FLAG = 0x97;
    public static final int VOICE_PUBLISH_FLAG = 0x98;
    public static final int VOICE_DETAILS_FLAG = 0x99;
    public static final int GET_LIVE_HOST_INFO_FLAG = 0x100;
    public static final int RELEASE_VIDEO_FLAG = 0x101;
    public static final int BIG_SHOT_FLAG = 0x102;
    public static final int MARKET_INTERPRET_FLAG = 0x103;
    public static final int VOICE_VOLUATE_FLAG = 0x104;
    public static final int VOICE_POINT_FLAG = 0x105;
    public static final int GET_DELETE_MY_SYSTEM_MESSAGE_FLAG = 0x106;
    public static final int GET_IS_READ_MY_SYSTEM_MESSAGE_FLAG = 0X107;
    public static final int LIVE_HOST_GET_WEALTH_SORT_FLAG = 0x108;
    public static final int GET_LIVE_ROOM_PERSONAL_NUM_FLAG = 0x109;
    public static final int GET_MINE_GOLD_COIN_FLAG = 0x110;
    public static final int GET_LIVE_ROOM_TAKE_PART_IN_FLAG = 0X111;
    public static final int GET_SETUP_PUSH_FLAGE = 0X112;
    public static final int GET_SETUP_PUSH_OPEN_OR_CLOSE_FLAG = 0X113;
    public static final int UPDATE_LIVE_ROOM_USER_STATE_FLAG = 0x114;
    public static final int ORDER_GOODS_FLAG = 0x115;
    public static final int GET_SHARE_ADDRESS_FLAG = 0x116;
    public static final int GET_CALCULATE_INCOME_FLAG = 0x117;
    public static final int GET_SAVE_BANKID_FLAG = 0x118;
    public static final int BIND_PHONE_FLAG = 0x119;

    public static final int GET_TI_XIAN_FLAG = 0x120;
    public static final int GET_WAIT_CALCULATE_FLAG = 0x121;
    public static final int GET_HAVE_CALCULATE_FLAG = 0x122;
    public static final int GET_EDIT_BANKID_FLAG = 0x123;
    public static final int GET_ARTICAL_REPUBLISH_FLAG = 0x124;

    /** 查询多通道房间状态标识 */
    public static final int QUERY_MULTICHANNEL_LIVE_STATE_FLAG = 0x125;

    /** 申请开通多通道房间状态标识 */
    public static final int APPLY_MULTICHANNEL_LIVE_FLAG = 0x126;

    /** 进入主房间标识 */
    public static final int ENTER_INTO_MAIN_ROOM_FLAG = 0x127;

    /** 搜索主播标识 */
    public static final int SEARCH_ANCHOR_FLAG = 0x128;

    /** 多通道房间邀请房管标识 */
    public static final int MULTICHANNEL_ROOM_INVITATION_MANAGER_FLAG = 0x129;

    /** 多通道房间接受、拒绝房管邀请标识 */
    public static final int AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG = 0x130;

    /** 邀请子房间的房主标识 */
    public static final int INVITATION_CHILD_ROOM_OWNER_FLAG = 0x131;

    /** 接受、拒绝子房间的房主邀请标识 */
    public static final int AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG = 0x132;

    /** 查询子房间列表标识 */
    public static final int QUERY_CHILD_ROOM_LIST_FLAG = 0x133;

    /** 副房主、房管进入多通道房间获取信息标识 */
    public static final int DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_FLAG = 0x134;

    /** 接受、拒绝主播认证邀请标识 */
    //    public static final int AGREE_AUTHENTICATION_INVITATION_FLAG = 0x134;

    /** 进入主房间解除职务 */
    public static final int ENTER_MAIN_ROOM_UNEMPLOYE_FLAG = 0x135;

    /** 进入主房间提拔副房主 */
    public static final int ENTER_MAIN_ROOM_UPEMPLOYE_FLAG = 0x136;

    /** 进入主房间降级 */
    public static final int ENTER_MAIN_ROOM_DOWNEMPLOYE_FLAG = 0x137;

    /** 进入主房间提拔为房主 */
    public static final int ENTER_MAIN_ROOM_UP_ROOMMANAGER_FLAG = 0x138;

    /** 解除房主职务 */
    public static final int ENTER_MAIN_ROOM_UNEMPLOYE_ROOMMANAGER_FLAG = 0x139;

    /** 降级房主职务 */
    public static final int ENTER_MAIN_ROOM_DOWNEMPLOYE_ROOMMANAGER_FLAG = 0x140;

    /** 主播推流成功后请求标识 */
    public static final int PUSH_STREAM_SUCCESS_REQUEST_FLAG = 0x141;

    /** 转播失败后切换视频标识 */
    public static final int LIVE_ROOM_EXCHANGE_FLAG = 0x142;

    /** 解除房主职务 */
    public static final int DELETE_ROOM_DOWNEMPLOYE_ROOMMANAGER_FLAG = 0x143;

    /** 降职房主职务 */
    public static final int DOWN_ROOM_DOWNEMPLOYE_ROOMMANAGER_FLAG = 0x144;

    /** 进入子房间解绑标识 */
    public static final int ENTER_CHILD_ROOM_UNBIND_FLAG = 0x144;

    /** 多通道房间排麦标识 */
    public static final int MULTICHANNEL_ROWS_WHEAT_FLAG = 0x145;

    /** 多通道房间主播信息、房管列表、排麦列表 */
    public static final int MULTICHANNEL_ROOM_USER_INFO_FLAG = 0x146;

    /** 多通道房间抢麦标识 */
    public static final int MULTICHANNEL_ROOM_GRAB_WHEAT_FLAG = 0x147;

    /** 多通道房间下麦标识 **/
    public static final int MULTICHANNEL_UNDER_WHEAT_FLAG = 0x148;

    /**
     * equipment标识是移动端直播还是PC端直播
     * 1代表手机，0代表电脑
     */

    /** 直播地址需要截取的位数 */
    //    public static final int INTERCEPTION_NUMBER = 37;

    /** 社区功能中每一页显示的数量 */
    public static final int NUMBER_EACH_PAGE = 10;

    /** 直播状态 直播状态：rest:休息中 normal:普通的直播中 local:直播中加密 pay:直播中付费 */

    public static final String LIVE_STATUS_REST = "rest";
    public static final String LIVE_STATUS_NORMAL = "normal";
    public static final String LIVE_STATUS_LOCAL = "local";
    public static final String LIVE_STATUS_PAY = "pay";
    public static final String LIVE_STATUS_READY = "READY";
    public static final String LIVE_STATUS_ONGOING = "ONGOING";
    public static final String LIVE_STATUS_PAUSED = "PAUSED";
    public static final String SP_POSITION = "position";

    public static final String IP_ADDRESS = "https://www.gupiaoask.com/yeneilive/index.php/";

    public static final String AGREEMENT_ADDRESS = "https://www.gupiaoask.com/yeneilive";

    /** 用户登录接口地址 */
    public static final String USER_LOGIN_URL = IP_ADDRESS + "home/user/login";

    /** 用户注册接口 */
    public static final String USER_REGISTER_URL = IP_ADDRESS + "home/user/register";

    /** 用户注册验证手机号是否注册接口 */
    public static final String USER_REGISTER_NEXT_URL = IP_ADDRESS + "home/user/next";

    /** 用户获取验证码(webchinese平台) */
    public static final String GET_SMS_CODE_URL = "http://utf8.sms.webchinese.cn/";

    /** 用户忘记密码接口 */
    public static final String USER_FORGET_PASSWORD_URL = IP_ADDRESS + "home/user/forget";

    /** 用户重置密码接口 */
    public static final String USER_RESET_PASSWORD_URL = IP_ADDRESS + "home/user/editnewpwd";

    /** 用户修改密码接口 */
    public static final String USER_UPDATE_PASSWORD_URL = IP_ADDRESS + "home/user/editpwd";

    /** 用户个人资料上传接口地址 */
    public static final String UPLOAD_USER_INFO_URL = IP_ADDRESS + "home/user/mymessage";

    /** 用户直播身份认证界面 */
    public static final String USER_LIVE_AUTHENTICATION_URL = IP_ADDRESS + "home/user/upload_idcard";

    /** 我要直播时用户主播身份信息接口 */
    public static final String GET_USER_STATU_URL = IP_ADDRESS + "home/user/mylive";

    /** 获取立即开播的推流地址 */
    public static final String GET_PUSH_ADDRESS_URL = IP_ADDRESS + "home/user/live";

    /** 立即开播修改直播选择信息 */
    public static final String UPDATE_LIVE_INFO_URL = IP_ADDRESS + "home/user/editLive";

    /** 停止直播接口地址 */
    public static final String STOP_LIVE_URL = IP_ADDRESS + "home/user/stopLive";

    /** 获取直播首页列表以及分类列表 */
    public static final String GET_HOME_PAGE_LIVE_LIST_URL = IP_ADDRESS + "home/user/liveIndex";

    /** 社区中发布动态接口 */
    public static final String RELEASE_DYNAMIC_URL = IP_ADDRESS + "home/user/publish";

    /** 社区中首页获取动态接口 */
    public static final String GET_HOME_PAGE_DYNAMIC_URL = IP_ADDRESS + "home/user/community";

    /** 社区中首页加载更多动态接口 */
    public static final String HOME_PAGE_LOADING_MORE_DYNAMIC_URL = IP_ADDRESS + "home/user/more";

    /** 社区中我关注的用户的动态列表 */
    public static final String GET_ATTENTION_USER_DYNAMIC_LIST_URL = IP_ADDRESS + "home/user/mydynamic";

    /** 社区中点赞接口 */
    public static final String COMMUNITY_USER_THUMB_URL = IP_ADDRESS + "home/user/zan";

    /** 社区中评论接口 */
    public static final String COMMUNITY_USER_COMMENT_URL = IP_ADDRESS + "home/user/comment";

    /** 社区中删除评论接口 */
    public static final String COMMUNITY_USER_DELETE_COMMENT_URL = IP_ADDRESS + "home/user/deleteComment";

    /** 关注用户接口地址 */
    public static final String ATTENTION_USER_URL = IP_ADDRESS + "home/user/attention";

    /** 取消关注用户接口地址 */
    public static final String CANCEL_ATTENTION_USER_URL = IP_ADDRESS + "home/user/deleteattention";
    /** 我的界面金币充值地址 */
    public static final String GET_GOLD_COIN_URL = IP_ADDRESS + "home/user/charge";
    /** 我的关注列表接口地址 */
    public static final String GET_MY_ATTENTION_LIST_URL = IP_ADDRESS + "home/user/myattention";

    /** 我的粉丝列表接口地址 */
    public static final String GET_MY_FANS_LIST_URL = IP_ADDRESS + "home/user/myFuns";

    /** 个人动态主页接口地址 */
    public static final String PERSONAL_DYNAMIC_HOME_PAGE_URL = IP_ADDRESS + "home/user/personal";

    /** 删除个人动态接口地址 */
    public static final String DELETE_PERSONAL_DYNAMIC_URL = IP_ADDRESS + "home/user/deleteCommunity";

    /** 社区动态正文中评论列表接口地址 */
    public static final String GET_USER_COMMENT_LIST_URL = IP_ADDRESS + "home/user/commentList";

    /** 社区动态正文中点赞列表接口地址 */
    public static final String GET_USER_THUMB_LIST_URL = IP_ADDRESS + "home/user/zanList";

    /** 意见反馈接口地址 */
    public static final String FEED_BACK_URL = IP_ADDRESS + "home/user/feedback";

    /** 用户注册协议接口地址 */
    public static final String USER_REGISTER_AGREEMENT_URL = IP_ADDRESS + "home/index/user_agreement.html";

    /** 直播协议接口地址 */
    public static final String USER_LIVE_AGREEMENT_URL = IP_ADDRESS + "home/index/anchor_agreement.html";

    /** 获取融云服务器token接口地址 */
    public static final String GET_RONG_CLOUD_TOKEN_URL = IP_ADDRESS + "home/RongCloud/getToken";

    /** 直播间参与人数统计接口 */
    public static final String LIVE_ROOM_TAKE_PART_IN_URL = IP_ADDRESS + "home/RongCloud/takepartin";
    /** 用户登录成功后刷新直播间用户状态 */
    public static final String UPDATE_LIVE_ROOM_USER_STATE_URL = IP_ADDRESS + "home/user/updatestatus";

    /** 获取聊天室用户详情 */
    public static final String GET_CHAT_ROOM_USER_INFO_URL = IP_ADDRESS + "home/RongCloud/detail";

    /** 获取聊天室中我自己的用户信息 */
    public static final String GET_CHAT_ROOM_MYSELF_INFO_URL = IP_ADDRESS + "home/RongCloud/detail";

    /** 邀请房管接口地址 */
    public static final String ADD_ROOM_MANAGE_URL = IP_ADDRESS + "home/RongCloud/editManage";

    /** 删除房管接口地址 */
    public static final String DELETE_ROOM_MANAGE_URL = IP_ADDRESS + "home/RongCloud/deletemanage";

    /** 禁言用户接口地址 */
    public static final String GAG_CHAT_ROOM_USER_URL = IP_ADDRESS + "home/RongCloud/addGagUser";

    /** 解除禁言接口地址 */
    public static final String CANCEL_GAG_CHAT_ROOM_USER_URL = IP_ADDRESS + "home/RongCloud/rollbackGagUser";

    /** 封禁用户(踢出聊天室)接口地址 */
    public static final String BLOCK_CHAT_ROOM_USER_URL = IP_ADDRESS + "home/RongCloud/Block";

    /** 解除封禁接口地址 */
    public static final String UNBLOCK_CHAT_ROOM_USER_URL = IP_ADDRESS + "home/RongCloud/unBlock";

    /** 查询聊天室中被封禁的用户接口地址 */
    public static final String QUERY_BE_BLOCKED_USER_URL = IP_ADDRESS + "home/RongCloud/queryBlock";

    /** 查询聊天室成员信息接口地址 */
    public static final String QUERY_CHAT_ROOM_USER_LIST_URL = IP_ADDRESS + "home/RongCloud/queryUser";

    /** 举报接口地址 */
    public static final String REPORT_USER_URL = IP_ADDRESS + "home/user/Jbao";

    /** 用户退出直播观看 */
    public static final String USER_EXIT_WATCH_LIVE_URL = IP_ADDRESS + "home/user/exit_live";

    /** 动态正文中评论排序 */
    public static final String USER_COMMENTS_LIST_SORT_URL = IP_ADDRESS + "home/user/sort";

    /** 社区评论列表点赞取消点赞 */
    public static final String COMMUNITY_COMMENTS_LIST_THUMB_URL = IP_ADDRESS + "home/user/zan_comment";

    /** 与我相关的评论接口 */
    public static final String MY_COMMENTS_URL = IP_ADDRESS + "home/user/relate";

    /** 查询聊天室房管信息 */
    public static final String QUERY_CHAT_ROOM_MANAGER_INFO_URL = IP_ADDRESS + "home/RongCloud/selectManage";

    /** 直播间获取贡献值前20名用户列表接口 */
    public static final String GET_CONTRIBUTION_VALUE_TOP_TWENTY_URL = IP_ADDRESS + "home/user/liveList";

    /** 直播间获取排行榜(周榜、总榜) */
    public static final String GET_CONTRIBUTION_VALUE_LIST_URL = IP_ADDRESS + "home/user/liveList";

    /** 直播应用退出接口 */
    public static final String APP_EXIT_URL = IP_ADDRESS + "home/user/logout";

    /** 直播搜索接口 */
    public static final String LIVE_SEARCH_URL = IP_ADDRESS + "home/user/search";

    /** 我的录制视频列表的接口 */
    public static final String MY_RECORD_VIDEO_LIST_URL = IP_ADDRESS + "home/user/record";

    /** 修改串流码接口 */
    public static final String UPDATE_STREAMING_CODE_URL = IP_ADDRESS + "home/user/editcode";

    /** 设置直播间密码接口 */
    public static final String SET_LIVE_ROOM_PASS_URL = IP_ADDRESS + "home/user/pwd";

    /** 设置直播间收费接口 */
    public static final String LIVE_ROOM_PAY_URL = IP_ADDRESS + "home/user/fee";

    /** 送礼物接口 */
    public static final String LIVE_ROOM_SEND_GIFT_URL = IP_ADDRESS + "home/user/gift";

    /** 观看直播加密验证接口 */
    public static final String WATCH_LIVE_VALIDATION_PASS_URL = IP_ADDRESS + "home/user/livepwd";

    /** 观看直播验证收费接口 */
    public static final String WATCH_LIVE_VALIDATION_PAY_COIN_URL = IP_ADDRESS + "home/user/liveFee";

    /** 获取当前金币 */
    public static final String GET_CURRENT_GOLD_COIN_URL = IP_ADDRESS + "home/user/current";

    /****我的财富接口****/
    public static final String GET_MYWEALTH_INCOMING_URL = IP_ADDRESS + "home/user/mywealth";
    /***当月财富接口****/
    public static final String GET_MONTHWEALTH_INCOMING_URL = IP_ADDRESS+"home/user/currentMonth" ;
    /****待结算接口列表****/
    public static final String GET_WAIT_CALCULATE_URL = IP_ADDRESS + "home/user/jslist";
    /****财富结算接口****/
    public static final String GET_CALCULATE_INCOMING_URL = IP_ADDRESS + "home/user/jsuan";
    /****保存银行卡信息接口****/
    public static final String GET_SAVE_BANKCARD_INFO_URL = IP_ADDRESS + "home/user/bank";
    /****修改银行卡信息接口****/
    public static final String GET_EDIT_BANKCARD_INFO_URL = IP_ADDRESS + "home/user/editBand";
    /****保存银行卡信息接口****/
    public static final String GET_TI_XIAN_URL = IP_ADDRESS + "home/user/txian";
    /** 我的贡献接口地址 */
    public static final String GET_MY_CONTRIBUTION_URL = IP_ADDRESS + "home/user/myContribution";

    /** 打开或关闭推送通知接口地址 */
    public static final String OPEN_OR_CLOSE_PUSH_URL = IP_ADDRESS + "home/user/sendStatus";

    /** 我的消息里面的评论和赞接口地址 */
    public static final String MY_COMMENT_THUMB_MESSAGE_URL = IP_ADDRESS + "home/user/commentZan";

    /** 我的消息里面的系统通知接口消息 */
    public static final String MY_SYSTEM_MESSAGE_URL = IP_ADDRESS + "home/user/mySystem";

    /** 单个删除我的消息里面的系统通知接口消息*/
    public static final String DELETE_MY_SYSTEM_MESSAGE_URL = IP_ADDRESS + "home/user/deleteSystem";

    /**系统消息是否已读接口*/
    public static final String IS_READ_MY_SYSTEM_MESSAGE_URL = IP_ADDRESS + "home/user/isRead";

    /** 获取发现首页金融列表 */
    public static final String GET_FIND_FIRST_PAGE_URL = IP_ADDRESS + "home/user/articleList";
    /** 获取发现观点主页*/
    public static final String GET_FIND_POINT_HOME_URL = IP_ADDRESS+"home/user/situation";
    /** 获取发现主播主页头部*/
    public static final String GET_FINF_PERSONAL_HOME_HEAD_URL = IP_ADDRESS+"home/user/header";

    /** 获取发现首页家教列表 */
    public static final String GET_FIND_FIRST_PAGE_TEACH_URL = IP_ADDRESS + "home/user/familyEducation";

    /** 获取发现主播主页*/
    public static final String GET_FINF_PERSONAL_HOME_URL = IP_ADDRESS+"home/user/purchase";
    /** 获取发现个人主页语音列表*/
    public static final String GET_FINF_PERSONAL_AUDIO_LIST_URL = IP_ADDRESS+"home/user/audioList";
    /** 获取文章详情页面*/
    public static final String GET_ARTICAL_DETAILS_URL = IP_ADDRESS + "home/user/rarticle";
    /** 获取语音详情页面*/
    public static final String GET_VOICE_DETAILS_URL = IP_ADDRESS + "home/user/listenAudio";
    /** 获取股市解读页面*/
    public static final String  GET_MARKET_INTERPRET_URL = IP_ADDRESS + "home/user/marketRead";
    /** 获取大咖页面*/
    public static final String GET_BIG_SHOT_URL = IP_ADDRESS + "home/user/manito";
    /** 获取精彩热文页面*/
    public static final String  GET_EXCITING_ARTICAL_URL = IP_ADDRESS + "home/user/jxuan";
    /** 获取今日必读页面*/
    public static final String  GET_MUSTREAD_TODAY_URL = IP_ADDRESS + "home/user/jxuan";
    /** 文章评价接口*/
    public static final String ARTICAL_EVALUATE_URL = IP_ADDRESS + "home/user/articleComment";
    /** 文章发表接口*/
    public static final String ARTICAL_PUBLISH_URL = IP_ADDRESS + "home/user/publishArticle";
    /** 文章重新发表接口*/
    public static final String ARTICAL_REPUBLISH_URL = IP_ADDRESS + "home/user/editArticle ";
    /** 文章语音接口*/
    public static final String Voice_PUBLISH_URL = IP_ADDRESS + "home/user/audio";
    /** 语音评价接口*/
    public static final String VOICE_EVALUATE_URL = IP_ADDRESS + "home/user/audioComent";
    /** 语音观点列表接口*/
    public static final String GET_VOICE_POINT_URL = IP_ADDRESS + "home/user/audioOpinion";
    /** 直播间观看提问接口地址 */
    public static final String LIVE_ROOM_ASK_URL = IP_ADDRESS + "home/user/ask";

    /** 直播间观看提问列表的接口地址 */
    public static final String GET_LIVE_ROOM_ASK_LIST_URL = IP_ADDRESS + "home/user/askList";

    /** 直播间笔记接口地址 */
    public static final String GET_LIVE_ROOM_NOTE_URL = IP_ADDRESS + "home/user/note";

    /** 直播间公告列表的接口 */
    public static final String GET_LIVE_ROOM_NOTICE_LIST_URL = IP_ADDRESS + "home/user/announcementList";

    /** 直播间获取主播信息接口 */
    public static final String GET_LIVE_HOST_INFO_URL = IP_ADDRESS + "home/user/clickIcon";

    /** 主播直播间提问列表接口 */
    public static final String GET_LIVE_HOST_ASK_LIST_URL = IP_ADDRESS + "home/user/haskList";

    /** 主播发布公告接口 */
    public static final String RELEASE_LIVE_NOTICE_URL = IP_ADDRESS + "home/user/announcement";

    /** 主播直播间回复提问接口 */
    public static final String LIVE_HOST_REPLY_ASK_URL = IP_ADDRESS + "home/user/reply";

    /** 主播直播间阅读提问接口 */
    public static final String LIVE_HOST_READ_ASK_URL = IP_ADDRESS + "home/user/readAsk";

    /** 主播直播间财富榜接口 */
    public static final String LIVE_HOST_GET_WEALTH_SORT_URL = IP_ADDRESS + "home/user/wealthSort";

    /** 获取直播间在线人数接口 */
    public static final String GET_LIVE_ROOM_PERSONAL_NUM_URL = IP_ADDRESS + "home/RongCloud/personNum";

    /** 用户接受主播添加房管邀请接口 **/
    public static final String USER_AGREE_BECOMING_MANAGER_URL = IP_ADDRESS + "home/RongCloud/AddRoommanage";

    /** 直播评价 **/
    public static final String LIVE_EVALUATE_URL = IP_ADDRESS + "home/user/score";

    /** 购买文章的接口 */
    public static final String BUY_ARTICLE_URL = IP_ADDRESS + "home/user/purchaseArticle";
    /** 我的直播视频列表接口 */
    public static final String MY_LIVE_VIDEO_URL = IP_ADDRESS + "home/user/record";
    /** 我的被举报记录列表接口 */
    public static final String MY_LIVE_REPORTED_URL = IP_ADDRESS + "home/user/jbrecord";

    /** 个人主页视频列表的接口 */
    public static final String GET_HOME_PAGE_VIDEO_LIST_URL = IP_ADDRESS + "home/user/vedioList";

    /** 个人主页音频列表的接口 */
    public static final String GET_HOME_PAGE_AUDIO_LIST_URL = IP_ADDRESS + "home/user/audioList";

    /** 上传视频 */
    public static final String RELEASE_VIDEO_URL = IP_ADDRESS + "home/user/vedio";

    /**设置推送列表的接口*/
    public static final String SETUP_PUSH_LIST_URL = IP_ADDRESS + "home/user/sendList";

    /**设置推送接口*/
    public static final String SETUP_PUSH_OPEN_OR_CLOSE = IP_ADDRESS + "home/user/editsend";

    /**我的推流工具介绍*/
    public static final String GET_PUSH_TOOL_INTRODUCTION = AGREEMENT_ADDRESS + "/uploads/admin/OBS20170722.pdf";
    /**我的房管设置介绍*/
    public static final String GET_ROOM_MANAGE_INTRODUCTION = "home/user/editsend";
    /**我的主播守则介绍*/
    public static final String GET_HOST_SIGNED_RULE_INTRODUCTION = AGREEMENT_ADDRESS + "/uploads/admin/userProtocol20170722.pdf";

    /** 商品下单 */
    public static final String ORDER_GOODS_URL = IP_ADDRESS + "home/user/order";

    /** 获取分享域名 */
    public static final String GET_SHARE_ADDRESS_URL = IP_ADDRESS + "home/user/address";

    /** 绑定手机接口地址 */
    public static final String BIND_PHONE_URL = IP_ADDRESS + "home/user/editPhone";

    /** 查询多通道房间状态 */
    public static final String QUERY_MULTICHANNEL_LIVE_STATE_URL = IP_ADDRESS + "home/user/moreway";

    /** 申请开通多通道房间 */
    public static final String APPLY_MULTICHANNEL_LIVE_URL = IP_ADDRESS + "home/user/inviteCode";

    /** 进入主房间的接口 */
    public static final String ENTER_INTO_MAIN_ROOM_URL = IP_ADDRESS + "home/user/mainRoom";

    /** 搜索主播的接口 */
    public static final String SEARCH_ANCHOR_URL = IP_ADDRESS + "home/user/searchUser";

    /** 多通道房间邀请房管 */
    public static final String MULTICHANNEL_ROOM_INVITATION_MANAGER_URL = IP_ADDRESS + "home/user/addManage";

    /** 多通道房间接受、拒绝房管邀请 */
    public static final String AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_URL = IP_ADDRESS + "home/user/AddRoommanages";

    /** 邀请子房间的房主 */
    public static final String INVITATION_CHILD_ROOM_OWNER_URL = IP_ADDRESS + "home/user/createSonroom";

    /** 接受、拒绝子房间的房主邀请 */
    public static final String AGREE_CHILD_ROOM_OWNER_INVITATION_URL = IP_ADDRESS + "home/user/AddRoomfather";

    /** 接受、拒绝主播认证邀请 */
    //    public static final String AGREE_AUTHENTICATION_INVITATION_URL = IP_ADDRESS + "home/user/recieve";

    /** 查询子房间列表接口 */
    public static final String QUERY_CHILD_ROOM_LIST_URL = IP_ADDRESS + "home/user/sonRoom";
    /** 副房主、房管进入多通道房间获取信息接口地址 */
    public static final String DEPUTYOWNER_MANAGER_GET_MULTICHANNEL_INFO_URL = IP_ADDRESS + "home/user/manageList";

    /** 进入房间解除职务的接口 */
    public static final String ENTER_MAIN_ROOM_UNEMPLOY_URL = IP_ADDRESS + "home/user/employee";

    /** 进入房间降职的接口 */
    public static final String ENTER_MAIN_ROOM_DOWNEMPLOY_URL = IP_ADDRESS + "home/user/reduce";

    /** 进入房间提拔的接口 */
    public static final String ENTER_MAIN_ROOM_UPEMPLOY_URL = IP_ADDRESS + "home/user/elevate";

    /** 主播直播成功后请求接口 */
    public static final String PUSH_STREAM_SUCCESS_REQUEST_URL = IP_ADDRESS + "home/user/liveSuccess";

    /** 转播失败后直播间切换接口 */
    public static final String LIVE_ROOM_EXCHANGE_URL = IP_ADDRESS + "home/user/changeLive";

    /** 解除子房间房主的接口 */
    public static final String DELETE_MAINCHILD_ROOM_HOST_URL = IP_ADDRESS + "home/user/deleteManage";

    /** 替换子房间房主的接口 */
    public static final String CHANGE_MAINCHILD_ROOM_HOST_URL = IP_ADDRESS + "home/user/reduceManage";

    /** 多通道房间排麦接口地址 */
    public static final String MULTICHANNEL_ROWS_WHEAT_URL = IP_ADDRESS + "home/user/paimai";

    /** 多通道房间获取当前直播的用户信息、管理列表、排序列表 */
    public static final String MULTICHANNEL_ROOM_USER_INFO_URL = IP_ADDRESS + "home/user/moreMylive";

    /** 多通道房间抢麦接口地址 */
    public static final String MULTICHANNEL_ROOM_GRAB_WHEAT_URL = IP_ADDRESS + "home/user/morewayLive";
    /** 解绑子房间地址 */
    public static final String ENTER_CHILD_ROOM_UNBIND_URL =IP_ADDRESS + "home/user/deleteSonroom";

    /** 多通道房间下麦接口地址 **/
    public static final String MULTICHANNEL_UNDER_WHEAT_URL = IP_ADDRESS + "home/user/exits";
}
