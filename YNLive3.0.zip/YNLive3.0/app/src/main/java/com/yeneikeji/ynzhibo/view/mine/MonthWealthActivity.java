package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.CurrentMonthTestBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.foldline.SelectBirthday;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MonthWealthActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private SelectBirthday birth;
    private List<CurrentMonthTestBean> datas;
    private TextView mTvData;
    private ImageView mSelectData;
    private int mCurrentYear;
    private int mCurrentMonth;
    private int mCurrentDay;
    private TextView mGiftIncome;
    private TextView mPriseIncome;
    private TextView mOtherIncome;


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_MY_MONTNWEALTH_FLAG:


                    if (msg.obj != null) {

                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                /***封装礼物***/
                                if(jsonObject.getJSONObject("data").getJSONObject("gift")!=null){
                                    mGiftIncome.setVisibility(View.VISIBLE);
                                    mGiftIncome.setText("+"+jsonObject.getJSONObject("data").getJSONObject("gift").getInt("giftsum"));
                                }else {
                                    mGiftIncome.setVisibility(View.GONE);
                               }
                                /***封装礼物***/

                                /***封装赞***/
                                if(jsonObject.getJSONObject("data").getJSONObject("zan")!=null){
                                    mPriseIncome.setVisibility(View.VISIBLE);
                                    mPriseIncome.setText("+"+jsonObject.getJSONObject("data").getJSONObject("zan").getInt("zansum"));
                                }else {
                                    mPriseIncome.setVisibility(View.GONE);
                                }
                                /***封装赞***/

                                /***封装其他***/

                                if(jsonObject.getJSONObject("data").getJSONObject("others")!=null){
                                    mOtherIncome.setVisibility(View.VISIBLE);
                                    mOtherIncome.setText("+"+jsonObject.getJSONObject("data").getJSONObject("others").getInt("osum"));

                                }else {
                                    mOtherIncome.setVisibility(View.GONE);
                                }

                            } catch (Exception e) {

                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(MonthWealthActivity.this, "暂时没有数据，换个月份试试吧", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {
                        Toast.makeText(MonthWealthActivity.this, "发生意外了，请重试", Toast.LENGTH_SHORT)
                             .show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_wealth);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initMyView();
        addClick();
        addEvent();

    }

    /***ExpendingListView子条目点击事件处理**/
    private void addClick() {
        getLeftBtn().setOnClickListener(this);
        mSelectData.setOnClickListener(this);
    }

    private void initMyView() {
        mGiftIncome = (TextView) findViewById(R.id.gift_income);
        mPriseIncome = (TextView) findViewById(R.id.prise_income);
        mOtherIncome = (TextView) findViewById(R.id.other_income);

        Calendar calendar=Calendar.getInstance();
        //获得当前时间的月份，月份从0开始所以结果要加1
        mCurrentYear = calendar.get(Calendar.YEAR);
        mCurrentMonth = calendar.get(Calendar.MONTH);
        mCurrentDay = calendar.get(Calendar.DAY_OF_MONTH);
        int type =mCurrentYear*10000+mCurrentMonth*100+mCurrentDay;
        configTopBarCtrollerWithTitle(""+ (mCurrentMonth+1) +"月份财富");
        mTvData = (TextView) findViewById(R.id.tv_select_date);
        mSelectData = (ImageView) findViewById(R.id.arrow_monthWealth_timeSelect);
        /***初始化当前年月**/
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        String dateNowStr = sdf.format(d);
        mTvData.setText(dateNowStr);
        getData(type);

    }
    /*****请求数据*****/
    private void getData(final int type) {

        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getMonthWealthIncome(MonthWealthActivity.this,
                                                   YNCommonConfig.GET_MONTHWEALTH_INCOMING_URL,
                                                   AccountUtils.getAccountBean()
                                                               .getId(),
                                                   type,
                                                   handler,
                                                   YNCommonConfig.GET_MY_MONTNWEALTH_FLAG,false);
            }
        });
    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
    }

    //点击事件处理
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.arrow_monthWealth_timeSelect:
                /*
                * 弹出选择年月时间的dialog
                * */
                birth = new SelectBirthday(MonthWealthActivity.this);
                birth.showAsDropDown(MonthWealthActivity.this.findViewById(R.id.tv_select_date)
                        ,0,20);
                birth.mMenuView.findViewById(R.id.submit).setOnClickListener(this);
                birth.mMenuView.findViewById(R.id.cancel).setOnClickListener(this);
                break;
            case R.id.submit:

                mTvData.setText(birth.MyYearAndMonth);
                birth.dismiss();
                configTopBarCtrollerWithTitle(""+birth.MyMonth+"月份财富");
                int subType=birth.MyYear*10000+birth.MyMonth*100+birth.MyDay;
                getData(subType);

                break;
            case R.id.cancel:
                birth.dismiss();
                break;
        }
    }


}