package com.yeneikeji.ynzhibo.application;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Process;
import android.support.multidex.MultiDex;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.tencent.bugly.crashreport.CrashReport;
import com.umeng.socialize.Config;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNFileUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

import org.xutils.x;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by Administrator on 2016/8/11.
 */
public class YNApplication extends Application
{
    public static  String        deviceId;
    private static YNApplication instance;
    private static Context       context;
    private Handler oHandler;
    private Handler mHandler;
    private Handler sHandler;

    private LinkedList<Activity> activitys;// 保存

    @Override
    public void onCreate()
    {
        super.onCreate();

        context = this;
        instance = this;

        createDir();
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        deviceId = tm.getDeviceId();
        YNLogUtil.e("123", deviceId);
        LiveKit.init(context, YNCommonConfig.RONG_CLOUD_APP_KEY);

//        SMSSDK.initSDK(this, YNCommonConfig.MOB_APP_KEY, YNCommonConfig.MOB_APP_SECRET);
        Config.isJumptoAppStore = true;
        UMShareAPI.get(this);
        Config.DEBUG = true;

        /***初始化极光**/
        JPushInterface.setDebugMode(true);
        JPushInterface.init(this);// 初始化 JPush
        JPushInterface.setLatestNotificationNumber(context, 5);
        AccountUtils.init(this);
        //初始化xutils框架
        x.Ext.init(this);
        x.Ext.setDebug(true);

        /** 初始化腾讯bugly */
        /*为了保证运营数据的准确性，建议不要在异步线程初始化Bugly。

         *第三个参数为SDK调试模式开关，调试模式的行为特性如下：

         *输出详细的Bugly SDK的Log；
         * 每一条Crash都会被立即上报；
         * 自定义日志将会在Logcat中输出。
         * 建议在测试阶段建议设置成true，发布时设置为false。
         */
        // 获取当前包名
        String packageName = this.getPackageName();
        // 获取当前进程名
        String progressName = getProgressName(Process.myPid());
        // 设置是否为上报进程
        CrashReport.UserStrategy strategy = new CrashReport.UserStrategy(this);
        strategy.setUploadProcess(progressName == null || progressName.equals(packageName));
        CrashReport.initCrashReport(getApplicationContext(), YNCommonConfig.BUGLY_APP_ID, true);
    }

    //各个平台的配置，建议放在全局Application或者程序入口
    {
        PlatformConfig.setWeixin(YNCommonConfig.WX_APP_ID, YNCommonConfig.WX_APP_SECRET);
        PlatformConfig.setQQZone(YNCommonConfig.QQ_APP_ID, YNCommonConfig.QQ_APP_KEY);
    }

    protected void attachBaseContext(Context base)
    {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    private void createDir()
    {
        //在本地创建一个文件加专门存储当前的头像
        if(YNFileUtil.hasSDCard())
        {
            String path = YNFileUtil.getRootFilePath(this) + YNCommonConfig.PHOTO_DIR;
            File file = new File(path);
            if(!file.exists())
            {
                //如果不存在，则进行创建
                file.mkdir();
            }
        }
    }

    /**
     * 单列模式，获取唯一的YNApplication实列
     */
    public static YNApplication getInstance() {
        return instance;
    }

    public Handler getOHandler(){
        return oHandler;
    }

    public void setOHandler(Handler h){
        oHandler = h;
    }

    public Handler getSHandler(){
        return sHandler;
    }

    public void setSHandler(Handler h){
        sHandler = h;
    }

    public Handler getMHandler(){
        return mHandler;
    }

    public void setMHandler(Handler h){
        mHandler = h;
    }

    /**
     * 整体摧毁的时候调用这个方法
     */
   /* @Override
    public void onTerminate()
    {
        if (sqlHelper != null)
            sqlHelper.close();
        super.onTerminate();

    }*/

    /**
     *  获取界面context
     * @return
     */
    public static Context getContext() {
        return context;
    }

    /**
     * 添加Activity到堆栈
     */
    public void addActivity(Activity activity)
    {
        if (activitys == null) {
            activitys = new LinkedList<>();
        }
        activitys.add(activity);
    }

    /**
     * 退出应用程序
     * @param context 上下文
     */
    public void AppExit(Context context)
    {
        try
        {
            finishAllActivity();
            ActivityManager activityMgr = (ActivityManager) context
                    .getSystemService(Context.ACTIVITY_SERVICE);
            activityMgr.restartPackage(context.getPackageName());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            YNToastMaster.cancelToast();
        }
    }

    /**
     * 结束所有Activity
     */
    public void finishAllActivity() {
        int size = activitys.size();

        for (int i = 0; i < size; i++) {

            if (!activitys.get(i).isFinishing()) {
                activitys.get(i).finish();

            }
        }
        activitys.clear();
        System.exit(0);
    }

    /**
     * 结束指定类名的Activity
     */
    public void finishActivity(Class<?> cls)
    {
        for (Activity activity : activitys)
        {
            if (activity.getClass().equals(cls))
            {
                finishActivity(activity);
            }
        }
    }

    /**
     * 结束指定的Activity
     */
    public void finishActivity(Activity activity)
    {
        YNLogUtil.e("TAG", "finishActivity" + activity.toString());
        if (activity != null) {
            activitys.remove(activity);
            activity.finish();
            activity = null;
        }
    }

    /**
     * 获取进程名
     * @param pid 进程号
     * @return 进程名
     */
    private String getProgressName(int pid)
    {
        BufferedReader bufferedReader = null;
        try
        {
            bufferedReader = new BufferedReader(new FileReader("/proc/" + pid + "/cmdline"));
            String processName = bufferedReader.readLine();
            if (!TextUtils.isEmpty(processName))
            {
                processName = processName.trim();
            }

            return processName;

        }
        catch (Throwable throwable)
        {
            throwable.printStackTrace();
        }
        finally
        {
            if (bufferedReader != null)
            {
                try
                {
                    bufferedReader.close();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }
}
