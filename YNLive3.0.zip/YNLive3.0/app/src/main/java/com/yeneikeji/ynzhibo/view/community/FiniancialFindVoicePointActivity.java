package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.List;
/*
* 发现经融页顶部语音观点页面
* */
public class FiniancialFindVoicePointActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private RadioGroup mRadioGroup;
    private RadioButton mMostNewRb;
    private RadioButton mMostHotRb;
    private ViewPager mViewPager;
    private    ArrayList<Fragment> fragments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finiancial_find_voice_point);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }
    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("语音观点");
        mRadioGroup = (RadioGroup) findViewById(R.id.voicepoint_radioGroup);
        mMostNewRb = (RadioButton) findViewById(R.id.voicepoint_most_new);
        mMostHotRb = (RadioButton) findViewById(R.id.voicepoint_most_hot);
        mViewPager = (ViewPager) findViewById(R.id.voice_point_view_pager);

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mMostNewRb.setOnClickListener(this);
        mMostHotRb.setOnClickListener(this);
        addFragment();
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position,
                                       float positionOffset,
                                       int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position) {

                switch (position) {
                    case 0:
                        mMostNewRb.setChecked(true);
                        mMostHotRb.setChecked(false);
                        break;
                    case 1:
                        mMostNewRb.setChecked(false);
                        mMostHotRb.setChecked(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void addFragment() {
        fragments = new ArrayList();
        VoicePointMostNewFragment fragment1=new VoicePointMostNewFragment();
        VoicePointMostHotFragment fragment2=new VoicePointMostHotFragment();
        fragments.add(fragment1);
        fragments.add(fragment2);
        AdapterFragment adapter=new AdapterFragment(getSupportFragmentManager(),fragments);
        mViewPager.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.voicepoint_most_new:
                mViewPager.setCurrentItem(0);

            break;

            case R.id.voicepoint_most_hot:
                mViewPager.setCurrentItem(1);
            break;

        }
    }
    class AdapterFragment extends FragmentPagerAdapter {
        private List<Fragment> mFragments;

        public AdapterFragment(FragmentManager fm, List<Fragment> mFragments) {
            super(fm);
            this.mFragments = mFragments;
        }

        @Override
        public Fragment getItem(int position) {//必须实现
            return mFragments.get(position);
        }

        @Override
        public int getCount() {//必须实现
            return mFragments.size();
        }


    }
}