package com.yeneikeji.ynzhibo.view;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageView;

import com.yeneikeji.ynzhibo.R;

/**
 * Created by Administrator on 2016/8/4.
 */
public class YNWelcomeActivity extends Activity
{
    public static String SHARE_FIRST = "isFirst";
    private boolean user_first;
    private SharedPreferences setting;
    private ImageView mWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
//        mWelcome = (ImageView) findViewById(R.id.iv_activity_welcome);
        settingDo();
    }

    protected void settingDo()
    {
        new Handler().postDelayed(new Runnable()
        {
            public void run()
            {
                skipActivity();
            }
        }, 700);

    }

    protected void skipActivity()
    {
        setting = this.getSharedPreferences(SHARE_FIRST, Context.MODE_PRIVATE);
        user_first = setting.getBoolean("FIRST", true);
        final Intent intent = new Intent();
        if (user_first)
        {// 第一次启动
            setting.edit().putBoolean("FIRST", false).commit();
            intent.setClass(YNWelcomeActivity.this, YNGuideActivity.class);
        }
        else
        {
            intent.setClass(YNWelcomeActivity.this, YNMainTabActivity.class);
        }
        startActivity(intent);
        this.finish();
    }

    private void setWelcomeAnim(ImageView imageView, final Intent intent)
    {
        PropertyValuesHolder alpha = PropertyValuesHolder.ofFloat("alpha", 0.3f, 1f);
        PropertyValuesHolder scaleX = PropertyValuesHolder.ofFloat("scaleX", 0.3f, 1f);
        PropertyValuesHolder scaleY = PropertyValuesHolder.ofFloat("scaleY", 0.3f, 1f);
        ObjectAnimator objectAnimator1 = ObjectAnimator.ofPropertyValuesHolder(imageView, alpha, scaleX, scaleY);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(objectAnimator1);
        animatorSet.setInterpolator(new AccelerateInterpolator());
        animatorSet.setDuration(2000);
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @Override
            public void onAnimationEnd(Animator animator) {
                intent.setClass(YNWelcomeActivity.this, YNMainTabActivity.class);
                startActivity(intent);
                YNWelcomeActivity.this.overridePendingTransition(R.anim.welcome_fade_in, R.anim.welcome_fade_out);
                finish();
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });
        animatorSet.start();
    }
}
