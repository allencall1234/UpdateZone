package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.model.CoinRecordBean;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.R.layout.activity_gold_coin_record;

/**
 * 金币充值记录界面
 * Created by Administrator on 2016/11/9.
 */
public class YNGoldCoinRecordActivity extends YNBaseTopBarActivity implements View.OnClickListener {
    private SmoothListView mLVCoinRecord;

    private List<CoinRecordBean> coinRecordList;
    private BaseAdapter mAdapter;

    private YNCommonDialog comDialog;
    private ImageView imgBack;
    private TextView txtService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(activity_gold_coin_record);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }


    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle("充值记录");
        getRightBtn().setVisibility(View.GONE);
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.customer_service));

        mLVCoinRecord = (SmoothListView) findViewById(R.id.mListView);
        mLVCoinRecord.setLoadMoreEnable(false);

    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
    }


    @Override
    protected void settingDo() {
        mAdapter = new CommonAdapter<CoinRecordBean>(this, getCoinRecordList(), R.layout.gold_coin_record_item) {
            @Override
            public void convert(CommonViewHolder viewHolder, CoinRecordBean item) {
               /* viewHolder.setText(R.id.tv_coin_state, item.getCoinState() == 1 ? getString(R.string.coin_success) : getString(R.string.coin_fail));
                viewHolder.setText(R.id.tv_coin_time, item.getCoinTime());
                viewHolder.setText(R.id.tv_coin_money, "¥" + item.getCoinMoney());
                viewHolder.setText(R.id.tv_order_number, getString(R.string.order_number) + item.getOrderNumber());
                viewHolder.setText(R.id.tv_gold_num, item.getGoldNum() + "");*/
                viewHolder.setText(R.id.money_numb, "¥" +item.getCoinMoney());
                viewHolder.setText(R.id.coin_numb, ""+item.getGoldNum()+"金币");
                viewHolder.setText(R.id.time_tv, item.getCoinTime());
            }
        };

        mLVCoinRecord.setAdapter(mAdapter);
        //点击条目跳转
        mLVCoinRecord.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(YNGoldCoinRecordActivity.this,YNGoldCoinDetails.class);
                startActivity(intent);
            }
        });
    }

    private List<CoinRecordBean> getCoinRecordList() {
        coinRecordList = new ArrayList<>();
        coinRecordList.add(new CoinRecordBean(1, "2016-11-02", 50, 50, "10161025163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-03", 50, 50, "20161026163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-03", 80, 80, "20161026163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-03", 100, 100, "20161026163600001"));
       /* coinRecordList.add(new CoinRecordBean(1, "2016-11-04", 8, 800, "20161027163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-05", 8, 800, "20161028163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-06", 8, 800, "20161029163600001"));
        coinRecordList.add(new CoinRecordBean(1, "2016-11-07", 8, 800, "20161030163600001"));*/

        return coinRecordList;
    }




    private void createDialog() {
        String content = getString(R.string.hotline) + getString(R.string._0755_25184613) + "\n" + getString(R.string.work_time);
        comDialog = new YNCommonDialog(this, R.style.transparentFrameWindowStyle, content, getString(R.string._0755_25184613), Color.BLUE, getString(R.string.dial), false, new YNCommonDialog.CustomDialogListener() {
            @Override
            public void OnClick(View view) {
                switch (view.getId()) {
                    case R.id.btnCancel:
                        comDialog.dismiss();
                        break;

                    case R.id.btnConfirm:
                        comDialog.dismiss();
                        break;
                }
            }
        });
        comDialog.show();
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.star_1_com_topbar_iv_left :
                finish();
                break;

            case R.id.star_1_com_topbar_tv_right:
                createDialog();
                break;
        }

    }
}
