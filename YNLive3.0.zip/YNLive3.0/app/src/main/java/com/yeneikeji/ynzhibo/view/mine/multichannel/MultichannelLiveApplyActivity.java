package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

/**
 * 多通道直播申请界面
 * Created by Administrator on 2017/7/28.
 */
public class MultichannelLiveApplyActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mETRoomTitle;
    private EditText mETRoomDescribe;
    private EditText mETCode;
    private Button mBtnApply;

    private YNPayDialog submitDialog;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
               case YNCommonConfig.APPLY_MULTICHANNEL_LIVE_FLAG:
                    YNLogUtil.e("cdy", msg.obj.toString());
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 210)
                        {
                            createSubmitDialog();
                        }

                        YNToastMaster.showToast(MultichannelLiveApplyActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(MultichannelLiveApplyActivity.this, R.string.request_fail);
                    }
                break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichannel_live_apply);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.multichannel_live_apply_title));

        mETCode = (EditText) findViewById(R.id.et_input_code);
        mETRoomTitle = (EditText) findViewById(R.id.et_room_title);
        mETRoomDescribe = (EditText) findViewById(R.id.et_room_describe);
        mBtnApply = (Button) findViewById(R.id.btn_apply);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mBtnApply.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                YNCommonUtils.hideSoftInput(this, view);
                finish();
                break;

            case R.id.btn_apply:
                if (TextUtils.isEmpty(mETRoomTitle.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "请输入房间名称");
                    return;
                }
                if (TextUtils.isEmpty(mETRoomDescribe.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "请输入房间简介");
                    return;
                }
                if (TextUtils.isEmpty(mETCode.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "请输入邀请码");
                    return;
                }
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().applyMultiChannelLive(MultichannelLiveApplyActivity.this, YNCommonConfig.APPLY_MULTICHANNEL_LIVE_URL, AccountUtils.getAccountBean().getId(),  mETRoomTitle.getText().toString().trim(),
                                mETRoomDescribe.getText().toString().trim(), mETCode.getText().toString().trim(), mHandler, YNCommonConfig.APPLY_MULTICHANNEL_LIVE_FLAG, true);
                    }
                });

                YNLogUtil.e("cdy", YNCommonConfig.APPLY_MULTICHANNEL_LIVE_URL + "," + AccountUtils.getAccountBean().getId()+ "," + mETRoomTitle.getText().toString().trim()+ "," +
                        mETRoomDescribe.getText().toString().trim()+ "," + mETCode.getText().toString().trim());
                break;
        }
    }

    /**
     * 创建提交弹出框
     */
    private void createSubmitDialog()
    {
        submitDialog = new YNPayDialog.Builder(this)
                .setHeight(0.23f)  //屏幕高度*0.23
                .setWidth(0.8f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setSingleMode(true)
                .setContentText(getString(R.string.multichannel_live_apply_notice))
                .setSingleButtonText("确定")
                .setSingleButtonTextColor(R.color.live_details_text_black)
                .setCanceledOnTouchOutside(false)
                .setInterceptBack(true)
                .setSingleListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view)
                    {
                        submitDialog.dismiss();
                        finish();
                    }
                })
                .build();
        submitDialog.show();
    }

}
