package com.yeneikeji.ynzhibo.interfaces;

import java.util.Map;

public interface ISelectChangeCallBack {
    void onSelectedSizeChange(Map<Integer,Boolean> items);
}
