package com.yeneikeji.ynzhibo.view.mine;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import java.util.ArrayList;
import java.util.List;

/**
 * 订阅界面
 * Created by Administrator on 2017/6/12.
 */
public class SubscribeActivity
        extends YNBaseTopBarActivity
{
    private SmoothListView mLVMySubscribe;

    private List<FindCategaryBean> mSubscribeList = new ArrayList<>();
    private CommonAdapter mSubscribeAdapter;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_subscribe);
    }

    @Override
    protected void initView()
    {
        mLVMySubscribe = (SmoothListView) findViewById(R.id.lv_my_subscribe);
    }

    @Override
    protected void addEvent() {
        super.addEvent();
    }

    @Override
    protected void settingDo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {

            }
        });

        mSubscribeAdapter = new CommonAdapter<FindCategaryBean>(this, mSubscribeList, R.layout.findfinancial_listview_item03)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, FindCategaryBean item)
            {

            }
        };
    }
}
