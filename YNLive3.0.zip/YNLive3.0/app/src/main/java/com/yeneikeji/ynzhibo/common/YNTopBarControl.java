package com.yeneikeji.ynzhibo.common;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;

/**
 * 顶部控件控制显示
 * Created by Administrator on 2016/8/5.
 */
public class YNTopBarControl extends LinearLayout
{
    private Context context;

    // 提供给外部自定义设置
    public ImageView leftItemIv, rightItemIv;

    public TextView leftItemTv, rightItemTv;

    public TextView titleTv;

    public TextView subTitleTv;

    public ImageView titleImageIv;

    public ViewGroup leftItemBtn, centerItemBtn, rightItemBtn;

    public YNIndexEditText searchEt;

    /**
     * 左键响应事件
     */
    private View.OnClickListener mActionLeftListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//            YNAppManager.getAppManager().finishActivity();
        }
    };

    public YNTopBarControl(Context context) {
        this(context, null);
    }

    public YNTopBarControl(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        bindView("");
    }

    /**
     * 绑定默认结构
     * @param titleTxt
     */
    public void bindView(String titleTxt) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View topbarView = inflater.inflate(R.layout.ynkj_topbar_control, null);
//        AutoUtils.auto(topbarView);

        // left
        leftItemBtn = (ViewGroup) topbarView
                .findViewById(R.id.star_1_com_topbar_lo_left);

//		leftItemBtn.setOnClickListener(mActionLeftListener);

        leftItemIv = (ImageView) topbarView
                .findViewById(R.id.star_1_com_topbar_iv_left);
        leftItemTv = (TextView) topbarView
                .findViewById(R.id.star_1_com_topbar_tv_left);
        leftItemIv.setOnClickListener(mActionLeftListener);

        // title
        centerItemBtn = (ViewGroup) topbarView
                .findViewById(R.id.star_1_com_topbar_lo_center);
        titleTv = (TextView) topbarView
                .findViewById(R.id.star_1_com_topbar_tv_center_title);
        titleTv.setText(titleTxt);
        subTitleTv = (TextView) topbarView
                .findViewById(R.id.star_1_com_topbar_tv_center_subtitle);
        titleImageIv = (ImageView) topbarView
                .findViewById(R.id.star_1_com_topbar_iv_center_image);

        // right
        rightItemBtn = (ViewGroup) topbarView
                .findViewById(R.id.star_1_com_topbar_lo_right);
        rightItemIv = (ImageView) topbarView
                .findViewById(R.id.star_1_com_topbar_iv_right);
        rightItemTv = (TextView) topbarView
                .findViewById(R.id.star_1_com_topbar_tv_right);

        searchEt = (YNIndexEditText) topbarView.findViewById(R.id.et_search);

        addView(topbarView, new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    /**
     * 只有文字的bar
     *
     * @param left
     * @param right
     */
    public void onlyTextStyle(String left, String right) {
        leftItemIv.setVisibility(View.GONE);
        leftItemTv.setVisibility(View.VISIBLE);
        leftItemTv.setText(left);

        rightItemIv.setVisibility(View.GONE);
        rightItemTv.setVisibility(View.VISIBLE);
        rightItemTv.setText(right);
    }

    /**
     * 只有图标的bar
     *
     * @param leftResId
     *            -1默认返回
     * @param rightResId
     */
    public void onlyImageStyle(int leftResId, int rightResId) {
        leftItemIv.setVisibility(View.VISIBLE);
        leftItemTv.setVisibility(View.GONE);
        if (leftResId != -1)
            leftItemIv.setImageResource(leftResId);

        if (rightResId == -1) {
            rightItemIv.setVisibility(View.GONE);
            rightItemTv.setVisibility(View.GONE);
        } else {
            rightItemIv.setVisibility(View.VISIBLE);
            rightItemTv.setVisibility(View.GONE);
            rightItemIv.setImageResource(rightResId);
        }
    }

    public void onlyTextStyleBySubTitle(String left, String right) {
        onlyTextStyle(left, right);
        // titleTv.setTextSize(DisplayUtil.px2sp(context,
        // DisplayUtil.dip2px(context, 14)));
    }

    public void subTitleStyle(String title, String subTitle) {
        titleTv.setText(title);
        subTitleTv.setText(subTitle);
        subTitleTv.setVisibility(View.VISIBLE);
        // titleTv.setTextSize(DisplayUtil.px2sp(context,
        // DisplayUtil.dip2px(context, 14)));
    }
}
