package com.yeneikeji.ynzhibo.model;

/**
 * 礼物实体类
 * Created by Administrator on 2016/12/29.
 */
public class GiftBean extends BaseBean
{
    private Integer giftId;
    private int giftCount;
    private String giftCode;

    private String id;
    private String userid;
    private String username;
    private String giftName;
    private String toId;
    private String count;
    private String price;
    private String time;
    private String type;
    private int contribution;
    private int wealth;

    public GiftBean()
    {

    }

    public GiftBean(Integer giftId, String giftName, int giftCount, String giftCode) {
        this.giftId = giftId;
        this.giftName = giftName;
        this.giftCount = giftCount;
        this.giftCode = giftCode;
    }

    public GiftBean(Integer giftId, String giftCode) {
        this.giftId = giftId;
        this.giftCode = giftCode;
    }

    public Integer getGiftId()
    {
        return giftId;
    }

    public void setGiftId(Integer giftId)
    {
        this.giftId = giftId;
    }

    public String getGiftName()
    {
        return giftName;
    }

    public void setGiftName(String giftName)
    {
        this.giftName = giftName;
    }

    public int getGiftCount()
    {
        return giftCount;
    }

    public void setGiftCount(int giftCount)
    {
        this.giftCount = giftCount;
    }

    public String getGiftCode() {
        return giftCode;
    }

    public void setGiftCode(String giftCode) {
        this.giftCode = giftCode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getToId() {
        return toId;
    }

    public void setToId(String toId) {
        this.toId = toId;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getContribution() {
        return contribution;
    }

    public void setContribution(int contribution) {
        this.contribution = contribution;
    }

    public int getWealth() {
        return wealth;
    }

    public void setWealth(int wealth) {
        this.wealth = wealth;
    }
}
