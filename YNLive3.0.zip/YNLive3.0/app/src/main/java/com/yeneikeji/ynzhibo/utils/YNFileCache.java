
package com.yeneikeji.ynzhibo.utils;

import android.content.Context;

/**
 * 文件缓存工具类
 */
public class YNFileCache extends YNAbstractFileCache {
    private Context mContext;

    public YNFileCache(Context context) {
        super(context);
        this.mContext = context;

    }

    @Override
    public String getSavePath(String url, Context context) {
        String filename = String.valueOf(url.hashCode());
        return getCacheDir(context) + filename;
    }

    @Override
    public String getCacheDir(Context context) {

        return YNFileUtil.getSaveFilePath(context);
    }

}
