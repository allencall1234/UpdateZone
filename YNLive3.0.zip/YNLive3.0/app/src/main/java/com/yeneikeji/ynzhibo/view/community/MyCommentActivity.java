package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.CommentBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *  我的评论界面
 * Created by Administrator on 2016/11/22.
 */
public class MyCommentActivity extends YNBaseTopBarActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private SmoothListView mMyCommentLV;
    private RelativeLayout mEmptyRL;
    private TextView mDynamicTV;

    private CommonAdapter myCommentsAdapter;
    private List<CommentBean> myCommentList;

    private YNCommonDialog dialog;
    private int index;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.MY_COMMENTS_FLAG:
                    mLoadingDialog.dismiss();
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                mMyCommentLV.setVisibility(View.VISIBLE);
                                JSONObject object = new JSONObject(msg.obj.toString());
                                JSONArray array = object.getJSONArray("data");
                                Type type = new TypeToken<List<CommentBean>>() {}.getType();
                                myCommentList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                myCommentsAdapter.setDatas(myCommentList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mEmptyRL.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(MyCommentActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                JSONArray array = object.getJSONArray("data");
                                Type type = new TypeToken<List<CommentBean>>() {}.getType();
                                myCommentList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                myCommentsAdapter.setDatas(myCommentList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mEmptyRL.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(MyCommentActivity.this, R.string.request_fail);
                    }
                    onStopLoad();
                    break;

                case YNCommonConfig.COMMUNITY_USER_DELETE_COMMENT_FLAG:
                    mLoadingDialog.dismiss();
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 45)
                        {
                            myCommentList.remove(index);
                            myCommentsAdapter.notifyDataSetChanged();
                        }
                        YNToastMaster.showToast(MyCommentActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(MyCommentActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private YNLoadingDialog mLoadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comment);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.my_comment));

        mMyCommentLV = (SmoothListView) findViewById(R.id.lv_mycomment);
        mEmptyRL = (RelativeLayout) findViewById(R.id.mycomment_empty);
        mDynamicTV = (TextView) mEmptyRL.findViewById(R.id.tv_dynamic_count);

//        mEmptyRL.setVisibility(View.VISIBLE);
        mDynamicTV.setVisibility(View.GONE);
        mMyCommentLV.setVisibility(View.GONE);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mMyCommentLV.setLoadMoreEnable(false);

        mMyCommentLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(MyCommentActivity.this, DynamicDetailsActivity.class);
                intent.putExtra(YNCommonConfig.OBJECT, myCommentList.get(position).getPublish_content());
                startActivity(intent);
            }
        });
    }

    @Override
    protected void settingDo()
    {
        mLoadingDialog = new YNLoadingDialog.Builder(this,
                                                     getString(R.string.loading_txt)).builder();
        mLoadingDialog.show();

        initData();

        myCommentsAdapter = new CommonAdapter<CommentBean>(this, new ArrayList<CommentBean>(), R.layout.my_comment_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, final CommentBean item)
            {
                index = viewHolder.getPosition();
                viewHolder.setImage(MyCommentActivity.this, R.id.iv_mycomment_head, item.getIcon());
                viewHolder.setText(R.id.tv_mycomment_nick, item.getUsername());
                viewHolder.setText(R.id.tv_mycomment_time, DateUtil.timeStamp2String(item.getTime()));
                viewHolder.setText(R.id.tv_comment_content, item.getContent());
                if (item.getPublish_content().getPicture() != null)
                {
                    viewHolder.getView(R.id.iv_release_img).setVisibility(View.VISIBLE);
                    viewHolder.setImage(MyCommentActivity.this, R.id.iv_release_img, item.getPublish_content().getPicture().get(0).getSmall());
                }
                else
                {
                    viewHolder.getView(R.id.iv_release_img).setVisibility(View.GONE);
                }
                viewHolder.setText(R.id.tv_release_name, item.getPublish_content().getUsername() + "：");
                viewHolder.setText(R.id.tv_release_content, item.getPublish_content().getContent());

                viewHolder.getView(R.id.iv_delete).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        if (YNBaseActivity.isConnectNet)
                        {
                            dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.delete_dynamic_notice), false, new YNCommonDialog.CustomDialogListener() {
                                @Override
                                public void OnClick(View view)
                                {
                                    switch (view.getId())
                                    {
                                        case R.id.btnCancel:
                                            dialog.dismiss();
                                            break;

                                        case R.id.btnConfirm:
                                            dialog.dismiss();
                                            mLoadingDialog = new YNLoadingDialog.Builder(context, "正在删除，请稍后...").builder();
                                            mLoadingDialog.show();
                                            mHandler.postDelayed(new Runnable()
                                            {
                                                @Override
                                                public void run()
                                                {
                                                    UserHttpUtils.newInstance().deleteComment(context, YNCommonConfig.COMMUNITY_USER_DELETE_COMMENT_URL, item.getId(), mHandler, YNCommonConfig.COMMUNITY_USER_DELETE_COMMENT_FLAG,false);
                                                }
                                            }, 500);
                                            break;
                                    }
                                }
                            });
                            dialog.show();
                        }
                        else
                        {
                            YNToastMaster.showToast(context, R.string.no_net);
                        }
                    }
                });

                viewHolder.getView(R.id.iv_mycomment_head).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        if (YNBaseActivity.isConnectNet)
                        {
                            Intent intent = new Intent();
                            intent.setClass(context, PersonalHomePageActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(YNCommonConfig.USER_ID, item.getUserid());
                            intent.putExtras(bundle);
                            if (AccountUtils.getLoginInfo())
                            {
                                if (AccountUtils.getAccountBean().getId().equals(item.getUserid()))
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, false);
                                }
                                else
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, true);
                                }
                            }
                            else
                            {
                                intent.putExtra(YNCommonConfig.ISSHOW, true);
                            }
                            context.startActivity(intent);
                        }
                        else
                        {
                            YNToastMaster.showToast(context, R.string.no_net);
                        }
                    }
                });

                viewHolder.getView(R.id.tv_mycomment_nick).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        if (YNBaseActivity.isConnectNet)
                        {
                            Intent intent = new Intent();
                            intent.setClass(context, PersonalHomePageActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(YNCommonConfig.USER_ID, item.getUserid());
                            intent.putExtras(bundle);
                            if (AccountUtils.getLoginInfo())
                            {
                                if (AccountUtils.getAccountBean().getId().equals(item.getUserid()))
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, false);
                                }
                                else
                                {
                                    intent.putExtra(YNCommonConfig.ISSHOW, true);
                                }
                            }
                            else
                            {
                                intent.putExtra(YNCommonConfig.ISSHOW, true);
                            }
                            context.startActivity(intent);
                        }
                        else
                        {
                            YNToastMaster.showToast(context, R.string.no_net);
                        }
                    }
                });
            }
        };

        mMyCommentLV.setAdapter(myCommentsAdapter);
    }

    private void initData()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().myComments(MyCommentActivity.this, YNCommonConfig.MY_COMMENTS_URL, AccountUtils.getAccountBean().getId(),
                        mHandler, YNCommonConfig.MY_COMMENTS_FLAG,false);
            }
        }, 200);
    }

/*    private List<DynamicBean> getMyCommentList()
    {
        myCommentList = new ArrayList<>();
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());

        return myCommentList;
    }*/

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }

    @Override
    public void onRefresh()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().myComments(MyCommentActivity.this, YNCommonConfig.MY_COMMENTS_URL, AccountUtils.getAccountBean().getId(),
                        mHandler, YNCommonConfig.ON_REFRESH,true);
            }
        }, 200);
    }

    @Override
    public void onLoadMore()
    {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mMyCommentLV.stopRefresh();
        mMyCommentLV.stopLoadMore();
        mMyCommentLV.setRefreshTime(DateUtil.getNowDate());
    }

}
