package com.yeneikeji.ynzhibo.model;

import java.io.Serializable;

/**
 * 金币充值记录实体类
 * Created by Administrator on 2016/11/9.
 */
public class CoinRecordBean implements Serializable
{
    private int coinState;// 操作状态
    private String coinTime;// 充值时间
    private int coinMoney;// 充值金额
    private int goldNum;// 充值金币数量
    private String orderNumber;// 订单编号

    public CoinRecordBean()
    {

    }

    public CoinRecordBean(int coinState, String coinTime, int coinMoney, int goldNum, String orderNumber) {
        this.coinState = coinState;
        this.coinTime = coinTime;
        this.coinMoney = coinMoney;
        this.goldNum = goldNum;
        this.orderNumber = orderNumber;
    }

    public int getCoinState() {
        return coinState;
    }

    public void setCoinState(int coinState) {
        this.coinState = coinState;
    }

    public String getCoinTime() {
        return coinTime;
    }

    public void setCoinTime(String coinTime) {
        this.coinTime = coinTime;
    }

    public int getCoinMoney() {
        return coinMoney;
    }

    public void setCoinMoney(int coinMoney) {
        this.coinMoney = coinMoney;
    }

    public int getGoldNum() {
        return goldNum;
    }

    public void setGoldNum(int goldNum) {
        this.goldNum = goldNum;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
}
