package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;

/**
 * 自定义礼物控件
 * Created by Administrator on 2016/12/15.
 */
public class LiveLeftGiftView extends RelativeLayout
{
    private RoundImageView headImg;
    private TextView uname;
    private TextView giftName;
    private ImageView giftImage;
    private Context context;

    public LiveLeftGiftView(Context context)
    {
        super(context);
        init(context, null);
    }

    public LiveLeftGiftView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);

    }

    public LiveLeftGiftView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs);
    }

    private void init(Context context, AttributeSet attrs)
    {
        this.context = context;
        View view = LayoutInflater.from(context).inflate(R.layout.widget_left_gift, this);
        headImg = (RoundImageView) view.findViewById(R.id.iv_head_img);
        uname = (TextView) view.findViewById(R.id.tv_uname);
        giftImage = (ImageView) view.findViewById(R.id.iv_gift);
        giftName = (TextView) view.findViewById(R.id.tv_gift_name);
    }

    public void setName(String name)
    {
        uname.setText(name);
    }

    public void setAvatar(String avatar)
    {
        YNImageLoaderUtil.setImage(context, headImg, avatar);
    }

    public void setGiftImageView(Integer giftImgId){
        giftImage.setImageResource(giftImgId);
    }

    public ImageView getGiftImageView()
    {
        return giftImage;
    }

    public void setGiftName(String gift_name)
    {
        giftName.setText(gift_name);
    }


}
