package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 消息详情界面
 * Created by Administrator on 2017/6/20.
 */
public class MessageConfirmationDetailsActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private static final String TAG = "MessageConfirmationDetailsActivity";
    private RelativeLayout    mRLLiveHostInfo;
    private YNCircleImageView mIVHead;
    private TextView          mTVHostName;
    private TextView          mTVLiveType;
    private TextView          mTVInvitationTime;
    private Button            mBtnRefuse;
    private Button            mBtnAgree;
    private LinearLayout      llIntroduce;
    private TextView          tvHandled;
    private TextView          tvInvite;

    private MessageBean message;
    private int isAcceptInvitaion = -1;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG:
                    // 用户同意、拒绝成为房管
                    if (msg.obj != null) {
                        YNLogUtil.e("cdy123", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
//                        YNToastMaster.showToast(MessageConfirmationDetailsActivity.this,
//                                                baseBean.getInfo(),
//                                                Toast.LENGTH_SHORT,
//                                                Gravity.CENTER);
                        if (baseBean.getCode() == 67) {
                            YNToastMaster.showToast(context, getString(R.string.msg_upper_limit));
                        }else if(baseBean.getCode() == 125){
                            YNToastMaster.showToast(context, "你已经拒绝了");
                        }else if(baseBean.getCode() == 52){
                            YNToastMaster.showToast(context, "添加房管成功");
                        }else if(baseBean.getCode() == 68){
                            YNToastMaster.showToast(context, "你已成为"+ message.getUsername()+"直播间的管理员");
                        }
                        finish();
                    } else {
                        YNToastMaster.showToast(MessageConfirmationDetailsActivity.this,
                                                R.string.request_fail,
                                                Toast.LENGTH_SHORT,
                                                Gravity.CENTER);
                    }
                    break;

                case YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG:
                    // 同意、拒绝多通道房间管理员邀请
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("cdy123", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                BaseBean.class);
                        YNToastMaster.showToast(MessageConfirmationDetailsActivity.this, baseBean.getInfo());
                        finish();
                    }
                    else
                    {
                        YNToastMaster.showToast(MessageConfirmationDetailsActivity.this,
                                R.string.request_fail,
                                Toast.LENGTH_SHORT,
                                Gravity.CENTER);
                    }
                    break;

                case YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG:
                    // 同意、拒绝子房间房主的邀请
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("cdy123", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                BaseBean.class);
                        if (baseBean.getCode() == 117)
                        {
                            YNToastMaster.showToast(context, "你已成为"+ message.getUsername()+"子房间的房主");
                        }
                        else
                        {
                            YNToastMaster.showToast(MessageConfirmationDetailsActivity.this, baseBean.getInfo());
                        }
                        finish();
                    }
                    else
                    {
                        YNToastMaster.showToast(MessageConfirmationDetailsActivity.this,
                                R.string.request_fail,
                                Toast.LENGTH_SHORT,
                                Gravity.CENTER);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        message = (MessageBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
        mRLLiveHostInfo = (RelativeLayout) findViewById(R.id.rl_live_host_info);
        mIVHead = (YNCircleImageView) findViewById(R.id.iv_msg_details_head);
        mTVHostName = (TextView) findViewById(R.id.tv_msg_details_name);
        mTVLiveType = (TextView) findViewById(R.id.tv_msg_details_type);
        mTVInvitationTime = (TextView) findViewById(R.id.tv_msg_details_time);
        mBtnRefuse = (Button) findViewById(R.id.btn_msg_details_refuse);
        mBtnAgree = (Button) findViewById(R.id.btn_msg_details_accept);
        llIntroduce = (LinearLayout) findViewById(R.id.ll_introduce);
        tvHandled = (TextView) findViewById(R.id.tv_handled);
        tvInvite = (TextView) findViewById(R.id.tv_invite);

        if (message.getMessage_type()
                   .equals(YNCommonConfig.VERIFY_MESSAGE)
                || message.getMessage_type().equals(YNCommonConfig.AUTHENTICATION_MESSAGE)
                || message.getMessage_type().equals(YNCommonConfig.ROOM_OWNER_MESSAGE)
                || message.getMessage_type().equals(YNCommonConfig.MULTICHANNELROOM_INVITATION_MANAGER_MSG))
        {
            configTopBarCtrollerWithTitle(getString(R.string.msg_details_title));
            displayHandleMsgStatus();


        } else if (message.getMessage_type()
                          .equals(YNCommonConfig.NOTIFYCATION_MESSAGE)
                ||message.getMessage_type().equals("0")
                ||message.getMessage_type().equals("1")
                ||message.getMessage_type().equals("10"))
        {
            configTopBarCtrollerWithTitle(getString(R.string.notification_message));
            llIntroduce.setVisibility(View.GONE);
        }

    }

    private void displayHandleMsgStatus() {
        if (message.getIs_accept().equals("1")) // 已处理
        {
            tvHandled.setVisibility(View.VISIBLE);
            llIntroduce.setVisibility(View.GONE);
        } else if(message.getIs_accept().equals("0")){ // 未处理
            llIntroduce.setVisibility(View.VISIBLE);
            tvHandled.setVisibility(View.GONE);
            if (message.getMessage_type().equals(YNCommonConfig.AUTHENTICATION_MESSAGE))
            {
                if (AccountUtils.getAccountBean().getCheck_status() == 0)
                {
                    tvHandled.setVisibility(View.VISIBLE);
                    tvHandled.setText("已认证");
                    llIntroduce.setVisibility(View.GONE);
                }
                else
                {
                    mBtnRefuse.setVisibility(View.INVISIBLE);
                }

            }
            else
            {
                mBtnRefuse.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLLiveHostInfo.setOnClickListener(this);
        mBtnRefuse.setOnClickListener(this);
        mBtnAgree.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        YNImageLoaderUtil.setImage(this, mIVHead, message.getIcon());
        mTVHostName.setText(message.getUsername());
        mTVLiveType.setText(message.getTag() + "-" + message.getTag2());
        mTVInvitationTime.setText(DateUtil.timeTick2DateNotSec(message.getTime()));
        tvInvite.setText(message.getContent());
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.rl_live_host_info:
//                Intent intent = new Intent(this, FindAnchorHomeActivity.class);
//                intent.putExtra("userId", message.getUserid());
//                startActivity(intent);
                break;

            case R.id.btn_msg_details_refuse:
                isAcceptInvitaion = 0;
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (message.getMessage_type().equals(YNCommonConfig.VERIFY_MESSAGE))
                        {
                            // 接受、拒绝成为房管邀请
                            UserHttpUtils.newInstance()
                                    .agreeBecomingRoomManager(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG,
                                            true);
                        }
                        if (message.getMessage_type().equals(YNCommonConfig.ROOM_OWNER_MESSAGE))
                        {
                            // 接受、拒绝成为子房间房主邀请
                            UserHttpUtils.newInstance()
                                    .agreeChildRoomOwnerInvitation(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG,
                                            true);
                        }
                        if (message.getMessage_type().equals(YNCommonConfig.MULTICHANNELROOM_INVITATION_MANAGER_MSG))
                        {
                            // 接受、拒绝成为多通道房间房管邀请
                            UserHttpUtils.newInstance()
                                    .agreeMultichannelRoomManagerInvitation(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG,
                                            true);
                        }
                    }
                });
                break;

            case R.id.btn_msg_details_accept:
                isAcceptInvitaion = 1;
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (message.getMessage_type().equals(YNCommonConfig.VERIFY_MESSAGE))
                        {
                            // 接受成为直播间房管邀请
                            UserHttpUtils.newInstance()
                                    .agreeBecomingRoomManager(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.USER_AGREE_BECOMING_MANAGER_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.USER_AGREE_BECOMING_MANAGER_FLAG,
                                            true);
                        }
                        if (message.getMessage_type().equals(YNCommonConfig.ROOM_OWNER_MESSAGE))
                        {
                            // 接受成为子房间房主邀请
                            UserHttpUtils.newInstance()
                                    .agreeChildRoomOwnerInvitation(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.AGREE_CHILD_ROOM_OWNER_INVITATION_FLAG,
                                            true);
                        }
                        if (message.getMessage_type().equals(YNCommonConfig.AUTHENTICATION_MESSAGE))
                        {
                            Intent intent = new Intent(MessageConfirmationDetailsActivity.this, YNRealNameActivity.class);
                            startActivity(intent);
                            finish();
//                            UserHttpUtils.newInstance()
//                                    .agreeRefuseAuthentication(MessageConfirmationDetailsActivity.this,
//                                            YNCommonConfig.AGREE_AUTHENTICATION_INVITATION_URL,
//                                            message.getId(),
//                                            message.getUserid(),
//                                            message.getUid(),
//                                            isAcceptInvitaion,
//                                            mHandler,
//                                            YNCommonConfig.AGREE_AUTHENTICATION_INVITATION_FLAG,
//                                            true);
                        }
                        if (message.getMessage_type().equals(YNCommonConfig.MULTICHANNELROOM_INVITATION_MANAGER_MSG))
                        {
                            // 接受多通道房间房管邀请
                            UserHttpUtils.newInstance()
                                    .agreeMultichannelRoomManagerInvitation(MessageConfirmationDetailsActivity.this,
                                            YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_URL,
                                            message.getId(),
                                            message.getUserid(),
                                            message.getUid(),
                                            isAcceptInvitaion,
                                            mHandler,
                                            YNCommonConfig.AGREE_MULTICHANNEL_ROOM_MANAGER_INVITATION_FLAG,
                                            true);
                        }
                    }
                });
                break;
        }
    }
}
