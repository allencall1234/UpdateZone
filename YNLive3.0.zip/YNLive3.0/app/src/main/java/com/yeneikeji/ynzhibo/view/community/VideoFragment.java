package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindVideoBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.live.AdvancedPlayActivity;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**这是发现主播主页视频碎片
 * Created by Administrator on 2017/6/27.
 */

public class VideoFragment extends BaseFragment implements SmoothListView.ISmoothListViewListener, View.OnClickListener {

    private SmoothListView mVideoLV;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private RelativeLayout mRLHomePageEmpty;
    private ImageView mIVHomePageEmpty;

    private CommonAdapter mVideoListAdapter;
    private List<FindVideoBean> mVideoList = new ArrayList<>();
    private ArrayList<RecordVideoBean> mRecordVideoList = new ArrayList<>();
    private String userId;
    private int homePageFlag;
    private boolean isRefresh = false;
    private boolean isPhoneLiving = false;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_HOME_PAGE_VIDEO_LIST_FLAG:
                    getNetData(msg);
                    break;

                case YNCommonConfig.ON_REFRESH:
                    onStopLoad();
                    getNetData(msg);
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void initView()
    {
        mVideoLV = (SmoothListView) findViewById(R.id.lv_note);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) mRLEmpty.findViewById(R.id.iv_empty);
        mRLHomePageEmpty = (RelativeLayout) findViewById(R.id.personal_homepage_empty);
        mIVHomePageEmpty = (ImageView) mRLHomePageEmpty.findViewById(R.id.iv_homepage_empty);

        mRLEmpty.setBackgroundColor(Color.parseColor("#00000000"));

        mIVEmpty.setOnClickListener(this);
        mIVHomePageEmpty.setOnClickListener(this);
        mVideoLV.setSmoothListViewListener(this);
        mVideoLV.setLoadMoreEnable(false);
    }

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            userId = bundle.getString(YNCommonConfig.USER_ID);
            homePageFlag = bundle.getInt(YNCommonConfig.HOME_PAGE_FLAG);
            isPhoneLiving = bundle.getBoolean(YNCommonConfig.ISSHOW);
        }
        return R.layout.fragment_note_list;
    }

    @Override
    protected void loadData()
    {
        loadingData();

        mVideoListAdapter = new CommonAdapter<FindVideoBean>(getContext(), mVideoList, R.layout.fragment_anchorhome_video_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, FindVideoBean item)
            {
                if (homePageFlag == 1)
                {
                    viewHolder.setText(R.id.video_name, item.getTitle(), ContextCompat.getColor(getContext(), R.color.ynkj_white));
                }
                else
                {
                    viewHolder.setText(R.id.video_name, item.getTitle(), ContextCompat.getColor(getContext(), R.color.wealth_black));
                    viewHolder.getView(R.id.ll_video_item).setBackgroundColor(ContextCompat.getColor(getContext(), R.color.ynkj_white));
                }
                if (isPhoneLiving)
                {
                    viewHolder.setText(R.id.video_time, DateUtil.timeStamp2StringSHort(item.getPublishTime()), Color.parseColor("#d9d9d9"));
                    viewHolder.setText(R.id.video_play_numb, DateUtil.timeTick2DateHour(item.getPublishTime()) + "点场", Color.parseColor("#d9d9d9"));
                }
                else
                {
                    viewHolder.setText(R.id.video_time, DateUtil.timeStamp2StringSHort(item.getPublishTime()), ContextCompat.getColor(getContext(), R.color.search_txt));
                    viewHolder.setText(R.id.video_play_numb, DateUtil.timeTick2DateHour(item.getPublishTime()) + "点场", ContextCompat.getColor(getContext(), R.color.search_txt));
                }
                viewHolder.setImage(getContext(), R.id.video_imag, item.getThumbnailList());
            }
        };

        mVideoLV.setAdapter(mVideoListAdapter);

        mVideoLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent(getContext(), AdvancedPlayActivity.class);
                intent.putExtra("List<RecordVideoBean>", mRecordVideoList);
                intent.putExtra(YNCommonConfig.ISSHOW, false);
                intent.putExtra(YNCommonConfig.POSITION, position - 1);
                startActivity(intent);
            }
        });
    }

    private void loadingData()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getHomePageAudioList(getContext(), YNCommonConfig.GET_HOME_PAGE_VIDEO_LIST_URL, userId,
                        mHandler, isRefresh ? YNCommonConfig.ON_REFRESH : YNCommonConfig.GET_HOME_PAGE_VIDEO_LIST_FLAG, !isRefresh, 500);
            }
        });
    }

    private void getNetData(Message msg)
    {
        if (msg.obj != null)
        {
            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
            if (baseBean.getCode() == 28)
            {
                if (isRefresh)
                {
                    YNToastMaster.showToast(getContext(), "刷新成功");
                    if (homePageFlag == 1)
                        mRLEmpty.setVisibility(View.GONE);
                    else
                        mRLHomePageEmpty.setVisibility(View.GONE);
                    mVideoLV.setVisibility(View.VISIBLE);
                }

                try
                {
                    JSONObject jsonObject = new JSONObject(msg.obj.toString());
                    JSONArray jsonArray = jsonObject.optJSONArray("data");
                    if (jsonArray != null)
                    {
                        Type type = new TypeToken<List<FindVideoBean>>() {}.getType();
                        mVideoList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                        for (FindVideoBean video : mVideoList)
                        {
                            RecordVideoBean recordVideo = new RecordVideoBean("", "", video.getTitle(),
                                    video.getPublishTime(), "", video.getPlayableUrlList(), video.getThumbnailList(), "", "");
                            mRecordVideoList.add(recordVideo);
                        }
                        mVideoListAdapter.updateListView(mVideoList);
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
            else
            {
                if (isRefresh)
                {
                    YNToastMaster.showToast(getContext(), "刷新失败");
                }
                else
                {
                    mVideoLV.setVisibility(View.GONE);
                    if (homePageFlag == 1)
                        mRLEmpty.setVisibility(View.VISIBLE);
                    else
                        mRLHomePageEmpty.setVisibility(View.VISIBLE);
                }
            }
        }
        else
        {
            if (isRefresh)
            {
                YNToastMaster.showToast(getContext(), "刷新失败");
            }
            else
            {
                mVideoLV.setVisibility(View.GONE);
                if (homePageFlag == 1)
                    mRLEmpty.setVisibility(View.VISIBLE);
                else
                    mRLHomePageEmpty.setVisibility(View.VISIBLE);
            }
        }
    }

    /*刷新*/
    @Override
    public void onRefresh()
    {
        isRefresh = true;
        loadingData();
    }

    @Override
    public void onLoadMore() {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mVideoLV.stopRefresh();
        mVideoLV.stopLoadMore();
        mVideoLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_empty:
            case R.id.iv_homepage_empty:
                isRefresh = false;
                loadingData();
                break;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacksAndMessages(null);
    }
}
