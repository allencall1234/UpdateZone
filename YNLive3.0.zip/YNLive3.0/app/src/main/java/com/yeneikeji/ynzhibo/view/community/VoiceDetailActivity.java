package com.yeneikeji.ynzhibo.view.community;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.weigan.loopview.LoopView;
import com.weigan.loopview.OnItemSelectedListener;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;
import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/*
* 这是语音详情页面
* */
public class VoiceDetailActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private ProgressBar    mSeekBar;
    private TextView       mVoiceLength;
    private TextView       mTvDescrible;
    private TextView       mListenerPeople;
    private TextView       mTotalEvaluate;
    private TextView       mGoodRate;
    private Button         mEvaluateNow;

    private Dialog                     dialog;
    private View                       inflate;
    private WindowManager.LayoutParams mLp;
    private LoopView                   mLoopView;
    private int                        evaluateType;
    private String                     mAid;
    private RecordVideoBean              mVoiceBean;
    private boolean isPlay;
    private int  mPlayProgress;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.VOICE_DETAILS_FLAG:

                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    mVoiceBean= YNJsonUtil.JsonToBean(jsonObject.getString("data"),RecordVideoBean.class);
                                  if(mVoiceBean.getTime()!=null){
                                  mPublishTime.setText(timeStamp2StringSHort(mVoiceBean.getTime()));
                                    }
                                    //时长
                                    if(mVoiceBean.getTime()!=null){
                                        mVoiceLength.setText(mVoiceBean.getPlayTime());
                                    }
                                    if(mVoiceBean.getDescribe1()!=null){
                                        mTvDescrible.setText(mVoiceBean.getDescribe1());
                                    }
                                       mListenerPeople.setText(mVoiceBean.getCount()+"收听");
                                        mTotalEvaluate.setText("评价("+mVoiceBean.getAll()+")");
                                    //好评率
                                    String goodRat=""+mVoiceBean.getGoodRat()*100;
                                    if(goodRat.length()>5){
                                        String NewgoodRat=goodRat.substring(0,5);
                                        mGoodRate.setText(NewgoodRat+"%");
                                    }else {
                                        mGoodRate.setText("好评率" + mVoiceBean.getGoodRat() * 100 + "%");
                                    }
                                    //好评率
//                                        mGoodRate.setText("好评率"+mVoiceBean.goodRat+"%");
                                    //判断是否评价过
                                    if(mVoiceBean.getIs_comment()==0){
                                        mEvaluateNow.setClickable(true);
                                        mEvaluateNow.setText("立即评价");
                                        mEvaluateNow.setClickable(true);
                                    }        else{
                                        mEvaluateNow.setClickable(false);
                                        mEvaluateNow.setText("已经评价过了");
                                        mEvaluateNow.setBackgroundResource(R.drawable.articaldetails_evaluate_graybg);
                                        mEvaluateNow.setClickable(false);
                                    }
                                }
                            } catch (JSONException e) {
                                Toast.makeText(context, "出现一点小意外哦，请重试一下吧", Toast.LENGTH_SHORT)
                                     .show();
                                e.printStackTrace();
                            }
                        }

                    } else {

                    }

                    break;
            //评价返回
                case YNCommonConfig.VOICE_VOLUATE_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 26) {
                            YNLogUtil.e("ddd",msg.obj.toString());
                            //评价成功
                            Toast.makeText(VoiceDetailActivity.this, "评价成功", Toast.LENGTH_SHORT)
                                 .show();
                            mEvaluateNow.setClickable(false);
                            mEvaluateNow.setText("已经评价过了");
                            mEvaluateNow.setBackgroundResource(R.drawable.articaldetails_evaluate_graybg);
                            //刷新好评率
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(msg.obj.toString());
                            if (jsonObject != null) {
                                mVoiceBean = YNJsonUtil.JsonToBean(jsonObject.getString("data"),
                                                                   RecordVideoBean.class);
                                mGoodRate.setText("好评率" + mVoiceBean.getGoodRat()*100+"%");
                                mTotalEvaluate.setText("评价("+mVoiceBean.getAll()+")");
                            }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }else{
                            Toast.makeText(VoiceDetailActivity.this, "已经评价过了哦，亲", Toast.LENGTH_SHORT)
                                 .show();

                        }

                        }
                    break;

            }
        }

    };
    private TextView mPublishTime;
    private MediaPlayer mPlayer;
    private ImageView mVoiceIv;
    private ImageView mVoicePlayIv;
    private ImageView mVoicePlayingIv;
    private ImageView mVoiceStopIv;
    private TimeTask mTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_detail);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {
        mAid = getIntent().getStringExtra("aid");
        configTopBarCtrollerWithTitle("收听");
        mPublishTime = (TextView) findViewById(R.id.publish_time);
       // mVoicePlay = (RelativeLayout) findViewById(R.id.rl_voice_play);
        //根据是否在播放切换图标
        mVoiceIv = (ImageView) findViewById(R.id.voice_iv);
        mVoicePlayingIv = (ImageView) findViewById(R.id.voice_playing_iv);
        mVoiceStopIv = (ImageView) findViewById(R.id.voice_stop_iv);

        mSeekBar = (ProgressBar ) findViewById(R.id.seekbar);
        mVoiceLength = (TextView) findViewById(R.id.voice_length);
        mTvDescrible = (TextView) findViewById(R.id.voice_describle);
        //评价统计
        mListenerPeople = (TextView) findViewById(R.id.read_people_numb);
        mTotalEvaluate = (TextView) findViewById(R.id.tv_total_evaluate);
        mGoodRate = (TextView) findViewById(R.id.good_evaluate_rate);
        //评价按钮
        mEvaluateNow = (Button) findViewById(R.id.evaluateNow);
        initData();

    }

    private void initData() {
        mHandler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getArticalDetails(VoiceDetailActivity.this,
                                                YNCommonConfig.GET_VOICE_DETAILS_URL,
                                                mAid,
                                                AccountUtils.getAccountBean()
                                                            .getId(),
                                                mHandler,
                                                YNCommonConfig.VOICE_DETAILS_FLAG,
                                                true);
            }
        });
    }

    @Override
    protected void addEvent() {

        getLeftBtn().setOnClickListener(this);
        //播放录音
        mVoiceIv.setOnClickListener(this);
        //正在播放
        mVoicePlayingIv.setOnClickListener(this);
        //暂停播放
        mVoiceStopIv.setOnClickListener(this);
        //评价
        mEvaluateNow.setOnClickListener(this);
    }

    @Override
    protected void settingDo() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                //释放播放器
                if(mPlayer!=null){
                    mPlayer.release();
                    mPlayer=null;
                }
                finish();
                break;
            //弹出评价统计
            case R.id.evaluateNow:
                inflate = LayoutInflater.from(this)
                                        .inflate(R.layout.dialog_evaluate, null);
                dialog = new Dialog(this, R.style.ActionSheetDialogStyle);

                WindowManager windowManager = getWindowManager();
                Display display       = windowManager.getDefaultDisplay();
                mLp = dialog.getWindow()
                            .getAttributes();
                mLp.width = (int) (display.getWidth()); //设置宽度
                dialog.getWindow()
                      .setAttributes(mLp);

                mLoopView = (LoopView) inflate.findViewById(R.id.loopview);
                TextView cancle = (TextView) inflate.findViewById(R.id.evaluate_cancle);
                TextView sure   = (TextView) inflate.findViewById(R.id.evaluate_sure);
                //取消和确定的监听
                cancle.setOnClickListener(this);
                sure.setOnClickListener(this);
                ArrayList<String> list = new ArrayList<>();
                list.add("好");
                list.add("一般");
                list.add("差");
                //设置是否循环播放
                //设置数据
                mLoopView.setItems(list);
                mLoopView.setNotLoop();
                //设置滚轮字体大小
                mLoopView.setTextSize(16);
                //滚动监听 可以知道选择了哪个评价
                mLoopView.setListener(new OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(int index) {
                        evaluateType = index;
                    }
                });
                dialog.setContentView(inflate);
                dialog.show();
                break;

            //评价取消
            case R.id.evaluate_cancle:
                dialog.dismiss();
                break;
            //提交评价
            case R.id.evaluate_sure:
                //先判断是否登录
                if(AccountUtils.getLoginInfo()){
                    mHandler.post(new Runnable() {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance()
                                         .getEvaluateArtical(VoiceDetailActivity.this,
                                                             YNCommonConfig.VOICE_EVALUATE_URL,
                                                             mAid,
                                                             AccountUtils.getAccountBean().getId(),
                                                             ""+(3-evaluateType),
                                                             mHandler,
                                                             YNCommonConfig.VOICE_VOLUATE_FLAG,
                                                             true);
                        }
                    });
                }else{
                    Toast.makeText(mContext, "请先登录哦，亲", Toast.LENGTH_SHORT)
                         .show();
                    Intent intent = new Intent(mContext, YNLoginActivity.class);
                    startActivity(intent);
                }
                dialog.dismiss();

                break;

            case R.id.voice_iv:
                //判断语音文件不为空
                if(mVoiceBean.getAudio()!=null){

                    isPlay=!isPlay;
                    if(isPlay){
                        //切换图标
                        mVoiceIv.setVisibility(View.GONE);
                        mVoicePlayingIv.setVisibility(View.VISIBLE);
                        try {
                            mPlayer = new MediaPlayer();
                            mPlayer.setDataSource(mVoiceBean.getAudio());
                            mPlayer.prepare();
                            mPlayer.start();
                            //更新进度
                            mSeekBar.setMax(mPlayer.getDuration()/1000);
                            mTask = new TimeTask();
                            mTask.run();

                        } catch (IOException e) {
                            Toast.makeText(context, "播放失败", Toast.LENGTH_SHORT)
                                 .show();
                            //重置播放状态
                            mVoiceIv.setVisibility(View.GONE);
                            mPlayer.release();
                            mPlayer=null;

                            e.printStackTrace();
                        }
                    }
                }else{
                    Toast.makeText(context, "还没发表语音观点哦，亲", Toast.LENGTH_SHORT)
                         .show();
                }
                break;
            case R.id.voice_playing_iv:
                //暂停播放
                isPlay=false;
                mPlayer.pause();
                //切换图标
                mVoiceIv.setVisibility(View.GONE);
                mVoicePlayingIv.setVisibility(View.GONE);
                mVoiceStopIv.setVisibility(View.VISIBLE);

                break;
            case R.id.voice_stop_iv:
                //继续播放
                isPlay=true;
                mPlayer.start();
                mTask.run();
                //切换图标
                mVoiceIv.setVisibility(View.GONE);
                mVoiceStopIv.setVisibility(View.GONE);
                mVoicePlayingIv.setVisibility(View.VISIBLE);
                isPlay=true;

                break;

        }
    }
    class TimeTask extends Thread implements Runnable{
        final Handler handler=new Handler();
        @Override
        public void run() {
            if(isPlay) {
                if (mPlayProgress < mPlayer.getDuration()/1000) {
                    mSeekBar.setProgress(mPlayProgress++);
                    handler.postDelayed(this, 1000);//每一秒刷新一次 }
                } else {
                    mSeekBar.setProgress(mPlayer.getDuration()/1000);
                    mPlayer.stop();
                    //播放完成后重置
                    mVoiceIv.setVisibility(View.VISIBLE);
                    mVoicePlayingIv.setVisibility(View.GONE);
                    mVoiceStopIv.setVisibility(View.GONE);
                    mSeekBar.setProgress(0);
                    mPlayer.release();
                    mPlayer = null;
                    mPlayProgress = 0;
                    isPlay=false;
                }
            }else{
                mPlayer.pause();
            }
        }
    }

}
