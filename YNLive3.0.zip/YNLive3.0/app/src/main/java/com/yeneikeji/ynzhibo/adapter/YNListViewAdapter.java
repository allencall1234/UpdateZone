package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.database.HistoryDao;
import com.yeneikeji.ynzhibo.database.WatchRecordDao;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.LiveTypeBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.utils.YNCacheUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.live.FinanceActivity;
import com.yeneikeji.ynzhibo.view.live.TeachActivity;
import com.yeneikeji.ynzhibo.view.live.YNLiveDetailsActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import java.util.List;

/**
 * 直播首页(推荐)分级列表显示适配器
 * Created by Administrator on 2016/8/22.
 */
public class YNListViewAdapter extends BaseAdapter
{
    private WatchRecordDao watchRecordDao;
    private Context mContext;
    private List<LiveTypeBean> liveList;
//    private List<LiveRoomBean> liveRoomList;
//    private YNCommonDialog comDialog;
    private YNPayDialog noticeDialog;
//    private List<LiveRoomBean> liveRoomList;

    //    public YNListViewAdapter(Context mContext, List<LiveTypeBean> liveList, List<LiveRoomBean> liveRoomList)
//    {
//        this.mContext = mContext;
//        this.liveList = liveList;
//        this.liveRoomList = liveRoomList;
//    }

    public YNListViewAdapter(Context mContext,
                             List<LiveTypeBean> liveList)
    {
        this.mContext = mContext;
        this.liveList = liveList;
        watchRecordDao = new WatchRecordDao(mContext);
    }

    public void setLiveList(List<LiveTypeBean> liveList)
    {
        this.liveList = liveList;
        notifyDataSetChanged();
    }

//   public void setLiveRoomList(List<LiveRoomBean> liveRoomList)    {
//       this.liveRoomList = liveRoomList;
//       notifyDataSetChanged();
//   }

    @Override
    public int getCount() {
        return liveList.size();
    }

    @Override
    public Object getItem(int i) {
        return liveList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        final LiveTypeBean liveType = liveList.get(i);
        ViewHolder holder;
        if (view == null)
        {
            view = LayoutInflater.from(mContext).inflate(R.layout.recommented_listview_item, null);
//            AutoUtils.auto(view);
            holder = new ViewHolder();

            holder.mGridView = (GridView) view.findViewById(R.id.gv_teacherImg);
            holder.mLLTitle = (LinearLayout) view.findViewById(R.id.ll_title);
            holder.mImgType = (ImageView) view.findViewById(R.id.iv_title_img);
            holder.rl_more = (RelativeLayout) view.findViewById(R.id.rl_more);
            holder.mTitle = (TextView) view.findViewById(R.id.tv_title);
            holder.mLLEmpty = (LinearLayout) view.findViewById(R.id.ll_empty);

            view.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) view.getTag();
        }

        holder.mTitle.setText(liveType.getTitle());
        holder.mImgType.setImageResource(liveType.getImg());
        YNGridViewAdapter mAdapter = new YNGridViewAdapter(mContext, liveType.getLiveRoomList());
        holder.mGridView.setAdapter(mAdapter);


       /* if (liveList.size() > 0)
        {
//            holder.mLLTitle.setVisibility(View.VISIBLE);
            holder.mTitle.setText(liveType.getTitle());
            holder.mLLEmpty.setVisibility(View.GONE);
//            holder.mImgType.setImageResource(liveType.getLiveRoomList().get(i).getTag() == 0 ? R.drawable.icon_finance : R.drawable.icon_teach);
            holder.mImgType.setImageResource(liveType.getLiveRoomList().get(i).getTag() == 0 ? R.drawable.icon_finance : R.drawable.icon_teach);
        }
        else
        {
//            holder.mLLTitle.setVisibility(View.GONE);
            holder.mLLEmpty.setVisibility(View.VISIBLE);
        }*/

        holder.rl_more.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent();
                if ("金融".equals(liveType.getTitle()))
                {
                    intent.setClass(mContext, FinanceActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                }
                else
                {
                    intent.setClass(mContext, TeachActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                }
                mContext.startActivity(intent);
            }
        });

        holder.mGridView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l)
            {
                if (NetUtils.isConnected(mContext))
                {
                    if (!NetUtils.isWifi(mContext))
                    {
                        noticeDialog = new YNPayDialog.Builder(mContext)
                                .setContentText("您当前处于非WIFI环境下，是否要观看直播？")
                                .setRightButtonTextColor(R.color.ynkj_red)
                                .setCanceledOnTouchOutside(false)
                                .setOnclickListener(new IDialogOnClickListener()
                                {
                                    @Override
                                    public void clickTopLeftButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickTopRightButton(View view)
                                    {

                                    }

                                    @Override
                                    public void clickBottomLeftButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                    }

                                    @Override
                                    public void clickBottomRightButton(View view)
                                    {
                                        noticeDialog.dismiss();
                                        watchRecordDao.insertWatchRecord(liveType.getLiveRoomList().get(i));
                                        Intent intent = new Intent(mContext, YNLiveDetailsActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable(YNCommonConfig.OBJECT, liveType.getLiveRoomList().get(i));
                                        intent.putExtras(bundle);
                                        mContext.startActivity(intent);
                                    }

                                    @Override
                                    public void clickBottomButton(View view)
                                    {

                                    }
                                })
                                .build();
                        noticeDialog.show();

                      /*  comDialog = new YNCommonDialog(mContext, R.style.transparentFrameWindowStyle, "您当前处于非WIFI环境下，是否要观看直播？", false, new YNCommonDialog.CustomDialogListener()
                        {
                            @Override
                            public void OnClick(View view)
                            {
                                switch (view.getId())
                                {
                                    case R.id.btnCancel:
                                        comDialog.dismiss();
                                        break;

                                    case R.id.btnConfirm:
                                        comDialog.dismiss();
//                                        if (liveRoomList.get(i).getStatus().equals(YNCommonConfig.LIVE_STATUS_REST))
//                                        {
//                                            YNToastMaster.showToast(mContext, "主播正在赶来的路上");
//                                            return;
//                                        }
                                        watchRecordDao.insertWatchRecord(liveType.getLiveRoomList().get(i));
                                        Intent intent = new Intent(mContext, YNLiveDetailsActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putSerializable(YNCommonConfig.OBJECT, liveType.getLiveRoomList().get(i));
                                        intent.putExtras(bundle);
                                        mContext.startActivity(intent);
                                        break;
                                }
                            }
                        });
                        comDialog.show();*/
                    }
                    else
                    {
//                        if (liveRoomList.get(i).getStatus().equals(YNCommonConfig.LIVE_STATUS_REST))
//                        {
//                            YNToastMaster.showToast(mContext, "主播正在赶来的路上");
//                            return;
//                        }
                        watchRecordDao.insertWatchRecord(liveType.getLiveRoomList().get(i));
                        Intent intent = new Intent(mContext, YNLiveDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, liveType.getLiveRoomList().get(i));
                        intent.putExtras(bundle);
                        mContext.startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, "网络未连接", Toast.LENGTH_SHORT, Gravity.CENTER);
//                    NetUtils.openSetting(mContext);
                }
            }
        });

        return view;
    }

    private class ViewHolder
    {
         private GridView mGridView;
         private LinearLayout mLLTitle;
         private RelativeLayout rl_more;
         private TextView mTitle;
         private ImageView mImgType;
         private LinearLayout mLLEmpty;
    }
}
