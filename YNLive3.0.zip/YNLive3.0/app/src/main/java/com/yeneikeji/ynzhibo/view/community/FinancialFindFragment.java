package com.yeneikeji.ynzhibo.view.community;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.YNBaseTopBarFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.YNJsonUtil.JsonToLBean;

/**
 * 直播发现界面
 * Created by Administrator on 2017/05/28.
 */
public class FinancialFindFragment
        extends YNBaseTopBarFragment
        implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private LayoutInflater inflater;
    //private YNBannerView   mYNBannerView;
    private SmoothListView mListView;
    private RelativeLayout mRLEmpty;
    private ImageView      mIVEmpty;
    private TextView       mTVEmpty;
    List<FindCategaryBean> Data1Beans;
    List<FindCategaryBean> Data2Beans;
    List<FindCategaryBean> Data3Beans;
    private List<FindCategaryBean> financialList= new ArrayList<>();;
   // private List<LiveRoomBean>           liveRoomList;
    private FindFinancialListViewAdapter mLiveAdapter;
    private FindCategaryBean             findCategaryBean;
    public static final String TAG = "FinancialFindFragment";
    private Integer[]    bannerImgs;
    private String       toBuyArticalaid;//记录要买文章的aid
    private String       toBuyArticalCoin;//记录要买文章的费用，以便更新本地保存的用户余额状态
    //这个计数器主要是引因为主页展示数据限制，方便第三种条目类型的点击跳转出处理
    private int          categray2Size;
    private String       userId="";
    private Intent       mIntent;
    private LinearLayout mMarketInterpret;
    private LinearLayout mMarketBigShot;
    private LinearLayout mMarketVoicePoint;
    private Intent       mIntent1;
    private YNPayDialog  buytDialog;
    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    @Override
    public void loginRefreshUI() {
    }
    @Override
    public void unLoginRefreshUI()
    {
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_FIND_FIRST_PAGE_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) {
                            mRLEmpty.setVisibility(View.GONE);
                            mListView.setVisibility(View.VISIBLE);
                            if(financialList!=null){
                                financialList.removeAll(financialList);
                            }
                            try {
                                /***封装第一个
                                 * 标题*/
                                FindCategaryBean bean01 = new FindCategaryBean();
                                bean01.setName("title1");
                                financialList.add(bean01);
                                /***封装第一个
                                 * 标题*/
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array1     = jsonObject.optJSONArray("data1");
                                JSONArray  array2     = jsonObject.optJSONArray("data2");
                                JSONArray  array3     = jsonObject.optJSONArray("data3");
                                /*****封装第一类*****/
                                if (array1 != null) {
                                    Type type = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    Data1Beans = YNJsonUtil.JsonToLBean(array1.toString(), type);
                                    for (int i = 0; i < 3; i++) {
                                        if (Data1Beans.get(i) != null) {
                                            findCategaryBean = Data1Beans.get(i);
                                        } else {
                                            findCategaryBean = new FindCategaryBean();
                                        }
                                        categray2Size++;
                                        findCategaryBean.setName("1");
                                        financialList.add(findCategaryBean);
                                    }
                                }
                                /*****封装第一类*****/
                                /*****封装第二类*****/
                                if (array2 != null) {
                                    Type type = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    Data2Beans = YNJsonUtil.JsonToLBean(array2.toString(), type);
                                    if (Data2Beans.get(0) != null) {
                                        findCategaryBean = Data2Beans.get(0);
                                    } else {
                                        findCategaryBean = new FindCategaryBean();
                                    }

                                    findCategaryBean.setName("2");
                                    financialList.add(findCategaryBean);
                                }
                                /*****封装第二类*****/

                                /***封装第二个
                                 * 标题*/
                                FindCategaryBean bean02 = new FindCategaryBean();
                                bean01.setName("title2");
                                financialList.add(bean02);
                                /***封装第二个
                                 * 标题*/
                                /*****封装第三类*****/
                                if (array3 != null) {
                                    Type type = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    Data3Beans = YNJsonUtil.JsonToLBean(array3.toString(), type);
                                    for (int i = 0; i < 3; i++) {
                                        if (Data3Beans.get(i) != null) {
                                            findCategaryBean = Data3Beans.get(i);
                                        } else {
                                            findCategaryBean = new FindCategaryBean();
                                        }
                                        findCategaryBean.setName("4");
                                        financialList.add(findCategaryBean);
                                    }
                                }
                                /*****封装第三类*****/
                                /***封装第二个
                                 * 标题*/
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            mListView.setVisibility(View.VISIBLE);
                            mRLEmpty.setVisibility(View.GONE);
                        }
                    } else {
                        mListView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
                      //  YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }


                    mLiveAdapter = new FindFinancialListViewAdapter(getActivity(),
                                                                    financialList,
                                                                    Data2Beans);
                    mListView.setAdapter(mLiveAdapter);
                    onStopLoad();
                    mListView.stopRefresh();
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (financialList != null) {
                        financialList.removeAll(financialList);
                    }
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) {
                            mRLEmpty.setVisibility(View.GONE);
                            mListView.setVisibility(View.VISIBLE);
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array      = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<LiveRoomBean>>() {}.getType();
                                financialList = JsonToLBean(array.toString(), type);

                                mLiveAdapter.updataData(financialList);
                            } catch (JSONException e) {
                                mRLEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        } else {
                            mRLEmpty.setVisibility(View.VISIBLE);
                        }
                    } else {
                        mRLEmpty.setVisibility(View.VISIBLE);
                        mListView.setVisibility(View.GONE);
                       // YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    onStopLoad();
                    break;
                //购买文章
                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 102) {
                            //购买成功
                            Toast.makeText(getActivity(), "购买成功", Toast.LENGTH_SHORT)
                                 .show();
                            for (FindCategaryBean bean : financialList) {
                                if (toBuyArticalaid.equals(bean.getId())) {
                                    bean.setIs_purchase(1);
                                    //刷新数据
                                    mLiveAdapter.updataData(financialList);
                                    //更新用户余额值
                                    UserInfoBean userInfoBean = AccountUtils.getAccountBean();
                                    userInfoBean.setCurrentCoin(userInfoBean.getCurrentCoin()-Integer.parseInt(toBuyArticalCoin));
                                    //保存到本地，更新用户余额
                                    AccountUtils.saveAccountBean(userInfoBean);
                                    //跳转到文章详情页面
                                    Intent intent = new Intent(getActivity(),
                                                               ArticalDetailsActivity.class);
                                    intent.putExtra("aid", toBuyArticalaid);
                                    startActivity(intent);
                                    break;
                                }
                            }
                        }
                    } else {
                        YNToastMaster.showToast(getActivity(),
                                                "购买失败",
                                                Toast.LENGTH_SHORT,
                                                Gravity.CENTER);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {

        this.inflater = inflater;
        View view = inflater.inflate(R.layout.fragment_recomment, container, false);
        //  AutoUtils.auto(view);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    protected void initView(View view)
    {
        //        bannerImages = getResources().getStringArray(R.array.url);
       /* bannerImgs = new Integer[]{R.drawable.banner_one,
                                   R.drawable.banner_two,
                                   R.drawable.banner_one,
                                   R.drawable.banner_two};*/
        //        mSearch = (ImageView) view.findViewById(R.id.iv_search);
        mListView = (SmoothListView) view.findViewById(R.id.mListView);
        mRLEmpty = (RelativeLayout) view.findViewById(R.id.empty);
        mIVEmpty = (ImageView) view.findViewById(R.id.iv_empty);
        mIVEmpty.setImageResource(R.drawable.blank);
        mTVEmpty = (TextView) view.findViewById(R.id.tv_empty);
        mListView.setVisibility(View.GONE);
        // 添加头部
        mListView.addHeaderView(initHeaderView());


    }

    /**
     * 初始化listview的头部信息
     * @return
     */
    public View initHeaderView()
    {
        View headerView = inflater.inflate(R.layout.fragment_findfinancial_headerview, null);
        // mYNBannerView = (YNBannerView) headerView.findViewById(R.id.ynBinnerView);
        //股市解读
        mMarketInterpret = (LinearLayout) headerView.findViewById(R.id.stock_market_interpret);
        //大咖
        mMarketBigShot = (LinearLayout) headerView.findViewById(R.id.stock_market_bigShot);
        //语音观点
        mMarketVoicePoint = (LinearLayout) headerView.findViewById(R.id.stock_market_voicePoint);


        return headerView;
    }

    @Override
    public void onResume()
    {
        super.onResume();
    }

    @Override
    protected void addEvents()
    {
        mMarketInterpret.setOnClickListener(this);
        mMarketBigShot.setOnClickListener(this);
        mMarketVoicePoint.setOnClickListener(this);

        mRLEmpty.setOnClickListener(this);
        mListView.setLoadMoreEnable(false);
        mListView.setSmoothListViewListener(this);

        mListView.setOnScrollListener(new SmoothListView.OnSmoothScrollListener() {
            @Override
            public void onSmoothScrolling(View view)
            {

            }
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
                // 当不滚动时
                if (scrollState == NumberPicker.OnScrollListener.SCROLL_STATE_IDLE) {
                    //判断是否滚动到底部
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        onLoadMore();
                    }
                }
            }
            @Override
            public void onScroll(AbsListView view,
                                 int firstVisibleItem,
                                 int visibleItemCount,
                                 int totalItemCount)
            {

            }
        });
    }

    @Override
    protected void settingDo()
    {
        mListView.setLoadMoreEnable(false);
        mListView.setSmoothListViewListener(this);
        if (AccountUtils.getLoginInfo()) {
            userId = AccountUtils.getAccountBean()
                                 .getId();
            if (!YNBaseActivity.isConnectNet) {
                mRLEmpty.setVisibility(View.VISIBLE);
                mIVEmpty.setImageResource(R.drawable.blank);
                mTVEmpty.setText("请检查您的手机是否联网");
            }
        }
        UserHttpUtils.newInstance()
                     .getFindFirstPage(getActivity(),
                                       YNCommonConfig.GET_FIND_FIRST_PAGE_URL,
                                       userId,
                                       1,
                                       mHandler,
                                       YNCommonConfig.GET_FIND_FIRST_PAGE_FLAG,
                                       true);
    }
    /**
     * 获取分级标题
     * @return
     */


    @Override
    public void onClick(View view)
    {
        switch (view.getId()) {
            //股市解读
            case R.id.stock_market_interpret:
                mIntent1 = new Intent(getActivity(), FiniancialFindMarketInterpretActivity.class);
                startActivity(mIntent1);
                break;
            //大咖
            case R.id.stock_market_bigShot:
                mIntent1 = new Intent(getActivity(), FiniancialFindBigShotActivity.class);
                startActivity(mIntent1);
                break;
            //语音观点
            case R.id.stock_market_voicePoint:
                mIntent1 = new Intent(getActivity(), FiniancialFindVoicePointActivity.class);
                startActivity(mIntent1);
                break;

            case R.id.tv_refresh_net:

            case R.id.empty:
               // onRefresh();
                if (YNBaseActivity.isConnectNet) {
                    mRLEmpty.setVisibility(View.GONE);
                    onRefresh();
                }else{
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有内容，点击屏幕刷新界面~");
                    mListView.stopRefresh();
                }
//                else {
//                    YNToastMaster.showToast(mContext, "网络未连接");
//                }
                break;
        }
    }

    @Override
    public void onRefresh()
    {
        if (!YNBaseActivity.isConnectNet) {
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
            return;
        } else {
            UserHttpUtils.newInstance()
                         .getFindFirstPage(getActivity(),
                                           YNCommonConfig.GET_FIND_FIRST_PAGE_URL,
                                           userId,
                                           1,
                                           mHandler,
                                           YNCommonConfig.GET_FIND_FIRST_PAGE_FLAG,
                                           true);
        }
    }

    @Override
    public void onLoadMore()
    {
    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime(DateUtil.getNowDate());
    }

    class FindFinancialListViewAdapter
            extends BaseAdapter

    {
        private Context                mContext;
        //所有的分类数据
        private List<FindCategaryBean> categaryList;
        //水平滚动的数据集合单独传进来处理
        List<FindCategaryBean> Data2Beans;
        private LinearLayout   mLinearLayout;

        public FindFinancialListViewAdapter(Context mContext,
                                            List<FindCategaryBean> categary,
                                            List<FindCategaryBean> Data2Beans)
        {
            this.mContext = mContext;
            this.categaryList = categary;

            this.Data2Beans = Data2Beans;
        }
        public void updataData( List<FindCategaryBean> data){
            this.categaryList = data;
            notifyDataSetChanged();
        }
        @Override
        public int getCount() {

            if (categaryList != null) {

                return categaryList.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int i) {
            if (categaryList != null) {
                return categaryList.get(i);
            }
            return null;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        /***listview不同条目总类****/
        @Override
        public int getItemViewType(int position) {
            if (("title1").equals(categaryList.get(position)
                                              .getName()))
            {
                return 0;
            } else if (("1").equals(categaryList.get(position)
                                                .getName()))
            {
                return 1;
            } else if (("2").equals(categaryList.get(position)
                                                .getName()))
            {
                return 2;
            } else if (("title2").equals(categaryList.get(position)
                                                     .getName()))
            {
                return 3;
            } else if (("4").equals(categaryList.get(position)
                                                .getName()))
            {
                return 4;
            }
            return super.getItemViewType(position);
        }

        @Override
        public int getViewTypeCount() {
            if (categaryList != null) {
                return 5;
            }
            return 0;
        }

        /***listview不同条目总类****/

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup)
        {
            final FindCategaryBean liveType     = categaryList.get(i);
            int                    itemViewType = getItemViewType(i);
            if (itemViewType == 1) {
                ViewHolderOne holder;
                if (view == null) {
                    view = LayoutInflater.from(mContext)
                                         .inflate(R.layout.findfinancial_listview_item, null);
                    //  AutoUtils.auto(view);
                    holder = new ViewHolderOne();
                    holder.rightLl = (RelativeLayout) view.findViewById(R.id.right_relativelayout);
                    holder.leftPicture = (ImageView) view.findViewById(R.id.find_financial_listview_leftIvItem);
                    holder.content = (TextView) view.findViewById(R.id.find_financial_listview_middleTItem);
                    holder.author = (TextView) view.findViewById(R.id.author_name);
                    holder.PublishTime = (TextView) view.findViewById(R.id.publish_time);
                    holder.readPeople = (TextView) view.findViewById(R.id.hao_many_people_readed);
                    holder.paycoin = (TextView) view.findViewById(R.id.pay_coin);
                    holder.moreContent = (ImageView) view.findViewById(R.id.more_content);
                    view.setTag(holder);
                } else {
                    holder = (ViewHolderOne) view.getTag();
                }

                holder.content.setText(categaryList.get(i)
                                                   .getTitle());
                holder.author.setText(categaryList.get(i)
                                                  .getUsername());
                holder.PublishTime.setText(DateUtil.timeStamp2StringSHort(categaryList.get(i)
                                                                                      .getTime()));
                holder.readPeople.setText(categaryList.get(i)
                                                      .getView() + "阅读");
                //需要付费而且未购买才显示出来
                if (categaryList.get(i)
                                .getIs_pay()
                                .equals("1") && categaryList.get(i)
                                                            .getIs_purchase() == 0)
                {
                    holder.paycoin.setVisibility(View.VISIBLE);
                    holder.paycoin.setText(categaryList.get(i)
                                                       .getPayCoin() + "金币");
                } else {
                    holder.paycoin.setVisibility(View.GONE);
                }
                //左边显示是文章里面图片
                if( categaryList.get(i)
                                .getPicture0()!=null){
                    holder.leftPicture.setVisibility(View.VISIBLE);
                    YNImageLoaderUtil.setImage(getActivity(),
                                               holder.leftPicture,
                                               categaryList.get(i)
                                                           .getPicture0());
                }else{
                    holder.leftPicture.setVisibility(View.GONE);
                }

                //点击不同地方响应事件
               /* holder.leftPicture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(mContext, FindAnchorHomeActivity.class);
                        intent.putExtra("userId",
                                        categaryList.get(i)
                                                    .getUserid());
                        mContext.startActivity(intent);
                    }
                });*/
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //文章设置是收费而且未购买才弹出购买框
                        if (categaryList.get(i)
                                        .getIs_pay()
                                        .equals("0") || categaryList.get(i)
                                                                    .getIs_purchase() == 1)
                        {
                            Intent intent = new Intent(mContext, ArticalDetailsActivity.class);
                            intent.putExtra("aid",
                                            categaryList.get(i)
                                                        .getId());
                            mContext.startActivity(intent);
                        } else {
                            //登录了才能判断
                            if (AccountUtils.getLoginInfo()) {
                                //需要购买,如果是自己发表的文章那个就不需要支付了
                                if (AccountUtils.getAccountBean()
                                                .getId()
                                                .equals(categaryList.get(i)
                                                                    .getUserid()))
                                {
                                    Intent intent = new Intent(getActivity(),
                                                               ArticalDetailsActivity.class);
                                    intent.putExtra("aid",
                                                    categaryList.get(i)
                                                                .getId());
                                    startActivity(intent);
                                } else {
                                    //需要购买才能进入文章详情
                                    showBuyDialog(categaryList.get(i)
                                                              .getPayCoin(),
                                                  categaryList.get(i)
                                                              .getId());
                                }

                            } else {
                                //跳转到登录界面
                                Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                                startActivity(intent);
                            }
                        }
                    }

                });


            } else if (itemViewType == 2) {
                ViewHolderTwo holder =null;
                if (view == null) {
                    view = LayoutInflater.from(mContext)
                                         .inflate(R.layout.findfinancial_listview_item02, null);
                    //  AutoUtils.auto(view);
                    holder = new ViewHolderTwo();
                    GridView  gridView = (GridView) view.findViewById(R.id.gridleview);
                    MyAdapter adapter  =new MyAdapter(Data2Beans);
                    gridView.setAdapter(adapter);

                    //    mLinearLayout = (LinearLayout) view.findViewById(R.id.horizontalScrollView_LinearLayout);
                    //mMImgIds = new int[] {R.drawable.pic_nine, R.drawable.pic_nine, R.drawable.pic_nine, R.drawable.pic_nine};

                 /*   for (int j= 0; j < Data2Beans.size(); j++)
                    {
                        View hzItemView= LayoutInflater.from(mContext).inflate(R.layout.horizental_scroller_item, null);
                        //AutoUtils.auto(hzItemView);
                        ImageView iv= (ImageView) hzItemView.findViewById(R.id.horizontal_scrollerview_item_iv);
                        mStatuiv = (ImageView) hzItemView.findViewById(R.id.live_state_iv);
                        TextView describle= (TextView) hzItemView.findViewById(R.id.horizontal_scrollerview_item_describle);
                        TextView name= (TextView) hzItemView.findViewById(R.id.horizontal_scrollerview_item_name);
                        YNImageLoaderUtil.setImage(mContext,iv,Data2Beans.get(j).getIcon());
                        final FindCategaryBean findCategaryBean = Data2Beans.get(j);
                        name.setText(findCategaryBean.getUsername());
                        describle.setText(findCategaryBean.getDescribes());
                        if(Data2Beans.get(j).getLive_status()!=null) {
                            if ("ONGOING".equals(Data2Beans.get(j)
                                          .getLive_status()))
                            {

                                mStatuiv.setImageResource(R.drawable.icon_find_live);
                            }
                        }else{
                            mStatuiv.setImageResource(R.drawable.icon_find_rest3x);
                        }

                        mLinearLayout.addView(hzItemView);
                        //点击跳转到个人页面
                        final int finalJ = j;
                        hzItemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent =new Intent(mContext, FindAnchorHomeActivity.class);
                                intent.putExtra(YNCommonConfig.USER_ID, Data2Beans.get(finalJ).getUserid());
                                mContext.startActivity(intent);

                            }
                        });

                    }
                    view.setTag(holder);
                } else {
                    holder = (ViewHolderTwo) view.getTag();*/

                }

            } else if (itemViewType == 4) {
                ViewHolderThree holder;
                if (view == null) {
                    view = LayoutInflater.from(mContext)
                                         .inflate(R.layout.findfinancial_listview_item03, null);
                    //  AutoUtils.auto(view);
                    holder = new ViewHolderThree();
                    holder.rightRl = (RelativeLayout) view.findViewById(R.id.rigth_relativell);
                    holder.leftPicture = (ImageView) view.findViewById(R.id.find_financial_listview_leftIvItem);
                    holder.author = (TextView) view.findViewById(R.id.author);
                    holder.contentTop = (TextView) view.findViewById(R.id.find_financial_listview_content);
                    holder.contentMiddle = (TextView) view.findViewById(R.id.middle_content);
                    holder.publishTime = (TextView) view.findViewById(R.id.publish_time);
                    holder.readPeople = (TextView) view.findViewById(R.id.hao_many_people_readed);
                    holder.paycoin = (TextView) view.findViewById(R.id.paycoin);
                    view.setTag(holder);
                } else {
                    holder = (ViewHolderThree) view.getTag();
                }
                holder.contentTop.setText(categaryList.get(i)
                                                      .getTitle());
                holder.contentMiddle.setText(categaryList.get(i)
                                                         .getContent());
                holder.author.setText(categaryList.get(i)
                                                  .getUsername());
                holder.publishTime.setText(DateUtil.timeStamp2StringSHort(categaryList.get(i)
                                                                                      .getTime()));
                holder.readPeople.setText(categaryList.get(i)
                                                      .getView() + "人阅读");
                //需要付费而且未购买才显示出来
                if (!categaryList.get(i)
                                 .getPayCoin()
                                 .equals("0") && categaryList.get(i)
                                                             .getIs_purchase() == 0)
                {
                    holder.paycoin.setText(categaryList.get(i)
                                                       .getPayCoin() + "金币");
                } else {
                    holder.paycoin.setVisibility(View.GONE);
                }
                YNImageLoaderUtil.setImage(mContext,
                                           holder.leftPicture,
                                           categaryList.get(i)
                                                       .getIcon());
                holder.leftPicture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(mContext, FindAnchorHomeActivity.class);
                        intent.putExtra("userId",
                                        categaryList.get(i)
                                                    .getUserid());
                        mContext.startActivity(intent);

                    }
                });
                holder.rightRl.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //判断是否需要购买(设置是收费且是未购买)
                        if (categaryList.get(i)
                                        .getIs_pay()
                                        .equals("0") || categaryList.get(i)
                                                                    .getIs_purchase() == 1)
                        {
                            Intent intent = new Intent(mContext, ArticalDetailsActivity.class);
                            intent.putExtra("aid",
                                            categaryList.get(i)
                                                        .getId());
                            mContext.startActivity(intent);
                        } else {
                            //登录了才能判断
                            if (AccountUtils.getLoginInfo()) {
                                //需要购买,如果是自己发表的文章那个就不需要支付了
                                if (AccountUtils.getAccountBean()
                                                .getId()
                                                .equals(categaryList.get(i)
                                                                    .getUserid()))
                                {
                                    Intent intent = new Intent(getActivity(),
                                                               ArticalDetailsActivity.class);
                                    intent.putExtra("aid",
                                                    categaryList.get(i)
                                                                .getId());
                                    startActivity(intent);
                                } else {
                                    //需要购买才能进入文章详情
                                    showBuyDialog(categaryList.get(i)
                                                              .getPayCoin(),
                                                  categaryList.get(i)
                                                              .getId());
                                }

                            } else {
                                //跳转到登录界面
                                Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                                startActivity(intent);
                            }
                        }
                    }
                });

                /*******两种不同标题*****/
            } else if (itemViewType == 0) {
                    view = LayoutInflater.from(mContext)
                                         .inflate(R.layout.findfinancial_listview_item_title2,
                                                  null);
                    //  AutoUtils.auto(view);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //点击跳转今日必读
                        Intent intent=new Intent(getActivity(),ExcitingArticalActivity.class);
                        intent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG,"mustReadToday");

                        startActivity(intent);
                    }
                });

            } else if (itemViewType == 3) {

                    view = LayoutInflater.from(mContext)
                                         .inflate(R.layout.findfinancial_listview_item_title1,
                                                  null);
                    //  AutoUtils.auto(view);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //点击跳转到精选热文
                        Intent intent=new Intent(getActivity(),ExcitingArticalActivity.class);
                        intent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG,"exciting");
                        startActivity(intent);
                    }
                });
            }
            /*******两种不同标题*****/
            return view;
        }
        private class ViewHolderOne {
            private RelativeLayout rightLl;
            private ImageView      leftPicture;
            private TextView       content;
            private TextView       author;
            private TextView       PublishTime;
            private TextView       readPeople;
            private TextView       paycoin;
            private ImageView      moreContent;

        }

        private class ViewHolderTwo {
            private ImageView head;
            private TextView  describle;

        }

        private class ViewHolderThree {
            private RelativeLayout rightRl;
            private ImageView      leftPicture;
            private TextView       contentTop;
            private TextView       contentMiddle;
            private TextView author;
            private TextView       publishTime;
            private TextView       readPeople;
            private TextView       paycoin;
        }

        public void showBuyDialog(final String payCoin, final String aid) {
        buytDialog = new YNPayDialog.Builder(getActivity()).setHeight(0.3f)  //屏幕高度*0.3
                                                               .setWidth(0.65f)  //屏幕宽度*0.65
                                                               .setTitleVisible(true)
                                                               .setTitleText("温馨提示")
                                                               .setTitleTextColor(R.color.black_light)
                                                               .setContentText("此文章需要付费" + payCoin + "金币，是否付费阅读？")
                                                               .setContentTextColor(R.color.black_light)
                                                               .setLeftButtonText("取消")
                                                               .setLeftButtonTextColor(R.color.ynkj_black)
                                                               .setRightButtonText("确定")
                                                               .setRightButtonTextColor(R.color.live_details_text_blue)
                                                               .setCanceledOnTouchOutside(false)
                                                               .setOnclickListener(new IDialogOnClickListener() {
                                                                   @Override
                                                                   public void clickTopLeftButton(
                                                                           View view)
                                                                   {

                                                                   }

                                                                   @Override
                                                                   public void clickTopRightButton(
                                                                           View view)
                                                                   {

                                                                   }

                                                                   //取消
                                                                   @Override
                                                                   public void clickBottomLeftButton(
                                                                           View view)
                                                                   {

                                                                       buytDialog.dismiss();
                                                                   }

                                                                   //确定
                                                                   @Override
                                                                   public void clickBottomRightButton(
                                                                           View view)
                                                                   {
                                                                       if (AccountUtils.getLoginInfo()) {
                                                                           //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                                                                           if (AccountUtils.getAccountBean()
                                                                                           .getCurrentCoin() > Integer.parseInt(
                                                                                   payCoin))
                                                                           {
                                                                               toBuyArticalaid = aid;
                                                                               toBuyArticalCoin=payCoin;
                                                                               mHandler.post(new Runnable() {
                                                                                   @Override
                                                                                   public void run()
                                                                                   {
                                                                                       UserHttpUtils.newInstance()
                                                                                                    .buyArticle(
                                                                                                            getActivity(),
                                                                                                            YNCommonConfig.BUY_ARTICLE_URL,
                                                                                                            aid,
                                                                                                            userId,
                                                                                                            Integer.parseInt(
                                                                                                                    payCoin),
                                                                                                            mHandler,
                                                                                                            YNCommonConfig.BUY_ARTICLE_FLAG,
                                                                                                            false);
                                                                                   }
                                                                               });
                                                                               buytDialog.dismiss();

                                                                           } else {
                                                                               Toast.makeText(
                                                                                       getActivity(),
                                                                                       "余额不足，请先充值再购买哦",
                                                                                       Toast.LENGTH_SHORT)
                                                                                    .show();
                                                                           }
                                                                       } else {
                                                                           Toast.makeText(mContext,
                                                                                          "请先登录哦，亲",
                                                                                          Toast.LENGTH_SHORT)
                                                                                .show();
                                                                           Intent intent = new Intent(
                                                                                   mContext,
                                                                                   YNLoginActivity.class);
                                                                           mContext.startActivity(
                                                                                   intent);
                                                                           buytDialog.dismiss();
                                                                       }
                                                                   }

                                                                   @Override
                                                                   public void clickBottomButton(
                                                                           View view)
                                                                   {

                                                                   }
                                                               })
                                                               .build();
            buytDialog.show();
           /* AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("需要支付 "+payCoin+" 金币才能进入");
            builder.setTitle("提示");
            builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //先判断是否登入了再跳转否则先登入
                    if(AccountUtils.getLoginInfo()) {
                        //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                        if(AccountUtils.getAccountBean().getCurrentCoin()>Integer.parseInt(payCoin)) {

                            toBuyArticalaid = aid;
                            mHandler.post(new Runnable() {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance()
                                                 .buyArticle(getActivity(),
                                                             YNCommonConfig.BUY_ARTICLE_URL,
                                                             aid,
                                                             userId,
                                                             Integer.parseInt(payCoin),
                                                             mHandler,
                                                             YNCommonConfig.BUY_ARTICLE_FLAG,
                                                             false);
                                }
                            });
                            dialog.dismiss();
                        }else {
                            //弹出是否跳转充值页面的对话框
                            AlertDialog.Builder builderBuy = new AlertDialog.Builder(getActivity());
                            builderBuy.setMessage("您的余额不足，请充值后再购买");
                            builderBuy.setTitle("提示");
                            builderBuy.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //跳转到充值页面
                                    Intent intent = new Intent(getActivity(), YNGoldCoinActivity.class);
                                    intent.putExtra("userbean", AccountUtils.getAccountBean());
                                    getActivity().startActivity(intent);
                                    dialog.dismiss();
                                }
                            });
                            builderBuy.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            builderBuy.create()
                                   .show();
                        }
                    }else {
                        Toast.makeText(mContext, "请先登录哦，亲", Toast.LENGTH_SHORT)
                             .show();
                        Intent intent = new Intent(mContext, YNLoginActivity.class);
                        mContext.startActivity(intent);
                        dialog.dismiss();
                    }
                }
            });
            builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.dismiss();
                }
            });
            builder.create()
                   .show();*/

        }
    }
    class  MyAdapter extends BaseAdapter{
        private     List<FindCategaryBean> Data2Beans;
        public MyAdapter(List<FindCategaryBean> data2Beans) {
            Data2Beans = data2Beans;
        }

        @Override
        public int getCount() {
            return Data2Beans.size();
        }

        @Override
        public FindCategaryBean getItem(int position) {
            return Data2Beans.get(position);

        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                convertView=  View.inflate(getActivity(),R.layout.horizental_scroller_item,null);
                ImageView              mStatuiv  = (ImageView) convertView.findViewById(R.id.live_state_iv);
                TextView               describle = (TextView) convertView.findViewById(R.id.horizontal_scrollerview_item_describle);
                TextView               name      = (TextView) convertView.findViewById(R.id.horizontal_scrollerview_item_name);
                final FindCategaryBean bean      =  Data2Beans.get(position);
                ImageView              iv        = (ImageView) convertView.findViewById(R.id.horizontal_scrollerview_item_iv);
                YNImageLoaderUtil.setImage(mContext,iv,bean.getIcon());
                name.setText(bean.getUsername());

          if(TextUtils.isEmpty(bean.getDescribes()) || bean.getDescribes()==null){
              describle.setText("这个家伙太懒什么都没有写");
             }else{
              describle.setText(bean.getDescribes());
                 }
                if(bean.getLive_status()!=null) {
                    if ("ONGOING".equals(bean
                                                 .getLive_status()))
                    {
                        mStatuiv.setImageResource(R.drawable.icon_find_live);
                    }
                }
                iv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent =new Intent(mContext, FindAnchorHomeActivity.class);
                        intent.putExtra(YNCommonConfig.USER_ID, bean.getUserid());
                        mContext.startActivity(intent);

                    }
                });


            }
            return convertView;
        }
    }

}
