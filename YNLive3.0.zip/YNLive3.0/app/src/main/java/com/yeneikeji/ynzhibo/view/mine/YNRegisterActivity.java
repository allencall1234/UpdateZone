package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 注册界面
 */
public class YNRegisterActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText edtPhoneNum;
    private TextView txtNext;
    private TextView txtFormatError;
    private LinearLayout llLeftBtn;
    private final int REGISTER_RESULT = 0;
    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
//                case REGISTER_RESULT:
//                    String password = (String) msg.obj;
//                    int resultCode = msg.arg1;
//                    switch (resultCode)
//                    {
//                        case 1:
//                            Toast.makeText(getApplicationContext(), "该用户已注册", Toast.LENGTH_SHORT).show();
//                            break;
//
//                        case 30:
//                            Toast.makeText(getApplicationContext(), "立即注册", Toast.LENGTH_SHORT).show();
//                            String phoneNum = edtPhoneNum.getText().toString();
//                            if (YNCommonUtils.isCellPhone(phoneNum))
//                            {
////                                SMSSDK.getVerificationCode("86", phoneNum);
//                                Intent intent = new Intent(getApplicationContext(), YNRegisterSetPassword.class);
//                                intent.setAction("num");
//                                intent.putExtra("num", phoneNum);
//                                startActivity(intent);
//                            }
//                            break;
//                    }
//                    break;

                case YNCommonConfig.USER_REGISTER_NEXT_STEP_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 30)
                        {
                            String phoneNum = edtPhoneNum.getText().toString();
//                            SMSSDK.getVerificationCode("86", phoneNum);
                            Intent intent = new Intent(getApplicationContext(), YNRegisterSetPasswordActivity.class);
                            intent.putExtra(YNCommonConfig.PHONE_NUMBER, phoneNum);
//                            intent.setAction("num");
//                            intent.putExtra("num", phoneNum);
                            startActivity(intent);
                            finish();
                        }

                        YNToastMaster.showToast(YNRegisterActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(YNRegisterActivity.this, getString(R.string.request_fail));
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ynregister);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        configTopBarCtrollerWithTitle("");
        getRightBtn().setVisibility(View.INVISIBLE);
        initView();
        addEvent();
        settingDo();
    }


    @Override
    public void onClick(View v)
    {

    }

    @Override
    protected void initView()
    {
        edtPhoneNum = (EditText) findViewById(R.id.edtPhoneNum);
        txtNext = (TextView) findViewById(R.id.txtNext);
        txtFormatError = (TextView) findViewById(R.id.txtFormatError);
        llLeftBtn = (LinearLayout) findViewById(R.id.star_1_com_topbar_lo_left);
    }

    protected void addEvent()
    {
        txtNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userRegisterNext(YNRegisterActivity.this, YNCommonConfig.USER_REGISTER_NEXT_URL, edtPhoneNum.getText().toString(), handler, YNCommonConfig.USER_REGISTER_NEXT_STEP_FLAG, false);
                    }
                }, 1000);
            }
        });

        edtPhoneNum.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                String num = s.toString();
                boolean isPhoneNum = YNCommonUtils.isCellPhone(num);
                if (isPhoneNum)
                {
                    txtNext.setClickable(true);
                    txtNext.setBackgroundResource(R.drawable.btn_login_selector);
                    txtFormatError.setVisibility(View.GONE);

                }
                else
                {
                    txtNext.setClickable(false);
                    txtNext.setBackgroundResource(R.drawable.btn_next_unclick);
                    txtFormatError.setVisibility(View.VISIBLE);
                }
            }
        });

        getLeftBtn().setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
//                Intent intent = new Intent(YNRegisterActivity.this, YNLoginActivity.class);
//                startActivity(intent);
                finish();
            }
        });
    }
}

