package com.yeneikeji.ynzhibo.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**这是一个保存用户简单设置的工具类
 * Created by Administrator on 2017/6/13.
 */

public class SpUtils {

    public static final String FILE_NAME = "share_data";


    public static void putPosition(Context context, int position, String name) {
        SharedPreferences        preferences = context.getSharedPreferences(FILE_NAME,
                                                                            Context.MODE_PRIVATE);
        SharedPreferences.Editor editor      = preferences.edit();
        editor.putInt(name, position);
        editor.commit();
    }

    public static int getPosition(Context context, String name) {
        SharedPreferences preferences = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        int               position    = preferences.getInt(name, 0);
        return position;
    }


    public static void putChecked(Context context, String key, boolean isChecked) {
        SharedPreferences        preferences = context.getSharedPreferences(FILE_NAME,
                                                                            Context.MODE_PRIVATE);
        SharedPreferences.Editor editor      = preferences.edit();
        editor.putBoolean(key, isChecked);
        editor.commit();
    }

    public static boolean getChecked(Context context, String key) {
        SharedPreferences preferences = context.getSharedPreferences(FILE_NAME,Context.MODE_PRIVATE);
        boolean           isChecked   = preferences.getBoolean(key, false);
        return isChecked;
    }


    public static void putIndex(Context context, String key, int index) {
        SharedPreferences        preferences = context.getSharedPreferences(FILE_NAME,
                                                                            Context.MODE_PRIVATE);
        SharedPreferences.Editor editor      = preferences.edit();
        editor.putInt(key, index);
        editor.commit();
    }

    public static int getIndex(Context context, String key) {
        SharedPreferences preferences = context.getSharedPreferences(FILE_NAME,Context.MODE_PRIVATE);
        int           index   = preferences.getInt(key, 0);
        return index;
    }


    public static void saveIconPath(Context context, String key, String path) {
        SharedPreferences        preferences = context.getSharedPreferences(FILE_NAME,
                                                                            Context.MODE_PRIVATE);
        SharedPreferences.Editor editor      = preferences.edit();
        editor.putString(key, path);
        editor.commit();
    }

    public static String getIconPath(Context context, String key) {
        SharedPreferences preferences = context.getSharedPreferences(FILE_NAME,Context.MODE_PRIVATE);
        String           path   = preferences.getString(key, "");
        return path;
    }


    /**
     * 移除某个key值已经对应的值
     * @param context
     * @param key
     */
    public static void remove(Context context, String key)
    {
        SharedPreferences sp = context.getSharedPreferences(FILE_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.remove(key);
        editor.commit();
    }

}
