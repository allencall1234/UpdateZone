package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RoomOwnerBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.live.PushStreamingActivity;
import com.yeneikeji.ynzhibo.view.mine.MyLiveActivity;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 多通道排麦直播界面
 * Created by Administrator on 2017/8/1.
 */
public class RowsWheatActivity extends YNBaseActivity implements View.OnClickListener
{
    private PullToRefreshLayout mRefreshView;
    private RelativeLayout mRLHeadView;
    private TextView mTVState;
    private TextView mTVMyLive;
    private ImageView imgBack;
    private TextView mTVRoomName;
    private TextView mTVCurrentAnchor;
    private YNCircleImageView mAnchorImg;
//    private TextView mTVRowsWheat;
    private RadioGroup mRGWheatManage;
//    private RadioButton mRBManage;
//    private RadioButton mRBWheatSort;
    private YNMyListView mLVMember;
    private Button mBtnOnWheat;
    private Button mBtnStarts;

    private CommonAdapter mRowsWheatAdapter;

//    private List<YNLiveCategrayBean> mTypeBeen;
//    private List<YNLiveCategrayBean> mClumBeen;
    private RoomOwnerBean userInfo;
    private List<RoomOwnerBean> manageList = new ArrayList<>();
    private int switchType;
    private boolean isPushStreaming;
    private UserStatusBean anchorInfo;
    boolean isStart  = false;
    private boolean isUnderWheatFlag = false;

    private LocalBroadcastManager broadcastManager;
    private BroadcastReceiver mUnderWheatReceiver;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                // 多通道房间排麦
                case YNCommonConfig.MULTICHANNEL_ROWS_WHEAT_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 227)
                        {
                            if (userInfo.getSortList() == 0)
                            {
                                isStart = false;
                                Intent intent = new Intent();
                                intent.setClass(RowsWheatActivity.this, PushStreamingActivity.class);
                                intent.putExtra(YNCommonConfig.OBJECT, anchorInfo);
                                intent.putExtra(YNCommonConfig.ISSHOW, true);
                                startActivity(intent);
                            }

                            if (switchType == 1)
                            {
                                isUnderWheatFlag = true;
                                mBtnOnWheat.setText("下麦");
                                getMultichannelAnchorInfo();
                            }
                            else
                            {
                                isUnderWheatFlag = true;
                                mBtnOnWheat.setText("下麦");
                            }

                            YNToastMaster.showToast(RowsWheatActivity.this, baseBean.getInfo());
                        }
                        if (baseBean.getCode() == 235)
                        {
                            mBtnOnWheat.setText("下麦");
                            Intent intent = new Intent();
                            intent.setClass(RowsWheatActivity.this, PushStreamingActivity.class);
                            intent.putExtra(YNCommonConfig.OBJECT, anchorInfo);
                            intent.putExtra(YNCommonConfig.ISSHOW, true);
                            startActivity(intent);
                        }
//                        else
//                        {
                            YNToastMaster.showToast(RowsWheatActivity.this, baseBean.getInfo());
//                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(RowsWheatActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.MULTICHANNEL_ROOM_USER_INFO_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 26)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONObject jsonObject1 = jsonObject.optJSONObject("data");
                                JSONArray jsonArray = jsonObject.optJSONArray("data1");
                                JSONObject jsonObject2 = jsonObject.optJSONObject("data2");

                                if (jsonObject1 != null)
                                {
                                    userInfo = YNJsonUtil.JsonToBean(jsonObject1.toString(), RoomOwnerBean.class);
                                    setUserInfo();
                                }

                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    manageList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);

                                    isFirst(manageList);
                                }

                                if (jsonObject2 != null)
                                {
                                    anchorInfo = YNJsonUtil.JsonToBean(jsonObject2.toString(), UserStatusBean.class);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {

                        }

                        mRowsWheatAdapter.updateListView(manageList);
                    }
                    else
                    {
                        YNToastMaster.showToast(RowsWheatActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 26)
                        {
                            mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONObject jsonObject1 = jsonObject.optJSONObject("data");
                                JSONArray jsonArray = jsonObject.optJSONArray("data1");
                                JSONObject jsonObject2 = jsonObject.optJSONObject("data2");

                                if (jsonObject1 != null)
                                {
                                    userInfo = YNJsonUtil.JsonToBean(jsonObject1.toString(), RoomOwnerBean.class);
                                    setUserInfo();
                                }

                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    manageList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    isFirst(manageList);
                                }

                                if (jsonObject2 != null)
                                {
                                    anchorInfo = YNJsonUtil.JsonToBean(jsonObject2.toString(), UserStatusBean.class);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                        }

                        mRowsWheatAdapter.updateListView(manageList);
                    }
                    else
                    {
                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                    }
                    break;

              /*  // 多通道房间抢麦
                case YNCommonConfig.MULTICHANNEL_ROOM_GRAB_WHEAT_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 229)
                        {
                            Intent intent = new Intent(RowsWheatActivity.this, PushStreamingActivity.class);
                            intent.putExtra(YNCommonConfig.OBJECT, AccountUtils.getUserStatus());
                            startActivity(intent);
                        }
                        else
                        {

                        }

                        YNToastMaster.showToast(RowsWheatActivity.this, baseBean.getInfo());
                    }
                    break;*/

                // 下麦
                case YNCommonConfig.MULTICHANNEL_UNDER_WHEAT_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 49)
                        {
                            isUnderWheatFlag = false;
                            mBtnOnWheat.setText("上麦");
                            getMultichannelAnchorInfo();
                        }

                        YNToastMaster.showToast(RowsWheatActivity.this, baseBean.getInfo());
                    }
                    break;

                case 0:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 26)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data1");

                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    List<RoomOwnerBean>  sort = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    isFirst(sort);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(RowsWheatActivity.this, R.string.request_fail);
                    }
                    break;

            }
            super.handleMessage(msg);
        }
    };

    /**
     * 设置用户头部信息
     */
    private void setUserInfo()
    {
        mTVRoomName.setText("房间ID : " + userInfo.getRoom_id());
        if(TextUtils.isEmpty(userInfo.getUsername()))
        {
            isPushStreaming = true;
            mTVCurrentAnchor.setText("当前麦霸 : " + "无");
            mAnchorImg.setImageResource(R.drawable.hand_wode);
        }
        else
        {
            isPushStreaming = false;
            mTVCurrentAnchor.setText("当前麦霸 : " + userInfo.getUsername());
            YNImageLoaderUtil.setImage(this, mAnchorImg, userInfo.getIcon());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rows_wheat);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {

        // mDataList = (List<List<YNLiveCategrayBean>>) getIntent().getSerializableExtra("dataList");
        //是否可以发送开播通知 1表示可以发送，2表示不可以发送
//        mTypeBeen = (List<YNLiveCategrayBean>) getIntent().getSerializableExtra("dataList1");
//        mClumBeen = (List<YNLiveCategrayBean>) getIntent().getSerializableExtra("dataList2");
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mRLHeadView = (RelativeLayout) mRefreshView.findViewById(R.id.head_view);
        mTVState = (TextView) mRLHeadView.findViewById(R.id.state_tv);
        mTVMyLive = (TextView) findViewById(R.id.tv_my_live);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        mTVRoomName = (TextView) findViewById(R.id.tv_room_name);
        mTVCurrentAnchor = (TextView) findViewById(R.id.tv_current_anchor);
        mAnchorImg = (YNCircleImageView) findViewById(R.id.iv_anchor_img);
//        mTVRowsWheat = (TextView) findViewById(R.id.tv_rows_wheat);
        mRGWheatManage = (RadioGroup) findViewById(R.id.radioGroup);
//        mRBManage = (RadioButton) findViewById(R.id.rb_manage);
//        mRBWheatSort = (RadioButton) findViewById(R.id.rb_wheat_sort);
        mLVMember = (YNMyListView) findViewById(R.id.lv_member);
        mBtnOnWheat = (Button) findViewById(R.id.btn_on_wheat);
        mBtnStarts = (Button) findViewById(R.id.btn_start);

        mTVState.setTextColor(ContextCompat.getColor(this, R.color.live_hot_text_color));

        isPushStreaming = AccountUtils.getUserStatus().getLiving_status() == 0 ? true : false;

        if (AccountUtils.getUserStatus().getIs_sort() == 1)
        {
            isUnderWheatFlag = true;
            mBtnOnWheat.setText("下麦");
        }
        else
        {
            isUnderWheatFlag = false;
            mBtnOnWheat.setText("上麦");
        }

    }

    @Override
    protected void onResume()
    {
        broadcastManager = LocalBroadcastManager.getInstance(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(YNCommonConfig.UNDER_WHEAT_FLAG);
        mUnderWheatReceiver= new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent)
            {
                mBtnStarts.setVisibility(View.GONE);
                getMultichannelAnchorInfo();
                isUnderWheatFlag = true;
                mBtnOnWheat.setText("下麦");
            }
        };
        broadcastManager.registerReceiver(mUnderWheatReceiver, intentFilter);
        super.onResume();
    }

    @Override
    protected void addEvent()
    {
        mTVMyLive.setOnClickListener(this);
        imgBack.setOnClickListener(this);
//        mTVRowsWheat.setOnClickListener(this);
        mBtnOnWheat.setOnClickListener(this);
        mBtnStarts.setOnClickListener(this);

        mRGWheatManage.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch (checkedId)
                {
                    case R.id.rb_manage:
                        switchType = 0;
                        break;

                    case R.id.rb_wheat_sort:
                        switchType = 1;
                        break;
                }
                if (!manageList.isEmpty())
                {
                    manageList.clear();
                }

                getMultichannelAnchorInfo();
            }
        });
    }

    @Override
    protected void settingDo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().multichannelLivingInfo(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_ROOM_USER_INFO_URL, AccountUtils.getAccountBean().getId(), 1,
                        mHandler, 0, false);
            }
        });

//        if (AccountUtils.getUserStatus().getLiving_status() == 0)
//        {
//            mTVRoomName.setText("房间ID : " + AccountUtils.getUserStatus().getId());
//            mTVCurrentAnchor.setText("当前麦霸 : 无" );
//            mAnchorImg.setImageResource(R.drawable.hand_wode);
//        }
//        else
//        {
            getMultichannelAnchorInfo();
//        }

//        AccountUtils.getUserStatus().setUserid();

        mRowsWheatAdapter = new CommonAdapter<RoomOwnerBean>(this, manageList, R.layout.item_rows_wheat)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, RoomOwnerBean item)
            {
                viewHolder.setImage(RowsWheatActivity.this, R.id.iv_item_anchor_img, item.getIcon());
                viewHolder.setText(R.id.tv_item_anchor_name, item.getUsername());
                if (switchType == 0)
                {
                    viewHolder.getView(R.id.tv_role_name).setVisibility(View.VISIBLE);
                    viewHolder.getView(R.id.tv_sort).setVisibility(View.GONE);
                    if (Integer.parseInt(item.getType()) == 2)
                    {
                        viewHolder.setText(R.id.tv_role_name, "房主");
                        viewHolder.setTextBackground(R.id.tv_role_name, R.drawable.yelllow_frame);
                    }
                    if (Integer.parseInt(item.getType()) == 1)
                    {
                        viewHolder.setText(R.id.tv_role_name, "副房主");
                        viewHolder.setTextBackground(R.id.tv_role_name, R.drawable.gray_frame);
                    }
                    if (Integer.parseInt(item.getType()) == 0)
                    {
                        viewHolder.setText(R.id.tv_role_name, "房管");
                        viewHolder.setTextBackground(R.id.tv_role_name, R.drawable.blue_frame);
                    }
                }
                else
                {
                    viewHolder.getView(R.id.tv_role_name).setVisibility(View.GONE);
                    viewHolder.getView(R.id.tv_sort).setVisibility(View.VISIBLE);
                    viewHolder.setText(R.id.tv_sort, item.getSort() + "");
                }
            }
        };

        mLVMember.setAdapter(mRowsWheatAdapter);

        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        UserHttpUtils.newInstance().multichannelLivingInfo(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_ROOM_USER_INFO_URL, AccountUtils.getAccountBean().getId(), switchType,
                                mHandler, YNCommonConfig.ON_REFRESH, true);
                    }
                });
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });

       /* if (switchType == 1)
        {
            for (RoomOwnerBean sortList : manageList)
            {
                if (sortList.getUserid().equals(AccountUtils.getAccountBean().getId()) && sortList.getSort() == 1)
                {
                    isStart = true;
                    mBtnStarts.setVisibility(View.VISIBLE);
                    break;
                }
            }
        }*/
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    /**
     * 获取多通道用户信息
     */
    private void getMultichannelAnchorInfo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().multichannelLivingInfo(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_ROOM_USER_INFO_URL, AccountUtils.getAccountBean().getId(), switchType,
                        mHandler, YNCommonConfig.MULTICHANNEL_ROOM_USER_INFO_FLAG, true);
            }
        });
    }

    /**
     * 多通道房间排麦
     */
    private void multichannelRowsWheat()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().multichannelRowsWheat(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_ROWS_WHEAT_URL, AccountUtils.getAccountBean().getId(),
                        mHandler, YNCommonConfig.MULTICHANNEL_ROWS_WHEAT_FLAG, true);
            }
        });
    }

    /**
     * 多通道房间下麦
     */
    private void multichannelUnderWheat()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().multichannelUnderWheat(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_UNDER_WHEAT_URL, AccountUtils.getAccountBean().getId(),
                        mHandler, YNCommonConfig.MULTICHANNEL_UNDER_WHEAT_FLAG, true);
            }
        });
    }

    private void isFirst(List<RoomOwnerBean> list)
    {
        if (switchType == 1) {
            for (RoomOwnerBean sortList : list)
            {
                if (list.size() == 1)
                {
                    if (sortList.getSort() == 1 && sortList.getUserid().equals(AccountUtils.getAccountBean().getId()))
                    {
                        isStart = true;
                        break;
                    }
                }
                else{
                    if (sortList.getSort() == 1 && sortList.getUserid().equals(AccountUtils.getAccountBean().getId()))
                    {
                        isStart = true;
                        break;
                    }
                }
            }

            if (isStart)
            {
                mBtnStarts.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void onDestroy() {
        broadcastManager.unregisterReceiver(mUnderWheatReceiver);
        super.onDestroy();
    }

    /**
     * 多通道房间抢麦
     */
   /* private void multichannelGrabWheat()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().multichannelGrabWheat(RowsWheatActivity.this, YNCommonConfig.MULTICHANNEL_ROOM_GRAB_WHEAT_URL, anchorId,
                        mHandler, YNCommonConfig.MULTICHANNEL_ROOM_GRAB_WHEAT_FLAG, true);
            }
        });
    }*/

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.imgBack:
                finish();
                break;

            case R.id.tv_my_live:
                intent.setClass(this, MyLiveActivity.class);
                startActivity(intent);
                break;

          /*  // 排麦
            case R.id.tv_rows_wheat:
                multichannelRowsWheat();
                break;*/

            // 下麦
            case R.id.btn_on_wheat:
                if (!isUnderWheatFlag)
                {
                    if (isPushStreaming && userInfo.getSortList() == 0)
                    {
                        multichannelRowsWheat();
                    }
                    else
                    {
                        if (switchType == 1)
                        {
                            if (isStart)
                            {
//                                mBtnStarts.setVisibility(View.GONE);
                                intent.setClass(RowsWheatActivity.this, PushStreamingActivity.class);
                                intent.putExtra(YNCommonConfig.OBJECT, anchorInfo);
                                startActivity(intent);
                            }
                            else
                            {
                                multichannelRowsWheat();
                            }
                        }
                        else
                        {
                            multichannelRowsWheat();
                        }
                    }
                }
                else
                {
                    mBtnStarts.setVisibility(View.GONE);
                    // 下麦
                    multichannelUnderWheat();
                }
                break;

            case R.id.btn_start:
                isStart = false;
                intent.setClass(RowsWheatActivity.this, PushStreamingActivity.class);
                intent.putExtra(YNCommonConfig.OBJECT, anchorInfo);
                intent.putExtra(YNCommonConfig.ISSHOW, true);
                startActivity(intent);
                break;
        }
    }
}
