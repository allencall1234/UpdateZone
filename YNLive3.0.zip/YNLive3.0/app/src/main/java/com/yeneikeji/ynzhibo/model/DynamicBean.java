package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * 社区首页实体类
 * Created by Administrator on 2017/1/5.
 */
public class DynamicBean extends BaseBean
{
    private String id;
    private String userid;
    private String icon;
    private String content;
    private String username;
    private int comment_num;
    private int zan_num;
    private String time;
    private List<PhotoInfoBean> picture;
    private int thumb;
    private int is_attention;
    private String picture0;
    private String picture1;
    private String picture2;
    private String picture3;
    private String picture4;
    private String picture5;
    private String picture6;
    private String picture7;
    private String picture8;
    private String smallpicture0;
    private String smallpicture1;
    private String smallpicture2;
    private String smallpicture3;
    private String smallpicture4;
    private String smallpicture5;
    private String smallpicture6;
    private String smallpicture7;
    private String smallpicture8;

    public DynamicBean() {
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getComment_num() {
        return comment_num;
    }

    public void setComment_num(int comment_num)
    {
        this.comment_num = comment_num;
    }

    public int getZan_num() {
        return zan_num;
    }

    public void setZan_num(int zan_num) {
        this.zan_num = zan_num;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public List<PhotoInfoBean> getPicture() {
        return picture;
    }

    public void setPicture(List<PhotoInfoBean> picture) {
        this.picture = picture;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getThumb() {
        return thumb;
    }

    public void setThumb(int thumb) {
        this.thumb = thumb;
    }

    public int getIs_attention() {
        return is_attention;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }

    public String getPicture0() {
        return picture0;
    }

    public void setPicture0(String picture0) {
        this.picture0 = picture0;
    }

    public String getPicture1() {
        return picture1;
    }

    public void setPicture1(String picture1) {
        this.picture1 = picture1;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getPicture3() {
        return picture3;
    }

    public void setPicture3(String picture3) {
        this.picture3 = picture3;
    }

    public String getPicture4() {
        return picture4;
    }

    public void setPicture4(String picture4) {
        this.picture4 = picture4;
    }

    public String getPicture5() {
        return picture5;
    }

    public void setPicture5(String picture5) {
        this.picture5 = picture5;
    }

    public String getPicture6() {
        return picture6;
    }

    public void setPicture6(String picture6) {
        this.picture6 = picture6;
    }

    public String getPicture7() {
        return picture7;
    }

    public void setPicture7(String picture7) {
        this.picture7 = picture7;
    }

    public String getPicture8() {
        return picture8;
    }

    public void setPicture8(String picture8) {
        this.picture8 = picture8;
    }

    public String getSmallpicture0() {
        return smallpicture0;
    }

    public void setSmallpicture0(String smallpicture0) {
        this.smallpicture0 = smallpicture0;
    }

    public String getSmallpicture1() {
        return smallpicture1;
    }

    public void setSmallpicture1(String smallpicture1) {
        this.smallpicture1 = smallpicture1;
    }

    public String getSmallpicture2() {
        return smallpicture2;
    }

    public void setSmallpicture2(String smallpicture2) {
        this.smallpicture2 = smallpicture2;
    }

    public String getSmallpicture3() {
        return smallpicture3;
    }

    public void setSmallpicture3(String smallpicture3) {
        this.smallpicture3 = smallpicture3;
    }

    public String getSmallpicture4() {
        return smallpicture4;
    }

    public void setSmallpicture4(String smallpicture4) {
        this.smallpicture4 = smallpicture4;
    }

    public String getSmallpicture5() {
        return smallpicture5;
    }

    public void setSmallpicture5(String smallpicture5) {
        this.smallpicture5 = smallpicture5;
    }

    public String getSmallpicture6() {
        return smallpicture6;
    }

    public void setSmallpicture6(String smallpicture6) {
        this.smallpicture6 = smallpicture6;
    }

    public String getSmallpicture7() {
        return smallpicture7;
    }

    public void setSmallpicture7(String smallpicture7) {
        this.smallpicture7 = smallpicture7;
    }

    public String getSmallpicture8() {
        return smallpicture8;
    }

    public void setSmallpicture8(String smallpicture8) {
        this.smallpicture8 = smallpicture8;
    }
}
