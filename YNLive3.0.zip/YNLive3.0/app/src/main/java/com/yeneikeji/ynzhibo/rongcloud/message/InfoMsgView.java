package com.yeneikeji.ynzhibo.rongcloud.message;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.rongcloud.EmojiManager;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

import io.rong.imlib.model.MessageContent;
import io.rong.message.InformationNotificationMessage;

public class InfoMsgView extends BaseMsgView
{
    public TextView username;
    private TextView infoText;

    public InfoMsgView(Context context)
    {
        super(context);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.msg_info_view, this);
        username = (TextView) view.findViewById(R.id.tv_user);
        infoText = (TextView) view.findViewById(R.id.info_text);
    }

    @Override
    public void setContent(MessageContent msgContent)
    {
        YNLogUtil.e("InfoMsg", msgContent.toString());
        InformationNotificationMessage msg = (InformationNotificationMessage) msgContent;
        if (!TextUtils.isEmpty(msg.getExtra()))
            YNLogUtil.e("cdy聊天室提示消息", msg.getExtra());

        if (msg.getUserInfo() != null)
        {
            username.setText(msg.getUserInfo().getName() + "");
        }
        username.setVisibility(GONE);
//        username.setText("");
        infoText.setText(EmojiManager.parse(msg.getMessage(), infoText.getTextSize()));
    }
}
