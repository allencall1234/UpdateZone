package com.yeneikeji.ynzhibo.interfaces;

/**
 * Created by Administrator on 2016/11/29.
 */
public interface IListViewItemListener
{
    void onItemClick(int position);
    boolean onItemLongClick(int position);
}
