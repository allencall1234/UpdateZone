package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 *  消息界面
 * Created by Administrator on 2016/11/25.
 */
public class MessageActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout mRLComment;
    private RelativeLayout mRLThumb;
    private RelativeLayout mRLPrivateLetter;
    private TextView mCommentNum;
    private TextView mThumbNum;
    private TextView mPrivateLetterNum;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.msg));

        mRLComment = (RelativeLayout) findViewById(R.id.rl_comment);
        mRLThumb = (RelativeLayout) findViewById(R.id.rl_thumb);
        mRLPrivateLetter = (RelativeLayout) findViewById(R.id.rl_private_letter);
        mCommentNum = (TextView) findViewById(R.id.tv_comment_num);
        mThumbNum = (TextView) findViewById(R.id.tv_thumb_num);
        mPrivateLetterNum = (TextView) findViewById(R.id.tv_private_letter_num);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLComment.setOnClickListener(this);
        mRLThumb.setOnClickListener(this);
        mRLPrivateLetter.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.rl_comment:
                intent.setClass(this, CommentListActivity.class);
                intent.putExtra(YNCommonConfig.ISSHOW, true);
                startActivity(intent);
                break;

            case R.id.rl_thumb:
                intent.setClass(this, PraiseListActivity.class);
                intent.putExtra(YNCommonConfig.ISSHOW, false);
                startActivity(intent);
                break;

            case R.id.rl_private_letter:
                intent.setClass(this, PrivateMessageActivity.class);
                startActivity(intent);
                break;
        }

    }

}
