package com.yeneikeji.ynzhibo.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;


public class AccountUtils {

    private final static String SP_NAME ="accountInfo";

    public static Context mContext;

    public static void init(Context mContext){
       AccountUtils.mContext = mContext;
    }

    /**
     * 保存用户信息
     * @param bean 用户信息Bean
     */
    public static void saveAccountBean(UserInfoBean bean)
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        // 将JSONObject 对象转换为String字符串
        String userInfo = new Gson().toJson(bean);
        editor.putString("userInfo",userInfo);
        editor.commit();
    }

    /**
     * 获取用户信息
     */
    public static UserInfoBean getAccountBean(){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        // 获取的用户信息字符串
        String userInfo = sp.getString("userInfo","");
        // 将获取的用户信息字符串重新格式化为UserInfoBean类  确保Gson格式化的数据不为空，否则报空指针
        if(TextUtils.isEmpty(userInfo)){
            return null;
        }else{
            return new Gson().fromJson(userInfo, UserInfoBean.class);
        }

    }

    /**
     * 保存登录状态
     */
    public static void saveLogin(boolean isLogin){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isLogin",isLogin);
        editor.commit();

    }

    /**
     * 获取登录状态
     * @return 是否登录
     */
    public static Boolean getLoginInfo(){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        return sp.getBoolean("isLogin",false);
    }

    /**
     * 保存分享地址
     * @param address
     */
    public static void saveShareAddress(String address)
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("shareAddress", address);
        editor.commit();
    }

    /**
     * 获取分享地址
     * @return
     */
    public static String getShareAddress()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        return sp.getString("shareAddress", "");
    }

    /**
     * 保存设置中的推送状态
     */
    public static void savePushStatus (boolean isOpen){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isOpen",isOpen);
        editor.commit();
    }

    /**
     * 获取设置中的推送状态
     */
    public static Boolean getPushStatus()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        return sp.getBoolean("isOpen", true);
    }

    /**
     * @return
     */
    public static PersonInfoBean getLocalPerson(){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        // 获取的用户信息字符串
        String localInfo = sp.getString("localPerson","");
        // 将获取的用户信息字符串重新格式化为PersonInfoBean类  确保Gson格式化的数据不为空，否则报空指针
        if(TextUtils.isEmpty(localInfo)){
            return null;
        }else{
            return new Gson().fromJson(localInfo, PersonInfoBean.class);
        }
    }

    /**
     * 保存用户信息
     * @param bean 用户信息Bean
     */
    public static void saveLocalPerson(PersonInfoBean bean){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        // 将JSONObject 对象转换为String字符串
        String localPerson = new Gson().toJson(bean);
        editor.putString("localPerson",localPerson);
        editor.commit();

    }

    /**
     * 保存用户状态信息如是否是主播，是否被认证，是否被禁播
     * @param bean 用户信息Bean
     */
    public static void saveUserStatus(UserStatusBean bean){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        // 将JSONObject 对象转换为String字符串
        String userStatus = new Gson().toJson(bean);
        editor.putString("userStatus",userStatus);
        editor.commit();

    }

    /**
     *获取用户状态信息
     * @return
     */
    public static UserStatusBean getUserStatus(){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        // 获取的用户信息字符串
        String userStatus = sp.getString("userStatus","");
        // 将获取的用户信息字符串重新格式化为PersonInfoBean类  确保Gson格式化的数据不为空，否则报空指针
        if(TextUtils.isEmpty(userStatus)){
            return null;
        }else{
            return new Gson().fromJson(userStatus, UserStatusBean.class);
        }
    }

    /**
     * 保存我要直播用户填写信息
     * @param liveRoomBean
     */
    public static void savaLiveHostInfo(LiveRoomBean liveRoomBean)
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String liveHostInfo = new Gson().toJson(liveRoomBean);
        editor.putString("LiveRoomBean",liveHostInfo);
        editor.commit();
    }

    /**
     * 获取主播直播时填写的信息
     * @return
     */
    public static LiveRoomBean getLiveHostInfo()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        String liveHostInfo = sp.getString("LiveRoomBean","");
        if(TextUtils.isEmpty(liveHostInfo))
        {
            return null;
        }
        else
        {
            return new Gson().fromJson(liveHostInfo, LiveRoomBean.class);
        }
    }

    /**
     * 保存发布动态草稿信息
     * @param dynamicBean
     */
    public static void savaDynamicContent(DynamicBean dynamicBean)
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String dynamicContent = new Gson().toJson(dynamicBean);
        editor.putString("NewDynamicBean", dynamicContent);
        editor.commit();
    }

    /**
     * 获取发布动态草稿信息
     * @return
     */
    public static DynamicBean getDynamicContent()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        String dynamicContent = sp.getString("NewDynamicBean","");
        if(TextUtils.isEmpty(dynamicContent))
        {
            return null;
        }
        else
        {
            return new Gson().fromJson(dynamicContent, DynamicBean.class);
        }
    }

/*
    */
/**
     * 保存极光别名状态
     *//*

    public static void saveSetAliasStatus (boolean isSetting){
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("JPush_Alias",isSetting);
        editor.commit();
    }

    */
/**
     * 获取极光别名状态
     *//*

    public static Boolean getSetAliasStatus()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        return sp.getBoolean("JPush_Alias", false);
    }
*/

    /**
     * 保存极光别名
     */
    public static void saveSetAlias (String alias)
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("Alias",alias);
        editor.commit();
    }

    /**
     * 获取极光别名
     */
    public static String getSetAlias()
    {
        SharedPreferences sp = mContext.getSharedPreferences(SP_NAME,Context.MODE_PRIVATE);
        return sp.getString("Alias", "");
    }

}
