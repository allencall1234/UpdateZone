package com.yeneikeji.ynzhibo.view.live;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNFragmentAdapter;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;

/**
 * 直播类别界面
 * Created by Administrator on 2016/11/2.
 */
public class LiveTypeActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
//    private Toolbar toolbar;
//    private ImageView mIVBack;
    private ViewPager mLiveVP;
    private TabLayout tabs;
    private String title;
    private int position;

    private YNFragmentAdapter mAdapter;

    /** Tab标题 */
    private  String[] tabTitle =  null;

    private ArrayList<Fragment> fragments;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_type);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        position = getIntent().getIntExtra(YNCommonConfig.POSITION, position);
//        title = getIntent().getStringExtra(YNCommonConfig.TITLE);
        configTopBarCtrollerWithTitle(getString(R.string.tab_live));
        tabTitle = getResources().getStringArray(R.array.LiveColumnTitles);

//        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
//        mIVBack = (ImageView) view.findViewById(R.id.iv_back);
        mLiveVP = (ViewPager) view.findViewById(R.id.view_pager);
        tabs = (TabLayout) view.findViewById(R.id.tabs);

        tabs.setTabMode (TabLayout.MODE_SCROLLABLE);
        tabs.setTabGravity(TabLayout.GRAVITY_CENTER);
        tabs.setupWithViewPager(mLiveVP, true);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
//        mIVBack.setOnClickListener(this);

        mLiveVP.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
        {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position)
            {


            }

            @Override
            public void onPageScrollStateChanged(int state)
            {

            }
        });
    }

    @Override
    protected void settingDo()
    {
        addFragment();
        mLiveVP.setCurrentItem(position + 1, true);
    }

    /**
     * 初始化Fragment
     */
    private void addFragment()
    {
        fragments = new ArrayList<Fragment>();
        fragments.clear();//清空
        int count =  tabTitle.length;
        for(int i = 0; i< count; i++)
        {
            LiveListFragment fragment= new LiveListFragment();
            fragment.setmTag(tabTitle[i]);
            fragments.add(fragment);
        }

        mAdapter = new YNFragmentAdapter(getSupportFragmentManager(), fragments, tabTitle);
        mLiveVP.setAdapter(mAdapter);
        mLiveVP.setOffscreenPageLimit(count);
        mLiveVP.setCurrentItem(0, false);
        UIUtils.dynamicSetTabLayoutMode(tabs);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    /*  private class LiveTypeFragmentAdapter extends FragmentStatePagerAdapter
    {
        private FragmentManager fm;
        private String[] titles;

        public LiveTypeFragmentAdapter(FragmentManager fm, String[] titles)
        {
            super(fm);
            this.fm = fm;
            this.titles = titles;
        }

        @Override
        public CharSequence getPageTitle(int position)
        {
            return titles[position % titles.length];
        }

        @Override
        public int getCount() {
            return titles.length;
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position)
        {
            Bundle bundle=new Bundle();
            bundle.putString(YNCommonConfig.TITLE, titles[position]);
            return LiveListFragment.newInstance(bundle);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object)
        {

        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position)
        {
            Object obj = super.instantiateItem(container, position);
            return obj;
        }
    }*/

}
