package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 *  编辑评论界面
 * Created by Administrator on 2016/11/24.
 */
public class EditCommentActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mEditComment;

    private YNCommonDialog dialog;

    private boolean isComment;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_comment);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        isComment = getIntent().getBooleanExtra(YNCommonConfig.ISCOMMENT, isComment);
        configTopBarCtrollerWithTitle(getString(R.string.my_comment));
        getLeftBtn().setVisibility(View.GONE);
        getLeftTV().setVisibility(View.VISIBLE);
        getLeftTV().setText(getString(R.string.cancel));
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.send));

        mEditComment = (EditText) findViewById(R.id.et_edit_comment);

        mEditComment.setHint(isComment ? "评论 从你的全世界路过" : "回复 @人生若只如初见" );
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightBtn().setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                dialog = new YNCommonDialog(this, R.style.transparentFrameWindowStyle, getString(R.string.give_up_edit_notice), getString(R.string.give_up), getString(R.string.continue_to_edit), false, new YNCommonDialog.CustomDialogListener() {
                    @Override
                    public void OnClick(View view)
                    {
                        switch (view.getId())
                        {
                            case R.id.btnCancel:
                                dialog.dismiss();
                                finish();
                                break;

                            case R.id.btnConfirm:
                                dialog.dismiss();
                                break;
                        }
                    }
                });
                dialog.show();
                break;

            case R.id.star_1_com_topbar_lo_right:
                if (TextUtils.isEmpty(mEditComment.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, getString(R.string.my_comment_notice));
                    return;
                }
                break;
        }
    }
}
