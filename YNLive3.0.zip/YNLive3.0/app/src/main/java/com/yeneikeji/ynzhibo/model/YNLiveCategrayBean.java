package com.yeneikeji.ynzhibo.model;

/**
 * Created by Administrator on 2017/6/15.
 */

public class YNLiveCategrayBean extends BaseBean {

            public String id;
            public String pid;
            public String name;
            public int numb;

}

