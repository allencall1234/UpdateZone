package com.yeneikeji.ynzhibo.view.community;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.weigan.loopview.LoopView;
import com.weigan.loopview.OnItemSelectedListener;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.ArticalDetailsBean;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;

public class ArticalDetailsActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    /*
    *
    * 这是一个文章详情页面
    * */
    private ImageView mBack;
    private Button mEvaluate;
    private TextView mTime;
    private String mAid;
    private TextView mTitle;
    private TextView mReadNumb;
    private Dialog dialog;
    private View inflate;
    private WindowManager.LayoutParams mLp;
    private ArticalDetailsBean articalDetailsBean;
    private String[] describles=new String[3];
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_ARTICAL_DETAILS_FLAG:

                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) {

                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    Gson gson=new Gson();
                                    articalDetailsBean = gson.fromJson(msg.obj.toString(),
                                                                       ArticalDetailsBean.class);

                                    if(articalDetailsBean.getData()!=null) {
                                        //由于图片和描述不在一个数组里面 把对图片的描述用数组装起来
                                        describles[0]=articalDetailsBean.getData().getDescribe0();
                                        describles[1]=articalDetailsBean.getData().getDescribe1();
                                        describles[2]=articalDetailsBean.getData().getDescribe2();

                                        mTitle.setText(articalDetailsBean.getData().getTitle());
                                        mTime.setText(DateUtil.timeStamp2StringSHort(articalDetailsBean.getData().getTime()));
                                        mReadNumb.setText("阅读数："+articalDetailsBean.getData().getView());
                                        mContent.setText(articalDetailsBean.getData().getContent());
                                        mAuthorName.setText(articalDetailsBean.getData().getUsername());
                                        YNImageLoaderUtil.setImage(ArticalDetailsActivity.this,mHeadiv,articalDetailsBean.getData().getIcon());
                                        switch (articalDetailsBean.getData().getKind()) {
                                            case 1:
                                                mArticalType.setText("金融");
                                                 break;
                                            case 2:
                                                mArticalType.setText("家教");
                                                break;
                                        }
                                        //底部评价统计
                                        mTotalEvaluate.setText("评价 (" + articalDetailsBean.getData().getAll()+")");
                                        //好评率
                                        String goodRat=""+articalDetailsBean.getData().getGoodRat()*100;
                                        if(goodRat.length()>5){
                                            String NewgoodRat=goodRat.substring(0,5);
                                            mGoodRate.setText(NewgoodRat+"%");
                                        }else {
                                            mGoodRate.setText("好评率" + articalDetailsBean.getData()
                                                                                        .getGoodRat() * 100 + "%");
                                        }
                                        List<ArticalDetailsBean.DataBean.PictureBean> pictures = articalDetailsBean.getData().getPicture();

                                if(articalDetailsBean.getData().getis_comment()==0){
                                    mEvaluate.setClickable(true);
                                    mEvaluate.setText("立即评价");
                                    mEvaluate.setClickable(true);
                                }        else{
                                    mEvaluate.setClickable(false);
                                    mEvaluate.setText("已经评价过了");
                                    mEvaluate.setBackgroundResource(R.drawable.articaldetails_evaluate_graybg);
                                    mEvaluate.setClickable(false);
                                }
                                        MyAdapter adapter=new MyAdapter(pictures,describles);
                                        mListview.setAdapter(adapter);
                                    }
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    } else {

                    }

                    break;

                case YNCommonConfig.GET_ARTICAL_EVALUATE_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 26) {
                            Toast.makeText(ArticalDetailsActivity.this, "评价成功", Toast.LENGTH_SHORT)
                                 .show();

                            //改变评价状态
                            articalDetailsBean.getData().setis_comment(1);
                            //设置评价不可点击
                            mEvaluate.setClickable(false);
                            mEvaluate.setText("已经评价过了");
                            mEvaluate.setBackgroundResource(R.drawable.articaldetails_evaluate_graybg);
                            //总评价加1
                            mTotalEvaluate.setText("评价(" + (articalDetailsBean.getData()
                                                                           .getAll() + 1)+")");
                            //刷新好评率
                            //好评率
                            String goodRat=""+articalDetailsBean.getData().getGoodRat()*100;
                            if(goodRat.length()>5){
                                String NewgoodRat=goodRat.substring(0,5);
                                mGoodRate.setText(NewgoodRat+"%");
                            }else {
                                mGoodRate.setText("好评率" + articalDetailsBean.getData()
                                                                            .getGoodRat() * 100 + "%");
                            }

                        } else {
                            Toast.makeText(ArticalDetailsActivity.this, "已经评价过了哦，亲", Toast.LENGTH_SHORT)
                                 .show();

                        }
                    }

                    break;
            }
        }

    };
    private TextView mTotalEvaluate;
    private TextView mWellEvaluate;
    private TextView mMiddleEvaluate;
    private TextView mBadEvaluate;
    private TextView mContent;
    private LoopView mLoopView;
    private int evaluateType;
    private ListView mListview;
    private TextView mGoodRate;
    private TextView mAuthorName;
    private TextView mArticalType;
    private YNCircleImageView mHeadiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artical_details_acticity);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        mAid = getIntent().getStringExtra("aid");
        initView();
        initEvent();
        netRequest();
    }
    private void netRequest() {
        if (AccountUtils.getLoginInfo()) {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getArticalDetails(ArticalDetailsActivity.this,
                                                    YNCommonConfig.GET_ARTICAL_DETAILS_URL,
                                                    mAid,
                                                    AccountUtils.getAccountBean()
                                                                .getId(),
                                                    mHandler,
                                                    YNCommonConfig.GET_ARTICAL_DETAILS_FLAG,
                                                    true);
                }
            });
        }else{
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getArticalDetails(ArticalDetailsActivity.this,
                                                    YNCommonConfig.GET_ARTICAL_DETAILS_URL,
                                                    mAid,
                                                    "",
                                                    mHandler,
                                                    YNCommonConfig.GET_ARTICAL_DETAILS_FLAG,
                                                    true);
                }
            });
        }
    }


    protected void initView() {
        mListview = (ListView) findViewById(R.id.artical_details_listview);
        View  headView= View.inflate(this,R.layout.articaldetails_headview,null);
        View footerView= View.inflate(this,R.layout.articaldetails_footerview,null);

        mTitle = (TextView) headView.findViewById(R.id.artical_details_title);
        mTime = (TextView) headView.findViewById(R.id.top_tv_time);
        mHeadiv = (YNCircleImageView) headView.findViewById(R.id.author_head_iv);
        mAuthorName = (TextView) headView.findViewById(R.id.author_name);
        mArticalType = (TextView) headView.findViewById(R.id.artical_type);
        mContent = (TextView) headView.findViewById(R.id.artical_details_content);

        mReadNumb = (TextView) footerView.findViewById(R.id.read_people_numb);

        mTotalEvaluate = (TextView) footerView.findViewById(R.id.tv_total_evaluate);
        mWellEvaluate = (TextView) footerView.findViewById(R.id.well_evaluate);
        mMiddleEvaluate = (TextView) footerView.findViewById(R.id.just_evaluate);
        mBadEvaluate = (TextView) footerView.findViewById(R.id.bad_evaluate);
        mGoodRate = (TextView) footerView.findViewById(R.id.good_evaluate_rate);
        mEvaluate = (Button) footerView.findViewById(R.id.evaluateNow);
        mListview.addHeaderView(headView);
        mListview.addFooterView(footerView);
        mListview.setDivider(null);
    }
    private void initEvent() {
        configTopBarCtrollerWithTitle("笔记");
        getLeftBtn().setOnClickListener(this);
        mHeadiv.setOnClickListener(this);
        mEvaluate.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.author_head_iv:
                Intent intent=new Intent(ArticalDetailsActivity.this,FindAnchorHomeActivity.class);
                intent.putExtra("userId",articalDetailsBean.getData().getUserid());
                startActivity(intent);
                break;
            //评价
            case R.id.evaluateNow:
                //先判断是否登录
                if(AccountUtils.getLoginInfo()) {
                    inflate = LayoutInflater.from(this)
                                            .inflate(R.layout.dialog_evaluate, null);
                    dialog = new Dialog(this, R.style.ActionSheetDialogStyle);

                    WindowManager windowManager = getWindowManager();
                    Display       display       = windowManager.getDefaultDisplay();
                    mLp = dialog.getWindow()
                                .getAttributes();
                    mLp.width = (int) (display.getWidth()); //设置宽度
                    dialog.getWindow()
                          .setAttributes(mLp);

                    mLoopView = (LoopView) inflate.findViewById(R.id.loopview);
                    TextView cancle = (TextView) inflate.findViewById(R.id.evaluate_cancle);
                    TextView sure   = (TextView) inflate.findViewById(R.id.evaluate_sure);
                    //取消和确定的监听
                    cancle.setOnClickListener(this);
                    sure.setOnClickListener(this);
                    ArrayList<String> list = new ArrayList<>();
                    list.add("好");
                    list.add("一般");
                    list.add("差");
                    //设置是否循环播放
                    //设置数据
                    mLoopView.setItems(list);
                    mLoopView.setNotLoop();
                    //设置滚轮字体大小
                    mLoopView.setTextSize(16);
                    //滚动监听 可以知道选择了哪个评价
                    mLoopView.setListener(new OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(int index) {
                            evaluateType = index;
                        }
                    });
                    dialog.setContentView(inflate);
                    dialog.show();
                }else {
                    Toast.makeText(mContext, "请先登录哦，亲", Toast.LENGTH_SHORT)
                         .show();
                    Intent intent1 = new Intent(mContext, YNLoginActivity.class);
                    startActivity(intent1);
                }
                break;
            //评价取消
            case R.id.evaluate_cancle:
                dialog.dismiss();
                break;
            //提交评价
            case R.id.evaluate_sure:
                //对话框消失
                dialog.dismiss();
                //发送给服务器进行同步
                mHandler.post(new Runnable() {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance()
                                     .getEvaluateArtical(ArticalDetailsActivity.this,
                                                         YNCommonConfig.ARTICAL_EVALUATE_URL,
                                                         mAid,
                                                         AccountUtils.getAccountBean().getId(),
                                                         ""+(3-evaluateType),
                                                         mHandler,
                                                         YNCommonConfig.GET_ARTICAL_EVALUATE_FLAG,
                                                         true);
                    }
                });
                break;

        }
    }
    class  MyAdapter extends BaseAdapter{
        List<ArticalDetailsBean.DataBean.PictureBean> pictures;
        private String[] describles;

        public MyAdapter(List<ArticalDetailsBean.DataBean.PictureBean> pictures,
                         String[] describles)
        {
            this.pictures = pictures;
            this.describles = describles;
        }
        @Override
        public int getCount() {
            if(pictures!=null){
                return pictures.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return pictures.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if(convertView==null){
                holder=new ViewHolder();
                convertView= View.inflate(ArticalDetailsActivity.this,R.layout.articaldetail_picture_iv,null);
                holder.pictureiv= (ImageView) convertView.findViewById(R.id.artical_picture_item_iv);
                holder.describle= (TextView) convertView.findViewById(R.id.tv_describle);
                convertView.setTag(holder);
            }else{
                holder= (ViewHolder) convertView.getTag();
            }
            ArticalDetailsBean.DataBean.PictureBean pictureBean = pictures.get(position);

            YNImageLoaderUtil.setImage(ArticalDetailsActivity.this, holder.pictureiv, pictureBean.getBig());
            if(describles[position]!=null){
                holder.describle.setText(describles[position]);
            }else{
                holder.describle.setVisibility(View.GONE);
            }

            return convertView;
        }

        class  ViewHolder {
            ImageView  pictureiv;
            TextView describle;
        }
    }
}
