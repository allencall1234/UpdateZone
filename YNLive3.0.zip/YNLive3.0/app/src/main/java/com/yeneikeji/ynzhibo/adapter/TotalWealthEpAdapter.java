package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.UserWealthBean;

import java.util.List;

/**
 * Created by Administrator on 2017/4/24.
 */

public class TotalWealthEpAdapter extends BaseExpandableListAdapter {
    private  List<UserWealthBean.DataBean.YeIncomeBean> childArray;
    private Context            mContext;
    private UserWealthBean.DataBean.YeIncomeBean.MoIncomeBean mMoIncomeBean;

    public TotalWealthEpAdapter(Context context, List<UserWealthBean.DataBean.YeIncomeBean> childArray){
        mContext = context;
        this.childArray = childArray;
    }

    @Override
    public int getGroupCount() {
        if(childArray!=null){
            return childArray.size();
        }
        return 0;
    }


    @Override
    public int getChildrenCount(int groupPosition) {
        if(childArray.get(groupPosition).getMoIncome()!=null){
            return childArray.get(groupPosition).getMoIncome().size();
        }
        return 0;
    }

    @Override
    public String getGroup(int groupPosition) {
        return ""+(childArray.get(groupPosition).getYear());
    }

    @Override
    public UserWealthBean.DataBean.YeIncomeBean.MoIncomeBean getChild(int groupPosition, int childPosition) {
        return childArray.get(groupPosition).getMoIncome().get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        View view = convertView;
        GroupHolder holder = null;
        if(view == null){
            holder = new GroupHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.totalwealth_expandlist_group, null);
            holder.groupName = (TextView)view.findViewById(R.id.tv_group_name);
            holder.totalWealthTv= (TextView) view.findViewById(R.id.tv_grou_totalwealth_name);
            holder.arrow = (ImageView)view.findViewById(R.id.iv_arrow);
            view.setTag(holder);
        }else{
            holder = (GroupHolder)view.getTag();
        }

        //判断是否已经打开列表
        if(isExpanded){
            holder.arrow.setBackgroundResource(R.drawable.arrow_up);
        }else{
            holder.arrow.setBackgroundResource(R.drawable.arrow_down);
        }

        holder.groupName.setText(""+childArray.get(groupPosition).getYear());
        holder.totalWealthTv.setText("  ");
        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        View view = convertView;
        ChildHolder holder = null;
        if(view == null){
            holder = new ChildHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.totalwealth_expandlist_item, null);
            holder.childName = (TextView)view.findViewById(R.id.tv_child_name);
            holder.monthincome = (TextView)view.findViewById(R.id.totall_wealth_monthincome);
            holder.divider = (ImageView)view.findViewById(R.id.iv_divider);
            view.setTag(holder);
        }else{
            holder = (ChildHolder)view.getTag();
        }

        if(childPosition == 0){
            holder.divider.setVisibility(View.GONE);
        }
        if(childArray.get(groupPosition).getMoIncome()!=null){
            mMoIncomeBean = childArray.get(groupPosition).getMoIncome().get(childPosition);
        }else{
            mMoIncomeBean=new UserWealthBean.DataBean.YeIncomeBean.MoIncomeBean();
        }
        holder.childName.setText(""+mMoIncomeBean.getMonth()+"月");
       holder.monthincome.setText(""+mMoIncomeBean.getSum());
        return view;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    class GroupHolder{
        public TextView groupName;
        public  TextView totalWealthTv;
        public ImageView arrow;
    }

    class ChildHolder{
        public TextView childName;
        public TextView monthincome;
        public ImageView divider;
    }
}

