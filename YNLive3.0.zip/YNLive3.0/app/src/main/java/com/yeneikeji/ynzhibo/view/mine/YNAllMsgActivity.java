package com.yeneikeji.ynzhibo.view.mine;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.database.SystemMessageDao;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created by chenss on 2017/7/4.
 */

public class YNAllMsgActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{

    private static final String TAG = "YNAllMsgActivity";
    private SmoothListView allLvMsg;
    private LinearLayout   bottom_del_layout;
    private TextView       checkAllMsg;
    private TextView       delSelctedMsg;
    private TextView       displayDeletedMsg;

    private List<MessageBean> mSystemMsgtList = new ArrayList<>();
    private SystemMessageDao mSystemMessageDao;

    private CommonAdapter<MessageBean> mAllMsgAdapter;
    private static boolean SELECTED_STATE = false;
    public         int     selectConut    = 0;

    private String mUserId;
    private static final int DECREASE_NUM = 0;
    private static final int INCREASE_NUM = 1;
    private static final int ZERO_NUM     = 2;
    private static final int ALL_NUM      = 3;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG:
                    if (msg.obj != null) {
//                         YNLogUtil.e(TAG, " msg.obj  " + msg.obj);
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  jsonArray  = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<MessageBean>>() {}.getType();
                                mSystemMsgtList = YNJsonUtil.JsonToLBean(jsonArray.toString(),
                                                                         type);
                                //避免消息重复保存，保存之前清空
                                mSystemMessageDao.deleteAllRecord();
                                mSystemMessageDao.saveCommentList(mSystemMsgtList);
                                mAllMsgAdapter.updateListView(mSystemMsgtList);
                                getRightBtn().setVisibility(View.VISIBLE);
                                onStopLoad();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else if (baseBean.getCode() == 29) {
//                            YNToastMaster.showToast(context, baseBean.getInfo());
                        }
                    }
                    break;

                case YNCommonConfig.GET_DELETE_MY_SYSTEM_MESSAGE_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 45) {
                            YNToastMaster.showToast(YNAllMsgActivity.this, baseBean.getInfo());
                        } else {
                            YNToastMaster.showToast(YNAllMsgActivity.this, baseBean.getInfo());
                        }
                    }
                    break;

                case YNCommonConfig.GET_IS_READ_MY_SYSTEM_MESSAGE_FLAG:
                    if (msg.obj != null) {
//                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
//                                                                  BaseBean.class);
//                        if (baseBean.getCode() == 28) {
//                            YNToastMaster.showToast(YNAllMsgActivity.this, "已读");
//                        }
                    }
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = View.inflate(this, R.layout.activity_mine_all_message, null);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        settingDo();
        addEvent();

    }

    @Override
    protected void initView() {

        configTopBarCtrollerWithTitle(getString(R.string.all_message));
        getRightBtn().setVisibility(View.GONE);
        getRightTV().setVisibility(View.GONE);
        getLeftBtn().setOnClickListener(this);
        getRightTV().setText(getResources().getString(R.string.cancel_delete_message));
        allLvMsg = (SmoothListView) findViewById(R.id.all_msg_lv);
        bottom_del_layout = (LinearLayout) findViewById(R.id.bottom_del_layout);
        checkAllMsg = (TextView) findViewById(R.id.check_all_message);
        delSelctedMsg = (TextView) findViewById(R.id.delete_selected_message);
        displayDeletedMsg = (TextView) findViewById(R.id.delete_seletcted_message_num);

        delSelctedMsg.setOnClickListener(this);
        bottom_del_layout.setVisibility(View.GONE);
        allLvMsg.setLoadMoreEnable(false);
        allLvMsg.setEmptyView(findViewById(R.id.empty));
        SELECTED_STATE = false;

        setCancelDelMsgOnclick();
        setDelMesOnClick();
        setCheckAllMsgOnClick();
        setListViewOnItemClick();
    }


    private void setListViewOnItemClick() {

        allLvMsg.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CommonViewHolder holder    = (CommonViewHolder) view.getTag();
                CheckBox         cb        = holder.getView(R.id.cb_message);
                int              mPosition = holder.getPosition();

                whenNoConnect();
                final MessageBean msgBean = mSystemMsgtList.get(mPosition);
                cb.toggle();
                if (SELECTED_STATE) {
                    if (cb.isChecked()) {
                        cb.setChecked(true);
                        oHandler.sendEmptyMessage(INCREASE_NUM);
                    } else {
                        cb.setChecked(false);
                        oHandler.sendEmptyMessage(DECREASE_NUM);
                    }
                    msgBean.setChecked(cb.isChecked());
                    mAllMsgAdapter.notifyDataSetChanged();

                } else {
                    ContentValues values = new ContentValues();
                    values.put(SystemMessageDao.COLUMN_NAME_IS_READ, YNCommonConfig.IS_READED);
                    mSystemMessageDao.updateCommentOrThumb((msgBean.getId()), values);
                    if (msgBean.getIs_read()
                               .equals(YNCommonConfig.IS_NO_READ))
                    {
                        msgBean.setIs_read(YNCommonConfig.IS_READED);
                        mHandler.postDelayed(new Runnable() {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance()
                                             .isReadMySystemMsg(context,
                                                                YNCommonConfig.IS_READ_MY_SYSTEM_MESSAGE_URL,
                                                                msgBean.getId(),
                                                                msgBean.getIs_read(),
                                                                mHandler,
                                                                YNCommonConfig.GET_IS_READ_MY_SYSTEM_MESSAGE_FLAG,
                                                                false);
                            }
                        }, 500);
                    }

                    mAllMsgAdapter.updateListView(mSystemMsgtList);
                    switch (msgBean.getMessage_type()) {
                        case YNCommonConfig.VERIFY_MESSAGE:
                        case YNCommonConfig.NOTIFYCATION_MESSAGE:
                        case YNCommonConfig.AUTHENTICATION_MESSAGE:
                        case YNCommonConfig.ROOM_OWNER_MESSAGE:
                        case YNCommonConfig.MULTICHANNELROOM_INVITATION_MANAGER_MSG:
                        case "0":
                        case "1":
                        case "10":
                            Intent intent = new Intent(context,
                                                       MessageConfirmationDetailsActivity.class);
                            intent.putExtra(YNCommonConfig.OBJECT, msgBean);
                            startActivity(intent);
                            break;
                        case YNCommonConfig.FOLLOW_MESSAGE:
                        case YNCommonConfig.SYSTEM_MESSAGE:
                        case "2":
                        case "4":
                        case "6":
                        case "7":
                        case"11":
                            Intent intent1 = new Intent(context, YNMessageDetailsActivity.class);
                            intent1.putExtra("data", msgBean);
                            startActivity(intent1);
                            break;
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
    }

    private Handler oHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case DECREASE_NUM:
                    selectConut--;
                    break;
                case INCREASE_NUM:
                    selectConut++;
                    break;
                case ZERO_NUM:
                    selectConut = 0;
                    break;
                case ALL_NUM:
                    selectConut = mSystemMsgtList.size();
                    break;
                default:
                    break;
            }

            if (selectConut == 0) {
                displayDeletedMsg.setVisibility(View.GONE);
            } else {
                displayDeletedMsg.setVisibility(View.VISIBLE);
            }
            displayDeletedMsg.setText("(" + selectConut + ")");


            if (selectConut == mSystemMsgtList.size()) {
                checkAllMsg.setText(getString(R.string.all_no_select));
            }
//            YNLogUtil.e(TAG, "selectConut  " + selectConut);
        }
    };


    private void whenNoConnect() {
        if (mSystemMsgtList == null || mSystemMsgtList.size() <= 0) {
            mSystemMsgtList = mSystemMessageDao.getCommentList();
            mAllMsgAdapter.updateListView(mSystemMsgtList);
        }
    }


    private void setCheckAllMsgOnClick() {
        checkAllMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (allSelect()) {
                    num_check(true);
                    changeCheckStatus(true);

                } else if (allNoSelect()) {
                    num_check(false);
                    changeCheckStatus(false);
                }
                mAllMsgAdapter.notifyDataSetChanged();

            }
        });
    }

    private boolean allSelect() {
        return checkAllMsg.getText() == getString(R.string.all_select);
    }

    private boolean allNoSelect() {
        return checkAllMsg.getText() == getString(R.string.all_no_select);
    }

    public void deleteMsg() {
        List<MessageBean> deleteList = new ArrayList<>();
        for (final MessageBean bean : mSystemMsgtList) {
            if (bean.isChecked()) {
                if (!TextUtils.isEmpty(bean.getId())) {
//                    YNLogUtil.e(TAG, " bean.getId ---0 " + bean.getId());
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance()
                                         .deleteMySystemMsg(context,
                                                            YNCommonConfig.DELETE_MY_SYSTEM_MESSAGE_URL,
                                                            bean.getId(),
                                                            mHandler,
                                                            YNCommonConfig.GET_DELETE_MY_SYSTEM_MESSAGE_FLAG,
                                                            false);
                        }
                    }, 500);

                    mSystemMessageDao.deleteCommentOrThumb(Integer.parseInt(bean.getId()));
                }
                // YNLogUtil.e(TAG, " bean.isChecked() : " +bean.isChecked());
                deleteList.add(bean);

            }
        }
        mSystemMsgtList.removeAll(deleteList);
        num_check(false);
        changeCheckStatus(false);
        mAllMsgAdapter.updateListView(mSystemMsgtList);
        getRightBtn().setVisibility(View.VISIBLE);
        getRightTV().setVisibility(View.GONE);
        bottom_del_layout.setVisibility(View.GONE);
        SELECTED_STATE = false;

        if (mSystemMsgtList.size() <= 0) {
            bottom_del_layout.setVisibility(View.GONE);
            getRightBtn().setVisibility(View.GONE);
            getRightTV().setVisibility(View.GONE);
        }

    }


    private void setCancelDelMsgOnclick() {
        getRightTV().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getRightBtn().setVisibility(View.VISIBLE);
                getRightTV().setVisibility(View.GONE);
                bottom_del_layout.setVisibility(View.GONE);
                SELECTED_STATE = false;
                num_check(false);
                changeCheckStatus(false);
                mAllMsgAdapter.notifyDataSetChanged();
            }
        });
    }

    private void changeCheckStatus(boolean isChecked) {
        whenNoConnect();
        for (MessageBean bean : mSystemMsgtList) {
            bean.setChecked(isChecked);
        }
    }


    private void num_check(boolean isChecked) {
        if (isChecked) {
            oHandler.sendEmptyMessage(ALL_NUM);
        } else {
            oHandler.sendEmptyMessage(ZERO_NUM);
        }
    }

    private void setDelMesOnClick() {
        getRightBtn().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getRightBtn().setVisibility(View.GONE);
                getRightTV().setVisibility(View.VISIBLE);
                bottom_del_layout.setVisibility(View.VISIBLE);
                num_check(false);
                changeCheckStatus(false);
                SELECTED_STATE = true;
            }
        });

    }


    @Override
    protected void settingDo() {
        if (AccountUtils.getLoginInfo()) {
            mUserId = AccountUtils.getAccountBean()
                                  .getId();
        }

        allLvMsg.setSmoothListViewListener(this);
        allLvMsg.setRefreshTime(DateUtil.getNowDate());
        mSystemMessageDao = new SystemMessageDao(context);

        if(mSystemMsgtList == null || mSystemMsgtList.size() <= 0){
            YNLogUtil.e(TAG, "mSystemMsgtList : " + mSystemMsgtList);
            mSystemMessageDao.deleteAllRecord();
        }

        if (mSystemMessageDao.getCommentList()
                             .size() <= 0 || mSystemMessageDao == null)
        {
            getRightBtn().setVisibility(View.GONE);
        } else {
            getRightBtn().setVisibility(View.VISIBLE);
        }
        mAllMsgAdapter = new CommonAdapter<MessageBean>(this,
                                                        mSystemMessageDao.getCommentList(),
                                                        R.layout.mine_all_message_item)
        {

            @Override
            public void convert(final CommonViewHolder viewHolder, final MessageBean item) {
                viewHolder.setText(R.id.msg_tv_content, item.getContent());
                TextView msgTvTitle = viewHolder.getView(R.id.msg_tv_title);

                if(item.getMessage_type().equals(YNCommonConfig.VERIFY_MESSAGE) || item.getMessage_type().equals(YNCommonConfig.ROOM_OWNER_MESSAGE) || item.getMessage_type().equals(YNCommonConfig.MULTICHANNELROOM_INVITATION_MANAGER_MSG)){
                    msgTvTitle.setText(getString(R.string.verify_message));
                }else if(item.getMessage_type().equals(YNCommonConfig.NOTIFYCATION_MESSAGE)
                        || item.getMessage_type().equals("0") //系统通知
                        || item.getMessage_type().equals("1") //开播通知
                        || item.getMessage_type().equals("10")){ // 登录通知
                    msgTvTitle.setText(getString(R.string.notification_message));
                }else if(item.getMessage_type().equals(YNCommonConfig.SYSTEM_MESSAGE)){
                    msgTvTitle.setText(getString(R.string.system_message));
                }else if(item.getMessage_type().equals(YNCommonConfig.FOLLOW_MESSAGE)){
                    msgTvTitle.setText(getString(R.string.follow_message));
                }else if(item.getMessage_type().equals("2")){
                    msgTvTitle.setText("评论消息");
                }else if(item.getMessage_type().equals("4")){
                    msgTvTitle.setText("点赞消息");
                }else if(item.getMessage_type().equals("6")){
                    msgTvTitle.setText("提问消息");
                }else if(item.getMessage_type().equals("7")){
                    msgTvTitle.setText("回复消息");
                }else if(item.getMessage_type().equals("11")){
                    msgTvTitle.setText("充值");
                }

                viewHolder.setImageResource(R.id.msg_iv_type, R.drawable.message_official_little);
//                YNCircleImageView imgHead = viewHolder.getView(R.id.msg_iv_head);
                viewHolder.setImageResource(R.id.msg_iv_head, R.drawable.message_official);
//                YNImageLoaderUtil.setImage(context, imgHead, item.getIcon());
                viewHolder.setText(R.id.msg_tv_time,
                                   DateUtil.timeTick2DateHourMinute(item.getTime()));
                viewHolder.setCheckedVisible(R.id.cb_message, SELECTED_STATE);
                if (item.getIs_read()
                        .equals(YNCommonConfig.IS_READED))
                {
                    viewHolder.setImageVisible(R.id.msg_iv_status, false);
                } else {
                    viewHolder.setImageVisible(R.id.msg_iv_status, true);
                }

                final CheckBox cb = viewHolder.getView(R.id.cb_message);
                cb.setChecked(item.isChecked());
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        // YNLogUtil.e(TAG, " isChecked " + isChecked);
                        if (!isChecked) { checkAllMsg.setText(getString(R.string.all_select));}

                    }
                });
            }
        };
        allLvMsg.setAdapter(mAllMsgAdapter);

    }

    private void initData() {
        //是否联网
        if (YNBaseActivity.isConnectNet) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMySystemMsg(context,
                                                 YNCommonConfig.MY_SYSTEM_MESSAGE_URL,
                                                 mUserId,
                                                 mHandler,
                                                 YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG,
                                                 false);
                }
            }, 0);


        }
    }


    @Override
    protected void addEvent() {
    }


    @Override
    public void loginRefreshUI() {
    }

    @Override
    public void unLoginRefreshUI() {
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.delete_selected_message:
                deleteMsg();
                break;
        }
    }

    @Override
    public void onRefresh() {
        // YNLogUtil.e(TAG, "======== onRefresh()======= ");
        //是否有网
        if (YNBaseActivity.isConnectNet) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMySystemMsg(context,
                                                 YNCommonConfig.MY_SYSTEM_MESSAGE_URL,
                                                 mUserId,
                                                 mHandler,
                                                 YNCommonConfig.GET_MY_SYSTEM_MESSAGE_FLAG,
                                                 true);
                }
            }, 1000);

        }
    }

    @Override
    public void onLoadMore() {}

    /** 停止刷新 */
    private void onStopLoad()
    {
        allLvMsg.stopRefresh();
        allLvMsg.stopLoadMore();
        allLvMsg.setRefreshTime(DateUtil.getNowDate());
    }
}
