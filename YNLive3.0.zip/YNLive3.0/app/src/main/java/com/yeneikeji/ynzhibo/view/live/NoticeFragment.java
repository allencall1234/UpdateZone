package com.yeneikeji.ynzhibo.view.live;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.RelativeLayout;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.NoticeBean;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.pullablescrollview.PullToRefreshLayout;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.http.YNCommonConfig.*;

/**
 * 公告界面
 * Created by Administrator on 2017/5/18.
 */
public class NoticeFragment extends BaseFragment
{
    private PullToRefreshLayout mRefreshView;
    private RelativeLayout mRefreshHead;
    private YNMyListView mNoticeListView;
    private RelativeLayout mRLEmpty;

    private LiveRoomBean liveRoomBean;
    private CommonAdapter mNoticeAdapter;
    private List<NoticeBean> mNoticeList = new ArrayList<>();

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_LIVE_ROOM_NOTICE_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<NoticeBean>>() {}.getType();
                                    mNoticeList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    mNoticeAdapter.updateListView(mNoticeList);
                                }

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mNoticeListView.setVisibility(View.GONE);
                            mRLEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        mNoticeListView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.SUCCEED);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                if (jsonArray != null)
                                {
                                    Type type = new TypeToken<List<NoticeBean>>() {}.getType();
                                    mNoticeList = YNJsonUtil.JsonToLBean(jsonArray.toString(), type);
                                    mNoticeAdapter.updateListView(mNoticeList);
                                }

                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mRLEmpty.setVisibility(View.VISIBLE);
                            mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                        }
                    }
                    else
                    {
                        mRLEmpty.setVisibility(View.VISIBLE);
                        mRefreshView.refreshFinish(PullToRefreshLayout.FAIL);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }
        return R.layout.fragment_notice;
    }

    @Override
    protected void initView()
    {
        mRefreshView = (PullToRefreshLayout) findViewById(R.id.refresh_view);
        mRefreshHead = (RelativeLayout) findViewById(R.id.head_view);
        mNoticeListView = (YNMyListView) findViewById(R.id.lv_notice);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);

        mRefreshHead.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.transparent));
    }

    @Override
    protected void loadData()
    {

        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomNoticeList(getActivity(), YNCommonConfig.GET_LIVE_ROOM_NOTICE_LIST_URL, liveRoomBean.getRoom_id(), mHandler, YNCommonConfig.GET_LIVE_ROOM_NOTICE_LIST_FLAG, true, 500);
            }
        });

        mRefreshView.setOnRefreshListener(new PullToRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh(PullToRefreshLayout pullToRefreshLayout)
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveRoomNoticeList(getActivity(), YNCommonConfig.GET_LIVE_ROOM_NOTICE_LIST_URL, liveRoomBean.getRoom_id(), mHandler, YNCommonConfig.ON_REFRESH, false, 500);
                    }
                });
            }

            @Override
            public void onLoadMore(PullToRefreshLayout pullToRefreshLayout)
            {

            }
        });

        mNoticeAdapter = new CommonAdapter<NoticeBean>(getActivity(), mNoticeList, R.layout.notice_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, NoticeBean item)
            {
                viewHolder.setText(R.id.tv_notice_content, item.getContent());
                if (liveRoomBean.getEquipment() == 1)
                    viewHolder.setText(R.id.tv_notice_time, DateUtil.timeTick2DateNotSec(item.getTime()), ContextCompat.getColor(getContext(), R.color.gift_txt_color));
                else
                    viewHolder.setText(R.id.tv_notice_time, DateUtil.timeTick2DateNotSec(item.getTime()), ContextCompat.getColor(getContext(), R.color.private_msg_introduce_txt));
            }
        };

        mNoticeListView.setAdapter(mNoticeAdapter);
    }

    public void setLiveRoomBean(LiveRoomBean liveRoomBean)
    {
        this.liveRoomBean = liveRoomBean;
    }

}
