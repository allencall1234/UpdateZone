package com.yeneikeji.ynzhibo.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.yeneikeji.ynzhibo.model.MessageBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lxy on 2017/6/20.
 */
public class SystemMessageDao
{
    public static final String TABLE_NAME = "systemmessage";
    public static final String COLUMN_NAME_ID = "id";
    public static final String COLUMN_NAME_USERID = "userid";
    public static final String COLUMN_NAME_UID = "uid";
    public static final String COLUMN_NAME_SEND_TYPE = "send_type";
    public static final String COLUMN_NAME_TYPE = "type";
    public static final String COLUMN_NAME_MESSAGE_TYPE = "message_type";
    public static final String COLUMN_NAME_CONTENT = "content";
    public static final String COLUMN_NAME_TIME = "time";
    public static final String COLUMN_NAME_IS_READ = "is_read";
    public static final String COLUMN_NAME_IS_ACCEPT = "is_accept";
    public static final String COLUMN_NAME_USERNAME = "username";
    public static final String COLUMN_NAME_DESCRIBES = "describes";
    public static final String COLUMN_NAME_ICON = "icon";
    public static final String COLUMN_NAME_LIVE_TYPE = "tag";
    public static final String COLUMN_NAME_LIVE_COLUMN = "tag2";


    private DbOpenHelper dbHelper;
    public SystemMessageDao(Context context) {
        dbHelper = DbOpenHelper.getInstance(context);
    }
    /**
     * 保存系统消息list
     * @param commentList
     */
    public void saveCommentList(List<MessageBean> commentList)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if (db.isOpen())
        {
         /*   MessageBean mesagBean=null;
            boolean           isInsert = true;
            List<MessageBean> list     = getCommentList();

            for (MessageBean comment : list)
            {*/
                for (MessageBean msgbean : commentList)
                {
                   /* mesagBean=msgbean;
                    if (comment.getId().equals(msgbean.getId()))
                    {
                        isInsert = false;
                        break;
                    }
                }
                if (db != null && isInsert) {*/
                    ContentValues values = new ContentValues();
                    values.put(COLUMN_NAME_ID, msgbean.getId());
                    values.put(COLUMN_NAME_USERID, msgbean.getUserid());
                    values.put(COLUMN_NAME_UID, msgbean.getUid());
                    values.put(COLUMN_NAME_SEND_TYPE, msgbean.getSend_type());
                    values.put(COLUMN_NAME_TYPE, msgbean.getType());
                    values.put(COLUMN_NAME_MESSAGE_TYPE, msgbean.getMessage_type());
                    values.put(COLUMN_NAME_CONTENT, msgbean.getContent());
                    values.put(COLUMN_NAME_TIME, msgbean.getTime());
                    values.put(COLUMN_NAME_IS_READ, msgbean.getIs_read());
                    values.put(COLUMN_NAME_IS_ACCEPT, msgbean.getIs_accept());
                    values.put(COLUMN_NAME_USERNAME, msgbean.getUsername());
                    values.put(COLUMN_NAME_DESCRIBES, msgbean.getDescribes());
                    values.put(COLUMN_NAME_ICON, msgbean.getIcon());
                    values.put(COLUMN_NAME_LIVE_TYPE, msgbean.getTag());
                    values.put(COLUMN_NAME_LIVE_COLUMN, msgbean.getTag2());
                    db.insert(TABLE_NAME, null, values);
                }

        }
        dbHelper.closeDb();
    }

    /**
     * 获取系统消息list
     * @return
     */
    public List<MessageBean> getCommentList()
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<MessageBean> messageBeans = new ArrayList();
        if(db.isOpen()){
            Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " desc",null);
            while(cursor.moveToNext()){
                MessageBean messageBean = new MessageBean();
                String id = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ID));
                String userid = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERID));
                String uid = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_UID));
                String send_type = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_SEND_TYPE));
                String type = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TYPE));
                String message_type = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_MESSAGE_TYPE));
                String content = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_CONTENT));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TIME));
                String is_read = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_IS_READ));
                String is_accept = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_IS_ACCEPT));
                String username = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERNAME));
                String describes = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_DESCRIBES));
                String icon = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ICON));
                String liveType = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_LIVE_TYPE));
                String liveColumn = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_LIVE_COLUMN));
                messageBean.setId(id);
                messageBean.setContent(content);
                messageBean.setIs_accept(is_accept);
                messageBean.setIs_read(is_read);
                messageBean.setMessage_type(message_type);
                messageBean.setSend_type(send_type);
                messageBean.setTime(time);
                messageBean.setType(type);
                messageBean.setUid(uid);
                messageBean.setUserid(userid);
                messageBean.setUsername(username);
                messageBean.setDescribes(describes);
                messageBean.setIcon(icon);
                messageBean.setTag(liveType);
                messageBean.setTag2(liveColumn);
                messageBeans.add(messageBean);
            }
            cursor.close();
            dbHelper.closeDb();
        }
        return messageBeans;
    }

    /**
     * 更新
     * @param commentId
     * @param values
     */
    public void updateCommentOrThumb(String commentId, ContentValues values){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if(db.isOpen())
        {
            db.update(TABLE_NAME, values, COLUMN_NAME_ID + " = ?", new String[]{commentId});
            dbHelper.closeDb();
        }
    }

    /**
     * 删除
     * @param commentId
     */
    public void deleteCommentOrThumb(int commentId)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if(db.isOpen())
        {
            db.delete(TABLE_NAME, COLUMN_NAME_ID + " = ?", new String[] {String.valueOf(commentId)});
            dbHelper.closeDb();
        }
    }

    /**
     * 清空数据
     */
    public void deleteAllRecord()
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("delete from " + TABLE_NAME);
        dbHelper.closeDb();
    }

}
