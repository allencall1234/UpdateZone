package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.FixedIndicatorView;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;
import com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;

public class FindPersonalHomeActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener {
    private UserInfoBean mUserBean;
    private YNCircleImageView CircleImageView;
    private ImageView mBack;
    private View mTopRelativeView;
    private com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout mScrollableLayout;
    private ImageView mTopBack;
    private TextView mFollowNumb;
    private TextView mFansNumb;
    private TextView mAddFollow;
    private TextView mTvDescrible;
    private TextView mName;
    private TextView mTopTitle;
    public String mUserid;
    public String mMyselfId;
    private int isAttention;
    public List<FindCategaryBean> mTotalArticalLists;
    //private TotalArticalListViewAdapter mAdapter;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_FIND_PERSONAL_HOME_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(msg.obj.toString());
                                //顶部个人信息
                                mUserBean = YNJsonUtil.JsonToBean(jsonObject.getString("data1"),
                                        UserInfoBean.class);

                                JSONArray array = jsonObject.getJSONArray("data");
                                //主播总的文章
                                Type type = new TypeToken<List<FindCategaryBean>>() {
                                }.getType();
                                mTotalArticalLists = YNJsonUtil.JsonToLBean(array.toString(), type);

                                if (baseBean != null) {

                                    isAttention = mUserBean.getIs_attention();
                                    initEvent();
                                }
                                if (mTotalArticalLists != null || mTotalArticalLists.size() > 0) {
                                    //  mAdapter = new TotalArticalListViewAdapter(FindPersonalHomeActivity.this, mTotalArticalLists);
                                    // mListview.setAdapter(mAdapter);
                                } else {
                                    //   mEmpty.setVisibility(View.VISIBLE);
                                }
                            } catch (JSONException e) {
                                //   mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }else if(baseBean.getCode() == 29){
                            // mEmpty.setVisibility(View.VISIBLE);
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(msg.obj.toString());
                                mUserBean = YNJsonUtil.JsonToBean(jsonObject.getString("data1"),
                                        UserInfoBean.class);
                                initEvent();
                            } catch (JSONException e) {
                                //  mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }
                    } else {
                        // mEmpty.setVisibility(View.VISIBLE);
                    }
                    break;
            }
        }
    };
    private FixedIndicatorView mTabsIndicator;
    private ViewPager mViewPager;
    private IndicatorViewPager indicatorViewPager;
    private String[] tabTitle = null;
    private ArrayList<Fragment> fragments;
    private MyAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // AutoUtils.setSize(this, false, 750, 1334);
        View view = View.inflate(this, R.layout.activity_find_personal_home, null);
        //  AutoUtils.auto(view);//放在加载布局的前面
        setContentView(view);
        initView();
    }

    protected void initView() {
        if (AccountUtils.getLoginInfo()) {
            mMyselfId = AccountUtils.getAccountBean()
                    .getId();
        }
        mUserid = getIntent().getStringExtra("userId");
        mTopTitle = (TextView) findViewById(R.id.top_tv_Title);
        //渐变的view
        mTopRelativeView = findViewById(R.id.top_relative_view);
        //渐变的view
        CircleImageView = (YNCircleImageView) findViewById(R.id.YNCircleImageView);
        mBack = (ImageView) findViewById(R.id.totalartical_img_Back);
        mName = (TextView) findViewById(R.id.top_tv_name);
        mTvDescrible = (TextView) findViewById(R.id.personhome_top_describle);
        mFollowNumb = (TextView) findViewById(R.id.find_hometv_artical_follow);
        mFansNumb = (TextView) findViewById(R.id.find_hometv_fans_count);
        mAddFollow = (TextView) findViewById(R.id.find_hometv_add_follow);
        //  mListview = (SmoothListView) findViewById(R.id.find_anchor_ListView);
        //  mEmpty = (RelativeLayout) findViewById(R.id.empty);
        tabTitle = getResources().getStringArray(R.array.articalColumnTitles);
        mScrollableLayout = (com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout) findViewById(R.id.ScrollableLayout);
        //指示器和viewpager
        mTabsIndicator = (FixedIndicatorView) findViewById(R.id.find_personal_activity_tabs);
        mViewPager = (ViewPager) findViewById(R.id.find_personal_activity_viewpager);

        float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#1694ff");
        int unSelectColor = Color.BLACK;
        ColorBar line1 = new ColorBar(this, Color.parseColor("#1694ff"), 5);
        line1.setWidth(UIUtils.dp2px(this, 55));
        line1.setHeight(UIUtils.dp2px(this, 3));
        mTabsIndicator.setScrollBar(line1);
        mTabsIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mViewPager.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mTabsIndicator, mViewPager);
        //请求数据
        if (AccountUtils.getLoginInfo()) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    UserHttpUtils.newInstance()
                            .getFindAnchorHome(FindPersonalHomeActivity.this,
                                    YNCommonConfig.GET_FINF_PERSONAL_HOME_URL,
                                    AccountUtils.getAccountBean().getId(),
                                    mUserid,
                                    0,
                                    mHandler,
                                    YNCommonConfig.GET_FIND_PERSONAL_HOME_FLAG,
                                    true);
                }
            });
        }
        addFragment();
    }

    private void addFragment()
    {
        fragments = new ArrayList();

        VideoFragment noteFragment = new VideoFragment();
        VoiceFragment voiceFragment = new VoiceFragment();
        VideoFragment videoFragment = new VideoFragment();
        fragments.add(noteFragment);
        fragments.add(voiceFragment);
        fragments.add(videoFragment);

       /* mAdapter = new YNFragmentAdapter(getSupportFragmentManager(), fragments, tabTitle);
        mArticalViewPager.setOffscreenPageLimit(count);
        mArticalViewPager.setAdapter(mAdapter);
        mArticalTabs.setupWithViewPager(mArticalViewPager, true);
        UIUtils.dynamicSetTabLayoutMode(mArticalTabs);*/
        mAdapter = new MyAdapter(getSupportFragmentManager());
        mAdapter.setFragments(fragments);
        indicatorViewPager.setAdapter(mAdapter);

    }

    private void initEvent() {
        //初始化头部信息
        YNImageLoaderUtil.setImage(this, CircleImageView, mUserBean.getIcon());
        mName.setText(mUserBean.getUsername());
        mTopTitle.setText(mUserBean.getUsername());
        mTvDescrible.setText(mUserBean.getDescribe());
        mFollowNumb.setText("关注：" + mUserBean.getFocus_count());
        mFansNumb.setText("粉丝：" + mUserBean.getFuns_count());
        mAddFollow.setTextColor(Color.WHITE);
        mBack.setOnClickListener(this);
        mTopBack.setOnClickListener(this);
        mAddFollow.setOnClickListener(this);
        //  mListview.setOnItemClickListener(this);
        mScrollableLayout.setOnScrollListener(new ScrollableLayout.OnScrollListener() {
            @Override
            public void onScroll(int currentY, int maxY, float diatance) {
                //上滑
                if(diatance>0){
                    mTopRelativeView.setBackgroundColor(getResources().getColor(R.color.ynkj_topbar_bg));
                    tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));

                }else{
                    mTopRelativeView.setBackgroundColor(getResources().getColor(R.color.personal_homepage_bg));
                    tintManager.setStatusBarTintColor(Color.rgb(38,154,252));

                }

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.totalartical_img_Back:
                finish();
                break;

        }
    }

    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter {
        private List<Fragment> fragments = new ArrayList<>();

        public MyAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        public void setFragments(List<Fragment> fragments) {
            this.fragments = fragments;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return tabTitle.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container) {
            if (convertView == null) {
                convertView = LayoutInflater.from(mContext).inflate(R.layout.tab_textview, container, false);
            }
            TextView textView = (TextView) convertView;
            textView.setText(tabTitle[position]);
            return convertView;
        }


        @Override
        public Fragment getFragmentForPage(int position) {
            return fragments.get(position);
        }
    }
}
