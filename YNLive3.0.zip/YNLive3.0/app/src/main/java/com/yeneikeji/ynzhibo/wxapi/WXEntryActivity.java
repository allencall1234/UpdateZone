package com.yeneikeji.ynzhibo.wxapi;


import com.umeng.weixin.callback.WXCallbackActivity;

//import com.umeng.socialize.weixin.view.WXCallbackActivity;

public class WXEntryActivity extends WXCallbackActivity {



}
