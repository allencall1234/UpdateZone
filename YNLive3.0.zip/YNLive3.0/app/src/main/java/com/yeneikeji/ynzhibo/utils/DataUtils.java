package com.yeneikeji.ynzhibo.utils;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveTypeBean;

import java.util.ArrayList;
import java.util.List;

/**
 * 测试数据工具类
 * Created by Administrator on 2016/11/29.
 */
public class DataUtils
{
    private static List<LiveTypeBean> liveTypeList;

    public static List<LiveTypeBean> getLiveTypeList()
    {
        liveTypeList = new ArrayList<>();

        List<Integer> headImgUrlList1 = new ArrayList<>();
        List<Integer> headImgUrlList2 = new ArrayList<>();
        List<Integer> headImgUrlList3 = new ArrayList<>();
        List<Integer> headImgUrlList4 = new ArrayList<>();
        List<Integer> headImgUrlList5 = new ArrayList<>();

       /* headImgUrlList1.add(R.drawable.pic_one);
        headImgUrlList1.add(R.drawable.pic_two);
        headImgUrlList1.add(R.drawable.pic_three);
        headImgUrlList1.add(R.drawable.pic_four);

        headImgUrlList2.add(R.drawable.pic_eight);
        headImgUrlList2.add(R.drawable.pic_nine);
        headImgUrlList2.add(R.drawable.pic_ten);
        headImgUrlList2.add(R.drawable.pic_nine);

        headImgUrlList3.add(R.drawable.pic_eleven);
        headImgUrlList3.add(R.drawable.pic_twelve);
        headImgUrlList3.add(R.drawable.pic_thirteen);
        headImgUrlList3.add(R.drawable.pic_fifteen);

        headImgUrlList4.add(R.drawable.pic_one);
        headImgUrlList4.add(R.drawable.pic_two);
        headImgUrlList4.add(R.drawable.pic_three);
        headImgUrlList4.add(R.drawable.pic_four);

        headImgUrlList5.add(R.drawable.pic_eight);
        headImgUrlList5.add(R.drawable.pic_nine);
        headImgUrlList5.add(R.drawable.pic_ten);
        headImgUrlList5.add(R.drawable.pic_nine);*/

//        liveTypeList.add(new LiveTypeBean("金融", R.drawable.icon_finance));
//        liveTypeList.add(new LiveTypeBean("家教", R.drawable.icon_teach));
//        liveTypeList.add(new LiveTypeBean("投资", R.drawable.hot));
//        liveTypeList.add(new LiveTypeBean("实时解盘", R.drawable.hot));
//        liveTypeList.add(new LiveTypeBean("商品期货", R.drawable.hot));
//        liveTypeList.add(new LiveTypeBean("保险理财", R.drawable.hot));

        return liveTypeList;
    }

    public static List<GiftBean> getGiftList()
    {
        ArrayList<GiftBean> giftList = new ArrayList<>();
//        giftList.add(new GiftBean(R.drawable.applause, "掌声", 10));
//        giftList.add(new GiftBean(R.drawable.continuous, "赞", 10));
//        giftList.add(new GiftBean(R.drawable.candy, "棒棒糖", 60));
//        giftList.add(new GiftBean(R.drawable.flower, "玫瑰花", 100));
//        giftList.add(new GiftBean(R.drawable.ring, "十克拉", 660));
//        giftList.add(new GiftBean(R.drawable.lip, "么么哒", 100));
//        giftList.add(new GiftBean(R.drawable.car, "法拉利", 8800));
//        giftList.add(new GiftBean(R.drawable.ship, "豪华游轮", 9900));
//        giftList.add(new GiftBean(R.drawable.cup, "干杯", 10));
//        giftList.add(new GiftBean(R.drawable.kneel, "给跪", 10));
//        giftList.add(new GiftBean(R.drawable.liu, "666", 80));
//        giftList.add(new GiftBean(R.drawable.qiqiu, "气球", 100));
//        giftList.add(new GiftBean(R.drawable.red_envelope, "塞红包", 600));
//        giftList.add(new GiftBean(R.drawable.airplane, "飞机", 18800));
        giftList.add(new GiftBean(R.mipmap.gift_car, "豪华跑车", 518, "008"));
        giftList.add(new GiftBean(R.mipmap.gift_warren, "股神", 188, "004"));
        giftList.add(new GiftBean(R.mipmap.gift_smoke, "中华烟", 50, "005"));
        giftList.add(new GiftBean(R.mipmap.gift_tea, "茶", 6, "002"));
        giftList.add(new GiftBean(R.mipmap.gift_flowers, "鲜花", 1, "007"));

        return giftList;
    }

    public static List<GiftBean> getSubjectList()
    {
        List<GiftBean> subjectList = new ArrayList<>();

        subjectList.add(new GiftBean(R.drawable.icon_subject01, "语文"));
        subjectList.add(new GiftBean(R.drawable.icon_subject02, "数学"));
        subjectList.add(new GiftBean(R.drawable.icon_subject03, "英语"));
        subjectList.add(new GiftBean(R.drawable.icon_subject04, "物理"));
        subjectList.add(new GiftBean(R.drawable.icon_subject05, "化学"));
        subjectList.add(new GiftBean(R.drawable.icon_subject06, "生物"));
        subjectList.add(new GiftBean(R.drawable.icon_subject07, "政治"));
        subjectList.add(new GiftBean(R.drawable.icon_subject08, "历史"));
        subjectList.add(new GiftBean(R.drawable.icon_subject09, "地理"));
        subjectList.add(new GiftBean(R.drawable.icon_subject10, "科学"));
        subjectList.add(new GiftBean(R.drawable.icon_subject11, "其他"));

        return subjectList;
    }

    public static List<GiftBean> getMultiChannelServiceList()
    {
        List<GiftBean> serviceList = new ArrayList<>();

        serviceList.add(new GiftBean(R.drawable.icon_room_haoling, "号令子房间"));
        serviceList.add(new GiftBean(R.drawable.icon_room_jilu, "直播记录"));

        return serviceList;
    }


}
