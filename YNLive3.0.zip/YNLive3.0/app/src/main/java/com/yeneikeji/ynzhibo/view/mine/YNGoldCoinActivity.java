package com.yeneikeji.ynzhibo.view.mine;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.GoldCoinRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.common.YNMyTextView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.CoinMoneyBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.pay.ZFBPayResult;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 金币充值界面
 * Created by Administrator on 2016/11/8.
 */
public class YNGoldCoinActivity extends YNBaseTopBarActivity implements View.OnClickListener,
                                                                        TextWatcher
{
    private RecyclerView mRecyclerView;
    private YNMyTextView mPaymentTotalTV;
    private TextView mTxtCoin;

    private List<CoinMoneyBean> coinMoneyList;
    private GoldCoinRecyclerViewAdapter mAdapter;
    private UserInfoBean mUserInfoBean;
    private TextView mUserName;
    private TextView mCurrentCoin;
    private EditText mInputMoney;
    private TextView mRechargerNumb;
    private String mCoinNumb;
    private float currentCoin;// 当前金币

    private static final int ZFB_SDK_PAY_FLAG = 1;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_MINE_GOLD_COIN_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("aaa", msg.obj.toString());
                        BaseBean   baseBean   = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        JSONObject jsonObject = null;
                        if (baseBean.getCode() ==77) {
                            try {
                                Toast.makeText(context, "充值成功", Toast.LENGTH_SHORT)
                                     .show();
                                //保存在本地的余额数更新,显示余额更新
                                jsonObject = new JSONObject(msg.obj.toString());
                               /* JSONArray data1 = jsonObject.optJSONArray("data1");
                                Type type = new TypeToken<List<RecordVideoBean>>() {
                                }.getType();*/

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }else{
                            Toast.makeText(context, "充值失败", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    break;
                case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                currentCoin = Float.parseFloat((jsonObject.getString("data")));
                                mCurrentCoin.setText(currentCoin+"金币");
                                AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                    }
                    else
                    {
                        //                    YNToastMaster.showToast(getContext(), getString(R.string.request_fail));
                    }
                    break;

                case ZFB_SDK_PAY_FLAG:
                    @SuppressWarnings("unchecked")
                    ZFBPayResult payResult = new ZFBPayResult((Map<String, String>) msg.obj);
                    /**
                     对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000"))
                    {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        YNToastMaster.showToast(YNGoldCoinActivity.this, "支付成功", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    else
                    {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        YNToastMaster.showToast(YNGoldCoinActivity.this, "支付失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
       // AutoUtils.setSize(this, false, 750, 1334);
        View view =View.inflate(this, R.layout.activity_gold_coin, null);
       // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        mUserInfoBean = AccountUtils.getAccountBean();
        initView();
        addEvent();
        settingDo();

    }

    @Override
    protected void initView()
    {
        getCurrentCoin();
        configTopBarCtrollerWithTitle(getString(R.string.gold_coin));
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.coin_record));

        mRecyclerView = (RecyclerView) findViewById(R.id.recyler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        mPaymentTotalTV = (YNMyTextView) findViewById(R.id.tv_payment_total);
        mTxtCoin = (TextView) findViewById(R.id.btn_coin);
        //自定义输入的金额
        mInputMoney = (EditText) findViewById(R.id.et_input_money);

        mUserName = (TextView) findViewById(R.id.tv_coin_number);
        mCurrentCoin = (TextView) findViewById(R.id.tv_account_gold);
        mUserName.setText("充值帐号："+mUserInfoBean.getPhone());


    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
        mTxtCoin.setOnClickListener(this);
        mInputMoney.setOnClickListener(this);
        //动态显示Editext里面内容
        mInputMoney.addTextChangedListener(this);
        mInputMoney.setOnClickListener(this);
        //获取焦点时上面固定充值金额要置为非选中状态
        mInputMoney.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                mAdapter.lastPressIndex=-1;
                mTxtCoin.setText("立即充值金币");
                mAdapter.notifyDataSetChanged();
            }
        });
    }
    @Override
    protected void settingDo()
    {
        mAdapter = new GoldCoinRecyclerViewAdapter(mTxtCoin,mInputMoney);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.replaceAll(getCoinData());
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.star_1_com_topbar_tv_right:
                intent.setClass(this, YNGoldCoinRecordActivity.class);
                startActivity(intent);
                break;

            case R.id.btn_coin:
               //充值之前必须登录
              if(AccountUtils.getLoginInfo()){
                AlertDialog.Builder builder = new AlertDialog.Builder(YNGoldCoinActivity.this);
                builder.setIcon(R.drawable.circle_green3x);
                builder.setTitle("请选择支付方式");
                final String[] sex = {"支付宝", "微信"};

                builder.setSingleChoiceItems(sex, 1, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(YNGoldCoinActivity.this, "支付方式：" + sex[which], Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {

                        //开始充值,先判断是否有充值金额输入
                        if(mAdapter.getCoinMoney()<1 || mCoinNumb.equals("0")){
                            Toast.makeText(context, "请输入充值金额", Toast.LENGTH_SHORT)
                                 .show();
                                return;
                        }else {
                            //判断是选择固定充值金额还是自定义充值金额
                            if (mCoinNumb.equals("0") || mCoinNumb == null) {
                                mCoinNumb = "" + mAdapter.getCoinMoney();
                            }
                            mHandler.post(new Runnable() {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance()
                                                 .getGoldCoin(YNGoldCoinActivity.this,
                                                              YNCommonConfig.GET_GOLD_COIN_URL,
                                                              AccountUtils.getAccountBean()
                                                                          .getId(),
                                                              mCoinNumb,
                                                              mHandler,
                                                              YNCommonConfig.GET_MINE_GOLD_COIN_FLAG,
                                                              true);
                                }
                            });
                            //输入金币内容清空
                            mInputMoney.setText(null);
                        }
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {

                    }
                });
                builder.show();
              }else{
                  Intent intent1=new Intent(YNGoldCoinActivity.this,YNLoginActivity.class);
                  startActivity(intent1);
              }
                break;
            case R.id.et_input_money:
                mAdapter.lastPressIndex=-1;
                 mInputMoney.setText(null);
                mAdapter.notifyDataSetChanged();
                break;
        }
    }

    private List<CoinMoneyBean> getCoinData()
    {
        coinMoneyList = new ArrayList<>();
        coinMoneyList.add(new CoinMoneyBean(8, 8));
        coinMoneyList.add(new CoinMoneyBean(30, 30));
        coinMoneyList.add(new CoinMoneyBean(98, 98));
        coinMoneyList.add(new CoinMoneyBean(800, 800));
        coinMoneyList.add(new CoinMoneyBean(1330, 1330));

        return coinMoneyList;
    }


    //动态监听Editext的内容
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
       // mPaymentTotalTV.setText(s.toString().trim());
        mCoinNumb=s.toString().trim();
        mTxtCoin.setText("立即充值"+s.toString().trim()+"金币");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
    }

    //获取当前金币
    // 获取用户当前金币
    private void getCurrentCoin()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getCurrentGoldCoin(YNGoldCoinActivity.this, YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

            }
        });
    }

    /**
     * 支付宝支付
     */
    private void zfbPay()
    {
        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(YNGoldCoinActivity.this);
                Map<String, String> result = alipay.payV2("业内科技", true);
                Log.i("msp", result.toString());

                Message msg = new Message();
                msg.what = ZFB_SDK_PAY_FLAG;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    private void wxPay()
    {

    }
}
