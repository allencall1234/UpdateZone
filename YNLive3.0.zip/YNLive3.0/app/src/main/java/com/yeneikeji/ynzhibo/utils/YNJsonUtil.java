package com.yeneikeji.ynzhibo.utils;

import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.List;

/**
 * Json字符串转换工具类
 * Created by Administrator on 2016/8/6.
 */
public final class YNJsonUtil
{
    private YNJsonUtil()
    {

    }

    /**
     * 对象转换成json字符串
     * @param object
     * @return
     */
    public static String toJson(Object object)
    {
        Gson gson = new Gson();
        return gson.toJson(object);
    }

    /**
     * json字符串转成对象
     * @param string
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T fromJson(String string, Type type)
    {
        Gson gson = new Gson();
        return gson.fromJson(string, type);
    }

    /**
     * json字符串转成对象
     * @param string
     * @param type
     * @param <T>
     * @return
     */
    public static <T> T fromJson(String string, Class<T> type)
    {
        Gson gson = new Gson();
        return gson.fromJson(string, type);
    }


    /**
     * Json转化为Bean (解析jsonObject)
     * @param json
     * @param classOfT
     * @param <T>
     * @return
     */
    public static <T> T JsonToBean(String json, Class<T> classOfT){
        Gson gson = new Gson();
        T clazz = gson.fromJson(json, classOfT);
        return clazz;
    }

    /**
     * Json转化为Bean (解析jsonArray)
     * @param json
     * @param typeOfT
     * @param <T>
     * @return
     */
    public static <T> List<T> JsonToLBean(String json, Type typeOfT)
    {
        Gson gson = new Gson();
        Object clazz = gson.fromJson(json, typeOfT);
        return (List<T>) clazz;
    }

}
