package com.yeneikeji.ynzhibo.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.yeneikeji.ynzhibo.model.LiveRoomBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/5/10.
 */
public class WatchRecordDao
{
    public static final String TABLE_NAME = "tab_watch_record";

    public static final String COLUMN_NAME_ID = "id";
    public static final String COLUMN_NAME_USER_ID = "user_id";
    public static final String COLUMN_NAME_USERNAME = "username";
    public static final String COLUMN_NAME_ICON = "icon";
    public static final String COLUMN_NAME_PUSH_ADDRESS = "push_address";
    public static final String COLUMN_NAME_PLAY_ADDRESS = "play_address";
    public static final String COLUMN_NAME_ROOM_ID = "room_id";
    public static final String COLUMN_NAME_PICTURE = "picture";
    public static final String COLUMN_NAME_TITLE = "title";
    public static final String COLUMN_NAME_TAG = "tag";
    public static final String COLUMN_NAME_IS_ATTENTION = "is_attention";
    public static final String COLUMN_NAME_FANS_COUNT = "fans_count";
    public static final String COLUMN_NAME_FOCUS_COUNT = "focus_count";
    public static final String COLUMN_NAME_DYNAMIC_COUNT = "dynamic_count";
    public static final String COLUMN_NAME_ACCOUNT = "account";
    public static final String COLUMN_NAME_EQUIPMENT = "equipment";
    public static final String COLUMN_NAME_ATTENTION_ID = "attention_id";
    public static final String COLUMN_NAME_DESCRIBES = "describes";
    public static final String COLUMN_NAME_USER_STATUS = "user_status";
    public static final String COLUMN_NAME_STATUS = "status";
    public static final String COLUMN_NAME_PAY_COIN = "payCoin";
    public static final String COLUMN_NAME_LIVING = "living";
    public static final String COLUMN_NAME_LIVE_STATUS = "live_status";
    public static final String COLUMN_NAME_LOCK = "lock";
    public static final String COLUMN_NAME_IS_PAY = "is_pay";
    public static final String COLUMN_NAME_LIVE_COUNT = "liveCount";
    public static final String COLUMN_NAME_TIME = "time";

    private DbOpenHelper dbHelper;

    public WatchRecordDao(Context context)
    {
        dbHelper = DbOpenHelper.getInstance(context);
    }
    /**
     * 插入一条记录
     * @return 插入记录的id -1表示插入不成功
     */
    public long insertWatchRecord(LiveRoomBean liveRoomBean)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        boolean isInsert = true;
        List<LiveRoomBean> watchList = getWatchRecordList();
        for (LiveRoomBean liveRoom : watchList)
        {
            if (liveRoomBean.getRoom_id().equals(liveRoom.getRoom_id()))
            {
                isInsert = false;
                break;
            }
        }
        long id = -1;
        if (db != null && isInsert)
        {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME_ID, Integer.parseInt(liveRoomBean.getId()));
            values.put(COLUMN_NAME_USER_ID, Integer.parseInt(liveRoomBean.getUserid()));
            values.put(COLUMN_NAME_USER_ID, Integer.parseInt(liveRoomBean.getUserid()));
            values.put(COLUMN_NAME_USERNAME, liveRoomBean.getUsername());
            values.put(COLUMN_NAME_ICON, liveRoomBean.getIcon());
            values.put(COLUMN_NAME_PUSH_ADDRESS, liveRoomBean.getPush_address());
            values.put(COLUMN_NAME_PLAY_ADDRESS, liveRoomBean.getPlay_address());
            values.put(COLUMN_NAME_ROOM_ID, liveRoomBean.getRoom_id());
            values.put(COLUMN_NAME_PICTURE, liveRoomBean.getPicture());
            values.put(COLUMN_NAME_TITLE, liveRoomBean.getTitle());
            values.put(COLUMN_NAME_TAG, liveRoomBean.getTag());
            values.put(COLUMN_NAME_IS_ATTENTION, liveRoomBean.getIs_attention());
            values.put(COLUMN_NAME_FANS_COUNT, liveRoomBean.getFuns_count());
            values.put(COLUMN_NAME_FOCUS_COUNT, liveRoomBean.getFocus_count());
            values.put(COLUMN_NAME_DYNAMIC_COUNT, liveRoomBean.getDynamic_count());
            values.put(COLUMN_NAME_ACCOUNT, liveRoomBean.getAcount());
            values.put(COLUMN_NAME_EQUIPMENT, liveRoomBean.getEquipment());
            values.put(COLUMN_NAME_ATTENTION_ID, liveRoomBean.getAttentionid());
            values.put(COLUMN_NAME_DESCRIBES, liveRoomBean.getDescribe());
            values.put(COLUMN_NAME_USER_STATUS, liveRoomBean.getUser_status());
            values.put(COLUMN_NAME_STATUS, liveRoomBean.getStatus());
            values.put(COLUMN_NAME_PAY_COIN, liveRoomBean.getPayCoin());
            values.put(COLUMN_NAME_LIVING, liveRoomBean.getLiving());
            values.put(COLUMN_NAME_LIVE_STATUS, liveRoomBean.getLive_status());
            values.put(COLUMN_NAME_LOCK, liveRoomBean.getLock());
            values.put(COLUMN_NAME_IS_PAY, liveRoomBean.getIs_pay());
            values.put(COLUMN_NAME_LIVE_COUNT, liveRoomBean.getLiveCount());
            values.put(COLUMN_NAME_TIME, liveRoomBean.getTime());

            id = db.insert(TABLE_NAME, null, values);
        }
        return id;
    }

    /**
     * 获取观看历史记录list
     * @return
     */
    public List<LiveRoomBean> getWatchRecordList()
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<LiveRoomBean> watchList = new ArrayList<>();
        if(db.isOpen())
        {
            Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " desc", null);
            while(cursor.moveToNext())
            {
                LiveRoomBean liveRoomBean = new LiveRoomBean();
                String id = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ID));
                String userId = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USER_ID));
                String username = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERNAME));
                String icon = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ICON));
                String push_address = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_PUSH_ADDRESS));
                String play_address = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_PLAY_ADDRESS));
                String room_id = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ROOM_ID));
                String picture = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_PICTURE));
                String title = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TITLE));
                String tag = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TAG));
                int is_attention = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_IS_ATTENTION));
                int fans_count = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_FANS_COUNT));
                int focus_count = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_FOCUS_COUNT));
                int dynamic_count = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_DYNAMIC_COUNT));
                int account = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_ACCOUNT));
                int equipment = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_EQUIPMENT));
                int attention_id = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_ATTENTION_ID));
                String describes = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_DESCRIBES));
                int user_status = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_USER_STATUS));
                String status = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_STATUS));
                int payCoin = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_PAY_COIN));
                int living = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_LIVING));
                int live_status = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_LIVE_STATUS));
                int lock = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_LOCK));
                int is_pay = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_IS_PAY));
                int liveCount = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_LIVE_COUNT));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TIME));

                liveRoomBean.setId(id);
                liveRoomBean.setUserid(userId);
                liveRoomBean.setUsername(username);
                liveRoomBean.setIcon(icon);
                liveRoomBean.setPush_address(push_address);
                liveRoomBean.setPlay_address(play_address);
                liveRoomBean.setRoom_id(room_id);
                liveRoomBean.setPicture(picture);
                liveRoomBean.setTitle(title);
                liveRoomBean.setTag(tag);
                liveRoomBean.setIs_attention(is_attention);
                liveRoomBean.setFuns_count(fans_count);
                liveRoomBean.setFocus_count(focus_count);
                liveRoomBean.setDynamic_count(dynamic_count);
                liveRoomBean.setAcount(account);
                liveRoomBean.setEquipment(equipment);
                liveRoomBean.setAttentionid(String.valueOf(attention_id));
                liveRoomBean.setDescribe(describes);
                liveRoomBean.setUser_status(user_status);
                liveRoomBean.setStatus(status);
                liveRoomBean.setPayCoin(payCoin);
                liveRoomBean.setLiving(living);
                liveRoomBean.setLive_status(live_status);
                liveRoomBean.setLock(lock);
                liveRoomBean.setIs_pay(is_pay);
                liveRoomBean.setLiveCount(liveCount);
                liveRoomBean.setTime(time);

                watchList.add(liveRoomBean);
            }
            cursor.close();
        }
        return watchList;
    }

    /**
     * 删除一个记录
     * @param roomId
     */
    public void deleteWatchRecord(String roomId)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if(db.isOpen())
        {
            String whereClauses = COLUMN_NAME_ROOM_ID + "=?";
            String [] whereArgs = { roomId };
            //调用delete方法，删除数据
            db.delete(TABLE_NAME, whereClauses, whereArgs);
            dbHelper.closeDb();
        }
    }

    /**
     * 清空数据
     */
    public void deleteAllRecord()
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("delete from " + TABLE_NAME);
        dbHelper.closeDb();
    }

}
