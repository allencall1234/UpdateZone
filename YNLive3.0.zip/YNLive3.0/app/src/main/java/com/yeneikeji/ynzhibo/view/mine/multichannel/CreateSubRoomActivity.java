package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNIndexEditText;
import com.yeneikeji.ynzhibo.common.YNMyTextView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 创建子房间、添加管理员
 * Created by Administrator on 2017/7/28.
 */
public class CreateSubRoomActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private TextView mTVInputNotice;
    private YNIndexEditText mETSearch;
    private RelativeLayout mRLSearchContent;
    private YNMyTextView mTVAnchor;
    private RelativeLayout mRLLiveHost;
    private LinearLayout mLLShowResult;
    private TextView mTVNoResult;
    private RelativeLayout mRLSearchResult;

    private ImageView mIVAnchorHead;
    private TextView mTVAnchorNickName;
    private TextView mTVAnchorSign;
    private TextView mTVAuthenticationResult;
    private TextView mTVAuthenticationAnchor;

    private LiveRoomBean anchorInfo;
    private boolean isAddManager = false;
    private boolean isAuthenticationAnchor = false;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.SEARCH_ANCHOR_FLAG:
                    mRLLiveHost.setVisibility(View.VISIBLE);
                    mLLShowResult.setVisibility(View.VISIBLE);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 212 || baseBean.getCode() == 214)
                        {
                            mRLSearchResult.setVisibility(View.VISIBLE);
                            mTVNoResult.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                anchorInfo = YNJsonUtil.JsonToBean(jsonObject.optString("data"), LiveRoomBean.class);
                                showSearchResult();
                                if (baseBean.getCode() == 212)// 未认证
                                {
                                    // 邀请认证成为主播
                                    isAuthenticationAnchor = true;
                                    mTVAuthenticationResult.setVisibility(View.VISIBLE);
                                }
                                else
                                {
                                    // 邀请成为多通道房间房管或者子房间的房主
                                    isAuthenticationAnchor = false;
                                    if (isAddManager)
                                       mTVAuthenticationAnchor.setText("邀请TA担任管理员");
                                    else
                                       mTVAuthenticationAnchor.setText("邀请TA担任子房间房主");
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            if (baseBean.getCode() == 211)// 找不到用户
                            {
                                mLLShowResult.setVisibility(View.VISIBLE);
                                mTVNoResult.setVisibility(View.VISIBLE);
                                mRLSearchResult.setVisibility(View.GONE);
                            }
                            else
                            {
                                mLLShowResult.setVisibility(View.VISIBLE);
                                mTVNoResult.setVisibility(View.VISIBLE);
                                mTVNoResult.setText(baseBean.getInfo());
                                mRLSearchResult.setVisibility(View.GONE);
                                YNToastMaster.showToast(CreateSubRoomActivity.this, baseBean.getInfo());
                            }
                        }
                    }
                    else
                    {
                        mRLSearchResult.setVisibility(View.GONE);
                        mTVNoResult.setVisibility(View.GONE);
                        YNToastMaster.showToast(CreateSubRoomActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.MULTICHANNEL_ROOM_INVITATION_MANAGER_FLAG:
                    mRLSearchResult.setVisibility(View.GONE);
                    mTVNoResult.setVisibility(View.GONE);
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("aaa",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(CreateSubRoomActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(CreateSubRoomActivity.this, R.string.request_fail);
                    }
                    break;

                case YNCommonConfig.INVITATION_CHILD_ROOM_OWNER_FLAG:
                    mRLSearchResult.setVisibility(View.GONE);
                    mTVNoResult.setVisibility(View.GONE);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(CreateSubRoomActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(CreateSubRoomActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private String mRoomHostid;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_subroom);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }
    @Override
    protected void initView()
    {
        isAddManager = getIntent().getBooleanExtra(YNCommonConfig.TITLE, false);
        //是添加管理员的话获取房主的Id
            mRoomHostid = getIntent().getStringExtra(YNCommonConfig.OBJECT);
        configTopBarCtrollerWithTitle(isAddManager ? "添加管理员" : "创建子房间");

        mTVInputNotice = (TextView) findViewById(R.id.tv_input_notice);
        mETSearch = (YNIndexEditText) findViewById(R.id.et_search_anchor);
        mRLSearchContent = (RelativeLayout) findViewById(R.id.rl_search_content);
        mTVAnchor = (YNMyTextView) findViewById(R.id.tv_anchor);
        mRLLiveHost = (RelativeLayout) findViewById(R.id.rl_live_host);
        mLLShowResult = (LinearLayout) findViewById(R.id.ll_show_result);
        mTVNoResult = (TextView) findViewById(R.id.tv_no_result);
        mRLSearchResult = (RelativeLayout) findViewById(R.id.search_result);
        mIVAnchorHead = (ImageView) mRLSearchResult.findViewById(R.id.iv_anchor_head);
        mTVAnchorNickName = (TextView) mRLSearchResult.findViewById(R.id.tv_anchor_nickname);
        mTVAnchorSign = (TextView) mRLSearchResult.findViewById(R.id.tv_anchor_sign);
        mTVAuthenticationResult = (TextView) mRLSearchResult.findViewById(R.id.tv_authentication_result);
        mTVAuthenticationAnchor = (TextView) mRLSearchResult.findViewById(R.id.tv_authentication_anchor);

    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLSearchContent.setOnClickListener(this);
        mRLSearchResult.setOnClickListener(this);
        mTVAuthenticationAnchor.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        // 搜索框的键盘搜索键点击回调
        mETSearch.setOnKeyListener(new View.OnKeyListener() {// 输入完后按键盘上的搜索键

            public boolean onKey(View v, int keyCode, KeyEvent event)
            {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)
                {// 修改回车键功能
                    // 先隐藏键盘
                    ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                            getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    if (TextUtils.isEmpty(mETSearch.getText().toString()))
                    {
                        YNToastMaster.showToast(CreateSubRoomActivity.this, "请输入用户ID");
                    }
                    if (!YNCommonUtils.isNumber(mETSearch.getText().toString()))
                    {
                        YNToastMaster.showToast(CreateSubRoomActivity.this, "用户ID有误");
                    }
                    if (!TextUtils.isEmpty(mETSearch.getText().toString()) && YNCommonUtils.isNumber(mETSearch.getText().toString()))
                    {
                        mRLSearchContent.setVisibility(View.GONE);
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().searchAnchor(CreateSubRoomActivity.this, YNCommonConfig.SEARCH_ANCHOR_URL, getSearchET().getText().toString(),
                                        mHandler, YNCommonConfig.SEARCH_ANCHOR_FLAG, false);
                            }
                        });
                    }
                }
                return false;
            }
        });

        mETSearch.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                if (mETSearch.getText().length() > 0)
                {
                    mRLSearchContent.setVisibility(View.VISIBLE);
                    mTVAnchor.setText("搜索用户ID为“" + mETSearch.getText().toString() + "”的主播");
                    mTVAnchor.setSpecifiedTextsColor(mTVAnchor.getText().toString(), mETSearch.getText().toString().trim(), Color.parseColor("#FF0000"));
                }
                else
                {
                    mRLSearchContent.setVisibility(View.GONE);
                    mRLLiveHost.setVisibility(View.GONE);
                    mLLShowResult.setVisibility(View.GONE);
                }
            }
            @Override
            public void afterTextChanged(Editable s)
            {
                if (mETSearch.getText().length() > 0)
                {
                    mRLSearchContent.setVisibility(View.VISIBLE);
                    mTVAnchor.setText("搜索用户ID为“" + mETSearch.getText().toString() + "”的主播");
                    mTVAnchor.setSpecifiedTextsColor(mTVAnchor.getText().toString(), mETSearch.getText().toString().trim(), Color.parseColor("#FF0000"));
                }
                else
                {
                    mRLSearchContent.setVisibility(View.GONE);
                    mRLLiveHost.setVisibility(View.GONE);
                    mLLShowResult.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                YNCommonUtils.hideSoftInput(this, view);
                finish();
                break;

            case R.id.rl_search_content:
                if (TextUtils.isEmpty(mETSearch.getText().toString()))
                {
                    YNToastMaster.showToast(this, "请输入用户ID");
                    return;
                }
                if (!YNCommonUtils.isNumber(mETSearch.getText().toString()))
                {
                    YNToastMaster.showToast(this, "用户ID有误");
                    return;
                }
                mRLSearchContent.setVisibility(View.GONE);
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().searchAnchor(CreateSubRoomActivity.this, YNCommonConfig.SEARCH_ANCHOR_URL, mETSearch.getText().toString(), mHandler, YNCommonConfig.SEARCH_ANCHOR_FLAG, false);
                    }
                });
                break;

            case R.id.tv_authentication_anchor:
                if (isAuthenticationAnchor)
                    authenticationAnchor();
                else
                    multichannelRoomManagerInvitation();
                break;
        }
    }

    /**
     * 显示搜索结果
     */
    private void showSearchResult()
    {
        YNImageLoaderUtil.setImageWithErrorImg(this, mIVAnchorHead, R.drawable.hand_none, R.drawable.hand_none, anchorInfo.getIcon());
        mTVAnchorNickName.setText(anchorInfo.getUsername());
        mTVAnchorSign.setText(anchorInfo.getDescribe());
    }

    /**
     * 邀请认证成为主播
     */
    private void authenticationAnchor()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {

            }
        });
    }

    /**
     * 多通道房间发送房管邀请、子房间发送房主邀请
     */
    private void multichannelRoomManagerInvitation()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                if (isAddManager)
                {

                    UserHttpUtils.newInstance().multichannelRoomInvitationManager(CreateSubRoomActivity.this, YNCommonConfig.MULTICHANNEL_ROOM_INVITATION_MANAGER_URL, anchorInfo.getId(), mRoomHostid,
                            mHandler, YNCommonConfig.MULTICHANNEL_ROOM_INVITATION_MANAGER_FLAG, true);
                }
                else
                {
                    UserHttpUtils.newInstance().childRoomOwnerInvitation(CreateSubRoomActivity.this, YNCommonConfig.INVITATION_CHILD_ROOM_OWNER_URL, anchorInfo.getId(),mRoomHostid,
                            mHandler, YNCommonConfig.INVITATION_CHILD_ROOM_OWNER_FLAG, true);
                }
            }
        });
    }
}
