package com.yeneikeji.ynzhibo.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.yeneikeji.ynzhibo.model.DynamicBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/5/8.
 */
public class DynamicDao
{
    public static final String TABLE_NAME = "dynamic";
    public static final String COLUMN_NAME_ID = "id";
    public static final String COLUMN_NAME_USER_ID = "user_id";
    public static final String COLUMN_NAME_CONTENT = "content";
    public static final String COLUMN_NAME_TIME = "time";
    public static final String COLUMN_NAME_ICON = "icon";
    public static final String COLUMN_NAME_USERNAME = "username";
    public static final String COLUMN_COMMENT_NUM = "comment_num";
    public static final String COLUMN_ZAN_NUM = "zan_num";
    public static final String COLUMN_IS_ATTENTION = "is_attention";
    public static final String COLUMN_THUMB = "thumb";
    public static final String COLUMN_PIC0 = "picture0";
    public static final String COLUMN_PIC1 = "picture1";
    public static final String COLUMN_PIC2 = "picture2";
    public static final String COLUMN_PIC3 = "picture3";
    public static final String COLUMN_PIC4 = "picture4";
    public static final String COLUMN_PIC5 = "picture5";
    public static final String COLUMN_PIC6 = "picture6";
    public static final String COLUMN_PIC7 = "picture7";
    public static final String COLUMN_PIC8 = "picture8";
    public static final String COLUMN_SMALL_PIC0 = "smallpicture0";
    public static final String COLUMN_SMALL_PIC1 = "smallpicture1";
    public static final String COLUMN_SMALL_PIC2 = "smallpicture2";
    public static final String COLUMN_SMALL_PIC3 = "smallpicture3";
    public static final String COLUMN_SMALL_PIC4 = "smallpicture4";
    public static final String COLUMN_SMALL_PIC5 = "smallpicture5";
    public static final String COLUMN_SMALL_PIC6 = "smallpicture6";
    public static final String COLUMN_SMALL_PIC7 = "smallpicture7";
    public static final String COLUMN_SMALL_PIC8 = "smallpicture8";

    private DbOpenHelper dbHelper;

    public DynamicDao(Context context) {
        dbHelper = DbOpenHelper.getInstance(context);
    }

    /**
     * 保存动态list
     * @param dynamic
     */
    public void saveDynamic(DynamicBean dynamic)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        boolean isInsert = true;
        if (db.isOpen())
        {
//            db.delete(TABLE_NAME, null, null);
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME_ID, dynamic.getId());
            values.put(COLUMN_NAME_USER_ID, dynamic.getUserid());
            values.put(COLUMN_NAME_CONTENT, dynamic.getContent());
            values.put(COLUMN_NAME_TIME, dynamic.getTime());
            values.put(COLUMN_NAME_ICON, dynamic.getIcon());
            values.put(COLUMN_NAME_USERNAME, dynamic.getUsername());
            values.put(COLUMN_COMMENT_NUM, dynamic.getComment_num());
            values.put(COLUMN_ZAN_NUM, dynamic.getZan_num());
            values.put(COLUMN_IS_ATTENTION, dynamic.getIs_attention());
            values.put(COLUMN_IS_ATTENTION, dynamic.getIs_attention());
            values.put(COLUMN_THUMB, dynamic.getThumb());
            values.put(COLUMN_PIC0, dynamic.getPicture0());
            values.put(COLUMN_PIC1, dynamic.getPicture1());
            values.put(COLUMN_PIC2, dynamic.getPicture2());
            values.put(COLUMN_PIC3, dynamic.getPicture3());
            values.put(COLUMN_PIC4, dynamic.getPicture4());
            values.put(COLUMN_PIC5, dynamic.getPicture5());
            values.put(COLUMN_PIC6, dynamic.getPicture6());
            values.put(COLUMN_PIC7, dynamic.getPicture7());
            values.put(COLUMN_PIC8, dynamic.getPicture8());
            values.put(COLUMN_SMALL_PIC0, dynamic.getSmallpicture0());
            values.put(COLUMN_SMALL_PIC1, dynamic.getSmallpicture1());
            values.put(COLUMN_SMALL_PIC2, dynamic.getSmallpicture2());
            values.put(COLUMN_SMALL_PIC3, dynamic.getSmallpicture3());
            values.put(COLUMN_SMALL_PIC4, dynamic.getSmallpicture4());
            values.put(COLUMN_SMALL_PIC5, dynamic.getSmallpicture5());
            values.put(COLUMN_SMALL_PIC6, dynamic.getSmallpicture6());
            values.put(COLUMN_SMALL_PIC7, dynamic.getSmallpicture7());
            values.put(COLUMN_SMALL_PIC8, dynamic.getSmallpicture8());

            List<DynamicBean> dynamics = getDynamicList();
            for (DynamicBean dynamicBean : dynamics)
            {
                if (dynamic.getId().equals(dynamicBean.getId()))
                {
                    isInsert = false;
                    break;
                }
            }

            if (isInsert)
            {
                db.insert(TABLE_NAME, null, values);
            }

            dbHelper.closeDb();
        }
    }

    /**
     * 获取动态list
     * @return
     */
    public List<DynamicBean> getDynamicList()
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<DynamicBean> dynamics = new ArrayList<DynamicBean>();
        if(db.isOpen()){
            Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " desc",null);
            while(cursor.moveToNext()){
                DynamicBean dynamicBean = new DynamicBean();
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_ID));
                int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_USER_ID));
                String content = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_CONTENT));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TIME));
                String icon = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ICON));
                String username = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERNAME));
                int comment_num = cursor.getInt(cursor.getColumnIndex(COLUMN_COMMENT_NUM));
                int thumb_num = cursor.getInt(cursor.getColumnIndex(COLUMN_ZAN_NUM));
                int is_attention = cursor.getInt(cursor.getColumnIndex(COLUMN_IS_ATTENTION));
                int thumb = cursor.getInt(cursor.getColumnIndex(COLUMN_THUMB));
                String pic0 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC0));
                String pic1 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC1));
                String pic2 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC2));
                String pic3 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC3));
                String pic4 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC4));
                String pic5 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC5));
                String pic6 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC6));
                String pic7 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC7));
                String pic8 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC8));
                String smallPic0 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC0));
                String smallPic1 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC1));
                String smallPic2 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC2));
                String smallPic3 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC3));
                String smallPic4 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC4));
                String smallPic5 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC5));
                String smallPic6 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC6));
                String smallPic7 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC7));
                String smallPic8 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC8));

                dynamicBean.setId(String.valueOf(id));
                dynamicBean.setUserid(String.valueOf(userId));
                dynamicBean.setContent(content);
                dynamicBean.setTime(time);
                dynamicBean.setIcon(icon);
                dynamicBean.setUsername(username);
                dynamicBean.setComment_num(comment_num);
                dynamicBean.setZan_num(thumb_num);
                dynamicBean.setIs_attention(is_attention);
                dynamicBean.setThumb(thumb);
                dynamicBean.setPicture0(pic0);
                dynamicBean.setPicture1(pic1);
                dynamicBean.setPicture2(pic2);
                dynamicBean.setPicture3(pic3);
                dynamicBean.setPicture4(pic4);
                dynamicBean.setPicture5(pic5);
                dynamicBean.setPicture6(pic6);
                dynamicBean.setPicture7(pic7);
                dynamicBean.setPicture8(pic8);
                dynamicBean.setSmallpicture0(smallPic0);
                dynamicBean.setSmallpicture1(smallPic1);
                dynamicBean.setSmallpicture2(smallPic2);
                dynamicBean.setSmallpicture3(smallPic3);
                dynamicBean.setSmallpicture4(smallPic4);
                dynamicBean.setSmallpicture5(smallPic5);
                dynamicBean.setSmallpicture6(smallPic6);
                dynamicBean.setSmallpicture7(smallPic7);
                dynamicBean.setSmallpicture8(smallPic8);

                dynamics.add(dynamicBean);
            }
            cursor.close();
            dbHelper.closeDb();
        }
        return dynamics;
    }

    public DynamicBean queryDynamic(int dynamicId)
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        if (db.isOpen())
        {
            String sql = "select * from " + TABLE_NAME +  "where id = ?";
            Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(dynamicId)});
            while(cursor.moveToNext())
            {
                DynamicBean dynamicBean = new DynamicBean();
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_ID));
                int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_USER_ID));
                String content = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_CONTENT));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TIME));
                String icon = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ICON));
                String username = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERNAME));
                int comment_num = cursor.getInt(cursor.getColumnIndex(COLUMN_COMMENT_NUM));
                int thumb_num = cursor.getInt(cursor.getColumnIndex(COLUMN_ZAN_NUM));
                int is_attention = cursor.getInt(cursor.getColumnIndex(COLUMN_IS_ATTENTION));
                int thumb = cursor.getInt(cursor.getColumnIndex(COLUMN_THUMB));
                String pic0 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC0));
                String pic1 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC1));
                String pic2 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC2));
                String pic3 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC3));
                String pic4 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC4));
                String pic5 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC5));
                String pic6 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC6));
                String pic7 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC7));
                String pic8 = cursor.getString(cursor.getColumnIndex(COLUMN_PIC8));
                String smallPic0 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC0));
                String smallPic1 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC1));
                String smallPic2 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC2));
                String smallPic3 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC3));
                String smallPic4 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC4));
                String smallPic5 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC5));
                String smallPic6 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC6));
                String smallPic7 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC7));
                String smallPic8 = cursor.getString(cursor.getColumnIndex(COLUMN_SMALL_PIC8));

                dynamicBean.setId(String.valueOf(id));
                dynamicBean.setUserid(String.valueOf(userId));
                dynamicBean.setContent(content);
                dynamicBean.setTime(time);
                dynamicBean.setIcon(icon);
                dynamicBean.setUsername(username);
                dynamicBean.setComment_num(comment_num);
                dynamicBean.setZan_num(thumb_num);
                dynamicBean.setIs_attention(is_attention);
                dynamicBean.setThumb(thumb);
                dynamicBean.setPicture0(pic0);
                dynamicBean.setPicture1(pic1);
                dynamicBean.setPicture2(pic2);
                dynamicBean.setPicture3(pic3);
                dynamicBean.setPicture4(pic4);
                dynamicBean.setPicture5(pic5);
                dynamicBean.setPicture6(pic6);
                dynamicBean.setPicture7(pic7);
                dynamicBean.setPicture8(pic8);
                dynamicBean.setSmallpicture0(smallPic0);
                dynamicBean.setSmallpicture1(smallPic1);
                dynamicBean.setSmallpicture2(smallPic2);
                dynamicBean.setSmallpicture3(smallPic3);
                dynamicBean.setSmallpicture4(smallPic4);
                dynamicBean.setSmallpicture5(smallPic5);
                dynamicBean.setSmallpicture6(smallPic6);
                dynamicBean.setSmallpicture7(smallPic7);
                dynamicBean.setSmallpicture8(smallPic8);

                return dynamicBean;
            }
        }

        return null;
    }

}
