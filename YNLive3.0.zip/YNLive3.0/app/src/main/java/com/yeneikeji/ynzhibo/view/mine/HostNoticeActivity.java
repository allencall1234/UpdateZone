package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/*
* 这是主播公告的类
* */
public class HostNoticeActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private TextView mCalculateMoney;
    private TextView mLiveContent;
    private TextView mPunishNotice;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_notice);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("主播公告");
        mCalculateMoney = (TextView) findViewById(R.id.host_money_calculate_data_notice);
        mLiveContent = (TextView) findViewById(R.id.platform_forcer_host_live_content);
        mPunishNotice = (TextView) findViewById(R.id.host_betray_playform_rule_punish_notice);

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mCalculateMoney.setOnClickListener(this);
        mLiveContent.setOnClickListener(this);
        mPunishNotice.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //主播结算工资
            case R.id.host_money_calculate_data_notice:
                mIntent = new Intent(HostNoticeActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, "calculateMoney");
                startActivity(mIntent);
                break;
            //主播直播内容监管
            case R.id.platform_forcer_host_live_content:
                mIntent = new Intent(HostNoticeActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, "controllerLiveContent");
                startActivity(mIntent);
                break;
            //主播惩罚通知
            case R.id.host_betray_playform_rule_punish_notice:
                mIntent = new Intent(HostNoticeActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, "punishHostNotice");
                startActivity(mIntent);
                break;

        }
    }
}
