package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.CalculateBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/*
* 这是结算财富首页跳转过来的财富列表
* */
public class SettlementWealthActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private ExpandableListView                 mExpandableListView;
    private CalculateBean                      mWaitCalculateBean;
    private CalculateBean                      mHaveCalculateBean;
    private List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>       data1=new ArrayList();
    private List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>       data2=new ArrayList();
    private List<List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>> datas=new ArrayList();
    private TotalWealthEpAdapter mAdapter;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_WAIT_CALCULATE_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        YNLogUtil.e("aaaa",msg.obj.toString());
                        if (baseBean.getCode() == 28) {
                            try {
                                Gson gson =new Gson();
                                mWaitCalculateBean = gson.fromJson(msg.obj.toString(),
                                                                   CalculateBean.class);
                                if(mWaitCalculateBean.getData()!=null&&mWaitCalculateBean.getData().getYeIncome().get(0).getMoIncome().size()>0) {
                                 //月收入集合
                                    List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean> moIncomes = mWaitCalculateBean.getData()
                                                                                                                        .getYeIncome()
                                                                                                                        .get(0)
                                                                                                                        .getMoIncome();
                                    for(int a=0; a<moIncomes.size();a++){
                                        //大于0才加进去
                                        if(moIncomes.get(a).getSum()>0){
                                            data1.add(moIncomes.get(a));
                                        }
                                    }
                                }
                                //添加一个结算对象，在最后
                                data1.add(new CalculateBean.DataBean.YeIncomeBean.MoIncomeBean() );
                                datas.clear();
                                datas.add(0,data1);
                                datas.add(1,data2);
                                mAdapter.upDateList(datas);

                            } catch (Exception e) {

                                e.printStackTrace();
                            }

                        } else {

                        }
                    } else {
                        datas.clear();
                        datas.add(0,data1);
                        datas.add(1,data2);
                        mAdapter.upDateList(datas);
                    }
                    break;

                case YNCommonConfig.GET_HAVE_CALCULATE_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                Gson gson =new Gson();
                                mHaveCalculateBean = gson.fromJson(msg.obj.toString(),
                                                                   CalculateBean.class);
                                if(mHaveCalculateBean.getData()!=null&&mHaveCalculateBean.getData().getYeIncome().get(0).getMoIncome().size()>0) {
                                    //月收入集合
                                    List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean> moIncomes = mHaveCalculateBean.getData()
                                                                                                                         .getYeIncome()
                                                                                                                         .get(0)
                                                                                                                         .getMoIncome();

                                    for (int a = 0; a < moIncomes.size(); a++) {
                                        //大于0才加进去
                                        if(moIncomes.get(a).getSum()>0){
                                            data2.add(moIncomes.get(a));
                                        }

                                    }

                                }
                                datas.clear();
                                datas.add(0,data1);
                                datas.add(1,data2);
                                mAdapter.upDateList(datas);
                            } catch (Exception e) {

                                e.printStackTrace();
                            }

                        } else {

                        }
                    } else {
                        datas.clear();
                        datas.add(0,data1);
                        datas.add(1,data2);
                        mAdapter.upDateList(datas);
                    }
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settlement_wealth);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("结算财富");
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText("帮助");
        mExpandableListView = (ExpandableListView) findViewById(R.id.settlement_wealth_expandableListView);
        mExpandableListView.setGroupIndicator(null);
        datas.add(data1);
        datas.add(data2);
        mAdapter = new TotalWealthEpAdapter(SettlementWealthActivity.this, datas);
        mExpandableListView.setAdapter(mAdapter);
        loadData();

    }

    private void loadData() {
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getCalculateInfo(SettlementWealthActivity.this,
                                                    YNCommonConfig.GET_WAIT_CALCULATE_URL,
                                                    AccountUtils.getAccountBean()
                                                                .getId(),
                                               "0",
                                                    handler,
                                                    YNCommonConfig.GET_WAIT_CALCULATE_FLAG, false);
            }
        });

        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getCalculateInfo(SettlementWealthActivity.this,
                                               YNCommonConfig.GET_WAIT_CALCULATE_URL,
                                               AccountUtils.getAccountBean()
                                                           .getId(),
                                               "1",
                                               handler,
                                               YNCommonConfig.GET_HAVE_CALCULATE_FLAG, false);
            }
        });
    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
    }

    @Override
    protected void settingDo() {


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
     class TotalWealthEpAdapter extends BaseExpandableListAdapter {
        private List<List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>>       mdatas=new ArrayList();
        private Context                                           mContext;
         private CalculateBean.DataBean.YeIncomeBean.MoIncomeBean  dataBean;
        public TotalWealthEpAdapter(Context context, List<List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>> datas){
            mContext = context;
            this.mdatas = datas;
        }
         public void  upDateList(List<List<CalculateBean.DataBean.YeIncomeBean.MoIncomeBean>> list){
             this.mdatas = list;
           notifyDataSetChanged();
         }
        @Override
        public int getGroupCount() {
            if(mdatas!=null){
                return mdatas.size();
            }
            return 0;
        }


        @Override
        public int getChildrenCount(int groupPosition) {
          if(mdatas!=null){
              return  mdatas.get(groupPosition).size();
          }
            return 0;
        }

        @Override
        public String getGroup(int groupPosition) {
            return "待结算";
        }

        @Override
        public CalculateBean.DataBean.YeIncomeBean.MoIncomeBean getChild(int groupPosition, int childPosition) {
            if(mdatas.get(groupPosition)!=null){
                return mdatas.get(groupPosition).get(childPosition);
            }
            return null;
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            View                                                           view   = convertView;
            GroupHolder holder = null;
            if(view == null){
                holder = new GroupHolder();
                view = LayoutInflater.from(mContext).inflate(R.layout.totalwealth_expandlist_group, null);
                holder.groupName = (TextView)view.findViewById(R.id.tv_group_name);
                holder.totalWealthTv= (TextView) view.findViewById(R.id.tv_grou_totalwealth_name);
                holder.arrow = (ImageView)view.findViewById(R.id.iv_arrow);
                view.setTag(holder);
            }else{
                holder = (GroupHolder)view.getTag();
            }
            //判断是否已经打开列表
            if(isExpanded){
                holder.arrow.setBackgroundResource(R.drawable.arrow_up);
            }else{
                holder.arrow.setBackgroundResource(R.drawable.arrow_down);
            }

            switch (groupPosition) {
                case 0:
                    if(mdatas.get(0).size()>0){
                        holder.groupName.setText("待结算("+(mdatas.get(0).size()-1)+")");
                    }else{
                        holder.groupName.setText("待结算("+0+")");
                    }

                     break;
                 case 1:
                    holder.groupName.setText("已结算");
                    break;
            }
            holder.totalWealthTv.setText(" ");
            return view;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            View                                                           view   = convertView;
            ChildHolder holder = null;
            if(view == null){
                holder = new ChildHolder();
                view = LayoutInflater.from(mContext).inflate(R.layout.totalwealth_expandlist_item, null);
                holder.childName = (TextView)view.findViewById(R.id.tv_child_name);
                holder.monthincome = (TextView)view.findViewById(R.id.totall_wealth_monthincome);
                holder.divider = (ImageView)view.findViewById(R.id.iv_divider);
                view.setTag(holder);
            }else{
                holder = (ChildHolder)view.getTag();
            }

            if(childPosition == 0){
                holder.divider.setVisibility(View.GONE);
            }
            switch (groupPosition) {
                case 0:
                    //有待结算的
                    if(mdatas.get(0)!=null&&mdatas.get(0).size()>1){
                        if(childPosition<mdatas.get(0).size()-1){
                            dataBean =  mdatas.get(0).get(childPosition);
                            holder.monthincome.setTextColor(getResources().getColor(R.color.live_hot_text_color));
                            holder.childName.setText(""+dataBean.getMonth()+"月");
                            holder.monthincome.setText("+"+dataBean.getSum());
                        }
                   if(childPosition==mdatas.get(0).size()-1){
                       holder.childName.setText("");
                       holder.monthincome.setText("结算");
                       holder.monthincome.setTextColor(getResources().getColor(R.color.Topblue));
                       holder.monthincome.setOnClickListener(new View.OnClickListener() {
                           @Override
                           public void onClick(View v) {
                               //点击结算跳转到提现界面 小于七号提示用户
                               Calendar calendar =Calendar.getInstance();
                               int      day        = calendar.get(Calendar.DAY_OF_MONTH);
                           if(day<=7) {
                                Intent intent = new Intent(SettlementWealthActivity.this,
                                                           WithdrawCashActivity.class);
                                intent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG, "calculate");
                               //把总财富带过去
                               intent.putExtra(YNCommonConfig.CMD_GIFT,mWaitCalculateBean.getData().getSum() );
                                startActivity(intent);
                            }else{
                                Toast.makeText(mContext, "请在每月一到七号发起结算", Toast.LENGTH_SHORT)
                                     .show();
                            }
                           }
                       });
                   }
                        //没有待结算的
                    }else{
                        holder.childName.setText("");
                        holder.monthincome.setText("结算");
                        holder.monthincome.setTextColor(getResources().getColor(R.color.Topblue));
                        holder.monthincome.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(mContext, "本月没有可结算财富值哦", Toast.LENGTH_SHORT)
                                     .show();
                               /* Calendar calendar =Calendar.getInstance();
                                int      day        = calendar.get(Calendar.DAY_OF_MONTH);

                                Intent intent = new Intent(SettlementWealthActivity.this,
                                                           WithdrawCashActivity.class);
                                intent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG, "calculate");
                                intent.putExtra(YNCommonConfig.CMD_GIFT,mWaitCalculateBean.getData().getSum() );
                                startActivity(intent);*/

                            }
                        });
                    }
                     break;
                case 1:
                    if(mdatas.get(0)!=null&&mdatas.get(1).size()>0){
                        holder.monthincome.setTextColor(getResources().getColor(R.color.live_hot_text_color));
                            dataBean =  mdatas.get(1).get(childPosition);
                            holder.childName.setText(""+dataBean.getMonth()+"月");
                            holder.monthincome.setText("+"+dataBean.getSum());
                        }
                    break;
            }
            return view;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        class GroupHolder{
            public TextView groupName;
            public  TextView totalWealthTv;
            public ImageView arrow;
        }

        class ChildHolder{
            public TextView childName;
            public TextView monthincome;
            public ImageView divider;
        }
    }
}
