package com.yeneikeji.ynzhibo.model;

/**
 * Created by Administrator on 2017/7/10.
 */

public class AnchorHomeHeadBean extends BaseBean{

            public String content;
            public String describe0;
            public String describe1;
            public String describe2;
            public String describe3;
            public String id;
            public String is_pass;
    public String kind;
    public String payCoin;
    public String picture0;
    public String picture1;
    public String picture2;
    public String purchase;
    public String smallpicture0;
    public String smallpicture1;
    public String smallpicture2;
    public String time;
    public String title;
    public int    type;
    public String userid;
    public String view;
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDescribe0() {
        return describe0;
    }

    public void setDescribe0(String describe0) {
        this.describe0 = describe0;
    }

    public String getDescribe1() {
        return describe1;
    }

    public void setDescribe1(String describe1) {
        this.describe1 = describe1;
    }

    public String getDescribe2() {
        return describe2;
    }

    public void setDescribe2(String describe2) {
        this.describe2 = describe2;
    }

    public String getDescribe3() {
        return describe3;
    }

    public void setDescribe3(String describe3) {
        this.describe3 = describe3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIs_pass() {
        return is_pass;
    }

    public void setIs_pass(String is_pass) {
        this.is_pass = is_pass;
    }

    public String getIs_pay() {
        return is_pay;
    }

    public void setIs_pay(String is_pay) {
        this.is_pay = is_pay;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getPayCoin() {
        return payCoin;
    }

    public void setPayCoin(String payCoin) {
        this.payCoin = payCoin;
    }

    public String getPicture0() {
        return picture0;
    }

    public void setPicture0(String picture0) {
        this.picture0 = picture0;
    }

    public String getPicture1() {
        return picture1;
    }

    public void setPicture1(String picture1) {
        this.picture1 = picture1;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getPurchase() {
        return purchase;
    }

    public void setPurchase(String purchase) {
        this.purchase = purchase;
    }

    public String getSmallpicture0() {
        return smallpicture0;
    }

    public void setSmallpicture0(String smallpicture0) {
        this.smallpicture0 = smallpicture0;
    }

    public String getSmallpicture1() {
        return smallpicture1;
    }

    public void setSmallpicture1(String smallpicture1) {
        this.smallpicture1 = smallpicture1;
    }

    public String getSmallpicture2() {
        return smallpicture2;
    }

    public void setSmallpicture2(String smallpicture2) {
        this.smallpicture2 = smallpicture2;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public String is_pay;
    public int    is_purchase;

    public int getIs_purchase() {
        return is_purchase;
    }

    public void setIs_purchase(int is_purchase) {
        this.is_purchase = is_purchase;
    }




}
