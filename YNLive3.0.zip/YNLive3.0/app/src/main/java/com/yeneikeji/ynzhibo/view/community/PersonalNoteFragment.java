package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *  个人笔记界面
 * Created by Administrator on 2017/7/7.
 */
public class PersonalNoteFragment extends BaseFragment implements SmoothListView.ISmoothListViewListener, View.OnClickListener
{
    private SmoothListView mLVPersonalNote;
    private RelativeLayout mRLHomePageEmpty;
    private ImageView mIVEmpty;

    private CommonAdapter mNoteAdapter;
    private List<FindCategaryBean> mNoteList = new ArrayList<>();
    private FindCategaryBean findCategary;

    private YNPayDialog buytDialog;

    private int type;
    private String hostId;
    private String userId;
    private int homePageFlag;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_LIVE_ROOM_NOTE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mLVPersonalNote.setVisibility(View.VISIBLE);
                            mRLHomePageEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    mNoteList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mNoteAdapter.updateListView(mNoteList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                        else
                        {
                            mLVPersonalNote.setVisibility(View.GONE);
                            mRLHomePageEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getApplicationContext(), R.string.request_fail);
                        mLVPersonalNote.setVisibility(View.GONE);
                        mRLHomePageEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    onStopLoad();
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            mLVPersonalNote.setVisibility(View.VISIBLE);
                            mRLHomePageEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type  = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    mNoteList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mNoteAdapter.updateListView(mNoteList);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                            YNToastMaster.showToast(getContext(), "刷新成功");
                        }
                        else
                        {
                            YNToastMaster.showToast(getContext(), "刷新失败");
                            mLVPersonalNote.setVisibility(View.GONE);
                            mRLHomePageEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getContext(), "刷新失败");
                        mLVPersonalNote.setVisibility(View.GONE);
                        mRLHomePageEmpty.setVisibility(View.VISIBLE);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void initView()
    {
        mLVPersonalNote = (SmoothListView) findViewById(R.id.lv_note);
        mRLHomePageEmpty = (RelativeLayout) findViewById(R.id.personal_homepage_empty);
        mIVEmpty = (ImageView) mRLHomePageEmpty.findViewById(R.id.iv_homepage_empty);

        mLVPersonalNote.setSmoothListViewListener(this);
        mLVPersonalNote.setLoadMoreEnable(false);

        mIVEmpty.setOnClickListener(this);
    }

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            hostId = bundle.getString(YNCommonConfig.USER_ID);
            homePageFlag = bundle.getInt(YNCommonConfig.HOME_PAGE_FLAG);
        }
        return R.layout.fragment_note_list;
    }

    @Override
    protected void loadData()
    {
        userId = AccountUtils.getAccountBean().getId();

        getNetData();

        mNoteAdapter = new CommonAdapter<FindCategaryBean>(getContext(), mNoteList, R.layout.totalartical_listview_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, final FindCategaryBean item)
            {
                ((TextView)viewHolder.getView(R.id.total_artical_title)).setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗
                viewHolder.getView(R.id.total_artical_to_buy).setVisibility(View.GONE);
                viewHolder.getView(R.id.totalartical_buy_coin_numb).setVisibility(View.GONE);
                viewHolder.getView(R.id.iv_gold).setVisibility(View.GONE);

                final List<PhotoInfoBean> photos = new ArrayList<>();

                if (item.getPicture() == null)
                {
                    viewHolder.getView(R.id.total_artical_leftimg).setVisibility(View.GONE);
                }
                else
                {
                    viewHolder.getView(R.id.total_artical_leftimg).setVisibility(View.VISIBLE);
                    for (int i = 0; i < item.getPicture().size(); i++)
                    {
                        photos.add(new PhotoInfoBean(item.getPicture().get(i).getBig(), item.getPicture().get(i).getSmall(), 640, 792));
                    }
                }

                ((MultiImageView)viewHolder.getView(R.id.total_artical_leftimg)).setList(photos);
                ((MultiImageView)viewHolder.getView(R.id.total_artical_leftimg)).setOnItemClickListener(new MultiImageView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(View view, int position)
                    {

                        //imagesize是作为loading时的图片size
                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                        List<String> photoUrls = new ArrayList<>();
                        for (PhotoInfoBean photoInfo : photos)
                        {
                            photoUrls.add(photoInfo.getBig());
                        }
                        ImagePagerActivity.startImagePagerActivity(getActivity(), photoUrls, position, imageSize);
                    }

                });

                if (homePageFlag == 1)
                    viewHolder.setText(R.id.total_artical_title, item.getTitle(), Color.parseColor("#ffffff"));
                else
                    viewHolder.setText(R.id.total_artical_title, item.getTitle(), Color.parseColor("#323232"));

                viewHolder.setText(R.id.total_artical_content, item.getContent());
                viewHolder.setText(R.id.time, DateUtil.timeTick2DateNotSec(item.getTime()));
                viewHolder.setText(R.id.totalartical_buy_coin_numb, "x " + item.getPayCoin());
                viewHolder.setText(R.id.have_buyed_people, item.getPurchase() + "人已购买");
            }
        };

        mLVPersonalNote.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                FindCategaryBean findNote = mNoteList.get(position - 1);
                Intent intent = new Intent(getContext(), ArticalDetailsActivity.class);
                intent.putExtra("aid", findNote.getId());
                startActivity(intent);
            }
        });

        mLVPersonalNote.setAdapter(mNoteAdapter);
    }


    public void setmTag(int type) {
        this.type = type;
    }

    private void getNetData()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomNote(getContext(), YNCommonConfig.GET_LIVE_ROOM_NOTE_URL, userId, hostId,
                        type, mHandler, YNCommonConfig.GET_LIVE_ROOM_NOTE_FLAG, true, 500);
            }
        });
    }

    @Override
    public void onRefresh()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveRoomNote(getContext(), YNCommonConfig.GET_LIVE_ROOM_NOTE_URL, userId, hostId,
                        type, mHandler, YNCommonConfig.ON_REFRESH, false, 500);
            }
        });
    }

    @Override
    public void onLoadMore()
    {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mLVPersonalNote.stopRefresh();
        mLVPersonalNote.stopLoadMore();
        mLVPersonalNote.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_homepage_empty:
                getNetData();
                break;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacksAndMessages(null);
    }
}
