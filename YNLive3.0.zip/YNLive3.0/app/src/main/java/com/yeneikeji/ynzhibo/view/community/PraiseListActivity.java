package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;

import java.util.ArrayList;
import java.util.List;

/**
 *  与点赞相关评论列表
 * Created by Administrator on 2016/11/28.
 */
public class PraiseListActivity extends YNBaseTopBarActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private SmoothListView mMyCommentLV;
    private RelativeLayout mEmptyRL;
    private TextView mDynamicTV;

    private BaseAdapter mAdapter;
    private List<DynamicBean> myCommentList;

    private YNCommonDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comment);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.give_thumb));

        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.clear_out));

        mMyCommentLV = (SmoothListView) findViewById(R.id.lv_mycomment);
        mEmptyRL = (RelativeLayout) findViewById(R.id.mycomment_empty);
        mDynamicTV = (TextView) mEmptyRL.findViewById(R.id.tv_dynamic_count);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightBtn().setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        mAdapter = new CommonAdapter<DynamicBean>(this, getMyCommentList(), R.layout.my_praise_item) {
        @Override
        public void convert(CommonViewHolder viewHolder, DynamicBean item)
        {


        }
    };

        mMyCommentLV.setAdapter(mAdapter);
    }

    private List<DynamicBean> getMyCommentList()
    {
        myCommentList = new ArrayList<>();
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());

        return myCommentList;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.star_1_com_topbar_iv_right:
                dialog = new YNCommonDialog(this, R.style.transparentFrameWindowStyle, getString(R.string.clear_out_notice), false, new YNCommonDialog.CustomDialogListener()
                {
                    @Override
                    public void OnClick(View view)
                    {
                        switch (view.getId())
                        {
                            case R.id.btnCancel:
                                break;

                            case R.id.btnConfirm:

                                break;
                        }
                        dialog.dismiss();
                    }
                });
                dialog.show();
                break;
        }
    }

    @Override
    public void onRefresh()
    {

    }

    @Override
    public void onLoadMore()
    {

    }
}
