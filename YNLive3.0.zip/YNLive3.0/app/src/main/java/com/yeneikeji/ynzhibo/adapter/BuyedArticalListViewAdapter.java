package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.view.community.ArticalDetailsActivity;
import com.yeneikeji.ynzhibo.view.community.ImagePagerActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;

import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/**
 * Created by Administrator on 2017/5/15.
 */

public class BuyedArticalListViewAdapter
        extends BaseAdapter {
    private Context                mContext;
    private List<FindCategaryBean> mBuyedList;

    public BuyedArticalListViewAdapter(Context context, List<FindCategaryBean> liveList) {
        this.mContext = context;
        this.mBuyedList = liveList;
    }

    @Override
    public int getCount() {
        if(mBuyedList!=null){

            return mBuyedList.size();
        }
        return 0;
    }

    @Override
    public FindCategaryBean getItem(int position) {
        return mBuyedList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder=new ViewHolder();
            convertView = LayoutInflater.from(mContext)
                                 .inflate(R.layout.buyedartical_listview_item, null);
          //  AutoUtils.auto(convertView);
            holder.title= (TextView) convertView.findViewById(R.id.buyed_artical_title);
            holder.content= (TextView) convertView.findViewById(R.id.buyed_artical_content);
            holder.time=(TextView) convertView.findViewById(R.id.buyed_artical_time);
            holder.haveBuyed=(TextView) convertView.findViewById(R.id.buyedArtical_have_buyed_people);
            holder.leftiv= (MultiImageView) convertView.findViewById(R.id.buyed_artical_leftimg);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final FindCategaryBean findCategaryBean = mBuyedList.get(position);
        holder.title.setText(findCategaryBean.getTitle());
        holder.content.setText(findCategaryBean.getContent());
        holder.time.setText(timeStamp2StringSHort(findCategaryBean.getTime()));
        holder.haveBuyed.setText(findCategaryBean.getView()+"人阅读");
     //   YNImageLoaderUtil.setImage(mContext, holder.leftiv,findCategaryBean.getIcon());
        holder.content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ArticalDetailsActivity.class);
                intent.putExtra("aid", findCategaryBean.getId());
                mContext.startActivity(intent);
            }
        });

        if (findCategaryBean.getPicture() != null) {
            final List<PhotoInfoBean> photos = new ArrayList<>();

            for (int i = 0; i < findCategaryBean.getPicture()
                                                 .size(); i++) {
                photos.add(new PhotoInfoBean(findCategaryBean.getPicture()
                                                              .get(i)
                                                              .getBig(),
                                             findCategaryBean.getPicture()
                                                              .get(i)
                                                              .getSmall(),
                                             320,
                                             400));
            }
            holder.leftiv.setVisibility(View.VISIBLE);
            holder.leftiv.setList(photos);
            //先判断是否有图片再添加
             /* if(mTotalList.get(position).getPicture()!=null){
             holder.leftiv.setList(photos);
              }else{
                  holder.leftiv.setList(null);
              }*/
            holder.leftiv.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                @Override
                public void onItemClick(View view, int position)
                {
                    //imagesize是作为loading时的图片size
                    ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(),
                                                                                              view.getMeasuredHeight());

                    List<String> photoUrls = new ArrayList();
                    for (PhotoInfoBean photoInfo : photos) {
                        photoUrls.add(photoInfo.getBig());
                    }
                    ImagePagerActivity.startImagePagerActivity(mContext,
                                                               photoUrls,
                                                               position,
                                                               imageSize);
                }

            });
        }else{
            holder.leftiv.setVisibility(View.GONE);
        }
        return convertView;
    }
    private class ViewHolder
    {
        private MultiImageView leftiv;
        private TextView       title;
        private TextView       content;
        private TextView       time;
        private TextView       haveBuyed;


    }
}
