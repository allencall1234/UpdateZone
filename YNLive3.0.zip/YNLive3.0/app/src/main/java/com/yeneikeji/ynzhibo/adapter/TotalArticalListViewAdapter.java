package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.view.community.ImagePagerActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;

import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/**
 * Created by Administrator on 2017/5/15.
 */

public class TotalArticalListViewAdapter extends BaseAdapter


{
    private Context                mContext;
    private List<FindCategaryBean> mTotalList;
    private FindCategaryBean mFindCategaryBean;
    //添加了头部view的跳转position
    private int mPosition;

    public TotalArticalListViewAdapter(Context context,List<FindCategaryBean> TotalList) {
        this.mContext = context;
        this.mTotalList = TotalList;

    }
   /* public void refreshUi(List<FindCategaryBean> TotalList){
        this.mTotalList = TotalList;
        notifyDataSetChanged();
    }*/

    @Override
    public int getCount() {
        if(mTotalList!=null){

            return mTotalList.size();
        }
        return 0;
    }

    @Override
    public FindCategaryBean getItem(int position) {
        return mTotalList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder=new ViewHolder();
            convertView = LayoutInflater.from(mContext)
                                 .inflate(R.layout.totalartical_listview_item, null);
           // AutoUtils.auto(convertView);
            holder.leftiv = (MultiImageView) convertView.findViewById(R.id.total_artical_leftimg);
            holder.title= (TextView) convertView.findViewById(R.id.total_artical_title);
            holder.goldIv= (ImageView) convertView.findViewById(R.id.iv_gold);
            holder.time= (TextView) convertView.findViewById(R.id.time);
            holder.content= (TextView) convertView.findViewById(R.id.total_artical_content);
            holder.coinNumb=(TextView) convertView.findViewById(R.id.totalartical_buy_coin_numb);
            holder.haveBuyed= (TextView) convertView.findViewById(R.id.have_buyed_people);
            holder.toBuy= (TextView) convertView.findViewById(R.id.total_artical_to_buy);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();

        }
        mPosition = position;
        mFindCategaryBean = mTotalList.get(position);

        holder.title.setText(mFindCategaryBean.getTitle());
        holder.content.setText(mFindCategaryBean.getContent());
       if( (mFindCategaryBean.getPayCoin()).equals("0")||mFindCategaryBean.getIs_purchase()==1) {
           holder.goldIv.setVisibility(View.GONE);
           holder.toBuy.setVisibility(View.GONE);
           holder.coinNumb.setVisibility(View.GONE);
        }else{
           holder.goldIv.setVisibility(View.VISIBLE);
           holder.toBuy.setVisibility(View.VISIBLE);
           holder.coinNumb.setVisibility(View.VISIBLE);
       }
        holder.coinNumb.setText("x"+mFindCategaryBean.getPayCoin());
        holder.time.setText(timeStamp2StringSHort(mFindCategaryBean.getTime()));
        holder.haveBuyed.setText(mFindCategaryBean.getView()+"人阅读");
       // YNImageLoaderUtil.setImage(mContext, holder.leftiv, mFindCategaryBean.getIcon());

        if (mFindCategaryBean.getPicture() != null) {
            final List<PhotoInfoBean> photos = new ArrayList<>();

            for (int i = 0; i < mFindCategaryBean.getPicture()
                                    .size(); i++) {
                photos.add(new PhotoInfoBean(mFindCategaryBean.getPicture()
                                                 .get(i)
                                                 .getBig(),
                                             mFindCategaryBean.getPicture()
                                                 .get(i)
                                                 .getSmall(),
                                             320,
                                             400));
            }
            holder.leftiv.setVisibility(View.VISIBLE);
            holder.leftiv.setList(photos);
            //先判断是否有图片再添加
             /* if(mTotalList.get(position).getPicture()!=null){
             holder.leftiv.setList(photos);
              }else{
                  holder.leftiv.setList(null);
              }*/
            holder.leftiv.setOnItemClickListener(new MultiImageView.OnItemClickListener() {
                @Override
                public void onItemClick(View view, int position)
                {
                    //imagesize是作为loading时的图片size
                    ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(),
                                                                                              view.getMeasuredHeight());

                    List<String> photoUrls = new ArrayList();
                    for (PhotoInfoBean photoInfo : photos) {
                        photoUrls.add(photoInfo.getBig());
                    }
                    ImagePagerActivity.startImagePagerActivity(mContext,
                                                               photoUrls,
                                                               position,
                                                               imageSize);
                }

            });
        }else{
            holder.leftiv.setVisibility(View.GONE);
        }

        return convertView;
    }


    private class ViewHolder
    {
        private MultiImageView leftiv;
        private TextView       title;
        private ImageView      goldIv;
        private TextView       time;
        private TextView       content;
        private TextView       coinNumb;
        private TextView       haveBuyed;
        private TextView       toBuy;


    }
}
