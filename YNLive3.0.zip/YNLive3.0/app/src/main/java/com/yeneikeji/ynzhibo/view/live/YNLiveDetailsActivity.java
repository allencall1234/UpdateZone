package com.yeneikeji.ynzhibo.view.live;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.cloud.media.player.IMediaPlayer;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.TabFragmentAdapter;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.videoplayer.BDCloudVideoView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/5/15.
 */
public class YNLiveDetailsActivity extends YNBaseActivity implements IMediaPlayer.OnPreparedListener,
        IMediaPlayer.OnCompletionListener, IMediaPlayer.OnErrorListener,
        IMediaPlayer.OnInfoListener, IMediaPlayer.OnBufferingUpdateListener,
        BDCloudVideoView.OnPlayerStateListener, View.OnClickListener
{
    private BDCloudVideoView mVV = null;
    private RelativeLayout mViewHolder = null;
    private RelativeLayout mFullScreenViewHolder = null;
    private LinearLayout mLLNoNet;
    private TextView mTVNoNet;
    private TextView mTVRetry;
    private TextView mTVPlayFail;
    private ImageView mIVClose;
    private ViewPager mViewPager;

    private LiveRoomBean liveRoomBean;
    private List<Fragment> fragments;
    private LiveLayerFragment liveLayerFragment;

//    public boolean isShowFullScreen = false;
    public boolean isPlaying = false;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case 0:
                    if (!"0".equals(liveRoomBean.getPid()))
                    {
                        YNLogUtil.e("123", "线路切换");
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().liveRoomExchage(YNLiveDetailsActivity.this, YNCommonConfig.LIVE_ROOM_EXCHANGE_URL, liveRoomBean.getUserid(), mHandler, YNCommonConfig.LIVE_ROOM_EXCHANGE_FLAG, true);
                            }
                        });

                    }
                    break;

                case 1:
                    break;

                case YNCommonConfig.LIVE_ROOM_EXCHANGE_FLAG:
                    if (msg.obj != null)
                    {
                        stopVideo();
                        mVV.reSetRender();
                        YNLogUtil.e("cdy直播间切换", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 230)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                liveRoomBean.setLiving(jsonObject.optJSONObject("data").optInt("living"));
                                liveRoomBean.setPlay_address(jsonObject.optJSONObject("data").optString("play_address"));
                                liveRoomBean.setEquipment(jsonObject.optJSONObject("data").optInt("equipment"));
                                liveRoomBean.setRoom_id(jsonObject.optJSONObject("data").optString("room_id"));
                                startPlay();
                                Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
                                intent.putExtra("liveRoom", false);
                                intent.putExtra(YNCommonConfig.OBJECT, liveRoomBean);
                                LocalBroadcastManager.getInstance(YNLiveDetailsActivity.this).sendBroadcast(intent);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mTVRetry.setVisibility(View.GONE);
                            mTVPlayFail.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        mTVRetry.setVisibility(View.GONE);
                        mTVPlayFail.setVisibility(View.VISIBLE);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // 防闪屏
        getWindow().setFormat(PixelFormat.TRANSLUCENT);
        // 保持屏幕常亮
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // 设置状态栏颜色
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//        {
//            Window window = this.getWindow();
//            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            // finally change the color
//            window.setStatusBarColor(0xff282828);
//        }

        View view = getLayoutInflater().inflate(R.layout.yn_activity_live_details, null);
//        AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.parseColor("#262626"));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        initView();
        addEvent();
        settingDo();
//        /*这里可以看到的就是我们将初始化直播的Fragment添加到了这个页面作为填充
//        * 并且将MainDialogFragment显示在该页面的顶部已达到各种不同交互的需求*/
//        getSupportFragmentManager().beginTransaction().add(R.id.flmain, liveDetailsFragment).commit();
//        LiveDialogFragment liveDialogFragment = new LiveDialogFragment();
//        liveDetailsFragment.setLiveRoomBean(liveRoomBean);
//        liveDialogFragment.show(getSupportFragmentManager(), "LiveDialogFragment");
    }

    @Override
    protected void initView()
    {
        liveRoomBean = (LiveRoomBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);

        mViewHolder = (RelativeLayout) findViewById(R.id.view_holder);
        mFullScreenViewHolder = (RelativeLayout) findViewById(R.id.rl_fullscreen_view_holder);
        mLLNoNet = (LinearLayout) findViewById(R.id.ll_no_net);
        mTVNoNet = (TextView) findViewById(R.id.tv_no_net);
        mTVRetry = (TextView) findViewById(R.id.tv_retry);
        mTVPlayFail = (TextView) findViewById(R.id.tv_play_fail);
        mIVClose = (ImageView) findViewById(R.id.iv_close);
        mViewPager = (ViewPager) findViewById(R.id.vp_panl);

        /**
         * 设置ak
         */
        BDCloudVideoView.setAK(YNCommonConfig.AK);

        mVV = new BDCloudVideoView(this);

        fragments = new ArrayList<>();
    }

    @Override
    protected void addEvent()
    {
//        mIVClose.setOnClickListener(this);
        /**
         * 注册listener
         */
        mVV.setOnPreparedListener(this);
        mVV.setOnCompletionListener(this);
        mVV.setOnErrorListener(this);
        mVV.setOnInfoListener(this);
        mVV.setOnBufferingUpdateListener(this);
        mVV.setOnPlayerStateListener(this);

        mTVRetry.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        mHandler.sendEmptyMessage(1);
        // 填充，保持视频内容的宽高比。视频与屏幕宽高不一致时，会留有黑边
//        mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT);

        // 视频保持比例缩放，不留黑边，填满显示区域的两边
        mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);

//        RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(-1, -1);
//        rllp.addRule(RelativeLayout.CENTER_IN_PARENT);
//        mViewHolder.addView(mVV, rllp);

        mViewHolder.addView(mVV);

        mVV.setLogEnabled(false);
//        mVV.setMaxProbeTime(1 * 1000); // 设置首次缓冲的最大时长
        startPlay();
        //        fragments.clear();//清空
        liveLayerFragment = new LiveLayerFragment();
        Bundle mBundle = new Bundle();
        mBundle.putSerializable(YNCommonConfig.OBJECT, liveRoomBean);
        liveLayerFragment.setArguments(mBundle);
//        liveLayerFragment.setLiveRoomBean(liveRoomBean);
        fragments.add(new EmptyFragment());
        fragments.add(liveLayerFragment);
        TabFragmentAdapter adapter = new TabFragmentAdapter(getSupportFragmentManager(), fragments);
//        mViewPager.setOffscreenPageLimit(2);
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(adapter.getCount() - 1);

    }

    private void startPlay()
    {
        if (liveRoomBean.getLiving() == 0)
        {
            mVV.showCacheInfo(false);
            mTVPlayFail.setVisibility(View.VISIBLE);
        }
        else
        {
//            if (liveRoomBean.getEquipment() == 1)
//                mVV.setCachingHintViewHeight();

            mVV.showCacheInfo(true);
            mTVPlayFail.setVisibility(View.GONE);
            mVV.setVideoPath(liveRoomBean.getPlay_address());
            // 初始化好之后立即播放（您也可以在onPrepared回调中调用该方法）
            playVideo();
        }
    }

    /**
     * 设置播放器大小(横屏、竖屏)
     */
    public void setBVideoViewSize(int dip)
    {
        // 视频保持比例缩放，不留黑边，填满显示区域的两边
//        mVV.setVideoScalingMode(BVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
//        if (isFulllScreen)
//        {
//             // 铺满，不保证视频内容宽高比。视频显示与屏幕宽高相等
//            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_MATCH_PARENT);
//        }
//        else
//        {
//            // 转为 填充模式：视频保持比例缩放，至少一边与显示区域相同，另一边有黑边
//            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT);
//        }
        if (dip > 0)
        {
//            getWindow().getDecorView().setSystemUiVisibility(View.VISIBLE);//显示状态栏
            mFullScreenViewHolder.removeView(mVV);
            mViewHolder.addView(mVV);
//            mVV.setMinimumWidth(screenWidth);
//            mVV.setMinimumHeight(220);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            // 视频保持比例缩放，不留黑边，填满显示区域的两边
            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
//            RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, UIUtils.dp2px(this, dip));
//            mViewHolder.setLayoutParams(layoutParams1);
//            mViewHolder.setY(UIUtils.dp2px(this, 120));
        }
        else
        {
//            getWindow().getDecorView().setSystemUiVisibility(View.GONE);//显示状态栏
            mViewHolder.removeView(mVV);
            mFullScreenViewHolder.addView(mVV);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
//            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
//            mFullScreenViewHolder.setLayoutParams(layoutParams);
//            mVV.setMinimumWidth(screenHeight);
//            mVV.setMinimumHeight(screenWidth);
        }
    }

    public void setPoriraitFullScreen()
    {
        mViewHolder.removeView(mVV);
        mFullScreenViewHolder.addView(mVV);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mVV.setVideoScalingMode(BDCloudVideoView.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
    }

    public void playVideo()
    {
        mVV.start();
    }

    public void stopVideo()
    {
        mVV.pause();
        mVV.stopPlayback();
    }

    public void setBtnClose(boolean isFocus)
    {
        mIVClose.setClickable(isFocus);
    }

    public void addManager(ChatRoomUserBean chatRoomUserBean)
    {
        liveLayerFragment.addManager(chatRoomUserBean);
    }

    public void deleteManager(ChatRoomUserBean chatRoomUserBean)
    {
        liveLayerFragment.deleteManager(chatRoomUserBean);
    }

    public void hideTopBar()
    {
        liveLayerFragment.animateToHide();
    }

    public void showTopBar()
    {
        liveLayerFragment.animateToShow();
    }

    public float getCurrentCoin()
    {
        return  liveLayerFragment.currentCoin;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
//            case R.id.iv_close:
//                if (liveLayerFragment.isFullScreen)
//                {
//                    liveLayerFragment.setPorirait();
//                }
//                else
//                {
//                    YNCommonUtils.hideSoftInput(this, view);
//                    YNApplication.getInstance().finishActivity(this);
//                }
//                break;

            case R.id.tv_retry:
                if (YNBaseActivity.isConnectNet)
                {
                    mVV.setVisibility(View.VISIBLE);
                    mLLNoNet.setVisibility(View.GONE);
                    playVideo();
                    onPlayerStateChanged(BDCloudVideoView.PlayerState.STATE_PLAYING);
                }
//                else
//                {
//                    YNToastMaster.showToast(getApplicationContext(), "网络未连接", Toast.LENGTH_SHORT, Gravity.CENTER);
//                }
                break;
        }
    }

    @Override
    public void loginRefreshUI()
    {

    }

    @Override
    public void unLoginRefreshUI()
    {

    }

    @Override
    public void onBufferingUpdate(IMediaPlayer iMediaPlayer, int i) {
        // 手机720*180 电脑 1092*614
        YNLogUtil.e("onBufferingUpdate", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
        // 创建的视频的宽度 1080,1845
        YNLogUtil.e("onBufferingUpdate", mVV.getWidth() + "," + mVV.getHeight());

    }

    @Override
    public void onCompletion(IMediaPlayer iMediaPlayer)
    {
//        mVV.setVisibility(View.GONE);
//        mLLNoNet.setVisibility(View.VISIBLE);
        if (YNBaseActivity.isConnectNet)
        {
            if (!"0".equals(liveRoomBean.getPid()))
            {
                mLLNoNet.setVisibility(View.GONE);
                mHandler.sendEmptyMessage(0);
            }
            else
            {
                mLLNoNet.setVisibility(View.VISIBLE);
                mTVNoNet.setVisibility(View.GONE);
            }

        }
        else
        {
            mLLNoNet.setVisibility(View.VISIBLE);
            mTVRetry.setVisibility(View.GONE);
            mTVNoNet.setVisibility(View.VISIBLE);
        }
        YNLogUtil.e("123000", "onCompletion播放出错");
    }

    @Override
    public boolean onError(IMediaPlayer iMediaPlayer, int i, int i1)
    {
//        stopVideo();
//        mVV.setBackgroundColor(Color.parseColor("#000000"));
//        mVV.setVisibility(View.GONE);
//        mTVPlayFail.setVisibility(View.VISIBLE);
//        mVV.reSetRender();
        YNLogUtil.e("123000", "onError");
        return false;
    }

    @Override
    public boolean onInfo(IMediaPlayer iMediaPlayer, int i, int i1) {
        YNLogUtil.e("123000", "onInfo");
        // 手机720*180 电脑 1092*614
        YNLogUtil.e("onInfo", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
        // 创建的视频的宽度 1080,1845
        YNLogUtil.e("onInfo", mVV.getWidth() + "," + mVV.getHeight());
        return false;
    }

    @Override
    public void onPlayerStateChanged(BDCloudVideoView.PlayerState nowState) {
        // 手机720*180 电脑 1092*614
        YNLogUtil.e("onPlayerStateChanged", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
        // 创建的视频的宽度 1080,1845
        YNLogUtil.e("onPlayerStateChanged", mVV.getWidth() + "," + mVV.getHeight());
        if (nowState == BDCloudVideoView.PlayerState.STATE_PLAYING)
        {
            // 手机720*180 电脑 1092*614
            YNLogUtil.e("cdy", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
            // 创建的视频的宽度 1080,1845
            YNLogUtil.e("cdy", mVV.getWidth() + "," + mVV.getHeight());
/*            if (liveRoomBean.getEquipment() == 0)
                isShowFullScreen = true;
//               liveLayerFragment.fullscreen.setVisibility(View.VISIBLE);
            else
                isShowFullScreen = false;*/

     /*       if (mVV.getVideoWidth() / mVV.getVideoHeight() > 1)
                isShowFullScreen = true;
            else
                isShowFullScreen = false;*/

            boolean isPhoneLiving;
            if (mVV.getVideoWidth() / mVV.getVideoHeight()  < 1)
            {
                isPhoneLiving = true;
                mVV.setCachingHintViewHeight();
            }
            else
            {
                isPhoneLiving = false;
            }

            liveLayerFragment.updateEquipment(isPhoneLiving);
            liveLayerFragment.isShowScreen(true);
        }
        else
        {
            liveLayerFragment.isShowScreen(false);
//            isShowFullScreen = false;
        }


      /*  if (nowState == BDCloudVideoView.PlayerState.STATE_ERROR)
        {
            stopVideo();
            mVV.reSetRender();
            mLLNoNet.setVisibility(View.VISIBLE);
//            mVV.setBackgroundColor(Color.parseColor("#000000"));
            mVV.setVisibility(View.GONE);
            if (!YNBaseActivity.isConnectNet)
            {
//                        if (liveRoomBean.getEquipment() == 0 || liveLayerFragment.isFullScreen)
//                        {
//                            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, UIUtils.dp2px(YNLiveDetailsActivity.this, 280));
//                            mTVPlayFail.setLayoutParams(layoutParams);
//                        }
//                        mHandler.sendEmptyMessage(0);
            }
            else
            {
                mHandler.sendEmptyMessage(0);
                mTVNoNet.setVisibility(View.GONE);
            }
        }*/
    }

    @Override
    public void onPrepared(IMediaPlayer iMediaPlayer) {
        // 手机720*1280 电脑 1092*614
        YNLogUtil.e("onPrepared", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
        // 创建的视频的宽度 1080,1845
        YNLogUtil.e("onPrepared", mVV.getWidth() + "," + mVV.getHeight());
        YNLogUtil.e("123000", "onPrepared");
//        boolean isPhoneLiving;
//        if (mVV.getVideoWidth() / mVV.getVideoHeight()  < 1)
//        {
//            isPhoneLiving = true;
//            mVV.setCachingHintViewHeight();
//        }
//        else
//        {
//            isPhoneLiving = false;
//        }
//
//        liveLayerFragment.updateEquipment(isPhoneLiving);
    }

    protected void onResume() {
        super.onResume();
//        if (liveLayerFragment != null) {
//            liveLayerFragment.onResume();
//        }
    }

    @Override
    protected void onRestart() {
        // 手机720*180 电脑 1092*614
        YNLogUtil.e("onRestart", mVV.getVideoWidth() + "," + mVV.getVideoHeight());
        // 创建的视频的宽度 1080,1845
        YNLogUtil.e("onRestart", mVV.getWidth() + "," + mVV.getHeight());
        YNLogUtil.e("123000", "onRestart");
        super.onRestart();
    }

    @Override
    public void onStop() {

        if (liveLayerFragment != null) {
            liveLayerFragment.onStop();
        }

        super.onStop();
    }


    @Override
    protected void onDestroy()
    {
        if (liveLayerFragment != null)
        {
            liveLayerFragment.onDestroy();
        }

        if (mVV != null) {
            mVV.stopPlayback(); // 释放播放器资源
            mVV.release(); // 释放播放器资源和显示资源
        }
        super.onDestroy();
    }
}
