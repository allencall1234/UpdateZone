package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.tb.emoji.EmojiUtil;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.interfaces.ISelectChangeCallBack;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;


public class MessageCenterAdapter extends BaseAdapter {

    private Context context;
    private List<MessageBean> list;
    private Map<Integer,Boolean> selectedItem;
    private boolean isShowSelected = false;
    private ISelectChangeCallBack callBack;
    private int msgType;
    private MessageBean mCommentBean;

    public MessageCenterAdapter(Context context, List<MessageBean> list, ISelectChangeCallBack callBack, int msgType)
    {
        this.context = context;
        this.list = list;
        this.callBack = callBack;
        this.msgType = msgType;
    }

    public void initData() {
        selectedItem = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            selectedItem.put(i,false);
        }
    }

    public void updateData(List<MessageBean> dynamicList)
    {
        this.list = dynamicList;
        initData();
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override

    public View getView(final int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;
        mCommentBean = list.get(position);
        if(convertView == null)
        {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.msg_center_content_item,null);
            holder.imgAvatar = (YNCircleImageView) convertView.findViewById(R.id.imgAvatar);
            holder.imgMsgType = (ImageView) convertView.findViewById(R.id.iv_msg_type);
            holder.isReadImg= (ImageView) convertView.findViewById(R.id.is_read_flag);
            holder.txtMsgTitle = (TextView) convertView.findViewById(R.id.txtMsgTitle);
            holder.txtDescribe = (TextView) convertView.findViewById(R.id.txtDescribe);
            holder.txtTime = (TextView) convertView.findViewById(R.id.txtTime);
            holder.chbSelected = (CheckBox) convertView.findViewById(R.id.checkBox);
            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txtMsgTitle.setText(mCommentBean.getUsername());
        holder.txtTime.setText(timeStamp2StringSHort(mCommentBean.getTime()));
        if(mCommentBean.getIs_read().equals("0")){
            holder.isReadImg.setVisibility(View.VISIBLE);
        }else{
            holder.isReadImg.setVisibility(View.GONE);
        }
      /*  //消息是否已读状态的改变
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCommentBean.setIs_read("1");
                //更新是否已读状态
                notifyDataSetInvalidated();
                Intent intent =new Intent(context, YNMessageDetailsActivity.class);
                context.startActivity(intent);
            }
        });*/
//        holder.txtDescribe.setText(commentBean.getContent());
        try
        {
            EmojiUtil.handlerEmojiText(holder.txtDescribe, mCommentBean.getContent(), context);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        holder.chbSelected.setChecked(selectedItem.get(position));

        if (msgType == 2)
        {
            holder.imgAvatar.setImageResource(R.drawable.message_official);
//            if ("0".equals(commentBean.getMessage_type()) || "1".equals(commentBean.getMessage_type()) || "3".equals(commentBean.getMessage_type()))
//            {
//                holder.imgMsgType.setImageResource(R.drawable.message_official_little);
//            }
//            else
//            {
//                holder.imgMsgType.setImageResource(R.drawable.message_service_little);
//            }

        }
        else
        {
            YNImageLoaderUtil.setImage(context, holder.imgAvatar, mCommentBean.getIcon());
        }

        if(isShowSelected)
        {
            holder.chbSelected.setVisibility(View.VISIBLE);
        }
        else
        {
            holder.chbSelected.setVisibility(View.GONE);
        }
        holder.chbSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
               selectedItem.put(position,isChecked);
                if(buttonView.getVisibility() == View.VISIBLE){
                    callBack.onSelectedSizeChange(selectedItem);
                }

            }
        });
        return convertView;
    }
    class ViewHolder{
        private TextView txtMsgTitle,txtTime,txtDescribe;
        private YNCircleImageView imgAvatar;
        private ImageView imgMsgType;
        private ImageView isReadImg;
        private CheckBox chbSelected;
    }

    public void setShowSelected(boolean showSelected) {
        isShowSelected = showSelected;
    }

    public Map<Integer, Boolean> getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Map<Integer, Boolean> selectedItem) {
        this.selectedItem = selectedItem;
    }
}
