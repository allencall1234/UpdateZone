package com.yeneikeji.ynzhibo.rongcloud.message;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;

import io.rong.imlib.model.MessageContent;
import io.rong.message.ImageMessage;

public class UnknownMsgView extends BaseMsgView
{
    public TextView username;
    private TextView content;

    public UnknownMsgView(Context context)
    {
        super(context);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.msg_unknown_view, this);
        username = (TextView) view.findViewById(R.id.username);
        content = (TextView) view.findViewById(R.id.content);
    }

    @Override
    public void setContent(MessageContent msgContent)
    {
        ImageMessage msg = (ImageMessage) msgContent;
        username.setText(msg.getUserInfo().getName() + " ");
        content.setText(msg.getBase64());
    }
}
