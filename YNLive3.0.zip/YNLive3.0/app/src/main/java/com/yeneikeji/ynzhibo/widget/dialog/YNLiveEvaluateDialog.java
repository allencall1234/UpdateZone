package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;

/**
 * 直播评价dialog
 * Created by Administrator on 2017/6/26.
 */
public class YNLiveEvaluateDialog implements View.OnClickListener, RadioGroup.OnCheckedChangeListener
{
    private ImageView mHeadImg;
    private TextView mHostName;
    private TextView mLiveType;
    private RadioGroup mRGEvaluate;
    private RadioButton mRBBad,mRBCommonly,mRBGood;
    private Button mLeftBtn;
    private Button mRightBtn;
    private Dialog mDialog;
    private View mDialogView;
    private Builder mBuilder;
    private int liveEvaluate = 2;

    public YNLiveEvaluateDialog(Builder builder) {

        this.mBuilder = builder;
        mDialog = new Dialog(mBuilder.getContext(), R.style.NormalDialogStyle);
        mDialogView = View.inflate(mBuilder.getContext(), R.layout.widget_live_evaluate_dialog, null);
        mHeadImg = (ImageView) mDialogView.findViewById(R.id.iv_host_img);
        mHostName = (TextView) mDialogView.findViewById(R.id.tv_host_name);
        mLiveType = (TextView) mDialogView.findViewById(R.id.tv_live_type);
        mRGEvaluate = (RadioGroup) mDialogView.findViewById(R.id.rg_evaluate);
        mRBBad = (RadioButton) mDialog.findViewById(R.id.rb_bad);
        mRBCommonly = (RadioButton) mDialog.findViewById(R.id.rb_commonly);
        mRBGood = (RadioButton) mDialog.findViewById(R.id.rb_good);
        mLeftBtn = (Button) mDialogView.findViewById(R.id.btn_cancel);
        mRightBtn = (Button) mDialogView.findViewById(R.id.btn_confirm);
        mDialogView.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(mBuilder.getContext()) * builder.getHeight()));
        mDialog.setContentView(mDialogView);

        Window dialogWindow = mDialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtil.getScreenWidth(mBuilder.getContext()) * builder.getWidth());
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialogWindow.setAttributes(lp);

        initDialog(builder);
    }

    private void initDialog(Builder builder)
    {
//        YNImageLoaderUtil.setImage(builder.getContext(), mHeadImg, builder.getMsgBean().getIcon());
//        mHostName.setText(builder.getMsgBean().getUsername());
//        mLiveType.setText(builder.getMsgBean().getTag() + "-" + builder.getMsgBean().getTag2());

        mDialog.setCanceledOnTouchOutside(builder.isTouchOutside());

        mLeftBtn.setText(builder.getLeftButtonText());
        mLeftBtn.setTextColor(builder.getLeftButtonTextColor());
        mLeftBtn.setTextSize(builder.getButtonTextSize());
        mRightBtn.setText(builder.getRightButtonText());
        mRightBtn.setTextColor(builder.getRightButtonTextColor());
        mRightBtn.setTextSize(builder.getButtonTextSize());

        mRGEvaluate.setOnCheckedChangeListener(this);
        mLeftBtn.setOnClickListener(this);
        mRightBtn.setOnClickListener(this);

        YNImageLoaderUtil.setImage(mBuilder.getContext(), mHeadImg, mBuilder.getHeadImg());
        mHostName.setText(mBuilder.getuName());
        mLiveType.setText(mBuilder.getLiveType());
    }

    public void show() {

        mDialog.show();
    }

    public void dismiss() {

        mDialog.dismiss();
    }

    @Override
    public void onClick(View view)
    {
        int i = view.getId();

        if (i == R.id.btn_cancel && mBuilder.getListener() != null) {

            mBuilder.getListener().clickLeftButton(mLeftBtn);
            return;
        }

        if (i == R.id.btn_confirm && mBuilder.getListener() != null) {

            mBuilder.getListener().clickRightButton(mRightBtn, liveEvaluate);
            return;
        }

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId)
    {
        switch (checkedId)
        {
            case R.id.rb_bad:
                liveEvaluate = 0;
                break;

            case R.id.rb_commonly:
                liveEvaluate = 1;
                break;

            case R.id.rb_good:
                liveEvaluate = 2;
                break;
        }
    }

    public static class Builder
    {
        private String leftButtonText;
        private int leftButtonTextColor;
        private String rightButtonText;
        private int rightButtonTextColor;
        private int buttonTextSize;
        private OnClickRadioGroupDialogListener listener;
        private boolean isTouchOutside;
        private float height;
        private float width;
        private Context mContext;

        private String headImg;
        private String uName;
        private String liveType;

        public Builder(Context context)
        {
            mContext = context;
            leftButtonText = "取消";
            leftButtonTextColor = ContextCompat.getColor(mContext, R.color.search_txt);
            rightButtonText = "确定";
            rightButtonTextColor = ContextCompat.getColor(mContext, R.color.live_details_text_blue);
            listener = null;
            isTouchOutside = true;
            height = 0.23f;
            width = 0.65f;
            buttonTextSize = 18;
        }

        public Context getContext() {

            return mContext;
        }

        public String getLeftButtonText() {
            return leftButtonText;
        }

        public Builder setLeftButtonText(String leftButtonText) {
            this.leftButtonText = leftButtonText;
            return this;
        }

        public int getLeftButtonTextColor() {
            return leftButtonTextColor;
        }

        public Builder setLeftButtonTextColor(@ColorRes int leftButtonTextColor) {
            this.leftButtonTextColor = ContextCompat.getColor(mContext, leftButtonTextColor);
            return this;
        }

        public String getRightButtonText() {
            return rightButtonText;
        }

        public Builder setRightButtonText(String rightButtonText) {
            this.rightButtonText = rightButtonText;
            return this;
        }

        public int getRightButtonTextColor() {
            return rightButtonTextColor;
        }

        public Builder setRightButtonTextColor(@ColorRes int rightButtonTextColor) {
            this.rightButtonTextColor = ContextCompat.getColor(mContext, rightButtonTextColor);
            return this;
        }

        public boolean isTouchOutside() {
            return isTouchOutside;
        }

        public Builder setCanceledOnTouchOutside(boolean isTouchOutside) {

            this.isTouchOutside = isTouchOutside;
            return this;
        }

        public int getButtonTextSize() {
            return buttonTextSize;
        }

        public Builder setButtonTextSize(int buttonTextSize) {
            this.buttonTextSize = buttonTextSize;
            return this;
        }

        public float getHeight() {
            return height;
        }

        public Builder setHeight(float height) {
            this.height = height;
            return this;
        }

        public float getWidth() {
            return width;
        }

        public Builder setWidth(float width) {
            this.width = width;
            return this;
        }

        public OnClickRadioGroupDialogListener getListener() {
            return listener;
        }

        public Builder setOnclickListener(OnClickRadioGroupDialogListener listener) {
            this.listener = listener;
            return this;
        }

        public String getHeadImg() {
            return headImg;
        }

        public Builder setHeadImg(String headImg) {
            this.headImg = headImg;
            return this;
        }

        public String getuName() {
            return uName;
        }

        public Builder setuName(String uName) {
            this.uName = uName;
            return this;
        }

        public String getLiveType() {
            return liveType;
        }

        public Builder setLiveType(String liveType) {
            this.liveType = liveType;
            return this;
        }

        public YNLiveEvaluateDialog build() {

            return new YNLiveEvaluateDialog(this);
        }
    }

    public interface OnClickRadioGroupDialogListener {

        void clickLeftButton(View view);

        void clickRightButton(View view, int liveEvaluateIndex);
    }
}
