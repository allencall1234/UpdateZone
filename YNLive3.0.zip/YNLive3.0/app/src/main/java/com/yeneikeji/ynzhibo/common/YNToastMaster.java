package com.yeneikeji.ynzhibo.common;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;

/**
 * Created by Administrator on 2016/8/5.
 * @Title: ToastMaster.java
 * @Description: 自定义Toast，加载样式、Toast显示及时间控制等
 */
public class YNToastMaster extends Toast
{
    private static YNToastMaster sToast = null;

    /**
     * （单例模式）实例化ToastMaster，自定义View
     */
    private YNToastMaster(Context context, String text) {
        super(context);
        // TODO Auto-generated constructor stub
        setView(customToastView(context, text));
    }


    /**
     * 创建Toast
     * @param context
     */
    private static YNToastMaster createToast(Context context, String text) {
        if (sToast != null) {
            sToast.cancel();//实现每次调用Toast时，先取消原来的
            sToast = null;
        }
        sToast = new YNToastMaster(context, text);
        return sToast;
    }

    /**
     * 显示Toast
     * @param context
     * @param text 提示内容
     */
    public static void showToast(Context context, String text) {
        sToast = createToast(context, text);
        sToast.show();
    }

    /**
     * 显示Toast
     * @param context
     * @param text 提示内容
     * @param duration 持续时间
     */
    public static void showToast(Context context, String text, int duration) {
        sToast = createToast(context, text);
        sToast.setDuration(duration);
        sToast.show();
    }

    /**
     * 显示Toast
     * @param context
     * @param text 提示内容
     * @param duration 持续时间
     * @param gravity 位置，如：Gravity.CENTER
     */
    public static void showToast(Context context, String text, int duration, int gravity) {
        sToast = createToast(context, text);
        sToast.setDuration(duration);
        sToast.setGravity(gravity, 0, 0);
        sToast.show();

    }

    /**
     * 创建Toast
     * @param context
     * @param resid 提示内容 id
     */
    public static void showToast(Context context, int resid) {
        showToast(context, context.getResources().getString(resid));
    }

    /**
     * 创建Toast
     * @param context
     * @param resid 提示内容 id
     * @param duration 持续时间
     */
    public static void showToast(Context context, int resid, int duration) {
        showToast(context, context.getResources().getString(resid), duration);
    }

    /**
     * 创建Toast
     * @param context
     * @param resid 提示内容 id
     * @param duration 持续时间
     * @param gravity 位置，如：Gravity.CENTER
     */
    public static void showToast(Context context, int resid, int duration, int gravity) {
        showToast(context, context.getResources().getString(resid), duration, gravity);
    }

    /**
     * 取消Toast
     */
    public static void cancelToast() {
        if (sToast != null) {
            sToast.cancel();
            sToast = null;
        }
    }

    /**
     * 自定义Toast的样式View
     * @param context
     * @return
     */
    private View customToastView(Context context, String text) {
        View view = View.inflate(context, R.layout.ynkj_common_toast, null);
        TextView toastTxt = (TextView)view.findViewById(R.id.txt_toast);
        toastTxt.setText(text);
        //view.setAnimation(AnimationUtils.loadAnimation(context, R.anim.from_bottom_to_top));
        return view;
    }
}
