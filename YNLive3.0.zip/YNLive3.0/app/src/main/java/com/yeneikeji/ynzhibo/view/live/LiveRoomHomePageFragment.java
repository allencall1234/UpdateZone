package com.yeneikeji.ynzhibo.view.live;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNFragmentAdapter;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.community.NoteFragment;
import com.yeneikeji.ynzhibo.view.community.PersonalNoteFragment;
import com.yeneikeji.ynzhibo.view.community.VoiceFragment;
import com.yeneikeji.ynzhibo.view.community.VideoFragment;
import com.yeneikeji.ynzhibo.widget.TabPageIndicator;
import com.yeneikeji.ynzhibo.widget.badgeview.BadgeTextView;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.FixedIndicatorView;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 直播间主页
 * Created by Administrator on 2017/6/26.
 */
public class LiveRoomHomePageFragment extends BaseFragment
{
//    private IndicatorViewPager indicatorViewPager;
//    private FixedIndicatorView mIndicator;
    private TabPageIndicator mIndicator;
    private ViewPager mViewPager;

//    private MyAdapter mAdapter;
    private YNFragmentAdapter mFragmentAdapter;

    /** Tab标题 */
    private  String[] tabTitle =  null;
    private ArrayList<Fragment> fragments;
    private LiveRoomBean liveRoomBean = null;

    private String userId = "";

    private LocalBroadcastManager broadcastManager;
    private BroadcastReceiver mRefreshReceiver;

    @Override
    protected void initView()
    {
        mIndicator = (TabPageIndicator) findViewById(R.id.fragment_home_page_indicator);
        mViewPager = (ViewPager) findViewById(R.id.vp_home_page);

        tabTitle = new String[]{"笔记", "语音", "视频"};

      /*  float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#df3535");
        int unSelectColor = Color.parseColor("#808080");
        ColorBar line1 = new ColorBar(getActivity(), Color.parseColor("#df3535"), 5);
        line1.setWidth(UIUtils.dp2px(getActivity(), 25));
        line1.setHeight(UIUtils.dp2px(getActivity(), 3));
        mIndicator.setScrollBar(line1);
        mIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mViewPager.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mIndicator, mViewPager);*/
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
//        broadcastManager = LocalBroadcastManager.getInstance(getActivity());
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction(YNCommonConfig.UPDATE_USER_STATE_FLAG);
//        mRefreshReceiver= new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent){
//                if (intent.getBooleanExtra("liveRoom", true))
//                {
//                    YNLogUtil.e("tag", "登录成功！");
//                    userId = AccountUtils.getAccountBean().getId();
//                    addFragment();
//                }
//            }
//        };
//        broadcastManager.registerReceiver(mRefreshReceiver, intentFilter);
    }

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }
        return R.layout.fragment_live_room_homepage;
    }

    @Override
    protected void loadData()
    {
        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();


        addFragment();

//        if (!((YNLiveDetailsActivity)getActivity()).isPlaying)
//        {
//            mIndicator.setCurrentItem(2);
//        }

        if (liveRoomBean.getLiving() == 0)
        {
//            mIndicator.setCurrentItem(2);
            mViewPager.setCurrentItem(2);
        }
    }

    /**
     * 设置竖屏全屏直播间控件显示
     */
    private void setPortraitFullScreenUI()
    {
        mIndicator.setIndicatorMode(TabPageIndicator.IndicatorMode.MODE_WEIGHT_NOEXPAND_SAME);// 设置模式，一定要先设置模式
        mIndicator.setDividerColor(Color.parseColor("#d9d9d9"));// 设置分割线的颜色
        mIndicator.setUnderlineColor(Color.parseColor("#808080"));
        mIndicator.setDividerPadding(UIUtils.dp2px(getContext(), 10));
        mIndicator.setIndicatorColor(Color.parseColor("#1694ff"));// 设置底部导航线的颜色
        mIndicator.setTextColorSelected(Color.parseColor("#1694ff"));// 设置tab标题选中的颜色
        mIndicator.setTextColor(Color.parseColor("#ffffff"));// 设置tab标题未被选中的颜色
        mIndicator.setTextSize(UIUtils.sp2px(getContext(), 16));// 设置字体大小
    }

    /**
     * 设置竖屏直播间控件显示
     */
    private void setPortraitScreenUI()
    {
        mIndicator.setIndicatorMode(TabPageIndicator.IndicatorMode.MODE_WEIGHT_NOEXPAND_SAME);// 设置模式，一定要先设置模式
        mIndicator.setDividerColor(Color.parseColor("#d9d9d9"));// 设置分割线的颜色
        mIndicator.setUnderlineColor(Color.parseColor("#808080"));
        mIndicator.setDividerPadding(UIUtils.dp2px(getContext(), 10));
        mIndicator.setIndicatorColor(Color.parseColor("#df3535"));// 设置底部导航线的颜色
        mIndicator.setTextColorSelected(Color.parseColor("#df3535"));// 设置tab标题选中的颜色
        mIndicator.setTextColor(Color.parseColor("#808080"));// 设置tab标题未被选中的颜色
        mIndicator.setTextSize(UIUtils.sp2px(getContext(), 16));// 设置字体大小
    }

    /**
     * 初始化Fragment
     */
    private void addFragment()
    {
        fragments = new ArrayList<>();
        fragments.clear();//清空

        Bundle mBundle = new Bundle();
        mBundle.putString(YNCommonConfig.USER_ID, liveRoomBean.getUserid());
        mBundle.putInt(YNCommonConfig.HOME_PAGE_FLAG, 1);
        if (liveRoomBean.getEquipment() == 1)
           mBundle.putBoolean(YNCommonConfig.ISSHOW, true);
        else
           mBundle.putBoolean(YNCommonConfig.ISSHOW, false);

        if (userId.equals(liveRoomBean.getUserid()))
        {
            PersonalNoteFragment personalNoteFragment = new PersonalNoteFragment();
            personalNoteFragment.setArguments(mBundle);
            fragments.add(personalNoteFragment);
        }
        else
        {
            NoteFragment noteFragment = new NoteFragment();
            noteFragment.setArguments(mBundle);
            fragments.add(noteFragment);
        }

//        NoteFragment noteFragment = new NoteFragment();
//        noteFragment.setArguments(mBundle);

        VoiceFragment voiceFragment = new VoiceFragment();
        voiceFragment.setArguments(mBundle);

        VideoFragment videoFragment = new VideoFragment();
        videoFragment.setArguments(mBundle);

//        fragments.add(noteFragment);
        fragments.add(voiceFragment);
        fragments.add(videoFragment);

//        AdapterFragment adapter = new AdapterFragment(getChildFragmentManager(), fragments);
//        mViewPager.setAdapter(adapter);
        mFragmentAdapter = new YNFragmentAdapter(getChildFragmentManager(), fragments, tabTitle);
        mViewPager.setAdapter(mFragmentAdapter);
        mViewPager.setOffscreenPageLimit(tabTitle.length);
        mIndicator.setViewPager(mViewPager);

        if (liveRoomBean.getEquipment() == 1)
            setPortraitFullScreenUI();
        else
            setPortraitScreenUI();
//        mAdapter = new MyAdapter(getChildFragmentManager());
//        mAdapter.setFragments(fragments);
//        indicatorViewPager.setAdapter(mAdapter);

    }

}
