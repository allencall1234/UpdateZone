package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.AutoUtils;

/**
 *  公共带动画的弹出框(只有一个确定按钮)
 * Created by Administrator on 2016/11/11.
 */
public class YNCommonAnimDialog extends Dialog implements View.OnClickListener
{
    private Context context;
    private AlertDialog dialog;
    private View view;
    boolean cancelable;

    private ImageView mIVDialog;
    private TextView mTVNotice;
    private Button mBtnConfirm;

    CustomDialogListener cdListener;

    private int img;
    private String content;

    /**
     *
     * @param context
     * @param cancelable
     * 触摸屏幕是否可以取消对话框,true:就是可以取消。FALSE：就是不可以取消。
     * 在四个主界面可以设置为true，可以取消。其他都设置为FALSE 在做网络访问和提交数据的一律设置为false
     */

    public YNCommonAnimDialog(Context context, int themeResId, int img, String content, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.img = img;
        this.content = content;
        this.cdListener = cdListener;
        this.context = context;
        this.cancelable = cancelable;
        initView();
        showDialog();
    }

    private void initView()
    {
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.realname_dialog, null);
//        AutoUtils.auto(view);

        mIVDialog = (ImageView) view.findViewById(R.id.iv_dialog_img);
        mTVNotice = (TextView) view.findViewById(R.id.tv_notice);
        mBtnConfirm = (Button) view.findViewById(R.id.btn_confirm);

        setIVDialog(img);
        setTVNotice(content);
        mBtnConfirm.setOnClickListener(this);
    }

    private void showDialog()
    {
        if (context != null)
        {
            dialog = new AlertDialog.Builder(context).show();
            dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            Window window = dialog.getWindow();

            WindowManager m = ((Activity) context).getWindowManager();
            Display d = m.getDefaultDisplay(); // 为获取屏幕宽、高

            // 设置显示动画
            window.setWindowAnimations(R.style.main_menu_animstyle);

            WindowManager.LayoutParams wl = window.getAttributes();

            wl.width = (int) (d.getWidth() * 0.8);

            // 设置显示位置
            dialog.onWindowAttributesChanged(wl);
            // 设置点击外围解散
            dialog.setCanceledOnTouchOutside(false);
        }

    }

    public void setIVDialog(int img)
    {
        mIVDialog.setImageResource(img);
    }

    public void setTVNotice(String content)
    {
        mTVNotice.setText(content);
    }

    @Override
    public void onClick(View v)
    {
        cdListener.OnClick(v);
        dismiss();
    }

    @Override
    public void dismiss() {
        super.dismiss();
    }

    public interface CustomDialogListener
    {
        void OnClick(View view);
    }
}
