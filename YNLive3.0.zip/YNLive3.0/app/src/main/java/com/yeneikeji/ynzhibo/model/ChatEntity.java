package com.yeneikeji.ynzhibo.model;

/**
 * Created by Ying on 2016/2/24.
 */
public class ChatEntity {
    private int mType;
    private String mText;
    private int mPic;

    public int getmType() {
        return mType;
    }

    public void setmType(int mType) {
        this.mType = mType;
    }

    public int getmPic() {
        return mPic;
    }

    public void setmPic(int mPic) {
        this.mPic = mPic;
    }

    public String getmText() {
        return mText;
    }

    public void setmText(String mText) {
        this.mText = mText;
    }
}
