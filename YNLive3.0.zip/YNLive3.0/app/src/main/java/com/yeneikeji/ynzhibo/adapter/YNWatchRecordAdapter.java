package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.ISelectChangeCallBack;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.widget.CustomShapeImageView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 观看记录Adapter
 * Created by Administrator on 2017/6/16.
 */
public class YNWatchRecordAdapter extends BaseAdapter
{
    private Context context;
    private List<LiveRoomBean> list;
    private Map<Integer,Boolean> selectedItem;
    private boolean isShowSelected = false;
    private ISelectChangeCallBack callBack;

    public YNWatchRecordAdapter(Context context, List<LiveRoomBean> list, ISelectChangeCallBack callBack)
    {
        this.context = context;
        this.list = list;
        this.callBack = callBack;
    }

    public void initData() {
        selectedItem = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            selectedItem.put(i,false);
        }
    }

    public void updateData(List<LiveRoomBean> watchRecordList)
    {
        this.list = watchRecordList;
        initData();
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);}

    @Override
    public long getItemId(int position) {return position;}

    @Override

    public View getView(final int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        LiveRoomBean liveRoomBean = list.get(position);
        if(convertView == null)
        {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_item,null);
            holder.mIVLiveImg = (CustomShapeImageView) convertView.findViewById(R.id.iv_video);
            holder.mIVLiveState = (ImageView) convertView.findViewById(R.id.iv_record_live_state);
            holder.mTVLiveTitle = (TextView) convertView.findViewById(R.id.tv_video_title);
            holder.mTVHostName = (TextView) convertView.findViewById(R.id.tv_live_name);
            holder.mTVLiveTime = (TextView) convertView.findViewById(R.id.tv_video_time);
            holder.mCBSelected = (CheckBox) convertView.findViewById(R.id.checkBox);
            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        if(isShowSelected)
        {
            holder.mCBSelected.setVisibility(View.VISIBLE);
        }
        else
        {
            holder.mCBSelected.setVisibility(View.GONE);
        }

        holder.mCBSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                selectedItem.put(position, isChecked);
                if(buttonView.getVisibility() == View.VISIBLE)
                {
                    callBack.onSelectedSizeChange(selectedItem);
                }
            }
        });

        YNImageLoaderUtil.setImageWithErrorImg(context, holder.mIVLiveImg, R.drawable.loading_cover, R.drawable.loading_cover, liveRoomBean.getPicture());
/*        if (liveRoomBean.getLiving() == 1)
        {
            if (liveRoomBean.getLive_status() == 2)
            {
//                holder.mIVLiveState.setBackgroundResource(R.drawable.icon_lable_pay);
            }
            if (liveRoomBean.getLock() == 1)
            {
//                holder.mIVLiveState.setBackgroundResource(R.drawable.icon_lable_encrypt);
            }
            if (liveRoomBean.getLive_status() != 2 && liveRoomBean.getLock() != 1)
            {
                holder.mIVLiveState.setBackgroundResource(R.drawable.icon_record_live);
            }
        }
        else
        {
//            holder.mIVLiveState.setBackgroundResource(R.drawable.icon_lable_rest);
        }*/
        holder.mCBSelected.setChecked(selectedItem.get(position));
        holder.mTVLiveTitle.setText(liveRoomBean.getTitle());
        holder.mTVHostName.setText(liveRoomBean.getUsername());
        if (!TextUtils.isEmpty(liveRoomBean.getTime()))
        {
            holder.mTVLiveTime.setText(DateUtil.timeTick2DateNotSec(liveRoomBean.getTime()));
        }
        else
        {
            holder.mTVLiveTime.setText(DateUtil.getNowDate());
        }
        return convertView;
    }

    class ViewHolder
    {
        private CustomShapeImageView mIVLiveImg;
        private ImageView mIVLiveState;
        private TextView mTVLiveTitle, mTVHostName, mTVLiveTime;
        private CheckBox mCBSelected;
    }

    public void setShowSelected(boolean showSelected) {
        isShowSelected = showSelected;
    }

    public Map<Integer, Boolean> getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Map<Integer, Boolean> selectedItem) {
        this.selectedItem = selectedItem;
    }
}
