package com.yeneikeji.ynzhibo.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.widget.InputPanel;

/**
 * 直播间底部按钮
 * Created by Administrator on 2016/8/30.
 */
public class BottomPanelFragment extends Fragment
{
    private static final String TAG = "LiveDetailsBottomPanelFragment";

    private View view;
    private ViewGroup buttonPanel;
    private InputPanel inputPanel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        view = inflater.inflate(R.layout.fragment_bottombar, container);
        buttonPanel = (ViewGroup) view.findViewById(R.id.button_panel);
        inputPanel = (InputPanel) view.findViewById(R.id.input_panel);

        return view;
    }

    /**
     * back键或者空白区域点击事件处理
     *
     * @return 已处理true, 否则false
     */
    public boolean onBackAction() {
        if (inputPanel.onBackAction()) {
            return true;
        }
        if (buttonPanel.getVisibility() != View.VISIBLE)
        {
            inputPanel.setVisibility(View.GONE);
            buttonPanel.setVisibility(View.VISIBLE);
            return true;
        }
        return false;
    }

    public void setInputPanelListener(InputPanel.InputPanelListener l) {
        inputPanel.setPanelListener(l);
    }
}
