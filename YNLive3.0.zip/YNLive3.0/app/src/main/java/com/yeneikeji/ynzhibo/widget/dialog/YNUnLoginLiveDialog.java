package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;

/**
 * 试看结束弹出框
 * Created by Administrator on 2017/2/16.
 */
public class YNUnLoginLiveDialog implements View.OnClickListener
{
    private ImageButton mCloseIBtn;
    private Button mRegisterBtn;
    private TextView mLoginWatchTV;
    private Dialog mDialog;
    private View mDialogView;
    private Builder mBuilder;

    public YNUnLoginLiveDialog(Builder builder)
    {
        this.mBuilder = builder;
        mDialog = new Dialog(mBuilder.getContext(), R.style.NormalDialogStyle);
        mDialogView = View.inflate(mBuilder.getContext(), R.layout.live_details_unlogin_dialog, null);
        mCloseIBtn = (ImageButton) mDialogView.findViewById(R.id.ib_close);
        mRegisterBtn = (Button) mDialogView.findViewById(R.id.btn_register);
        mLoginWatchTV = (TextView) mDialogView.findViewById(R.id.tv_login_watch);
        mDialogView.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(mBuilder.getContext()) * builder.getHeight()));
        mDialog.setContentView(mDialogView);

        Window dialogWindow = mDialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtil.getScreenWidth(mBuilder.getContext()) * builder.getWidth());
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialogWindow.setAttributes(lp);

        initDialog(builder);
    }

    private void initDialog(Builder builder)
    {

        mDialog.setCanceledOnTouchOutside(builder.isTouchOutside());

        mCloseIBtn.setOnClickListener(this);
        mRegisterBtn.setOnClickListener(this);
        mLoginWatchTV.setOnClickListener(this);

        if (builder.isInterceptBack())
            interceptBack();
    }

    @Override
    public void onClick(View view) {

        int i = view.getId();

        if (i == R.id.ib_close && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickTopRightButton(mCloseIBtn);
            return;
        }

        if (i == R.id.btn_register && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomLeftButton(mRegisterBtn);
            return;
        }

        if (i == R.id.tv_login_watch && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomRightButton(mLoginWatchTV);
            return;
        }

    }

    private void interceptBack()
    {
        mDialog.setCancelable(false);
    }

    public void show() {

        mDialog.show();
    }

    public void dismiss() {

        mDialog.dismiss();
    }

    public static class Builder
    {
        private IDialogOnClickListener onclickListener;
        private boolean isTouchOutside;
        private float height;
        private float width;
        private Context mContext;
        private boolean isInterceptBack;

        public Builder(Context context)
        {
            mContext = context;

            onclickListener = null;
            isTouchOutside = true;
            height = 0.23f;
            width = 0.65f;
            isInterceptBack = false;
        }

        public Context getContext()
        {
            return mContext;
        }

        public IDialogOnClickListener getOnclickListener() {
            return onclickListener;
        }

        public Builder setOnclickListener(IDialogOnClickListener onclickListener) {
            this.onclickListener = onclickListener;
            return this;
        }

        public boolean isTouchOutside() {
            return isTouchOutside;
        }

        public Builder setCanceledOnTouchOutside(boolean isTouchOutside) {

            this.isTouchOutside = isTouchOutside;
            return this;
        }

        public float getHeight() {
            return height;
        }

        public Builder setHeight(float height) {
            this.height = height;
            return this;
        }

        public float getWidth() {
            return width;
        }

        public Builder setWidth(float width) {
            this.width = width;
            return this;
        }

        public boolean isInterceptBack() {
            return isInterceptBack;
        }

        public Builder setInterceptBack(boolean interceptBack) {
            isInterceptBack = interceptBack;
            return this;
        }

        public YNUnLoginLiveDialog build() {

            return new YNUnLoginLiveDialog(this);
        }
    }

}
