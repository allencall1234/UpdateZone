package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.DynamicAdapter;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.YNBaseFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *  社区中我关注的用户动态界面
 * Created by Administrator on 2016/11/30.
 */
public class DynamicFragment extends YNBaseFragment implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    public static final String TAG = "DynamicFragment";

    private RelativeLayout mDynamicRL;
    private SmoothListView mDynamicLV;// 推荐
//    private ImageView mReleaseDynamicIV;
    private RelativeLayout mRLDynamicEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;

    private LinearLayout mLLLogin;
    private TextView mBtnAtonceLogin;
    private List<DynamicBean> dynamicList;

    private DynamicAdapter mDynamicAdapter;

    //listView中第一项的索引
    private int mListViewFirstItem = 0;
    private int totalPages = 0;
    private int curragePage = 0;// 当前页

    private String userid = "";

    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_MY_ATTENTION_USER_DYNAMIC_LIST_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            mRLDynamicEmpty.setVisibility(View.GONE);
                            mDynamicLV.setVisibility(View.VISIBLE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                totalPages = UserHttpUtils.newInstance().getTotalPages(jsonObject.getInt("count"));
                                if (curragePage + 1 >= totalPages)
                                    mDynamicLV.setLoadMoreEnable(false);
                                else
                                    mDynamicLV.setLoadMoreEnable(true);

                                JSONArray array = jsonObject.getJSONArray("data");
                                if (array.length() <= 0)
                                    mRLDynamicEmpty.setVisibility(View.VISIBLE);
                                Type type = new TypeToken<List<DynamicBean>>() {}.getType();
                                dynamicList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mDynamicAdapter.setDynamicList(dynamicList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mRLDynamicEmpty.setVisibility(View.VISIBLE);
                        }
//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mRLDynamicEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            curragePage = 0;
                            mRLDynamicEmpty.setVisibility(View.GONE);
                            mDynamicLV.setVisibility(View.VISIBLE);
//                            YNToastMaster.showToast(getActivity(), "刷新成功");
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                totalPages = UserHttpUtils.newInstance().getTotalPages(jsonObject.getInt("count"));
                                if (curragePage + 1 < totalPages)
                                    mDynamicLV.setLoadMoreEnable(true);
                                else
                                    mDynamicLV.setLoadMoreEnable(false);

                                JSONArray array = jsonObject.getJSONArray("data");
                                Type type = new TypeToken<List<DynamicBean>>() {}.getType();
                                dynamicList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mDynamicAdapter.setDynamicList(dynamicList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                        mRLDynamicEmpty.setVisibility(View.VISIBLE);
                        mDynamicLV.setVisibility(View.GONE);
                    }
                    onStopLoad();
                    break;

                case YNCommonConfig.LOAD_MORE:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("data");
                                for (int i = 0; i < array.length(); i++)
                                {
                                    DynamicBean dynamicBean = YNJsonUtil.JsonToBean(array.getJSONObject(i).toString(), DynamicBean.class);
                                    dynamicList.add(dynamicBean);
                                }
                                mDynamicAdapter.setDynamicList(dynamicList);
                                if (curragePage + 1 >= totalPages)
                                    mDynamicLV.setLoadMoreEnable(false);
                                else
                                    mDynamicLV.setLoadMoreEnable(true);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                    }
                    onStopLoad();
                    break;

            }
            super.handleMessage(msg);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_dynamic, container, false);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    public void onResume()
    {
        if (AccountUtils.getLoginInfo())
            loginRefreshUI();
        else
            unLoginRefreshUI();

        if (!YNBaseActivity.isConnectNet)
        {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("空的，什么也没有~");
        }

        super.onResume();
    }

    @Override
    protected void initView(View view)
    {
        mLLLogin = (LinearLayout) view.findViewById(R.id.ll_login);
        mBtnAtonceLogin = (TextView) view.findViewById(R.id.btn_atonce_login);
        mDynamicRL = (RelativeLayout) view.findViewById(R.id.rl_dynamic);
        mDynamicLV = (SmoothListView) view.findViewById(R.id.lv_dynamic);
        mRLDynamicEmpty = (RelativeLayout) view.findViewById(R.id.empty);
        mIVEmpty = (ImageView) view.findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) view.findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) view.findViewById(R.id.tv_refresh_net);
//        mReleaseDynamicIV = (ImageView) view.findViewById(R.id.iv_release_dynamic);

        mDynamicLV.setVisibility(View.GONE);
    }

    @Override
    protected void addEvents()
    {
        if(mLLLogin != null)
        {
            mLLLogin.setOnClickListener(this);
        }
        if(mBtnAtonceLogin != null)
        {
            mBtnAtonceLogin.setOnClickListener(this);
        }

        mDynamicLV.setLoadMoreEnable(false);// 设置上拉加载
        mDynamicLV.setSmoothListViewListener(this);
//        mReleaseDynamicIV.setOnClickListener(this);
        mRLDynamicEmpty.setOnClickListener(this);

        mDynamicLV.setOnScrollListener(new AbsListView.OnScrollListener()
        {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
//                if(scrollState == SCROLL_STATE_IDLE)
//                {
//                    Glide.with(mContext).resumeRequests();
//                }
//                else
//                {
//                    Glide.with(mContext).pauseRequests();
//                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
            {
                if(firstVisibleItem != mListViewFirstItem)
                {
                    if(firstVisibleItem > mListViewFirstItem)
                    {
                        Log.e("--->", "向上滑动");
//                        mReleaseDynamicIV.setVisibility(View.GONE);
                    }
                    else
                    {
                        Log.e("--->", "向下滑动");
//                        mReleaseDynamicIV.setVisibility(View.VISIBLE);
                    }
                    mListViewFirstItem = firstVisibleItem;
                }
            }
        });

    }

    @Override
    protected void settingDo()
    {
//        presenter = new DynamicPresenter(DynamicFragmentTest.this);
        if (!YNBaseActivity.isConnectNet)
        {
            mRLDynamicEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mRLDynamicEmpty.setVisibility(View.GONE);
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("空的，什么也没有~");
            initListData();
        }

        mDynamicLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    DynamicBean item = dynamicList.get(position - 1);
                    Intent intent = new Intent();
//                    intent.setClass(mContext, DynamicDetailsActivity.class);
                    intent.setClass(mContext, DynamicDetailsActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(YNCommonConfig.OBJECT, item);
//                bundle.putBoolean(YNCommonConfig.ISSHOW, false);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.no_net);
                }
            }
        });
    }

    /**
     * 初始化界面数据
     */
    private void initListData()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getMyAttentionUserDynamicList(getActivity(), YNCommonConfig.GET_ATTENTION_USER_DYNAMIC_LIST_URL, userid, curragePage, mHandler, YNCommonConfig.GET_MY_ATTENTION_USER_DYNAMIC_LIST_FLAG, true);
            }
        }, 1000);

        mDynamicAdapter = new DynamicAdapter(getActivity(), new ArrayList<DynamicBean>(), false);
        mDynamicLV.setAdapter(mDynamicAdapter);

    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
           /* case R.id.iv_release_dynamic:
                if (AccountUtils.getLoginInfo())
                {
                    intent.setClass(getActivity(), ReleaseDynamicActivity.class);
                    startActivity(intent);
                }
                else
                {
                    intent.setClass(getActivity(),YNLoginActivity.class);
                    startActivity(intent);
                }
                break;*/

            case R.id.tv_refresh_net:
            case R.id.empty:
                if (YNBaseActivity.isConnectNet)
                {
                    mRLDynamicEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("空的，什么也没有~");
                    initListData();
                }
                else
                {
                    YNToastMaster.showToast(mContext, "网络未连接");
                }
                break;

            case R.id.btn_atonce_login:
            case R.id.ll_login:
                intent.setClass(mContext, YNLoginActivity.class);
                startActivity(intent);
                break;
        }
    }


    @Override
    public void onRefresh()
    {
        if (!YNBaseActivity.isConnectNet)
        {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("空的，什么也没有~");
        }
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getMyAttentionUserDynamicList(getContext(), YNCommonConfig.GET_ATTENTION_USER_DYNAMIC_LIST_URL, userid, 0, mHandler, YNCommonConfig.ON_REFRESH, false);
            }
        }, 1000);
    }

    @Override
    public void onLoadMore()
    {
        if (curragePage + 1 < totalPages)
        {
            curragePage++;
            mHandler.postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyAttentionUserDynamicList(getContext(), YNCommonConfig.GET_ATTENTION_USER_DYNAMIC_LIST_URL, userid, curragePage, mHandler, YNCommonConfig.LOAD_MORE, false);
                }
            }, 1000);
        }
    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mDynamicLV.stopRefresh();
        mDynamicLV.stopLoadMore();
        mDynamicLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void loginRefreshUI()
    {
        mLLLogin.setVisibility(View.GONE);
        mDynamicRL.setVisibility(View.VISIBLE);
        userid = AccountUtils.getAccountBean().getId();
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getMyAttentionUserDynamicList(getContext(), YNCommonConfig.GET_ATTENTION_USER_DYNAMIC_LIST_URL, userid, 0, mHandler, YNCommonConfig.ON_REFRESH, false);
            }
        });
    }

    @Override
    public void unLoginRefreshUI()
    {
        mLLLogin.setVisibility(View.VISIBLE);
        mDynamicRL.setVisibility(View.GONE);
    }

}
