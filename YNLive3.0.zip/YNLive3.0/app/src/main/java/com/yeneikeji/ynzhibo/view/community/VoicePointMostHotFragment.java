package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindVoiceBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;
import com.yeneikeji.ynzhibo.widget.weelwight.CenterTextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/**
 * 语音观点最新内容碎片
 * Created by Administrator on 2017/6/26.
 */
public class VoicePointMostHotFragment
        extends BaseFragment implements SmoothListView.ISmoothListViewListener, View.OnClickListener{

    private SmoothListView mSmoothListView;
    private   List<FindVoiceBean> VoiceBeans;
    private  String userid;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.VOICE_POINT_FLAG:

                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    JSONArray      array      = jsonObject.getJSONArray("data");
                                    Type           type       = new TypeToken<List<FindVoiceBean>>() {}.getType();
                                    VoiceBeans = YNJsonUtil.JsonToLBean(array.toString(),
                                                                        type);
                                    MyListViewAdapter adapter=new MyListViewAdapter(VoiceBeans);
                                    mSmoothListView.setAdapter(adapter);
                                }
                            } catch (JSONException e) {
                                mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }

                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    //记得清空 防止出现重复视图
                    if (VoiceBeans != null) {
                        VoiceBeans.removeAll(VoiceBeans);
                    }
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() ==28) {
                            mEmpty.setVisibility(View.GONE);
                            YNLogUtil.e("lxy",msg.obj.toString());
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if (jsonObject != null) {
                                    JSONArray      array      = jsonObject.getJSONArray("data");
                                    Type           type       = new TypeToken<List<FindVoiceBean>>() {}.getType();
                                    VoiceBeans = YNJsonUtil.JsonToLBean(array.toString(),
                                                                        type);
                                    MyListViewAdapter adapter=new MyListViewAdapter(VoiceBeans);
                                    mSmoothListView.setAdapter(adapter);
                                }
                            } catch (JSONException e) {
                                mEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        }

                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                    }
                    mSmoothListView.stopRefresh();
                    break;

            }
        }

    };
    private RelativeLayout mEmpty;

    @Override
    protected void initView() {
        mSmoothListView = (SmoothListView)findViewById(R.id.mListView);
        mEmpty = (RelativeLayout) findViewById(R.id.empty);
        mEmpty.setOnClickListener(this);
        mSmoothListView.setSmoothListViewListener(this);
        mSmoothListView.setLoadMoreEnable(false);
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_recomment;
    }
    //加载数据
    @Override
    protected void loadData() {
        initData(1);
    }

    private void initData(final int i) {
        if(AccountUtils.getLoginInfo()){
            userid=AccountUtils.getAccountBean().getId();
        }else{
            userid="";
        }
        //判断是否有网络
        if(YNBaseActivity.isConnectNet) {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getVoicePointList(getActivity(),
                                                    YNCommonConfig.GET_VOICE_POINT_URL,
                                                    userid,
                                                    i,
                                                    mHandler,
                                                    YNCommonConfig.VOICE_POINT_FLAG,
                                                    true);
                }
            });
        }else{
            Toast.makeText(getActivity(), "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }
    @Override
    public void onRefresh() {
        if(AccountUtils.getLoginInfo()){
            userid=AccountUtils.getAccountBean().getId();
        }else{
            userid="";
        }
        if (YNBaseActivity.isConnectNet) {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getMarketInterpretList(getActivity(),
                                                         YNCommonConfig.GET_VOICE_POINT_URL,
                                                         userid,
                                                         1,
                                                         mHandler,
                                                         YNCommonConfig.ON_REFRESH,
                                                         true);
                }
            });
        }else{
            Toast.makeText(getActivity(), "请检查您的网络状态哦", Toast.LENGTH_SHORT)
                 .show();
            mEmpty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onLoadMore() {

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.empty:
                onRefresh();
                break;

        }
    }


    class  MyListViewAdapter extends BaseAdapter{
        private   List<FindVoiceBean> VoiceBeans;

        public MyListViewAdapter(List<FindVoiceBean> voiceBeans) {
            VoiceBeans = voiceBeans;
        }

        @Override
        public int getCount() {
            if(VoiceBeans!=null){
            return VoiceBeans.size();
            }
            return  0;
        }

        @Override
        public FindVoiceBean getItem(int position) {
            if(VoiceBeans!=null){
                return VoiceBeans.get(position);
            }
            return null;
        }
        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder=null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView=View.inflate(getActivity(), R.layout.voice_point_mostnew_item, null);
                holder.leftIv= (YNCircleImageView) convertView.findViewById(R.id.find_financial_listview_leftIvItem);
                holder.authorName= (CenterTextView) convertView.findViewById(R.id.author_name);
                holder.play= (LinearLayout) convertView.findViewById(R.id.play_voice);
                holder.voiceLength= (TextView) convertView.findViewById(R.id.voice_length);
                holder.describle= (TextView) convertView.findViewById(R.id.voice_describle);
                holder.time= (TextView) convertView.findViewById(R.id.voice_publish_time);
                holder.listenePeople= (TextView) convertView.findViewById(R.id. receiver_people_numb);
                convertView.setTag(holder);
            }else{
                holder= (ViewHolder) convertView.getTag();
            }

            final FindVoiceBean voiceBean = VoiceBeans.get(position);
            YNImageLoaderUtil.setImage(getActivity(), holder.leftIv, voiceBean.getIcon());
            holder.authorName.setText(voiceBean.getUsername());

            if(voiceBean.getPlayTime()!=null){
                holder.voiceLength.setText(voiceBean.getPlayTime());
            }else{
                holder.voiceLength.setVisibility(View.GONE);
            }
            if(voiceBean.getDescribe1()!=null){
                holder.describle.setText(voiceBean.getDescribe1());
            }else{
                holder.describle.setVisibility(View.GONE);
            }
            if(voiceBean.getTime()!=null){
                holder.time.setText(timeStamp2StringSHort(voiceBean.getTime()));
            }

                holder.listenePeople.setText(voiceBean.getCount());


            holder.play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getActivity(),VoiceDetailActivity.class);
                    intent.putExtra("aid",voiceBean.getId());
                    startActivity(intent);
                }
            });

            return convertView;
        }
        class ViewHolder{
            private YNCircleImageView leftIv;
            private CenterTextView authorName;
            private LinearLayout play;
            private TextView  voiceLength;
            private TextView  describle;
            private TextView  time;
            private TextView  listenePeople;

        }
    }
}
