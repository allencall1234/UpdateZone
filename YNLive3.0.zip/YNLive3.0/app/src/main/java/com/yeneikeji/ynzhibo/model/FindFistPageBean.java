package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * Created by Administrator on 2017/5/16.
 */

public class FindFistPageBean {


    /**
     * code : 28
     * info : 获取数据成功！
     * data1 : [{"id":"16","userid":"43","title":"啦啦啦，我是卖报的小胖家","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588e57f.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588e8ed.png","picture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588eb9b.png","smallpicture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588e57f.png","smallpicture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588e8ed.png","smallpicture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588eb9b.png","mediaId":"","is_pay":"0","payCoin":"0","view":"78","time":"2017-05-17 01:36","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"7","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591a96898ec2c.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591a96147bd70.png","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"mda-hczp6ejcrw56qj5w","is_pay":"0","payCoin":"0","view":"39","time":"2017-05-16 02:04","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"15","userid":"43","title":"健健康康快乐渐酒空金榼","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bce364ce10.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bce364d3d4.png","picture2":"","smallpicture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591bce364ce10.png","smallpicture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591bce364d3d4.png","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"28","time":"2017-05-17 12:14","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"8","userid":"43","title":"0","kind":"0","content":"啦啦咯舞台涂抹兔图咯考虑兔兔图\n","picture0":null,"picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"mda-hczpbtai3rtw6dkv","is_pay":"0","payCoin":"0","view":"10","time":"2017-05-16 02:18","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"14","userid":"43","title":"正文正文正文","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049e9b0e.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049e9f97.png","picture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049ea39d.png","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"7","time":"2017-05-17 11:15","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"9","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad19fa7df3.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"3","view":"1","time":"2017-05-16 06:17","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"10","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad546f29ba.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"1","time":"2017-05-16 06:32","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"11","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad580536c8.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"0","time":"2017-05-16 06:33","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"12","userid":"43","title":"啦咯哦","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad5f6ec896.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"3","view":"0","time":"2017-05-16 06:35","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"13","userid":"43","title":"记录我OK提供了","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad6b489309.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"5","view":"0","time":"2017-05-16 06:38","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"}]
     * data2 : [{"username":"baby","describes":"投资有风险，入股需谨慎","icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","live_status":"READY","play_address":"rtmp://www.yeneilive.com/YNLive/xqtpHPZWoxKvlMQprfsXRXTQaTXGjG"},{"username":"股经股道","describes":"金融解析，指点股市迷津","icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-03-03/58b8e30541322.jpg","live_status":"READY","play_address":"rtmp://www.yeneilive.com/YNLive/TFRPUnN2O3e1Bvr0CXASg1qdi1ZqZ3"},{"username":"黄金操盘手","describes":"加勒比海岸","icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-03-28/58da63c60e953.png","live_status":"READY","play_address":"rtmp://www.yeneilive.com/YNLive/ITfX3W3uipSFTceyRXqT9RGWosmjGo"},{"username":"要有名称","describes":"我只是一行文字很长很长的,我只是一行文字很长很长的,我只是一行文字很长","icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-03-28/58da56ed5925e.png","live_status":null,"play_address":"rtmp://www.yeneilive.com/YNLive/eneilive.cn/YNLive/11154655452"}]
     * data3 : [{"id":"16","userid":"43","title":"啦啦啦，我是卖报的小胖家","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588e57f.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588e8ed.png","picture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591be1588eb9b.png","smallpicture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588e57f.png","smallpicture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588e8ed.png","smallpicture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591be1588eb9b.png","mediaId":"","is_pay":"0","payCoin":"0","view":"78","time":"2017-05-17 01:36","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"15","userid":"43","title":"健健康康快乐渐酒空金榼","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bce364ce10.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bce364d3d4.png","picture2":"","smallpicture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591bce364ce10.png","smallpicture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/small591bce364d3d4.png","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"28","time":"2017-05-17 12:14","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"14","userid":"43","title":"正文正文正文","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049e9b0e.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049e9f97.png","picture2":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-17/591bc049ea39d.png","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"7","time":"2017-05-17 11:15","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"13","userid":"43","title":"记录我OK提供了","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda.","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad6b489309.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"5","view":"0","time":"2017-05-16 06:38","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"12","userid":"43","title":"啦咯哦","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad5f6ec896.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"3","view":"0","time":"2017-05-16 06:35","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"11","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad580536c8.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"0","time":"2017-05-16 06:33","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"10","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad546f29ba.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"0","payCoin":"0","view":"1","time":"2017-05-16 06:32","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"9","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591ad19fa7df3.png","picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"","is_pay":"1","payCoin":"3","view":"1","time":"2017-05-16 06:17","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"8","userid":"43","title":"0","kind":"0","content":"啦啦咯舞台涂抹兔图咯考虑兔兔图\n","picture0":null,"picture1":"","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"mda-hczpbtai3rtw6dkv","is_pay":"0","payCoin":"0","view":"10","time":"2017-05-16 02:18","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"},{"id":"7","userid":"43","title":"0","kind":"0","content":"Lorem ipsum dolor sit er elit lamet, consectetaur cilli","picture0":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591a96898ec2c.png","picture1":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-16/591a96147bd70.png","picture2":"","smallpicture0":"","smallpicture1":"","smallpicture2":"","mediaId":"mda-hczp6ejcrw56qj5w","is_pay":"0","payCoin":"0","view":"39","time":"2017-05-16 02:04","read":0,"icon":"https://www.gupiaoask.com/yeneilive/Uploads/Admin/2017-05-09/5911939b6e603.png","username":"baby"}]
     */

    private int code;
    private String          info;
    private List<Data1Bean> data1;
    private List<Data2Bean> data2;
    private List<Data3Bean> data3;

    public int getCode() { return code;}

    public void setCode(int code) { this.code = code;}

    public String getInfo() { return info;}

    public void setInfo(String info) { this.info = info;}

    public List<Data1Bean> getData1() { return data1;}

    public void setData1(List<Data1Bean> data1) { this.data1 = data1;}

    public List<Data2Bean> getData2() { return data2;}

    public void setData2(List<Data2Bean> data2) { this.data2 = data2;}

    public List<Data3Bean> getData3() { return data3;}

    public void setData3(List<Data3Bean> data3) { this.data3 = data3;}

    public static class Data1Bean {

        private String id;
        private String userid;
        private String title;
        private String kind;
        private String content;
        private String picture0;
        private String picture1;
        private String picture2;
        private String smallpicture0;
        private String smallpicture1;
        private String smallpicture2;
        private String mediaId;
        private String is_pay;
        private String payCoin;
        private String view;
        private String time;
        private int    read;
        private String icon;
        private String username;

        public String getId() { return id;}

        public void setId(String id) { this.id = id;}

        public String getUserid() { return userid;}

        public void setUserid(String userid) { this.userid = userid;}

        public String getTitle() { return title;}

        public void setTitle(String title) { this.title = title;}

        public String getKind() { return kind;}

        public void setKind(String kind) { this.kind = kind;}

        public String getContent() { return content;}

        public void setContent(String content) { this.content = content;}

        public String getPicture0() { return picture0;}

        public void setPicture0(String picture0) { this.picture0 = picture0;}

        public String getPicture1() { return picture1;}

        public void setPicture1(String picture1) { this.picture1 = picture1;}

        public String getPicture2() { return picture2;}

        public void setPicture2(String picture2) { this.picture2 = picture2;}

        public String getSmallpicture0() { return smallpicture0;}

        public void setSmallpicture0(String smallpicture0) { this.smallpicture0 = smallpicture0;}

        public String getSmallpicture1() { return smallpicture1;}

        public void setSmallpicture1(String smallpicture1) { this.smallpicture1 = smallpicture1;}

        public String getSmallpicture2() { return smallpicture2;}

        public void setSmallpicture2(String smallpicture2) { this.smallpicture2 = smallpicture2;}

        public String getMediaId() { return mediaId;}

        public void setMediaId(String mediaId) { this.mediaId = mediaId;}

        public String getIs_pay() { return is_pay;}

        public void setIs_pay(String is_pay) { this.is_pay = is_pay;}

        public String getPayCoin() { return payCoin;}

        public void setPayCoin(String payCoin) { this.payCoin = payCoin;}

        public String getView() { return view;}

        public void setView(String view) { this.view = view;}

        public String getTime() { return time;}

        public void setTime(String time) { this.time = time;}

        public int getRead() { return read;}

        public void setRead(int read) { this.read = read;}

        public String getIcon() { return icon;}

        public void setIcon(String icon) { this.icon = icon;}

        public String getUsername() { return username;}

        public void setUsername(String username) { this.username = username;}
    }

    public static class Data2Bean {

        private String username;
        private String describes;
        private String icon;
        private String live_status;
        private String play_address;

        public String getUsername() { return username;}

        public void setUsername(String username) { this.username = username;}

        public String getDescribes() { return describes;}

        public void setDescribes(String describes) { this.describes = describes;}

        public String getIcon() { return icon;}

        public void setIcon(String icon) { this.icon = icon;}

        public String getLive_status() { return live_status;}

        public void setLive_status(String live_status) { this.live_status = live_status;}

        public String getPlay_address() { return play_address;}

        public void setPlay_address(String play_address) { this.play_address = play_address;}
    }

    public static class Data3Bean {

        private String id;
        private String userid;
        private String title;
        private String kind;
        private String content;
        private String picture0;
        private String picture1;
        private String picture2;
        private String smallpicture0;
        private String smallpicture1;
        private String smallpicture2;
        private String mediaId;
        private String is_pay;
        private String payCoin;
        private String view;
        private String time;
        private int    read;
        private String icon;
        private String username;

        public String getId() { return id;}

        public void setId(String id) { this.id = id;}

        public String getUserid() { return userid;}

        public void setUserid(String userid) { this.userid = userid;}

        public String getTitle() { return title;}

        public void setTitle(String title) { this.title = title;}

        public String getKind() { return kind;}

        public void setKind(String kind) { this.kind = kind;}

        public String getContent() { return content;}

        public void setContent(String content) { this.content = content;}

        public String getPicture0() { return picture0;}

        public void setPicture0(String picture0) { this.picture0 = picture0;}

        public String getPicture1() { return picture1;}

        public void setPicture1(String picture1) { this.picture1 = picture1;}

        public String getPicture2() { return picture2;}

        public void setPicture2(String picture2) { this.picture2 = picture2;}

        public String getSmallpicture0() { return smallpicture0;}

        public void setSmallpicture0(String smallpicture0) { this.smallpicture0 = smallpicture0;}

        public String getSmallpicture1() { return smallpicture1;}

        public void setSmallpicture1(String smallpicture1) { this.smallpicture1 = smallpicture1;}

        public String getSmallpicture2() { return smallpicture2;}

        public void setSmallpicture2(String smallpicture2) { this.smallpicture2 = smallpicture2;}

        public String getMediaId() { return mediaId;}

        public void setMediaId(String mediaId) { this.mediaId = mediaId;}

        public String getIs_pay() { return is_pay;}

        public void setIs_pay(String is_pay) { this.is_pay = is_pay;}

        public String getPayCoin() { return payCoin;}

        public void setPayCoin(String payCoin) { this.payCoin = payCoin;}

        public String getView() { return view;}

        public void setView(String view) { this.view = view;}

        public String getTime() { return time;}

        public void setTime(String time) { this.time = time;}

        public int getRead() { return read;}

        public void setRead(int read) { this.read = read;}

        public String getIcon() { return icon;}

        public void setIcon(String icon) { this.icon = icon;}

        public String getUsername() { return username;}

        public void setUsername(String username) { this.username = username;}
    }
}
