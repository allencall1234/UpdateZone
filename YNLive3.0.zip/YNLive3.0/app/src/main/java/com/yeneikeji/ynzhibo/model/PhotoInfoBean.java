package com.yeneikeji.ynzhibo.model;

/**
 * 动态item中图片实体类
 * Created by Administrator on 2016/12/6.
 */
public class PhotoInfoBean extends BaseBean
{
    private String id;
    private String big;
    private String small;
    private  int w;
    private int h;

    public PhotoInfoBean(String big, String small, int w, int h)
    {
        this.big = big;
        this.small = small;
        this.w = w;
        this.h = h;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBig() {
        return big;
    }

    public void setBig(String big) {
        this.big = big;
    }

    public String getSmall() {
        return small;
    }

    public void setSmall(String small) {
        this.small = small;
    }

    public int getW() {
        return w;
    }

    public void setW(int w) {
        this.w = w;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }
}
