package com.yeneikeji.ynzhibo.http;

import android.content.Context;

import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;

import org.xutils.common.Callback;
import org.xutils.ex.HttpException;
import org.xutils.http.HttpMethod;
import org.xutils.http.RequestParams;
import org.xutils.x;

/**
 * Created by Administrator on 2017/1/3.
 */
public abstract class BaseHttpUtils
{
    private final String TAG = "BaseHttpUtils";
    private YNLoadingDialog loadingDialog;
    private boolean isShowDialog;

    /**
     * http get请求
     * @param params 请求参数 get请求使用 addQueryStringParameter方法添加参数
     * @param mCallback 回调对象
     * @return 网络请求的Cancelable 可以中断请求
     */
    public void getHttpRequest(Context context, RequestParams params, final HttpUtilsCallBack mCallback, boolean isShowLoaingDialog, int height) {
        sendHttpRequest(context, HttpMethod.GET, params, mCallback, isShowLoaingDialog, height);


    }

    /**
     * http post请求
     * @param params 请求参数 post请求使用 addBodyParameter方法添加参数
     * @param mCallback 回调对象
     * @return 网络请求的Cancelable 可以中断请求
     */
    public void postHttpRequest(Context context, RequestParams params, final HttpUtilsCallBack mCallback, boolean isShowLoaingDialog, int height)
    {
        sendHttpRequest(context, HttpMethod.POST, params, mCallback,isShowLoaingDialog, height);
    }

    /**
     * 发送请求 Cancelable
     * @param method 请求方式(GET POST)
     * @param params 请求参数
     * @param mCallback 回调对象
     * @return 网络请求的Cancelable 可以中断请求
     */
    public void sendHttpRequest(Context context, HttpMethod method, RequestParams params, final HttpUtilsCallBack mCallback, boolean isShowLoaingDialog, int height)
    {
        isShowDialog = isShowLoaingDialog;
        if (!NetUtils.isConnected(YNApplication.getContext()))
        {
            // 网络请求之前先检查网络是否可用
            mCallback.onError();
//            mCallback.onError("网络连接失败，请重试");
            return;
        }

        showLoadingDialog(context, isShowLoaingDialog, height);

        if (params == null)
        {
            params = new RequestParams();
        }
        params.setCacheMaxAge(1000 * 0); //为请求添加缓存时间
        params.setConnectTimeout(60000); //超时时间60s
        params.setReadTimeout(8 * 1000);//访问时间限制

//        params.setSslSocketFactory(FakeX509TrustManager.allowAllSSL().getSocketFactory()); //绑定SSL证书(https请求)
     /*  SSLContext sslContext = getSSLContext(YNApplication.getInstance());
        if(null == sslContext){
           return;
       }
       params.setSslSocketFactory(sslContext.getSocketFactory()); //绑定SSL证书(https请求)
*/
        /** Cancelable cancelable = x.http().get(params, Callback); */
        x.http().request(method, params , new Callback.CommonCallback<String>()
        {
            @Override //取消
            public void onCancelled(CancelledException msg)
            {
                mCallback.onError();
//                mCallback.onError("取消");
            }

            @Override //错误
            public void onError(Throwable arg0, boolean arg1)
            {
                if (arg0.toString().contains("SocketTimeoutException"))
                {
                    mCallback.onError();
//                    mCallback.onError("请求超时");
                }
                if (arg0 instanceof HttpException)
                {
                    mCallback.onError();
//                    mCallback.onError("网络错误");
                }
            }

            @Override //成功
            public void onSuccess(String result)
            {
                mCallback.onSuccess(result);
            }

            @Override //完成
            public void onFinished()
            {
                closeLoadingDialog();
            }
        });
    }

    /**
     * 显示dialog
     * @param context
     * @param isShow
     */
    private void showLoadingDialog(Context context, boolean isShow, int height)
    {
        if (isShow)
        {
            loadingDialog = new YNLoadingDialog.Builder(context)
                    .setHeight(height)
                    .builder();
            loadingDialog.show();
        }
    }

    /**
     * 关闭dialog
     */
    private void closeLoadingDialog()
    {
        if (isShowDialog && loadingDialog != null)
        {
            loadingDialog.dismiss();
        }
    }

}
