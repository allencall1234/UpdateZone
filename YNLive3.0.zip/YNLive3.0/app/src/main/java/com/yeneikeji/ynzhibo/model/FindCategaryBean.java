package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * 文章实体类(订阅、笔记)
 * Created by Administrator on 2017/5/16.
 */
public class FindCategaryBean extends BaseBean{

    private String name;
    private String content;
    private String id;
    private String is_pay;// 是否收费  0：不收费  1：收费
    private String kind;
    private String mediaId;
    private String payCoin;
    private String picture0;
    private String picture1;
    private String picture2;
    private String time;
    private String title;
    private String userid;
    private String view;
    private String describes;
    private String describe0;
    private String describe1;

    private String describe2;
    private String describe3;
    private String icon;
    private String live_status;
    private String play_address;
    private String username;
    private int    is_purchase;// 是否已购 1: 已购 0: 未购
    private int    purchase;
    private int    read;
    private int    is_attention;
    public  String is_pass;
    public int getIs_attention() {
        return is_attention;
    }

    public void setIs_attention(int is_attention) {
        this.is_attention = is_attention;
    }




    public String getIs_pass() {
        return is_pass;
    }

    public void setIs_pass(String is_pass) {
        this.is_pass = is_pass;
    }


    public String getDescribe0() {
        return describe0;
    }

    public void setDescribe0(String describe0) {
        this.describe0 = describe0;
    }

    public String getDescribe1() {
        return describe1;
    }

    public void setDescribe1(String describe1) {
        this.describe1 = describe1;
    }

    public String getDescribe2() {
        return describe2;
    }

    public void setDescribe2(String describe2) {
        this.describe2 = describe2;
    }

    public String getDescribe3() {
        return describe3;
    }

    public void setDescribe3(String describe3) {
        this.describe3 = describe3;
    }

    private List<PhotoInfoBean> picture;
    private PhotoInfoBean vedio = null;

    public int getRead() { return read;}

    public void setRead(int read) { this.read = read;}

    public String getName() { return name;}

    public void setName(String name) { this.name = name;}

    public String getContent() { return content;}

    public void setContent(String content) { this.content = content;}

    public String getId() { return id;}

    public void setId(String id) { this.id = id;}

    public String getIs_pay() { return is_pay;}

    public void setIs_pay(String is_pay) { this.is_pay = is_pay;}

    public String getKind() { return kind;}

    public void setKind(String kind) { this.kind = kind;}

    public String getMediaId() { return mediaId;}

    public void setMediaId(String mediaId) { this.mediaId = mediaId;}

    public String getPayCoin() { return payCoin;}

    public void setPayCoin(String payCoin) { this.payCoin = payCoin;}

    public String getPicture0() { return picture0;}

    public void setPicture0(String picture0) { this.picture0 = picture0;}

    public String getPicture1() { return picture1;}

    public void setPicture1(String picture1) { this.picture1 = picture1;}

    public String getPicture2() { return picture2;}

    public void setPicture2(String picture2) { this.picture2 = picture2;}

    public String getTime() { return time;}

    public void setTime(String time) { this.time = time;}

    public String getTitle() { return title;}

    public void setTitle(String title) { this.title = title;}

    public String getUserid() { return userid;}

    public void setUserid(String userid) { this.userid = userid;}

    public String getView() { return view;}

    public void setView(String view) { this.view = view;}

    public String getDescribes() { return describes;}

    public void setDescribes(String describes) { this.describes = describes;}

    public String getIcon() { return icon;}

    public void setIcon(String icon) { this.icon = icon;}

    public String getLive_status() { return live_status;}

    public void setLive_status(String live_status) { this.live_status = live_status;}

    public String getPlay_address() { return play_address;}

    public void setPlay_address(String play_address) { this.play_address = play_address;}

    public String getUsername() { return username;}

    public void setUsername(String username) { this.username = username;}

    public List<PhotoInfoBean> getPicture() {
        return picture;
    }

    public void setPicture(List<PhotoInfoBean> picture) {
        this.picture = picture;
    }

    public int getIs_purchase() {
        return is_purchase;
    }

    public void setIs_purchase(int is_purchase) {
        this.is_purchase = is_purchase;
    }

    public PhotoInfoBean getVedio() {
        return vedio;
    }

    public void setVedio(PhotoInfoBean vedio) {
        this.vedio = vedio;
    }

    public int getPurchase() {
        return purchase;
    }

    public void setPurchase(int purchase) {
        this.purchase = purchase;
    }
}
