package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.PhotoAdapter;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.listener.RecyclerItemClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;

import java.io.File;
import java.util.ArrayList;

import me.iwf.photopicker.PhotoPicker;
import me.iwf.photopicker.PhotoPreview;

/**
 * 发布动态界面
 * Created by Administrator on 2016/11/23.
 */
public class ReleaseDynamicActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mReleaseDynamic;
    private RecyclerView mRecyclerView;
    private ImageView mAddPhotos;
//    private YNGridView gridview;
//    private NinePicturesAdapter ninePicturesAdapter;
    private PhotoAdapter photoAdapter;
    private ArrayList<String> selectedPhotos = new ArrayList<>();

    private YNCommonDialog dialog;
    private TextView txtCancel;
    private TextView txtSend;

    private File[] files = null;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.RELEASE_DYNAMIC_FLAG:
                    System.out.print(msg.obj + "");
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj + "", BaseBean.class);
                        if (bean.getCode() == 26)
                        {
                            YNLogUtil.i("cdy", msg.obj.toString());
//                            DynamicBean item = new DynamicBean();
//                            item.setId(String.valueOf(211));
//                            item.setUser(AccountUtils.getAccountBean());
//                            item.setContent(mReleaseDynamic.getText().toString());
//                            item.setCreateTime(DateUtil.getNowDate());
//                            item.setComments(createCommentItemList());
//                            item.setThumbs(createThumbItemList());
//                            item.setPhotos(createPhotos());
//                            Intent intent = new Intent();
//                            intent.putExtra("bean",item);
//                            setResult(10,intent);
                            finish();
                        }

                        YNToastMaster.showToast(ReleaseDynamicActivity.this, bean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(ReleaseDynamicActivity.this, getString(R.string.request_fail));
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_release_dynamic);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        mReleaseDynamic = (EditText) findViewById(R.id.et_release_dynamic);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mAddPhotos = (ImageView) findViewById(R.id.iv_add_photos);
//        gridview = (YNGridView) findViewById(R.id.gridview);
        txtCancel = (TextView) findViewById(R.id.txtCancel);
        txtSend = (TextView) findViewById(R.id.txtSend);
    }

    @Override
    protected void addEvent()
    {
        txtCancel.setOnClickListener(this);
        txtSend.setOnClickListener(this);
        mAddPhotos.setOnClickListener(this);

        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener()
        {
            @Override
            public void onItemClick(View view, int position)
            {
                PhotoPreview.builder()
                        .setPhotos(selectedPhotos)
                        .setCurrentItem(position)
                        .start(ReleaseDynamicActivity.this);
            }
        }));
    }

    @Override
    protected void settingDo()
    {
        photoAdapter = new PhotoAdapter(this, selectedPhotos);

        mRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(4, OrientationHelper.VERTICAL));
        mRecyclerView.setAdapter(photoAdapter);
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && (requestCode == PhotoPicker.REQUEST_CODE || requestCode == PhotoPreview.REQUEST_CODE))
        {

            ArrayList<String> photos = null;
            if (data != null)
            {
                photos = data.getStringArrayListExtra(PhotoPicker.KEY_SELECTED_PHOTOS);
                YNLogUtil.i("cdy", photos.size() + "");
            }
            selectedPhotos.clear();

            if (photos != null)
            {
                selectedPhotos.addAll(photos);
            }

            photoAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {

        }
        else
        {
            Toast.makeText(this, "No read storage permission! Cannot perform the action.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean shouldShowRequestPermissionRationale(@NonNull String permission)
    {
        // No need to explain to user as it is obvious
        return false;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.txtCancel:
                if (TextUtils.isEmpty(mReleaseDynamic.getText().toString().trim()) && selectedPhotos.size() <= 0)
                {
                    finish();
                }
                else
                {
                    dialog = new YNCommonDialog(this, R.style.transparentFrameWindowStyle, getString(R.string.give_up_edit_notice), getString(R.string.give_up), getString(R.string.save), false, new YNCommonDialog.CustomDialogListener() {
                        @Override
                        public void OnClick(View view)
                        {
                            switch (view.getId())
                            {
                                case R.id.btnCancel:
                                    dialog.dismiss();
                                    finish();
                                    break;

                                case R.id.btnConfirm:
                                    DynamicBean dynamicBean = new DynamicBean();
                                    String content = "";
                                    String[] pictures = null;
                                    if (TextUtils.isEmpty(mReleaseDynamic.getText().toString()));
                                    else
                                        content = mReleaseDynamic.getText().toString();
                                    dynamicBean.setContent(content);
                                    if (selectedPhotos.size() > 0)
                                    {
                                        pictures = new String[selectedPhotos.size()];
                                        for (int i = 0; i < selectedPhotos.size(); i++)
                                        {
                                            pictures[i] = new String(selectedPhotos.get(i));
                                        }
                                        YNLogUtil.i("selectedPhotos", selectedPhotos.toString());
                                    }

//                                    dynamicBean.setPicture(pictures);
                                    AccountUtils.savaDynamicContent(dynamicBean);
                                    dialog.dismiss();
                                    break;
                            }
                        }
                    });
                    dialog.show();
                }
                break;

            case R.id.txtSend:
                if (TextUtils.isEmpty(mReleaseDynamic.getText().toString().trim()) && selectedPhotos.size() <= 0)
                {
                    YNToastMaster.makeText(this, "发布内容不能为空!", Toast.LENGTH_SHORT).show();
                    return;
                }

                String filePath;
                final UserInfoBean user = AccountUtils.getAccountBean();
                if (selectedPhotos.size() > 0)
                {
                    files = new File[selectedPhotos.size()];
                    for (int i = 0; i < selectedPhotos.size(); i++)
                    {
                        BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(selectedPhotos.get(i));
                        int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
                        int imgMax = Math.max(options.outWidth, options.outHeight);
                        int inSimpleSize = 1;
                        if (screenMax <= imgMax)
                        {
                            inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
                        }
                        filePath = YNBitMapUtil.compressBitmap(context, selectedPhotos.get(i), Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                        files[i] = new File(filePath);
                    }
                    YNLogUtil.i("selectedPhotos", selectedPhotos.toString());
                }

                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().releaseDynamic(ReleaseDynamicActivity.this, YNCommonConfig.RELEASE_DYNAMIC_URL, "Android", user.getId(), mReleaseDynamic.getText().toString().trim(), files, mHandler, YNCommonConfig.RELEASE_DYNAMIC_FLAG, true);
                    }
                }, 1000);

                break;

            case R.id.iv_add_photos:
                PhotoPicker.builder()
                        .setPhotoCount(9)
                        .setShowCamera(true)
                        .setSelected(selectedPhotos)
                        .start(this);
                break;
        }
    }
}

