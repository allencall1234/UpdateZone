package com.yeneikeji.ynzhibo.utils;

import android.app.Activity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/7/19.
 */

public class ActivityCollector {

    static List<Activity> mActivities = new ArrayList<>();

    public static void addActivity(Activity activity){
        mActivities.add(activity);
    }

    public static void removeActivity(Activity activity){
        mActivities.remove(activity);
    }

    public static void finishAllActivity(){
        for (Activity activity : mActivities){
            if(!activity.isFinishing()){
                activity.finish();
            }
        }
    }
}
