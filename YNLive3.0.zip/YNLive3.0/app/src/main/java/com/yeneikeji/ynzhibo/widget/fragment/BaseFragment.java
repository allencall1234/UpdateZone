package com.yeneikeji.ynzhibo.widget.fragment;

import android.os.Bundle;
import android.view.View;

import com.yeneikeji.ynzhibo.utils.AutoUtils;

import butterknife.ButterKnife;

/**
 * Created by Administrator on 2017/2/27.
 */
public abstract class BaseFragment extends LazyFragment
{
    @Override
    protected void onCreateViewLazy(Bundle savedInstanceState)
    {
        super.onCreateViewLazy(savedInstanceState);
        setContentView(getLayout());
        ButterKnife.bind(this, getContentView());
        initView();
        loadData();
    }

    protected abstract void initView();
    protected abstract int getLayout();
    protected abstract void loadData();
}
