package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * Created by Administrator on 2017/6/12.
 */

public class LiveReportedBean {

    private int code;
    private String   info;
    private DataBean data;

    public int getCode() { return code;}

    public void setCode(int code) { this.code = code;}

    public String getInfo() { return info;}

    public void setInfo(String info) { this.info = info;}

    public DataBean getData() { return data;}

    public void setData(DataBean data) { this.data = data;}

    public static class DataBean {
        private CurrentBean current;
        private BeforeBean before;

        public CurrentBean getCurrent() { return current;}

        public void setCurrent(CurrentBean current) { this.current = current;}

        public BeforeBean getBefore() { return before;}

        public void setBefore(BeforeBean before) { this.before = before;}

        public static class CurrentBean {
            private int num;
            private List<Current1Bean> current1;

            public int getNum() { return num;}

            public void setNum(int num) { this.num = num;}

            public List<Current1Bean> getCurrent1() { return current1;}

            public void setCurrent1(List<Current1Bean> current1) { this.current1 = current1;}

            public static class Current1Bean {


                private String id;
                private String myselfId;
                private String userid;
                private String content;
                private Object img;
                private String phone;
                private String time;

                public String getId() { return id;}

                public void setId(String id) { this.id = id;}

                public String getMyselfId() { return myselfId;}

                public void setMyselfId(String myselfId) { this.myselfId = myselfId;}

                public String getUserid() { return userid;}

                public void setUserid(String userid) { this.userid = userid;}

                public String getContent() { return content;}

                public void setContent(String content) { this.content = content;}

                public Object getImg() { return img;}

                public void setImg(Object img) { this.img = img;}

                public String getPhone() { return phone;}

                public void setPhone(String phone) { this.phone = phone;}

                public String getTime() { return time;}

                public void setTime(String time) { this.time = time;}
            }
        }

        public static class BeforeBean {
            private int                                       num;
            private List<CurrentBean.Current1Bean> before1;

            public int getNum() { return num;}

            public void setNum(int num) { this.num = num;}

            public List<CurrentBean.Current1Bean> getBefore1() { return before1;}

            public void setBefore1(List<CurrentBean.Current1Bean> before1) { this.before1 = before1;}

            public static class Before1Bean {

                private String id;
                private String myselfId;
                private String userid;
                private String content;
                private Object img;
                private String phone;
                private String time;

                public String getId() { return id;}

                public void setId(String id) { this.id = id;}

                public String getMyselfId() { return myselfId;}

                public void setMyselfId(String myselfId) { this.myselfId = myselfId;}

                public String getUserid() { return userid;}

                public void setUserid(String userid) { this.userid = userid;}

                public String getContent() { return content;}

                public void setContent(String content) { this.content = content;}

                public Object getImg() { return img;}

                public void setImg(Object img) { this.img = img;}

                public String getPhone() { return phone;}

                public void setPhone(String phone) { this.phone = phone;}

                public String getTime() { return time;}

                public void setTime(String time) { this.time = time;}
            }
        }

    }
}
