package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.yeneikeji.ynzhibo.R;

/**
 * 直播间中金币加减按钮
 * Created by Administrator on 2017/6/15.
 */
public class AddMinusView extends LinearLayout implements View.OnClickListener, TextWatcher
{
    private EditText mETRewardNum;
//    private LinearLayout mLLAdd;
//    private LinearLayout mLLMinus;
//    private ImageButton mIBAdd;
//    private ImageButton mIBMinus;
    private Button mBtnAdd;
    private Button mBtnMinus;

    private int rewardCoin = 1; // 打赏金币数量
    private int rewardMaxCoin = 1;// 打赏最大金额

    private OnRewardNumChangeListener mListener;

    public AddMinusView(Context context)
    {
        this(context, null);
    }

    public AddMinusView(Context context, AttributeSet attrs)
    {
        super(context, attrs);

        LayoutInflater.from(context).inflate(R.layout.layout_add_minus, this);
        mETRewardNum = (EditText) findViewById(R.id.et_reward_num);
        mBtnAdd = (Button) findViewById(R.id.btn_add);
        mBtnMinus = (Button) findViewById(R.id.btn_minus);
//        mLLAdd = (LinearLayout) findViewById(R.id.ll_add);
//        mLLMinus = (LinearLayout) findViewById(R.id.ll_minus);
//        mIBAdd = (ImageButton) findViewById(R.id.ib_add);
//        mIBMinus = (ImageButton) findViewById(R.id.ib_minus);

//        mIBAdd.setOnClickListener(this);
//        mIBMinus.setOnClickListener(this);
        mBtnAdd.setOnClickListener(this);
        mBtnMinus.setOnClickListener(this);
//        mLLAdd.setOnClickListener(this);
//        mLLMinus.setOnClickListener(this);
        mETRewardNum.addTextChangedListener(this);

        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attrs, R.styleable.AmountView);
//        int btnWidth = obtainStyledAttributes.getDimensionPixelSize(R.styleable.AmountView_btnWidth, 15);
//        int etWidth = obtainStyledAttributes.getDimensionPixelSize(R.styleable.AmountView_tvWidth, 50);
        int etTextSize = obtainStyledAttributes.getDimensionPixelSize(R.styleable.AmountView_tvTextSize, 0);
        obtainStyledAttributes.recycle();

//        LayoutParams btnParams = new LayoutParams(btnWidth, LayoutParams.MATCH_PARENT);
//        mIBAdd.setLayoutParams(btnParams);
//        mIBMinus.setLayoutParams(btnParams);
//
//        LayoutParams textParams = new LayoutParams(etWidth, LayoutParams.MATCH_PARENT);
//        mETRewardNum.setLayoutParams(textParams);
        if (etTextSize != 0) {
            mETRewardNum.setTextSize(etTextSize);
        }
    }

    public void setRewardMaxCoin(int rewardMaxCoin)
    {
        this.rewardMaxCoin = rewardMaxCoin;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
         /*   case R.id.ll_add:
                rewardCoin++;
                mETRewardNum.setText(rewardCoin + "");
                break;

            case R.id.ll_minus:
                if (rewardCoin > 0)
                {
                    rewardCoin--;
                    mETRewardNum.setText(rewardCoin + "");
                }
                break;*/

            case R.id.btn_add:
                if (rewardCoin < rewardMaxCoin)
                {
                    rewardCoin++;
                    mETRewardNum.setText(rewardCoin + "");
                }
                break;

            case R.id.btn_minus:
                if (rewardCoin > 0)
                {
                    rewardCoin--;
                    mETRewardNum.setText(rewardCoin + "");
                }
                break;
        }

        mETRewardNum.clearFocus();

        if (mListener != null) {
            mListener.onRewardNumChange(this, rewardCoin);
        }
    }

    public void setOnAmountChangeListener(OnRewardNumChangeListener onRewardNumChangeListener)
    {
        this.mListener = onRewardNumChangeListener;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s)
    {
        if (s.toString().isEmpty())
            return;
        rewardCoin = Integer.valueOf(s.toString());
//        if (rewardCoin > rewardMaxCoin) {
//            mETRewardNum.setText(rewardCoin + "");
//            return;
//        }

        if (mListener != null) {
            mListener.onRewardNumChange(this, rewardCoin);
        }
    }

    public interface OnRewardNumChangeListener
    {
        void onRewardNumChange(View view, int rewardNum);
    }
}
