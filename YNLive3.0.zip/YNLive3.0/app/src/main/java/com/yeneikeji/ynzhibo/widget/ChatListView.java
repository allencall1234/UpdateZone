package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

public class ChatListView extends ListView {

    public ChatListView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }
}
