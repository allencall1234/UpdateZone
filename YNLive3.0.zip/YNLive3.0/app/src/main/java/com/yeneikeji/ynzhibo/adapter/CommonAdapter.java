package com.yeneikeji.ynzhibo.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.yeneikeji.ynzhibo.interfaces.IListViewItemListener;

import java.util.List;

/**
 * 自定义BaseAdapter多用适配器
 */
public abstract class CommonAdapter<T> extends BaseAdapter {

	private LayoutInflater mInflater;
	private Context mContext;
	private List<T> mList;

	private final int mItemLayoutId;

	protected IListViewItemListener itemListener;

	public CommonAdapter(Context context, List<T> list, int itemLayoutId)
	{
		super();
		mContext = context;
		mList = list;
		mInflater = LayoutInflater.from(mContext);
		mItemLayoutId = itemLayoutId;
	}

	public List<T> getDatas() {
		return mList;
	}

	public void setDatas(List<T> datas) {
		this.mList = datas;
	}
	
	/**
	 * 当ListView数据发生变化时,调用此方法来更新ListView
	 * @param list
	 */
	public void updateListView(List<T> list){
		mList = list;
		notifyDataSetChanged();
	}

	public void setItemListener(IListViewItemListener listener){
		this.itemListener = listener;
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final CommonViewHolder viewHolder = getViewHolder(position, convertView,
				parent);
		convert(viewHolder, (T) getItem(position));
		return viewHolder.getConvertView();
	}

	public abstract void convert(CommonViewHolder viewHolder, T item);

	private CommonViewHolder getViewHolder(int position, View convertView,
										   ViewGroup parent) {

		return CommonViewHolder.get(mContext, convertView, parent, mItemLayoutId,
				position);
	}
}
