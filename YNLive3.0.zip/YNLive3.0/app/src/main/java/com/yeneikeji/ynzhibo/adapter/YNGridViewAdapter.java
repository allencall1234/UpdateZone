package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IOnCheckedChangeListener;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.widget.CustomShapeImageView;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * 直播房间显示适配器
 * Created by Administrator on 2016/8/18.
 */
public class YNGridViewAdapter extends BaseAdapter
{
    private List<LiveRoomBean> liveRoomList;
    private Context mContext;

    private IOnCheckedChangeListener listener;
    // 用来控制CheckBox的选中状况
    private static HashMap<Integer, Boolean> isSelected;
    private static boolean isShow = true;
    private boolean flag;
    private int clickTemp = -1;

    public YNGridViewAdapter(Context context, List<LiveRoomBean> liveRoomList)
    {
        this.mContext = context;
        this.liveRoomList = liveRoomList;

        Collections.sort(liveRoomList, new Comparator<LiveRoomBean>(){

            /*
             * int compare(LiveRoomBean liveRoom1, LiveRoomBean liveRoom2) 返回一个基本类型的整型，
             * 返回负数表示：liveRoom1小于liveRoom2，
             * 返回0 表示：liveRoom1和liveRoom2相等，
             * 返回正数表示：liveRoom1大于liveRoom2。
             */
            public int compare(LiveRoomBean liveRoom1, LiveRoomBean liveRoom2) {

                if(liveRoom1.getLiving() < liveRoom2.getLiving())
                {
                    return 1;
                }
                if(liveRoom1.getLiving() == liveRoom2.getLiving())
                {
                    return 0;
                }
                return -1;
            }
        });
    }

    public YNGridViewAdapter(Context context, List<LiveRoomBean> liveRoomList, boolean flag)
    {
        this.mContext = context;
        this.liveRoomList = liveRoomList;
        isSelected = new HashMap<Integer, Boolean>();
        this.listener = (IOnCheckedChangeListener) context;
        this.flag = flag;
    }

    // 初始化isSelected的数据
    public void initData(List<LiveRoomBean> liveRoomList)
    {
        this.liveRoomList = liveRoomList;
        isSelected = new HashMap<Integer, Boolean>();
        for (int i = 0; i < liveRoomList.size(); i++)
        {
            getIsSelected().put(i, false);
        }
        notifyDataSetChanged();
    }

    public static HashMap<Integer, Boolean> getIsSelected() {
        return isSelected;
    }

    public static void setIsSelected(HashMap<Integer, Boolean> isSelected) {
        YNGridViewAdapter.isSelected = isSelected;
    }

    public static boolean isShow() {
        return isShow;
    }

    public static void setIsShow(boolean isShow) {
        YNGridViewAdapter.isShow = isShow;
    }

    @Override
    public int getCount() {
        return liveRoomList.size();
    }

    @Override
    public Object getItem(int i) {
        return liveRoomList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup)
    {
        LiveRoomBean liveRoomBean = liveRoomList.get(i);
        final ViewHolder holder;
        if (view == null)
        {
            view = LayoutInflater.from(mContext).inflate(R.layout.recommented_grideview_item, null);
//            AutoUtils.auto(view);
            holder = new ViewHolder();
            holder.iv_bgImg = (CustomShapeImageView) view.findViewById(R.id.iv_img);
            holder.tv_live_type = (TextView) view.findViewById(R.id.tv_live_type);
            holder.tv_areasOfExpertise = (TextView) view.findViewById(R.id.tv_areas_of_expertise);
            holder.tv_uName = (TextView) view.findViewById(R.id.tv_user_name);
            holder.tv_watchNumber = (TextView) view.findViewById(R.id.tv_watch_number);
            holder.mCBChoose = (CheckBox) view.findViewById(R.id.cb_choose);
            holder.iv_headImg = (ImageView) view.findViewById(R.id.iv_head);
            holder.iv_sex = (ImageView) view.findViewById(R.id.iv_sex);
            holder.iv_living_state = (ImageView) view.findViewById(R.id.iv_living_state);

            view.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) view.getTag();
        }

        holder.mCBChoose.setTag(i);

        if (flag)
        {
            if (isShow)
            {
                holder.mCBChoose.setVisibility(View.VISIBLE);
                // 根据isSelected来设置checkbox的选中状况
                holder.mCBChoose.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
                {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked)
                    {
                        isSelected.put(i, isChecked);
                        listener.checkedChange(isSelected);
                    }
                });
            }
            else
            {
                holder.mCBChoose.setVisibility(View.GONE);
            }

            holder.mCBChoose.setChecked(getIsSelected().get(i));
        }

        YNImageLoaderUtil.setImageWithErrorImg(mContext, holder.iv_bgImg, R.drawable.loading_cover, R.drawable.loading_cover, liveRoomBean.getPicture());
        YNImageLoaderUtil.setImage(mContext, holder.iv_headImg, liveRoomBean.getIcon());
        holder.tv_uName.setText(liveRoomBean.getUsername());
        holder.tv_watchNumber.setText(liveRoomBean.getLiveCount() + "");
        holder.tv_areasOfExpertise.setText(liveRoomBean.getTitle());
        if (!TextUtils.isEmpty(liveRoomBean.getTag2()))
        {
            holder.tv_live_type.setVisibility(View.VISIBLE);
            holder.tv_live_type.setText(liveRoomBean.getTag2());
        }
        else
        {
            holder.tv_live_type.setVisibility(View.GONE);
        }
        holder.iv_sex.setImageResource(liveRoomBean.getSex() == 2 ? R.drawable.icon_boy : R.drawable.icon_girl);

        if (liveRoomBean.getLiving() == 1)
        {
            if (liveRoomBean.getLive_status() == 2)
            {
                holder.iv_living_state.setBackgroundResource(R.drawable.icon_lable_pay);
            }
            if (liveRoomBean.getLock() == 1)
            {
                holder.iv_living_state.setBackgroundResource(R.drawable.icon_lable_encrypt);
            }
            if (liveRoomBean.getLive_status() != 2 && liveRoomBean.getLock() != 1)
            {
                holder.iv_living_state.setBackgroundResource(R.drawable.icon_lable_live);
            }
        }
        else
        {
            holder.iv_living_state.setBackgroundResource(R.drawable.icon_lable_rest);
        }

        return view;
    }

    /**
     * 判断是否所有的被选中
     * @return	true所有条目全部被选中
     * 			false还有条目没有被选中
     */
/*    private boolean isAllSelected()
    {
        boolean flag = true;
        for(int i=0; i<userList.size(); i++)
        {
            if(!getIsSelected().get(i))
            {
                flag = false;
                break;
            }
        }
        return flag;
    }*/

    class ViewHolder
    {
        private CustomShapeImageView iv_bgImg;
        private ImageView iv_headImg;
        private ImageView iv_sex;
        private ImageView iv_living_state;
        private TextView tv_live_type;
        private TextView tv_areasOfExpertise;
        private TextView tv_uName;
        private TextView tv_watchNumber;
        public CheckBox mCBChoose;//  是否选中
    }
}
