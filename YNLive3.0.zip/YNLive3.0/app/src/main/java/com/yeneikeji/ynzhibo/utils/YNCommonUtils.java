package com.yeneikeji.ynzhibo.utils;

import android.app.AppOpsManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.umeng.socialize.utils.Log;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 公共工具类
 * Created by Administrator on 2016/8/4.
 */
public class YNCommonUtils
{
    private static final String TAG = "CommonUtils";

    // 用于匹配手机号码
    private final static String REGEX_MOBILEPHONE = "^0?1[34578]\\d{9}$";

    // 用于匹配固定电话号码
    private final static String REGEX_FIXEDPHONE = "^(010|02\\d|0[3-9]\\d{2})?\\d{6,8}$";

    // 用于获取固定电话中的区号
    private final static String REGEX_ZIPCODE = "^(010|02\\d|0[3-9]\\d{2})\\d{6,8}$";

    /**
     * 判断是否为合法的json
     *
     * @param jsonContent 需判断的字串
     */
    public static boolean isJsonFormat(String jsonContent) {
        try {
            new JsonParser().parse(jsonContent);
            return true;
        } catch (JsonParseException e) {
            return false;
        }
    }

    /**
     * 获取软件版本
     * @param context
     * @return
     */
    public static String softVersion(Context context) {
        PackageInfo info = null;
        try {
            info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return info.versionName;
    }

    // 发短信
    public static void sendMsg(Context context, String phone) {
        String str = "smsto:" + phone;
        Uri uri = Uri.parse(str);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", "");
        context.startActivity(intent);

    }

    /**
     * 检测Sdcard是否存在
     * @return
     */
    public static boolean isExitsSdcard() {
        return android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
    }

    /**
     * 发送广播
     * @param context
     * @param action
     */
    public static void sendBroadcast(Context context, String action)
    {
        Intent intent = new Intent(action);
        context.sendBroadcast(intent);
    }

    /**
     * 发送带参数的广播
     * @param context
     * @param action
     * @param map
     */
    public static void sendBroadcast(Context context, String action, HashMap<String, String> map) {
        Object[] obj = map.keySet().toArray();

        Intent intent = new Intent(action);
        if (map.size() > 0) {
            for (int i = 0; i < map.size(); i++) {
                intent.putExtra(obj[i].toString(), map.get(obj[i].toString()));
            }
        }
        context.sendBroadcast(intent);
    }

    /**
     * 设置webview
     * @param view
     */
    public static void SetWebview(WebView view) {
        WebSettings webSettings = view.getSettings();
        webSettings.setJavaScriptEnabled(true); // 支持js
        webSettings.setUseWideViewPort(false); // 将图片调整到适合webview的大小
        webSettings.setSupportZoom(true); // 支持缩放
        webSettings.supportMultipleWindows(); // 多窗口
        webSettings.setAppCacheEnabled(false);// 设置不进行缓存
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 关闭webview中缓存
        webSettings.setAllowFileAccess(true); // 设置可以访问文件
        webSettings.setNeedInitialFocus(true); // 当webview调用requestFocus时为webview设置节点
        webSettings.setBuiltInZoomControls(true); // 设置支持缩放
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true); // 支持通过JS打开新窗口
        webSettings.setLoadWithOverviewMode(true); // 缩放至屏幕的大小
        webSettings.setLoadsImagesAutomatically(true); // 支持自动加载图片
    }

    /**
     * 手机号
     */
    public static boolean isCellPhone(String number) {
        Pattern patter = Pattern.compile(REGEX_MOBILEPHONE);
        Matcher match = patter.matcher(number);
        return match.matches();
    }

    /**
     * 固定电话
     */
    public static boolean isFixedPhone(String number) {
        Pattern pattern = Pattern.compile(REGEX_FIXEDPHONE);
        Matcher match = pattern.matcher(number);
        return match.matches();
    }

    /**
     * 判断是否是email
     * @param email
     * @return
     */
    public static boolean isEmail(String email) {
        if (null == email || "".equals(email))
            return false;
        Pattern p = Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");// 复杂匹配
        Matcher m = p.matcher(email);
        return m.matches();
    }

    /**
     *  将手机号中间四位替换为*号
     * @param phoneNumber
     * @return
     */
    public static String hidePhoneCenterNumber(String phoneNumber)
    {
        //这里*只要一个，因为会替代多次，每次一个
         return phoneNumber.replaceAll("(?<=[\\d]{3})\\d(?=[\\d]{4})", "*");
    }

    /**
     *  将身份证中间五位替换为*号
     * @param idNumber
     * @return
     */
    public static String hideIDCenterNumber(String idNumber)
    {
        //这里*只要一个，因为会替代多次，每次一个
        return idNumber.replaceAll("(?<=[\\d]{6})\\d(?=[\\d]{5})", "*");
    }

    /**
     *  将姓名前几位替换为*号只留最后一个字
     * @param name
     * @return
     */
    public static String hideName(String name){
        int len = name.length();
        StringBuffer buf = new StringBuffer();
        for (int i = 0 ; i < len-1; i++) {
            buf.append("*");
        }
        buf.append(name.substring(len-1));
        return buf.toString();
    }

    /**
     * 我国当前的身份证号分为三种： 一、15位身份证号 二、18位身份证号（前17位位数字，最后一位为字母x） 三、18为身份证号（18位都是数字）
     * 验证身份证号是否符合规则
     *
     * @param text
     *            身份证号
     * @return
     */
    public static boolean personIdValidation(String text) {
        String regx = "[0-9]{17}x";
        String reg1 = "[0-9]{15}";
        String regex = "[0-9]{18}";
        return text.matches(regx) || text.matches(reg1) || text.matches(regex);
    }

    /**
     * 判断是否为汉字
     * @param text
     * @return
     */
    public static boolean isChinese(String text)
    {
//        Pattern pa = Pattern.compile("[\u4e00-\u9fa5]");
        Pattern pa = Pattern.compile("^[\\u4e00-\\u9fa5]*$");
        Matcher matcher = pa.matcher(text);
        return  matcher.matches();
    }

    /**
     * 判断是否为数字
     * @param text
     * @return
     */
    public static boolean isNumber(String text)
    {
        Pattern p = Pattern.compile("[0-9]*");
        Matcher matcher = p.matcher(text);
        return  matcher.matches();
    }

    /**
     * 拼接字符串
     * @param words
     * @return
     */
    public static String splitString (String[] words)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < words.length; i++)
        {
            if(i != 0)
            {
                sb.append("、");
            }
            sb.append(words[i]);
        }
        return sb.toString();
    }

    /**
     * 显示输入法
     * @param context
     * @param view
     */
    public static void showSoftInput(Context context, View view)
    {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        imm.showSoftInput(view, InputMethodManager.SHOW_FORCED);
    }

    /**
     * 隐藏输入法
     * @param context
     * @param view
     */
    public static void hideSoftInput(Context context, View view){
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0); //强制隐藏键盘
    }

    /**
     * 判断输入法的状态
     * @param context
     * @return
     */
    public static boolean isShowSoftInput(Context context)
    {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        //获取状态信息
        return imm.isActive();//true 打开
    }

    /**
     * 随机字母加数字
     * @return
     */
    public static String getRandomNumberAndLetter()
    {
        String[] beforeShuffle = new String[] { "1", "2", "3", "4", "5", "6", "7",
                "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
                "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
                "W", "X", "Y", "Z" };
        List list = Arrays.asList(beforeShuffle);
        Collections.shuffle(list);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++)
        {
            sb.append(list.get(i));
        }
        String afterShuffle = sb.toString();
        String result = afterShuffle.substring(4, 23);
        return result;
    }

    /**
     * 随机数字
     * @return
     */
    public static String getRandomNumber()
    {
        String[] beforeShuffle = new String[] { "1", "2", "3", "4", "5", "6", "7",
                "8", "9", "0" };
        List list = Arrays.asList(beforeShuffle);
        Collections.shuffle(list);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++)
        {
            sb.append(list.get(i));
        }
        String afterShuffle = sb.toString();
        String result = afterShuffle.substring(0, 10);
        return result;
    }

    /**
     * 随机数字(6)
     * @return
     */
    public static String getRandomSixNumber()
    {
        String[] beforeShuffle = new String[] { "1", "2", "3", "4", "5", "6", "7",
                "8", "9", "0" };
        List list = Arrays.asList(beforeShuffle);
        Collections.shuffle(list);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++)
        {
            sb.append(list.get(i));
        }
        String afterShuffle = sb.toString();
        String result = afterShuffle.substring(4, 10);
        return result;
    }

    // 获取串码流
    public static String interceptionString(String str)
    {
        String newStr = "";
        if (!TextUtils.isEmpty(str))
        {
            newStr = str.substring(YNCommonConfig.LIVE_ADDRESS_HEAD.length(), str.length());
        }
        return newStr;
    }

    // 获取FMS URL
    public static String interceptionLiveAddressString(String str)
    {
        String newStr = "";
        if (!TextUtils.isEmpty(str))
        {
            newStr = str.substring(0, YNCommonConfig.LIVE_ADDRESS_HEAD.length());
        }
        return newStr;
    }

    /**
     * 用时间戳生成照片名称
     * @return
     */
    public static String getPhotoFileName()
    {
         Date date = new Date(System.currentTimeMillis());
         SimpleDateFormat dateFormat = new SimpleDateFormat("'IMG'_yyyyMMdd_HHmmss");
         return dateFormat.format(date) + ".jpg";
    }

    public static boolean isNotificationEnabled(Context context) {

        String CHECK_OP_NO_THROW = "checkOpNoThrow";
        String OP_POST_NOTIFICATION = "OP_POST_NOTIFICATION";

        AppOpsManager mAppOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        ApplicationInfo appInfo = context.getApplicationInfo();
        String pkg = context.getApplicationContext().getPackageName();
        int uid = appInfo.uid;

        Class appOpsClass = null;
     /* Context.APP_OPS_MANAGER */
        try {
            appOpsClass = Class.forName(AppOpsManager.class.getName());
            Method checkOpNoThrowMethod = appOpsClass.getMethod(CHECK_OP_NO_THROW, Integer.TYPE, Integer.TYPE,
                    String.class);
            Field opPostNotificationValue = appOpsClass.getDeclaredField(OP_POST_NOTIFICATION);

            int value = (Integer) opPostNotificationValue.get(Integer.class);
            return ((Integer) checkOpNoThrowMethod.invoke(mAppOps, value, uid, pkg) == AppOpsManager.MODE_ALLOWED);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void safeShowDialog(Dialog var0)
    {
        try
        {
            if(var0 != null && !var0.isShowing())
            {
                var0.show();
            }
            else
            {
                var0.dismiss();
            }
        }
        catch (Exception var2) {
            Log.e("SocializeUtils", "dialog show error", var2);
        }

    }

    public static void safeCloseDialog(Dialog var0) {
        try {
            if(var0 != null && var0.isShowing()) {
                var0.dismiss();
                var0 = null;
            }
        } catch (Exception var2) {
            Log.e("SocializeUtils", "dialog dismiss error", var2);
        }
    }

    public static String interceptionMultichannelRoomPID(String str)
    {
        String newStr = "";
        int i;
        if (!TextUtils.isEmpty(str))
        {
            if (str.contains("-"))
            {
                i = str.indexOf("-");
                newStr = str.substring(i + 1, str.length());
            }
        }
        return newStr;
    }
}
