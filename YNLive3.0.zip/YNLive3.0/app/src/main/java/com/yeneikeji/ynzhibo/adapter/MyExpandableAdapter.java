package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.CurrentMonthTestBean;
import com.yeneikeji.ynzhibo.model.GiftBean;

import java.util.List;

/**
 * Created by Administrator on 2017/4/24.
 */

public class MyExpandableAdapter extends BaseExpandableListAdapter

{
    private List<CurrentMonthTestBean> mdatas;
    private Context                    mContext;

    public MyExpandableAdapter(Context context, List<CurrentMonthTestBean> datas){

        mContext = context;
        this.mdatas = datas;


    }


    @Override
    public int getGroupCount() {
        if(mdatas!=null) {
            return mdatas.size();
        }
        return 0;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if(mdatas.get(groupPosition).datas!=null) {
            return mdatas.get(groupPosition).datas.size();

        }
        return 0;
    }


    @Override
    public CurrentMonthTestBean getGroup(int groupPosition) {
        if (mdatas != null) {
            return mdatas.get(groupPosition);
        }
        return null;


    }

    @Override
    public GiftBean getChild(int groupPosition, int childPosition) {
        if(mdatas.get(groupPosition).datas!=null){
            return mdatas.get(groupPosition).datas.get(childPosition);

        }
        return null;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        View view = convertView;
        GroupHolder holder = null;
        if(view == null){
            holder = new GroupHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.expandlist_group, null);
            holder.groupName = (TextView)view.findViewById(R.id.tv_group_name);
            holder.arrow = (ImageView)view.findViewById(R.id.iv_arrow);
            view.setTag(holder);
        }else{
            holder = (GroupHolder)view.getTag();
        }

        //判断是否已经打开列表
        if(isExpanded){
            holder.arrow.setBackgroundResource(R.drawable.arrow_up);
        }else{
            holder.arrow.setBackgroundResource(R.drawable.arrow_down);
        }

        holder.groupName.setText(getGroup(groupPosition).name);

        return view;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        View view = convertView;
        ChildHolder holder = null;
        if(view == null){
            holder = new ChildHolder();
            view = LayoutInflater.from(mContext).inflate(R.layout.expandlist_item, null);
            holder.childName = (TextView)view.findViewById(R.id.tv_monthWealth_gift_incomName);
            holder.childTime = (TextView)view.findViewById(R.id.tv_monthWealth_gift_incomTime);
            holder.childContribution = (TextView)view.findViewById(R.id.tv_monthWealth_gift_incomContribution);
            //  holder.divider = view.findViewById(R.id.iv_divider);
            view.setTag(holder);
        }else{
            holder = (ChildHolder)view.getTag();
        }

       /* if(childPosition == 0){
            holder.divider.setVisibility(View.GONE);
        }*/

        //  holder.childTime.setText("2017年");
        GiftBean giftBean =getChild(groupPosition,childPosition);
        holder.childName.setText(giftBean.getGiftName());
        holder.childTime.setText(giftBean.getTime());
        holder.childContribution.setText(""+(giftBean.getPrice()));
        return view;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }



    class GroupHolder{
        public TextView groupName;
        public ImageView arrow;
    }

    class ChildHolder{
        public TextView childName;
        public TextView childTime;
        public TextView childContribution;

    }



}

