package com.yeneikeji.ynzhibo.adapter;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.umeng.socialize.utils.SocializeUtils;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.rongcloud.message.BaseMsgView;
import com.yeneikeji.ynzhibo.rongcloud.message.GiftMsgView;
import com.yeneikeji.ynzhibo.rongcloud.message.InfoMsgView;
import com.yeneikeji.ynzhibo.rongcloud.message.TextMsgView;
import com.yeneikeji.ynzhibo.rongcloud.message.UnknownMsgView;
import com.yeneikeji.ynzhibo.widget.InputPanel;
import com.yeneikeji.ynzhibo.widget.dialog.YNChatRoomAlertDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import io.rong.imlib.model.Conversation;
import io.rong.imlib.model.Message;
import io.rong.imlib.model.MessageContent;
import io.rong.imlib.model.UserInfo;

public class ChatListAdapter extends BaseAdapter
{
    private ArrayList<MessageContent> msgContentList;
    private ArrayList<Message> msgList;
//    private ChatRoomUserBean mySelfInfo;
    private CommonRecyclerViewAdapter<ChatRoomUserBean> mAdapter;
    private ChatRoomUserBean chatRoomUserBean;
    private ViewGroup buttonPanel;
    private InputPanel inputPanel;
    private UserInfo userInfo;
    private Context context;
    private TextView mTVUserName;
    private boolean processFlag = true; //默认可以点击
    private LiveRoomBean liveRoomBean;
    private UserStatusBean userStatusBean;
    private YNChatRoomAlertDialog chatRoomDialog;
    private long mLasttime = 0;
    private int reportContent;
    private boolean isLive = false;
    private String userId;
    private String roomId;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(android.os.Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                chatRoomUserBean = YNJsonUtil.JsonToBean(jsonObject.get("data").toString(), ChatRoomUserBean.class);
                                creatChatRoomDialog(chatRoomUserBean);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;

                case YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 200)
                            YNToastMaster.showToast(context, "禁言成功");
                        else
                            YNToastMaster.showToast(context, "禁言失败");
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 200)
                            YNToastMaster.showToast(context, "解禁成功");
                        else
                            YNToastMaster.showToast(context, "解禁失败");
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.REPORT_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.DELETE_ROOM_MANAGE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 54)
                        {
                            for (int i = 0; i < mAdapter.getList().size(); i++)
                            {
                                if (mAdapter.getList().get(i).getUserid().equals(chatRoomUserBean.getUserid()))
                                {
                                    mAdapter.getList().remove(i);
                                    break;
                                }
                            }
                            mAdapter.updateListView(mAdapter.getList());
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.ADD_ROOM_MANAGE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 52)
                        {
                            mAdapter.getList().add(chatRoomUserBean);
                            mAdapter.updateListView(mAdapter.getList());
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.USER_EXIT_WATCH_LIVE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

            }
            super.handleMessage(msg);
        }
    };

    public ChatListAdapter(Context context, LiveRoomBean liveRoomBean, CommonRecyclerViewAdapter<ChatRoomUserBean> mAdapter, ViewGroup buttonPanel, InputPanel inputPanel)
    {
        msgContentList = new ArrayList<>();
        msgList = new ArrayList<>();
        this.context = context;
        this.liveRoomBean = liveRoomBean;
        this.mAdapter = mAdapter;
        this.buttonPanel = buttonPanel;
        this.inputPanel = inputPanel;
    }

    public ChatListAdapter(Context context, UserStatusBean userStatusBean, CommonRecyclerViewAdapter<ChatRoomUserBean> mAdapter, boolean isLive)
    {
        msgContentList = new ArrayList<>();
        msgList = new ArrayList<>();
        this.context = context;
        this.userStatusBean = userStatusBean;
        this.mAdapter = mAdapter;
        this.isLive = isLive;
    }

    @Override
    public int getCount() {
        return msgContentList.size();
    }

//    public void setMySelfInfo(ChatRoomUserBean mySelfInfo)
//    {
//        this.mySelfInfo = mySelfInfo;
//        notifyDataSetChanged();
//    }

    @Override
    public Object getItem(int position) {
        return msgContentList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        BaseMsgView baseMsgView = (BaseMsgView) convertView;
        MessageContent msgContent = msgContentList.get(position);
        Class<? extends BaseMsgView> msgViewClass = LiveKit.getRegisterMessageView(msgContent.getClass());
        if (msgViewClass == null)
        {
            baseMsgView = new UnknownMsgView(parent.getContext());
        }
        else if (baseMsgView == null || baseMsgView.getClass() != msgViewClass)
        {
            try
            {
                baseMsgView = msgViewClass.getConstructor(Context.class).newInstance(parent.getContext());
            }
            catch (Exception e)
            {
                throw new RuntimeException("baseMsgView newInstance failed.");
            }
        }
        baseMsgView.setContent(msgContent);
        if (msgViewClass != null)
        {
            if (baseMsgView instanceof GiftMsgView)
            {
                mTVUserName = ((GiftMsgView) baseMsgView).username;
                onClickUserName(position);
            }
            if (baseMsgView instanceof TextMsgView)
            {
                mTVUserName = ((TextMsgView) baseMsgView).username;
                onClickUserName(position);
            }
            if (baseMsgView instanceof InfoMsgView)
            {
                mTVUserName = ((InfoMsgView) baseMsgView).username;
                onClickUserName(position);
            }
        }

        return baseMsgView;
    }

    private void onClickUserName(final int index)
    {
        mTVUserName.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                queryBeClickedUserInfo(index);
            }
        });
    }

    private void queryBeClickedUserInfo(final int index)
    {
            if (isLive)
            {
                userId = userStatusBean.getUserid();
                roomId = userStatusBean.getRoom_id();
            }
            else
            {
                if (AccountUtils.getLoginInfo())
                    userId = AccountUtils.getAccountBean().getId();

                roomId = liveRoomBean.getRoom_id();
            }

        if (processFlag)
        {
            setProcessFlag();
            if (getMsg().get(index).getConversationType() == Conversation.ConversationType.CHATROOM)
            {
//                if (!getMessage().get(index).getUserInfo().getUserId().equals(userId) && !(getMessage().get(index).getUserInfo().getUserId().equals(liveRoomBean.getUserid())))
//                {
                    userInfo = getMessage().get(index).getUserInfo();
                    // 查询被点击的用户信息
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getChatRoomUserInfo(context, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, roomId,
                                    userInfo.getUserId(), userId, handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                        }
                    }, 200);
//                }
            }
            new TimeThread().start();
        }
    }

    /** 创建聊天室弹出框 */
    private void creatChatRoomDialog(final ChatRoomUserBean chatRoomUserBean)
    {
//        boolean isAllGone = false;
//        boolean isManager = false;
//        boolean isLiveHost = false;
//        boolean loginIsLiveHost = false;
        boolean isAllGone = false;
        boolean isBeClickedManager = false;
        boolean isBeClickedHost = false;
        boolean isHost = false;
        boolean isManager = false;
        boolean showManagerCount = false;

        if (userInfo.getUserId().equals(userId))
            isAllGone = true;

        if (isLive)
        {
            isHost = true;
        }
        else
        {
            if (chatRoomUserBean.getIs_myselfHost() == 1)
                isHost = true;

            if (chatRoomUserBean.getIs_selfManage() == 1)
                isManager = true;

            // 判断被点击的人是不是主播
            if (userInfo.getUserId().equals(liveRoomBean.getUserid()))
                isBeClickedHost = true;

            if (chatRoomUserBean.getIs_manage() == 1)
                isBeClickedManager = true;

        }
        if (isHost && !isAllGone)
        {
            showManagerCount = true;
        }

        chatRoomDialog = new YNChatRoomAlertDialog.Builder(context)
                .setHeight(0.4f)
                .setWidth(0.8f)
                .setLiveHost(isHost)
                .setAllGone(isAllGone)
                .setRoomManager(isManager)
                .setBeClickedLiveHost(isBeClickedHost)
                .setBeClickedManager(isBeClickedManager)
                .setChatRoomUserBean(chatRoomUserBean)
                .setCanceledOnTouchOutside(false)
                .setShowManagerCount(showManagerCount)
                .setOnclickListener(new IDialogOnClickListener()
                {
                    @Override
                    public void clickTopLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_manage() == 1)
                        {
                            // 取消房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().deleteRoomManager(context, YNCommonConfig.DELETE_ROOM_MANAGE_URL, roomId, userInfo.getUserId(),
                                            handler, YNCommonConfig.DELETE_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 设置房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().addRoomManager(context, YNCommonConfig.ADD_ROOM_MANAGE_URL, roomId, userInfo.getUserId(),
                                            handler, YNCommonConfig.ADD_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickTopRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
//                        if (System.currentTimeMillis() - mLasttime < 700) {
//                            return;
//                        }
//                        mLasttime = System.currentTimeMillis();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog(userInfo.getUserId());
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_say() == 1)
                        {
                            // 删除禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomCancelGagUser(context, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_URL, roomId, userInfo.getUserId(),
                                            handler, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomGagUser(context, YNCommonConfig.GAG_CHAT_ROOM_USER_URL, roomId, userInfo.getUserId(),
                                            handler, YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view)
                    {
                        chatRoomDialog.dismiss();
//                        if (System.currentTimeMillis() - mLasttime < 700) {
//                            return;
//                        }
//                        mLasttime = System.currentTimeMillis();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog(userInfo.getUserId());
                    }
                }).build();
        chatRoomDialog.show();

    }

    /**
     * 创建举报弹出框
     */
    private void createReportDialog(final String userid)
    {
        View view = LayoutInflater.from(context).inflate(R.layout.report_dialog, null);
        Button mBtnReport1 = (Button) view.findViewById(R.id.btn_report1);
        Button mBtnReport2 = (Button) view.findViewById(R.id.btn_report2);
        Button mBtnReport3 = (Button) view.findViewById(R.id.btn_report3);
        Button mBtnReport4 = (Button) view.findViewById(R.id.btn_report4);
        Button mBtnReport5 = (Button) view.findViewById(R.id.btn_report5);
        Button mBtnCancel = (Button) view.findViewById(R.id.btn_cancel);
        final Dialog dialog = new Dialog(context, R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = ScreenSizeUtil.getScreenHigh(context);

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);

        mBtnCancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        mBtnReport1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(context, YNCommonConfig.REPORT_USER_URL, AccountUtils.getAccountBean().getId(), userid,
                                1, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(context, YNCommonConfig.REPORT_USER_URL, AccountUtils.getAccountBean().getId(), userid,
                                2, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(context, YNCommonConfig.REPORT_USER_URL, AccountUtils.getAccountBean().getId(), userid,
                                3, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(context, YNCommonConfig.REPORT_USER_URL, AccountUtils.getAccountBean().getId(), userid,
                                4, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(context, YNCommonConfig.REPORT_USER_URL, AccountUtils.getAccountBean().getId(), userid,
                                5, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });
        dialog.show();
    }

    /**
     * 设置按钮在短时间内被重复点击的有效标识（true表示点击有效，false表示点击无效）
     */
    private synchronized void setProcessFlag()
    {
        processFlag = false;
    }

    /**
     * 计时线程（防止在一定时间段内重复点击按钮）
     */
    private class TimeThread extends Thread
    {
        public void run()
        {
            try
            {
                sleep(2000);
                processFlag = true;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    public void addMessage(MessageContent msg) {
        msgContentList.add(msg);
    }

    public List<MessageContent> getMessage()
    {
        return msgContentList;
    }

    public void addMsg(Message msg) {
        msgList.add(msg);
    }

    public List<Message> getMsg()
    {
        return msgList;
    }

}
