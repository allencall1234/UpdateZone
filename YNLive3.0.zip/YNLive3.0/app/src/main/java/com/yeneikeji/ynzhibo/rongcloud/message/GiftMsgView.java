package com.yeneikeji.ynzhibo.rongcloud.message;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.rongcloud.EmojiManager;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

import io.rong.imlib.model.MessageContent;

public class GiftMsgView extends BaseMsgView
{

    public TextView username;
    private TextView content;

    public GiftMsgView(Context context)
    {
        super(context);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.msg_gift_view, this);
        username = (TextView) view.findViewById(R.id.username);
        content = (TextView) view.findViewById(R.id.content);
    }

    @Override
    public void setContent(MessageContent msgContent)
    {
        GiftMessage msg = (GiftMessage) msgContent;
        YNLogUtil.e("gift", msg.getExtra());
        YNLogUtil.e("gift", msg.getType());
        username.setText(msg.getUserInfo().getName() + ":");
        if ("0".equals(msg.getType()))
        {
            content.setText("送给主播" + EmojiManager.parse(msg.getContent(), content.getTextSize()));
        }
        if ("1".equals(msg.getType()))
        {
            content.setText("为主播点赞");
        }
    }

//    @Override
//    public void setOnClickListener(View view)
//    {
//        view.setOnClickListener(new OnClickListener()
//        {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
//
//    }

}
