package com.yeneikeji.ynzhibo.model;

import android.os.Parcel;

import org.json.JSONObject;

/**
 * 录制视频实体类
 * Created by Administrator on 2017/3/24.
 */
public class RecordVideoBean extends BaseBean
{
    private String mediaId;
    private String status;
    private String title;
    private String publishTime;
    private String createTime;
    private String playableUrlList;
    private String thumbnailList;
    private String room_id;
    private String push_address;
/*
* 新增字段
* */
    public String content;
    public String describe0;
    public String describe1;
    public String describe2;
    public String describe3;
    public String id;
    public String is_pass;
    public String kind;
    public String payCoin;
    public String picture0;
    public String picture1;
    public String picture2;
    public String purchase;
    public String smallpicture0;
    public String smallpicture1;
    public String smallpicture2;
    public String time;
    public int    type;
    public String userid;
    public String view;
    public String is_pay;
    public int is_purchase;
    private int    bad;
    private int good;
    private int is_comment;
    private int middle;
    public  float goodRat;
    private String audio;
    private String playTime;// 播放时长
    private String count;// 播放次数
    private int    all;
    private String icon;
    private String username;
    private String isExamed;//主要区分是否通过审核
    //新增描述字段
    public String describes;

    public String getDescribes() {
        return describes;
    }

    public void setDescribes(String describes) {
        this.describes = describes;
    }

    /*
    * 新增字段
    * */
    public int getBad() {
        return bad;
    }

    public void setBad(int bad) {
        this.bad = bad;
    }

    public int getGood() {
        return good;
    }

    public void setGood(int good) {
        this.good = good;
    }

    public int getIs_comment() {
        return is_comment;
    }

    public void setIs_comment(int is_comment) {
        this.is_comment = is_comment;
    }

    public int getMiddle() {
        return middle;
    }

    public void setMiddle(int middle) {
        this.middle = middle;
    }

    public float getGoodRat() {
        return goodRat;
    }

    public void setGoodRat(int goodRat) {
        this.goodRat = goodRat;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public String getPlayTime() {
        return playTime;
    }

    public void setPlayTime(String playTime) {
        this.playTime = playTime;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIsExamed() {
        return isExamed;
    }

    public void setIsExamed(String isExamed) {
        this.isExamed = isExamed;
    }


    public String getIs_pay() {
        return is_pay;
    }

    public void setIs_pay(String is_pay) {
        this.is_pay = is_pay;
    }

    public int getIs_purchase() {
        return is_purchase;
    }

    public void setIs_purchase(int is_purchase) {
        this.is_purchase = is_purchase;
    }


    public String getPush_address() {
        return push_address;
    }

    public void setPush_address(String push_address) {
        this.push_address = push_address;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDescribe0() {
        return describe0;
    }

    public void setDescribe0(String describe0) {
        this.describe0 = describe0;
    }

    public String getDescribe1() {
        return describe1;
    }

    public void setDescribe1(String describe1) {
        this.describe1 = describe1;
    }

    public String getDescribe2() {
        return describe2;
    }

    public void setDescribe2(String describe2) {
        this.describe2 = describe2;
    }

    public String getDescribe3() {
        return describe3;
    }

    public void setDescribe3(String describe3) {
        this.describe3 = describe3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIs_pass() {
        return is_pass;
    }

    public void setIs_pass(String is_pass) {
        this.is_pass = is_pass;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getPayCoin() {
        return payCoin;
    }

    public void setPayCoin(String payCoin) {
        this.payCoin = payCoin;
    }

    public String getPicture0() {
        return picture0;
    }

    public void setPicture0(String picture0) {
        this.picture0 = picture0;
    }

    public String getPicture1() {
        return picture1;
    }

    public void setPicture1(String picture1) {
        this.picture1 = picture1;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getPurchase() {
        return purchase;
    }

    public void setPurchase(String purchase) {
        this.purchase = purchase;
    }

    public String getSmallpicture0() {
        return smallpicture0;
    }

    public void setSmallpicture0(String smallpicture0) {
        this.smallpicture0 = smallpicture0;
    }

    public String getSmallpicture1() {
        return smallpicture1;
    }

    public void setSmallpicture1(String smallpicture1) {
        this.smallpicture1 = smallpicture1;
    }

    public String getSmallpicture2() {
        return smallpicture2;
    }

    public void setSmallpicture2(String smallpicture2) {
        this.smallpicture2 = smallpicture2;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }


    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPlayableUrlList() {
        return playableUrlList;
    }

    public void setPlayableUrlList(String playableUrlList) {
        this.playableUrlList = playableUrlList;
    }

    public String getThumbnailList() {
        return thumbnailList;
    }

    public void setThumbnailList(String thumbnailList) {
        this.thumbnailList = thumbnailList;
    }


    public String getpush_address() {
        return push_address;
    }
    public void setpush_address(String push_address) {
        this.push_address = push_address;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public String getRoom_id() {
        return room_id;
    }

    public RecordVideoBean(String mediaId, String status, String title, String publishTime, String createTime, String playableUrlList, String thumbnailList, String room_id,String push_address) {
        this.mediaId = mediaId;
        this.status = status;
        this.title = title;
        this.publishTime = publishTime;
        this.createTime = createTime;
        this.playableUrlList = playableUrlList;
        this.thumbnailList = thumbnailList;
        this.room_id = room_id;
        this.push_address=push_address;
    }

    protected RecordVideoBean(Parcel in) {
        mediaId = in.readString();
        status = in.readString();
        title = in.readString();
        publishTime = in.readString();
        createTime = in.readString();
        playableUrlList = in.readString();
        thumbnailList = in.readString();
        room_id = in.readString();
    }

   /* @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mediaId);
        dest.writeString(status);
        dest.writeString(title);
        dest.writeString(publishTime);
        dest.writeString(createTime);
        dest.writeString(playableUrlList);
        dest.writeString(thumbnailList);
        dest.writeString(room_id);
    }*/

    /**
     * 方便持久化
     * @return
     */
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("mediaId", mediaId);
            json.put("status", status);
            json.put("title", title);
            json.put("publishTime", publishTime);
            json.put("createTime", createTime);
            json.put("playableUrlList", playableUrlList);
            json.put("thumbnailList", thumbnailList);
            json.put("room_id", room_id);
            json.put("push_address", push_address);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }

    /**
     * 从持久化恢复
     * @param json
     * @return
     */
    public static RecordVideoBean fromJson(JSONObject json) {
        RecordVideoBean info = null;
        try
        {
            info = new RecordVideoBean(json.getString("mediaId"), json.getString("status"), json.getString("title"),
                    json.getString("publishTime"), json.getString("createTime"), json.getString("playableUrlList"),
                    json.getString("thumbnailList"), json.getString("room_id"),json.getString("push_address"));

            info.setMediaId(json.optString("mediaId", ""));
            info.setStatus(json.optString("status", ""));
            info.setTitle(json.optString("title", ""));
            info.setPublishTime(json.optString("publishTime", ""));
            info.setCreateTime(json.optString("createTime", ""));
            info.setPlayableUrlList(json.optString("playableUrlList", ""));
            info.setThumbnailList(json.optString("thumbnailList", ""));
            info.setRoom_id(json.optString("room_id", ""));
            info.setPublishTime(json.optString("push_address",""));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return info;
    }

    /*@Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RecordVideoBean> CREATOR = new Creator<RecordVideoBean>() {
        @Override
        public RecordVideoBean createFromParcel(Parcel in) {
            String title = in.readString();
            String url = in.readString();
            String imageUrl = in.readString();
            boolean[] boolArray = new boolean[1];
            in.readBooleanArray(boolArray);
//            RecordVideoBean p = new RecordVideoBean(title, url);
//            p.setImageUrl(imageUrl);
//            p.setCanDelete(boolArray[0]);
            return new RecordVideoBean(in);
        }

        @Override
        public RecordVideoBean[] newArray(int size) {
            return new RecordVideoBean[size];
        }
    };*/
}
