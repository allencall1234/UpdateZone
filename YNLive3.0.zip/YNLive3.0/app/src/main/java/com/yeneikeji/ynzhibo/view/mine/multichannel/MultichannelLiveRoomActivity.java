package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNMyListView;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 多通道直播房间界面(测试)子房间详情
 * Created by Administrator on 2017/7/28.
 */
public class MultichannelLiveRoomActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private LinearLayout mLLMemberList;
    private LinearLayout mLLPriorityList;
    private TextView mTVMemberTitle;
    private TextView mTVPriorityTitle;
    private YNMyListView mLVMember;
    private YNMyListView mLVPriority;

    private CommonAdapter mMemberAdapter;
    private CommonAdapter mPriorityAdapter;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {

            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichannel_live_room);
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.multichannel_room));

        mLLMemberList = (LinearLayout) findViewById(R.id.ll_member_list);
        mLLPriorityList = (LinearLayout) findViewById(R.id.ll_live_priority_list);
        mTVMemberTitle = (TextView) mLLMemberList.findViewById(R.id.tv_multichannel_title);
        mTVPriorityTitle = (TextView) mLLMemberList.findViewById(R.id.tv_multichannel_title);
        mLVMember = (YNMyListView) mLLMemberList.findViewById(R.id.lv_multichannel_room);
        mLVPriority = (YNMyListView) mLLMemberList.findViewById(R.id.lv_multichannel_room);

        mTVMemberTitle.setText("成员列表");
       // mTVPriorityTitle.setText("直播优先级");

    }
    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);

    }

    @Override
    protected void settingDo()
    {
        mMemberAdapter = new CommonAdapter<GiftBean>(this, DataUtils.getSubjectList(), R.layout.item_multichannel_room)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, GiftBean item)
            {

            }
        };

        mLVMember.setAdapter(mMemberAdapter);

        mPriorityAdapter = new CommonAdapter<GiftBean>(this, DataUtils.getSubjectList(), R.layout.item_multichannel_room)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, GiftBean item)
            {

            }
        };

        mLVPriority.setAdapter(mPriorityAdapter);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
        }
    }
}
