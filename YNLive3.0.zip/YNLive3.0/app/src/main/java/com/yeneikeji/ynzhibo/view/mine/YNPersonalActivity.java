package com.yeneikeji.ynzhibo.view.mine;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.FileUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import org.joda.time.DateTime;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

/**
 * 个人资料界面
 */
public class YNPersonalActivity
        extends YNBaseTopBarActivity
        implements CalendarDatePickerDialog.OnDateSetListener, View.OnClickListener
{
    private static final String TAG = "YNPersonalActivity";
    private TextView  txtSave;
    private TextView  txtDate;
    private ImageView imgHead, imgBack;
    // 用户昵称输入框
    private EditText edtNickName;
    // 用户特长描述输入框
    private EditText edtDescribe;

//    private AlertDialog              alertCache;
    private YNPayDialog alertDialog;
    private CalendarDatePickerDialog calendarDatePickerDialog;
    public static final String FRAG_TAG_DATE_PICKER = "fragment_date_picker_name";
    private RadioGroup  rgSex;
    private RadioButton rbBoy, rbGirl;
    private String headPicPath = " ";
    private File   imgFile     = null;
    private int    sex         = 0;
    // 获取保存的本地用户信息
    private PersonInfoBean localBean;
    private Uri            imageUri;
    private Dialog         mDialog;
    private File           mTmpFile;
    private  PersonInfoBean personInfoBean;
    private static final String EXTERNAL_STORAGE_PERMISSION = "android.permission.WRITE_EXTERNAL_STORAGE";

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case YNCommonConfig.EDIT_PERSONAL_INFO_FLAG:
                    if (msg.obj != null) {
                     YNLogUtil.e(TAG,"========msg.obj  == " + msg.obj);
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 9) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                 personInfoBean = YNJsonUtil.JsonToBean(jsonObject.getString("data").toString(), PersonInfoBean.class);
                                saveLocalPerson();
                                finish();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }

                        YNToastMaster.showToast(YNPersonalActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(YNPersonalActivity.this,
                                                getString(R.string.request_fail));
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // AutoUtils.setSize(this, false, 750, 1334);
        View view = View.inflate(this, R.layout.activity_personal_profile, null);
        //AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView() {
        imgHead = (ImageView) findViewById(R.id.imgAvatar);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        txtDate = (TextView) findViewById(R.id.txtDate);
        edtNickName = (EditText) findViewById(R.id.edtNickName);
        edtDescribe = (EditText) findViewById(R.id.edtDescribe);
        rgSex = (RadioGroup) findViewById(R.id.rgSex);
        rbBoy = (RadioButton) findViewById(R.id.rbBoy);
        rbGirl = (RadioButton) findViewById(R.id.rbGirl);
        localBean = AccountUtils.getLocalPerson();

        txtSave = (TextView) findViewById(R.id.txtSave);
    }

    @Override
    protected void addEvent() {
        imgHead.setOnClickListener(this);
        imgBack.setOnClickListener(this);
        txtDate.setOnClickListener(this);
        txtSave.setOnClickListener(this);

        // 设置性别，存储当前性别数据，用于上传
        rgSex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbBoy:
                        sex = 2;
                        break;

                    case R.id.rbGirl:
                        sex = 1;
                        break;
                }
            }
        });
    }

    @Override
    protected void settingDo() {
        if (localBean != null) {
            headPicPath = localBean.getIcon();
            YNImageLoaderUtil.setImage(this, imgHead, headPicPath);
            edtNickName.setText(localBean.getUsername());
            edtNickName.setClickable(false);
            txtDate.setText(localBean.getDate());
            edtDescribe.setText(localBean.getDescribe());
            int sexValue = localBean.getSex();
            if (sexValue == 2) {
                rbBoy.setChecked(true);
            } else {
                rbGirl.setChecked(true);
            }
            sex = sexValue;
        }
    }

    @Override
    public void onDateSet(CalendarDatePickerDialog dialog,
                          int year,
                          int monthOfYear,
                          int dayOfMonth)
    {
        txtDate.setText(year + "年" + (monthOfYear + 1) + "月" + dayOfMonth + "日");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgBack:
                dealOrNot();
                break;

            case R.id.imgAvatar:
                showDialog();
                break;

            case R.id.txtDate:
                DateTime now = DateTime.now();
                calendarDatePickerDialog = CalendarDatePickerDialog.newInstance(YNPersonalActivity.this,
                                                                                now.getYear(),
                                                                                now.getMonthOfYear() - 1,
                                                                                now.getDayOfMonth());
                calendarDatePickerDialog.show(getSupportFragmentManager(), FRAG_TAG_DATE_PICKER);
                break;

            case R.id.txtSave:
                final String username = edtNickName.getText()
                                                   .toString();
                final String date = txtDate.getText()
                                           .toString();
                YNLogUtil.e("tag", date);
                final String describe = edtDescribe.getText()
                                                   .toString();

                // 判断是否选择头像
                if (headPicPath == null || TextUtils.isEmpty(headPicPath)) {
                    YNToastMaster.showToast(YNPersonalActivity.this, "请设置头像！");
                    return;
                }
                if (TextUtils.isEmpty(username)) {
                    YNToastMaster.showToast(YNPersonalActivity.this, "用户昵称不能为空！");
                    return;
                }
                // 判断是否填写特长描述
                if (TextUtils.isEmpty(describe)) {
                    YNToastMaster.showToast(YNPersonalActivity.this, "请填写特长描述！");
                    return;
                }

                if (!localBean.getIcon()
                              .equals(headPicPath) || !localBean.getDate()
                                                                .equals(date) || !localBean.getUsername()
                                                                                           .equals(username) || !localBean.getDescribe()
                                                                                                                          .equals(describe) || sex != localBean.getSex())
                {
                    if (localBean.getIcon()
                                 .equals(headPicPath))
                    {
                        //                        imgFile = null;
                    } else {
                        BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(headPicPath);
                        int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context),
                                                 ScreenSizeUtil.getScreenHigh(context));
                        int imgMax = Math.max(options.outWidth, options.outHeight);
                        int inSimpleSize = 1;
                        if (screenMax <= imgMax) {
                            inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax,
                                                                                  imgMax);
                        }

                        headPicPath = YNBitMapUtil.compressBitmap(context,
                                                                  headPicPath,
                                                                  Bitmap.CompressFormat.JPEG,
                                                                  options.outWidth / inSimpleSize,
                                                                  options.outHeight / inSimpleSize,
                                                                  false);
                        imgFile = new File(headPicPath);

                    }

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            UserHttpUtils.newInstance()
                                         .uploadUserInfo(YNPersonalActivity.this,
                                                         YNCommonConfig.UPLOAD_USER_INFO_URL,
                                                         AccountUtils.getAccountBean()
                                                                     .getId(),
                                                         username,
                                                         date,
                                                         sex,
                                                         imgFile,
                                                         describe,
                                                         handler,
                                                         YNCommonConfig.EDIT_PERSONAL_INFO_FLAG,
                                                         true);
                        }
                    });
                } else {
                    finish();
                }
                break;
        }

    }

    /**
     * 确定是否显示保存提示对话框
     */
    private void dealOrNot() {
        if (localBean != null) {
            YNLogUtil.e("cdy", localBean.getDate() + "," + localBean.getDescribe() + "," + localBean.getIcon() + "," + localBean.getSex() + "," + localBean.getUsername());
            if (!localBean.getIcon()
                          .equals(headPicPath) || !txtDate.getText()
                                                          .equals(localBean.getDate()) || !edtNickName.getText()
                                                                                                      .toString()
                                                                                                      .equals(localBean.getUsername()) || !edtDescribe.getText()
                                                                                                                                                      .toString()
                                                                                                                                                      .equals(localBean.getDescribe()) || sex != localBean.getSex())
            {
                createDialog();
            } else {
                finish();
            }
        } else {
            if (!TextUtils.isEmpty(headPicPath) || !TextUtils.isEmpty(edtNickName.getText()
                                                                                 .toString()) || !TextUtils.isEmpty(
                    edtDescribe.getText()
                               .toString()))
            {
                createDialog();
            } else {
                finish();
            }
        }
    }

    /**
     * 保存本地用户信息，如头像、昵称、生日、特长等
     */
    private void saveLocalPerson() {
//        PersonInfoBean bean = new PersonInfoBean();
//        bean.setDate(txtDate.getText()
//                            .toString());
//        bean.setDescribe(edtDescribe.getText()
//                                    .toString());
//        bean.setIcon(personInfoBean.getIcon());
//        bean.setUsername(edtNickName.getText()
//                                    .toString());
//        bean.setSex(sex);
        AccountUtils.saveLocalPerson(personInfoBean);
    }


    /**
     * 修改头像弹出dialog
     */
    private void showDialog() {
        View view = getLayoutInflater().inflate(R.layout.head_image_choose_dialog, null);
        mDialog = new Dialog(this, R.style.transparentFrameWindowStyle);
        mDialog.setContentView(view,
                               new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                                                          ViewGroup.LayoutParams.WRAP_CONTENT));
        Window window = mDialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getWindowManager().getDefaultDisplay()
                                 .getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        mDialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        mDialog.setCanceledOnTouchOutside(true);

        buttonHeadOnClickListenner();

        mDialog.show();
    }


    /**
     * 修改头像弹出dialogh后的点击事件
     *
     * @param
     */
    private void buttonHeadOnClickListenner() {
        Button btn_takephoto = (Button) mDialog.getWindow()
                                               .findViewById(R.id.btn_takephoto);
        Button btn_choose_images = (Button) mDialog.getWindow()
                                                   .findViewById(R.id.btn_choose_images);
        Button btn_cancel = (Button) mDialog.getWindow()
                                            .findViewById(R.id.btn_cancel);

        btn_takephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(context,
                                                      Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(YNPersonalActivity.this,
                                                      new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                                                   Manifest.permission.CAMERA},
                                                      2);
                } else {
                    openCamera();
                }

            }
        });


        btn_choose_images.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(context,
                                                      android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(YNPersonalActivity.this,
                                                      new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                                      1);
                } else {
                    openAlbum();
                }

            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

    }

    private void openCamera() {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(context.getPackageManager()) != null) {
            try {
                mTmpFile = FileUtils.createTmpFile(context);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (mTmpFile != null && mTmpFile.exists()) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                    imageUri = Uri.fromFile(mTmpFile);
                } else {
                    ContentValues contentValues = new ContentValues(1);
                    contentValues.put(MediaStore.Images.Media.DATA, mTmpFile.getAbsolutePath());
                    imageUri = context.getContentResolver()
                                      .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                              contentValues);
                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, YNCommonConfig.TAKE_PHOTO);
            } else {
                YNToastMaster.showToast(context, " File is not exists");
            }
        } else {
            YNToastMaster.showToast(context, "No camera");
        }
        mDialog.dismiss();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openAlbum();
                } else {
                    YNToastMaster.showToast(this, "You denied the permission");
                }
                break;
            case 2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                } else {
                    YNToastMaster.showToast(this, "You denied the permission");
                }
                break;
        }

    }

    private void openAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK,
                                   MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, YNCommonConfig.CHOOSE_IMAGES);
        mDialog.dismiss();
    }


    /**
     * 创建放弃修改弹出框
     */
    private void createDialog()
    {
        alertDialog = new YNPayDialog.Builder(this)
                .setContentText("是否放弃编辑？")
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setContentTextSize(18)
                .setRightButtonTextColor(R.color.ynkj_red)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener()
                {
                    @Override
                    public void clickTopLeftButton(View view)
                    {

                    }

                    @Override
                    public void clickTopRightButton(View view)
                    {

                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        alertDialog.dismiss();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        finish();
                        alertDialog.dismiss();
                    }

                    @Override
                    public void clickBottomButton(View view)
                    {

                    }
                })
                .build();
        alertDialog.show();

       /* alertCache = new AlertDialog.Builder(this).create();
        alertCache.show();
        alertCache.getWindow()
                  .setContentView(R.layout.dialog_cleancache);
        TextView tvContent = (TextView) alertCache.getWindow()
                                                  .findViewById(R.id.tv_content);
        Button btnPositive = (Button) alertCache.getWindow()
                                                .findViewById(R.id.btnConfirm);
        Button btnNegative = (Button) alertCache.getWindow()
                                                .findViewById(R.id.btnCancel);

        tvContent.setText("是否放弃编辑？");
        btnNegative.setText(getString(R.string.give_up));
        btnPositive.setText(getString(R.string.continue_to_edit));
        btnPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertCache.dismiss();

                finish();
            }
        });
        btnNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertCache.dismiss();
            }
        });*/
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            dealOrNot();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap image = null;
        switch (requestCode) {
            case YNCommonConfig.TAKE_PHOTO:
                if (resultCode == Activity.RESULT_OK) {
                    headPicPath = YNBitMapUtil.getPathByUri(this, imageUri);
                    image = BitmapFactory.decodeFile(headPicPath);
                }
                break;

            case YNCommonConfig.CHOOSE_IMAGES:
                if (data == null) { return; }
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getData();
                    headPicPath = YNBitMapUtil.getPathByUri(this, uri);
                    image = BitmapFactory.decodeFile(headPicPath);
                }
                break;
        }
        imgHead.setImageBitmap(image);
    }
}
