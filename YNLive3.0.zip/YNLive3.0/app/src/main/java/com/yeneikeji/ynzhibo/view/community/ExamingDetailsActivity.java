package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/*
* 这是审核详情的类
* */
public class ExamingDetailsActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private TextView mTime;
    private TextView mTitle;
    private YNCircleImageView mHeadiv;
    private TextView mAuthorName;
    private TextView mArticalType;
    private TextView mContent;
    private RecordVideoBean mExamBean;
    private String mFlag;
    private Button mReEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_examing_details);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        mFlag = getIntent().getStringExtra("pointType");
        mExamBean = (RecordVideoBean) getIntent().getSerializableExtra("RecordVideoBean");

        mTitle = (TextView) findViewById(R.id.artical_details_title);
        mTime = (TextView)findViewById(R.id.top_tv_time);
        mHeadiv = (YNCircleImageView) findViewById(R.id.author_head_iv);
        mAuthorName = (TextView)findViewById(R.id.author_name);
        mArticalType = (TextView) findViewById(R.id.artical_type);
        mContent = (TextView)findViewById(R.id.artical_details_content);
        mReEdit = (Button) findViewById(R.id.reEdit_btn);
        if(mFlag.equals("examing")){
            configTopBarCtrollerWithTitle("正在审核观点");
            mReEdit.setVisibility(View.GONE);
        }else if(mFlag.equals("refuse")){
            configTopBarCtrollerWithTitle("被驳回观点");
            mReEdit.setVisibility(View.VISIBLE);
        }

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mReEdit.setOnClickListener(this);
        mTitle.setText(mExamBean.getTitle());
        mTime.setText(DateUtil.timeStamp2StringSHort(mExamBean.getTime()));
        YNImageLoaderUtil.setImage(ExamingDetailsActivity.this, mHeadiv, AccountUtils.getAccountBean().getIcon());
        mContent.setText(mExamBean.getContent());

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //跳转到重新编辑页面
            case R.id.reEdit_btn:
                Intent intent=new Intent(ExamingDetailsActivity.this,ArticalPublishActivity.class);
                intent.putExtra("pointType","reEdit");
                intent.putExtra("RecordVideoBean",mExamBean);
                startActivity(intent);
                break;
        }
    }
}
