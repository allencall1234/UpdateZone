package com.yeneikeji.ynzhibo.view.mine;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.yeneikeji.ynzhibo.R;

public class MyGiftDetails
        extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_gift_details);
    }
}
