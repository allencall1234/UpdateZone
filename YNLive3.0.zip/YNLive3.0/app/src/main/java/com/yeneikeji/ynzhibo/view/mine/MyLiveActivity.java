package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.RelativeLayout;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.multichannel.MultichannelLiveActivity;
import com.yeneikeji.ynzhibo.view.mine.multichannel.MultichannelLiveApplyActivity;
import com.yeneikeji.ynzhibo.view.mine.multichannel.MultichannelRoomManageActivity;

/**
 * 我的直播界面
 */
public class MyLiveActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout mRLRoomManage;
    private RelativeLayout mRLMultichannelLive;
    private RelativeLayout mRLMyLiveVideo;
    private RelativeLayout mRLUseIntroduce;
    private RelativeLayout mRLLiveAgreement;
    private RelativeLayout mRLLiveHostNotice;
    private RelativeLayout mRLReportRecord;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.QUERY_MULTICHANNEL_LIVE_STATE_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("lxy",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 205)
                        {
                            // 申请多通道直播房间
                            Intent intent = new Intent(MyLiveActivity.this, MultichannelLiveApplyActivity.class);
                            startActivity(intent);
                        }
                        if (baseBean.getCode() == 201)
                        {
                            // 进入主房主的权限界面
                            Intent intent = new Intent(MyLiveActivity.this, MultichannelLiveActivity.class);
                            startActivity(intent);
                        }
                      /*  if (baseBean.getCode() == 203)
                        {
                            // 进入子房间的房主界面
                            RoomOwnerBean       roomOwner       = null;
                            List<RoomOwnerBean> deputyOwnerList = null;
                            List<RoomOwnerBean> roomManageList  = null;
                            List<RoomOwnerBean> roomLiveSort    = null;
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                roomOwner = YNJsonUtil.JsonToBean(jsonObject.optString("data1"), RoomOwnerBean.class);
                                JSONArray deputyOwner = jsonObject.optJSONArray("data2");
                                JSONArray manageList  = jsonObject.optJSONArray("data3");
                                JSONArray liveSort    = jsonObject.optJSONArray("data4");

                                if (deputyOwner != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    deputyOwnerList = YNJsonUtil.JsonToLBean(deputyOwner.toString(), type);
                                }

                                if (manageList != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    roomManageList = YNJsonUtil.JsonToLBean(manageList.toString(), type);
                                }

                                if (liveSort != null)
                                {
                                    Type type = new TypeToken<List<RoomOwnerBean>>() {}.getType();
                                    roomLiveSort = YNJsonUtil.JsonToLBean(liveSort.toString(), type);
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                            Intent intent = new Intent(MyLiveActivity.this, MultichannelActivity.class);
                           *//* Bundle bundle = new Bundle();
                            bundle.putBoolean(YNCommonConfig.TITLE, false);
                            bundle.putSerializable(YNCommonConfig.OBJECT, roomOwner);
                            bundle.putSerializable("deputyOwnerList", (Serializable) deputyOwnerList);
                            bundle.putSerializable("manageList", (Serializable) roomManageList);
                            bundle.putSerializable("roomLiveSort", (Serializable) roomLiveSort);
                            intent.putExtras(bundle);*//*
                            startActivity(intent);
                        }*/
                        if (baseBean.getCode() == 203)
                        {
                            // 子房间房主进入界面
                            Intent intent = new Intent(MyLiveActivity.this, MultichannelRoomManageActivity.class);
                            intent.putExtra(YNCommonConfig.TITLE, false);
                            startActivity(intent);
                        }
                        if (baseBean.getCode() == 204)
                        {
                            YNToastMaster.showToast(MyLiveActivity.this, baseBean.getInfo());
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(MyLiveActivity.this, R.string.request_fail);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_live);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    protected void initView()
    {
        configTopBarCtrollerWithTitle("我的直播");
        mRLRoomManage = (RelativeLayout) findViewById(R.id.rl_room_manage);
        mRLMultichannelLive = (RelativeLayout) findViewById(R.id.rl_multichannel_live);
        mRLMyLiveVideo = (RelativeLayout) findViewById(R.id.rl_my_live_video);
        mRLUseIntroduce = (RelativeLayout) findViewById(R.id.rl_use_introduce);
        mRLLiveAgreement = (RelativeLayout) findViewById(R.id.rl_live_agreement);
        mRLLiveHostNotice = (RelativeLayout) findViewById(R.id.rl_live_host_notice);
        mRLReportRecord = (RelativeLayout) findViewById(R.id.rl_report_record);
    }

    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);

        mRLRoomManage.setOnClickListener(this);
        mRLMultichannelLive.setOnClickListener(this);
        mRLMyLiveVideo.setOnClickListener(this);
        mRLUseIntroduce.setOnClickListener(this);
        mRLLiveAgreement.setOnClickListener(this);
        mRLLiveHostNotice.setOnClickListener(this);
        mRLReportRecord.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View view)
    {
        Intent intent = new Intent();
        switch (view.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                YNCommonUtils.hideSoftInput(this, view);
                break;

            case R.id.rl_room_manage:
                intent.setClass(this, LiveRoomManageActivity.class);
                startActivity(intent);
                break;

            case R.id.rl_multichannel_live:
                /*    intent.setClass(this, MultichannelRoomManageActivity.class);
                  startActivity(intent);*/
              mHandler.post(new Runnable()
               {
                   @Override
                   public void run()
                   {
                       UserHttpUtils.newInstance().queryMultiChannelLiveState(MyLiveActivity.this, YNCommonConfig.QUERY_MULTICHANNEL_LIVE_STATE_URL,
                                                                              AccountUtils.getAccountBean().getId(),
                                                                              mHandler, YNCommonConfig.QUERY_MULTICHANNEL_LIVE_STATE_FLAG, true);
                    }
               });
              /*  intent.setClass(this, SubRoomListActivity.class);
                startActivity(intent);*/
                break;

            //直播视频
            case R.id.rl_my_live_video:
                intent.setClass(this, MyLiveVideoActivity.class);
                intent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, 2);
                startActivity(intent);
                break;

            //平台使用指南
            case R.id.rl_use_introduce:
                intent.setClass(this, UseIntroductiomActivity.class);
                startActivity(intent);
                break;

            //直播协定
            case R.id.rl_live_agreement:
                intent.setClass(this, LiveAgreementActivity.class);
                startActivity(intent);
                break;

            //主播公告
            case R.id.rl_live_host_notice:
              /*  intent.setClass(this, HostNoticeActivity.class);
                startActivity(intent);*/
                break;

            //被举报记录
            case R.id.rl_report_record:
                intent.setClass(this, ReportRecordActivity.class);
                startActivity(intent);
                break;
        }
    }

}
