package com.yeneikeji.ynzhibo.view.live;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.utils.SocializeUtils;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.ChatListAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.animation.HeartLayout;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.BottomPanelFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.listener.SoftKeyBoardListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.rongcloud.message.GiftMessage;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.YNGoldCoinActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.ChatListView;
import com.yeneikeji.ynzhibo.widget.GiftLayout;
import com.yeneikeji.ynzhibo.widget.InputPanel;
import com.yeneikeji.ynzhibo.widget.LiveLeftGiftView;
import com.yeneikeji.ynzhibo.widget.dialog.YNChatRoomAlertDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLiveEvaluateDialog;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import cn.jpush.android.api.JPushInterface;
import io.rong.imlib.RongIMClient;
import io.rong.imlib.model.Conversation;
import io.rong.imlib.model.MessageContent;
import io.rong.imlib.model.UserInfo;
import io.rong.message.CommandNotificationMessage;
import io.rong.message.ImageMessage;
import io.rong.message.InformationNotificationMessage;
import io.rong.message.TextMessage;

/**
 * 聊天界面
 * Created by Administrator on 2017/5/16.
 */
public class ChatFragment extends BaseFragment implements View.OnClickListener, Handler.Callback
{
    private static final String TAG = "ChatFragment";

    private BottomPanelFragment bottomPanel;// 底部聊天点赞组件
//    private ImageView mIVClear;//  清屏
    private ImageView mIVSpeak;//  聊天
    private ImageView mIVShare;//  分享
    private ImageView mIVEvaluate;// 评价
    private ImageView mIVGift;
    private ImageView mIVThumb;//  点赞
    private HeartLayout heartLayout;// 心形气泡
    private ViewGroup buttonPanel;
    private InputPanel inputPanel;
    private LiveLeftGiftView leftGiftView;
    private LiveLeftGiftView leftGiftView2;
    private ChatListView mChatListView;
    private LinearLayout mLLBottomShare;
    private ViewGroup mLLBottomGift;
    private TextView mGoldCount;
    private RelativeLayout mRLChat;

    private ChatListAdapter mChatListAdapter;
    private CommonRecyclerViewAdapter<ChatRoomUserBean> mAdapter;
    private LiveRoomBean liveRoomBean = null;
    private String beClickedUserId;// 被点击的人的用户id
    private int giftType = 0;
    private int thumbCount;
    private GiftBean gift;
    private int giftIndex;
    private float currentCoin;// 当前金币
    List<UserInfo> toShowList = Collections.synchronizedList(new LinkedList<UserInfo>());
    private ChatRoomUserBean chatRoomUserBean = null;
    private String userId;
    private String userName;
    private String userImg;

    private ProgressDialog shareDialog;
    private UMWeb web;
    private YNPopupWindows mPopupWindows;
    private GiftPopupWindows mGiftPopupWindows;
    private YNChatRoomAlertDialog chatRoomDialog;
    private YNLiveEvaluateDialog mEvaluateDialog;

    private boolean processFlag = true; //默认可以点击
    private boolean clickManagerList = false;
    // 显示礼物
    volatile boolean isGiftShowing = false;
    volatile boolean isGift2Showing = false;

    private Random random = new Random();
    private Handler handler = new Handler(this);

    private Timer barTimer;

    private LocalBroadcastManager broadcastManager;
    private BroadcastReceiver mRefreshReceiver;

    @Override
    public boolean handleMessage(Message msg)
    {
        switch (msg.what)
        {
            case LiveKit.MESSAGE_SENT:
            case LiveKit.MESSAGE_ARRIVED:
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message)msg.obj;
                MessageContent content = msgContent.getContent();
                // 过滤消息
                if (liveRoomBean.getPid().length() <= 1)
                {
                    if (content instanceof GiftMessage)
                    {
                        GiftMessage giftMsg = (GiftMessage) content;
                        if ("0".equals(giftMsg.getType()))
                            showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                        else
                            addHeartLayout();
                    }

                    if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                    {
                        mChatListAdapter.addMessage(content);
                        mChatListAdapter.addMsg(msgContent);
                        mChatListView.setTranscriptMode(2);
                    }
                }
                else
                {
                    if ("0".equals(YNCommonUtils.interceptionMultichannelRoomPID(liveRoomBean.getPid())))
                    {
                        if (content instanceof GiftMessage)
                        {
                            GiftMessage giftMsg = (GiftMessage) content;
                            if ("0".equals(giftMsg.getType()))
                                showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                            else
                                addHeartLayout();
                        }

                        if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                        {
                            mChatListAdapter.addMessage(content);
                            mChatListAdapter.addMsg(msgContent);
                            mChatListView.setTranscriptMode(2);
                        }
                    }
                    else
                    {
                        // 判断是否属于此房间的消息
                        if (content instanceof InformationNotificationMessage)
                        {
                            if (!TextUtils.isEmpty(((InformationNotificationMessage) content).getExtra()))
                            {
                                if (((InformationNotificationMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                        if (content instanceof TextMessage)
                        {
                            if (!TextUtils.isEmpty(((TextMessage) content).getExtra()))
                            {
                                if (((TextMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                        if (content instanceof GiftMessage)
                        {
                            if (!TextUtils.isEmpty(((GiftMessage) content).getExtra()))
                            {
                                if (((GiftMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    GiftMessage giftMsg = (GiftMessage) content;
                                    if ("0".equals(giftMsg.getType()))
                                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                                    else
                                        addHeartLayout();
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                    }
                }
                break;

             /*  {
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message)msg.obj;
                MessageContent content = msgContent.getContent();
                if (content instanceof GiftMessage)
                {
                    GiftMessage giftMsg = (GiftMessage) content;
                    if ("0".equals(giftMsg.getType()))
                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                }
                if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                {
                    mChatListAdapter.addMessage(content);
                    mChatListAdapter.addMsg(msgContent);
                    mChatListView.setTranscriptMode(2);
                }
                break;
            }
            case LiveKit.MESSAGE_SENT: {
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message)msg.obj;
                MessageContent content = msgContent.getContent();
                if (content instanceof GiftMessage)
                {
                    GiftMessage giftMsg = (GiftMessage) content;
                    if ("0".equals(giftMsg.getType()))
                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                }
                if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                {
                    mChatListAdapter.addMessage(content);
                    mChatListAdapter.addMsg(msgContent);
                    mChatListView.setTranscriptMode(2);
                }
                break;
            }*/

           /* case LiveKit.MESSAGE_SENT:
            case LiveKit.MESSAGE_ARRIVED:
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message)msg.obj;
                MessageContent content = msgContent.getContent();
                if (content instanceof GiftMessage)
                {
                    GiftMessage giftMsg = (GiftMessage) content;
                    if ("0".equals(giftMsg.getType()))
                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                }
                if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                {
                    mChatListAdapter.addMessage(content);
                    mChatListAdapter.addMsg(msgContent);
                    mChatListView.setTranscriptMode(2);
                }
                break;*/

            case LiveKit.MESSAGE_SEND_ERROR:
                break;

            case YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNLogUtil.e("tag", msg.obj.toString());
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject object = new JSONObject(msg.obj.toString());
                            String token = object.getString("0");
                            connectRongYunServers(token);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                else
                {
//                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                    {
//                        InformationNotificationMessage gagInfo = InformationNotificationMessage.obtain("被禁言");
//                        LiveKit.sendMessage(gagInfo, Conversation.ConversationType.CHATROOM);
                        YNToastMaster.showToast(getActivity(), "禁言成功");
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), "禁言失败");
                    }
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                        YNToastMaster.showToast(getActivity(), "解禁成功");
                    else
                        YNToastMaster.showToast(getActivity(), "解禁失败");
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.REPORT_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNToastMaster.showToast(getActivity(), baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.ADD_ROOM_MANAGE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 52)
                    {
                        ((YNLiveDetailsActivity)getActivity()).addManager(chatRoomUserBean);
                    }

                    YNToastMaster.showToast(getActivity(), baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.DELETE_ROOM_MANAGE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 54)
                    {
                        ((YNLiveDetailsActivity)getActivity()).deleteManager(chatRoomUserBean);
                    }

                    YNToastMaster.showToast(getActivity(), baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), R.string.request_fail);
                }
                break;

            case YNCommonConfig.QUERY_BE_BLOCKED_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                    {
                        if (baseBean.getUsers() != null)
                        {
                            for (UserInfoBean userInfoBean : baseBean.getUsers())
                            {
                                if (userId.equals(userInfoBean.getId()))
                                {
//                                    mTVLoadingTxt.setText("您已被禁言，加入聊天室失败");
                                    break;
                                }
                                else
                                {
                                    handler.postDelayed(new Runnable()
                                    {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance().getRongCloudToken(getActivity(), YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
                                                    AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, true, 500);
                                        }
                                    }, 200);
                                }
                            }
                        }
                        else
                        {
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().getRongCloudToken(getActivity(), YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
                                            AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG,  true, 500);
                                }
                            }, 200);
                        }
                    }
                }
                else
                {
//                    mTVLoadingTxt.setText("加入聊天室失败");
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            chatRoomUserBean = YNJsonUtil.JsonToBean(jsonObject.get("data").toString(), ChatRoomUserBean.class);
                            creatChatRoomDialog(chatRoomUserBean);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG:
                if (msg.obj != null)
                {
                    YNLogUtil.e("tag", msg.obj.toString());
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 70)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            currentCoin = Float.parseFloat(jsonObject.getJSONObject("0").optString("currentCoin"));
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                        if (giftType == 1)
                        {
//                            currentCoin = currentCoin - thumbCount;
//                            for (int i = 0; i < thumbCount; i++)
//                            {
//                                GiftMessage giftMsg = new GiftMessage("1", "", "0");
//
//                                LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
//                            }
//                            thumbCount = 0;
//                            heartLayout.postDelayed(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    int rgb = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));
//                                    heartLayout.addHeart(rgb);
//                                }
//                            }, 200);
//                            currentCoin = currentCoin - 0.1f;
                            GiftMessage giftMsg = new GiftMessage("1", "", "0", liveRoomBean.getPid());
                            LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
                        }
                        else
                        {
//                            currentCoin = currentCoin - gift.getGiftCount();

//                            mGoldCount.setText(currentCoin + "");
                            GiftMessage giftMsg = new GiftMessage("0", gift.getGiftName(), String.valueOf(giftIndex), liveRoomBean.getPid());
                            LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
                        }
                        AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                    }

//                    YNToastMaster.showToast(getActivity(), baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), R.string.request_fail);
                }
                break;

            case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            currentCoin = Float.parseFloat(jsonObject.getString("data"));
                            AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                    }
                }
                else
                {
//                    YNToastMaster.showToast(getContext(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.LIVE_EVALUATE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNToastMaster.showToast(getContext(), baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(getContext(), R.string.request_fail);
                }
                break;
        }
        mChatListAdapter.notifyDataSetChanged();
        return false;
    }

    @Override
    protected int getLayout()
    {
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }
        return R.layout.fragment_live_chat;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (inputPanel.getVisibility() == View.VISIBLE) {
                    buttonPanel.setVisibility(View.VISIBLE);
                    inputPanel.setVisibility(View.GONE);
                    YNCommonUtils.hideSoftInput(getActivity(), inputPanel.getInputView());
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();

                }

//                hideKeyBoard();
//                else
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
            }
        });

        broadcastManager = LocalBroadcastManager.getInstance(getActivity());
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(YNCommonConfig.UPDATE_USER_STATE_FLAG);
        mRefreshReceiver= new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent){
                if (!intent.getBooleanExtra("liveRoom", false))
                {
                    liveRoomBean = (LiveRoomBean)intent.getSerializableExtra(YNCommonConfig.OBJECT);
                    quitChatRoom(liveRoomBean);
                }

            }
        };
        broadcastManager.registerReceiver(mRefreshReceiver, intentFilter);

//        if (liveRoomBean.getLiving() == 1)
//            softKeyboardListnenr();
    }

    @Override
    protected void initView()
    {
        bottomPanel = (BottomPanelFragment) getChildFragmentManager().findFragmentById(R.id.bottom_bar);
//        mIVClear = (ImageView) bottomPanel.getView().findViewById(R.id.iv_clear);
        mIVShare = (ImageView) bottomPanel.getView().findViewById(R.id.iv_share);
        mIVEvaluate = (ImageView) bottomPanel.getView().findViewById(R.id.iv_evaluate);
        mIVGift = (ImageView) bottomPanel.getView().findViewById(R.id.iv_gift);
        mIVThumb = (ImageView) bottomPanel.getView().findViewById(R.id.iv_thumb);
        mIVSpeak = (ImageView) bottomPanel.getView().findViewById(R.id.iv_speak);
        buttonPanel = (ViewGroup) bottomPanel.getView().findViewById(R.id.button_panel);
        inputPanel = (InputPanel) bottomPanel.getView().findViewById(R.id.input_panel);
        heartLayout = (HeartLayout) findViewById(R.id.heart_layout);
        leftGiftView = (LiveLeftGiftView) findViewById(R.id.left_gift_view1);
        leftGiftView2 = (LiveLeftGiftView) findViewById(R.id.left_gift_view2);
        mChatListView = (ChatListView) findViewById(R.id.chat_listview);
        mRLChat = (RelativeLayout) findViewById(R.id.rl_chat);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        LiveKit.addEventHandler(handler);
    }

    @Override
    protected void loadData()
    {
        mIVShare.setOnClickListener(this);
        mIVEvaluate.setOnClickListener(this);
        mIVGift.setOnClickListener(this);
        mIVThumb.setOnClickListener(this);
//        mIVClear.setOnClickListener(this);
        mIVSpeak.setOnClickListener(this);
        mRLChat.setOnClickListener(this);

        mChatListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if (inputPanel.getVisibility() == View.VISIBLE)
                {
                    YNCommonUtils.hideSoftInput(getActivity(), inputPanel.getInputView());
                    inputPanel.setVisibility(View.GONE);
                    buttonPanel.setVisibility(View.VISIBLE);
                }
//                else
//                {
//                    if (processFlag)
//                    {
//                        setProcessFlag();
//                        if (mChatListAdapter.getMsg().get(position).getContent() instanceof InformationNotificationMessage)
//                        {
//                            beClickedUserId = mChatListAdapter.getMessage().get(position).getUserInfo().getUserId();
//                            // 查询被点击的用户信息
//                            handler.postDelayed(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    UserHttpUtils.newInstance().getChatRoomUserInfo(getActivity(), YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, liveRoomBean.getRoom_id(),
//                                            beClickedUserId, userId, handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
//                                }
//                            }, 200);
//                        }
//                        new TimeThread().start();
//                    }
//                }
            }
        });

        // 发送消息
        bottomPanel.setInputPanelListener(new InputPanel.InputPanelListener()
        {
            @Override
            public void onSendClick(String text)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo() && LiveKit.getCurrentUser() != null)
                    {
                        final TextMessage content = TextMessage.obtain(text);
                        content.setExtra(liveRoomBean.getPid());
                        LiveKit.sendMessage(content, Conversation.ConversationType.CHATROOM);
                    }
                    else
                    {
                        Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                        startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.no_net));
                }
            }
        });

        shareDialog = new ProgressDialog(getContext());


        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();
            userImg = AccountUtils.getAccountBean().getIcon();

            if (userId.equals(liveRoomBean.getUserid()))
            {
                mIVGift.setVisibility(View.INVISIBLE);
                mIVThumb.setVisibility(View.INVISIBLE);
                mIVEvaluate.setVisibility(View.INVISIBLE);
            }

            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getCurrentGoldCoin(getActivity(), YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, handler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

                }
            });
        }
        else
        {
//            userId = System.currentTimeMillis() / 1000 + "";
//            SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            userId = DateUtil.timeToTimeStamp(sDateFormat.format(new java.util.Date()));
            userId = YNCommonUtils.getRandomNumber();
            userName = "游客<" + YNCommonUtils.getRandomNumber() + ">";
            userImg = "http://www.qqw21.com/article/uploadpic/2012-9/201291893228996.jpg";
        }

//        if (liveRoomBean.getLiving() == 1)
//        {
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getRongCloudToken(getActivity(), YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId,
                            userName, userImg, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, true, 500);
                }
            });
//        }

        initShareContent();

        mChatListAdapter = new ChatListAdapter(getActivity(), liveRoomBean, mAdapter, buttonPanel, inputPanel);
        mChatListView.setAdapter(mChatListAdapter);

    }

    /**
     * 连接融云服务器
     * @param token
     */
    private void connectRongYunServers(String token)
    {
        /**
         * 建立与融云服务器的连接
         * @param token
         */
        LiveKit.connect(token, new RongIMClient.ConnectCallback()
        {
            @Override
            public void onTokenIncorrect()
            {
                // 检查appKey与token是否匹配
                YNLogUtil.d(TAG, "connect onTokenIncorrect");
            }

            @Override
            public void onSuccess(String s)
            {
                UserInfo userInfo1;
                if (AccountUtils.getLoginInfo())
                {
                    userInfo1 = new UserInfo(AccountUtils.getAccountBean().getId(), AccountUtils.getAccountBean().getUsername(), Uri.parse(AccountUtils.getAccountBean().getIcon()));
//                    userInfo1 = new UserInfo(userId, userName, Uri.parse(userImg));
                    LiveKit.setCurrentUser(userInfo1);
                }

                joinChatRoom(liveRoomBean.getRoom_id(), -1);
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {
                // 根据errorCode检查原因
                YNLogUtil.d(TAG, "connect onError = " + errorCode);
            }
        });
    }

    /**
     * 加入融云聊天室
     * @param roomId
     */
    private void joinChatRoom(final String roomId, int defMessageCount)
    {

        LiveKit.joinChatRoom(roomId, defMessageCount, new RongIMClient.OperationCallback()
        {
            @Override
            public void onSuccess()
            {
                if (AccountUtils.getLoginInfo())
                {
                    InformationNotificationMessage sysMsg = InformationNotificationMessage.obtain("系统提示：股市有风险，入市需谨慎!");
                    InformationNotificationMessage msg = InformationNotificationMessage.obtain(LiveKit.getCurrentUser().getName() + " 加入聊天室");
                    sysMsg.setExtra(liveRoomBean.getPid());
                    msg.setExtra(liveRoomBean.getPid());
//                    msg.setUserInfo(LiveKit.getCurrentUser());
//                    msg.setUserInfo(LiveKit.getCurrentUser());
                    LiveKit.sendMessage(sysMsg, Conversation.ConversationType.CUSTOMER_SERVICE);
                    LiveKit.sendMessage(msg, Conversation.ConversationType.CHATROOM);
//                    TextMessage content = TextMessage.obtain("0x0x0x1230x0x加入聊天室");

//                    LiveKit.sendMessage(content, Conversation.ConversationType.CHATROOM);
                }
                else
                {
                    InformationNotificationMessage sysMsg = InformationNotificationMessage.obtain("系统提示：股市有风险，入市需谨慎!");
//                    msg.setUserInfo(LiveKit.getCurrentUser());
                    sysMsg.setExtra(liveRoomBean.getPid());
                    LiveKit.sendMessage(sysMsg, Conversation.ConversationType.CUSTOMER_SERVICE);
                }
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {
                // 根据errorCode检查原因
                YNLogUtil.d(TAG, "connect onError = " + errorCode);
            }
        });
    }

    /**
     * 软键盘显示与隐藏的监听
     */
    private void softKeyboardListnenr() {
        SoftKeyBoardListener.setListener(getActivity(), new SoftKeyBoardListener.OnSoftKeyBoardChangeListener() {
            @Override
            public void keyBoardShow(int height) {/*软键盘显示：执行隐藏title动画，并修改listview高度和装载礼物容器的高度*/
                ((YNLiveDetailsActivity)getActivity()).hideTopBar();
//                dynamicChangeListviewH(100);
//                dynamicChangeGiftParentH(true);
            }
            @Override
            public void keyBoardHide(int height) {/*软键盘隐藏：隐藏聊天输入框并显示聊天按钮，执行显示title动画，并修改listview高度和装载礼物容器的高度*/
                if (inputPanel.getEmojiBtn().isSelected() == true)
                {
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
                }
                else
                {
                    inputPanel.setVisibility(View.GONE);
                    buttonPanel.setVisibility(View.VISIBLE);
//                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
                }
            }
        });
    }

    /**
     * 设置按钮在短时间内被重复点击的有效标识（true表示点击有效，false表示点击无效）
     */
    private synchronized void setProcessFlag()
    {
        processFlag = false;
    }

    /**
     * 计时线程（防止在一定时间段内重复点击按钮）
     */
    private class TimeThread extends Thread
    {
        public void run()
        {
            try
            {
                sleep(2000);
                processFlag = true;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_speak:
                buttonPanel.setVisibility(View.GONE);
                inputPanel.setVisibility(View.VISIBLE);
                inputPanel.getInputView().requestFocus();
                inputPanel.getInputView().requestFocusFromTouch();

                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        YNCommonUtils.showSoftInput(getActivity(), inputPanel.getInputView());
                    }
                });
//                ((YNLiveDetailsActivity)getActivity()).hideTopBar();
                break;

            case R.id.iv_share:
                showSharePopupWindow();
                break;

            case R.id.iv_evaluate:
                if (liveRoomBean.getLiving() == 0)
                {
                    YNToastMaster.showToast(getContext(), "主播不在线，不能进行直播评价");
                }
                else
                {
                    showEvaluateDialog();
                }
                break;

            case R.id.iv_gift:
                giftType = 0;
                showChooseGift();
                break;

            case R.id.iv_thumb:
                giftType = 1;
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo())
                    {
                        if (liveRoomBean.getLiving() == 1)
                        {
                            if (AccountUtils.getAccountBean().getCurrentCoin() >= 0.1)
                            {
                                handler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().liveRoomSendGift(getContext(), YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId, liveRoomBean.getUserid(),
                                                "为主播点赞", 1, 0.1f, giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                YNToastMaster.showToast(getContext(), "您的余额不足，请及时充值");
                            }
//                            thumbCount ++;
//                            AfterFiveSecondsSendThumb();
                        }
                        else
                        {
                            YNToastMaster.showToast(getActivity(), "主播不在线，无法点赞");
                        }
                    }
                    else
                    {
                        Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                        startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.no_net));
                }
                break;

            case R.id.rl_chat:
//                if (inputPanel.getVisibility() == View.VISIBLE)
//                {
//                    YNCommonUtils.hideSoftInput(getActivity(), inputPanel.getInputView());
//                    inputPanel.setVisibility(View.GONE);
//                    buttonPanel.setVisibility(View.VISIBLE);
////                    ((YNLiveDetailsActivity)getActivity()).showTopBar();
//                }
                break;

            case R.id.ll_ask:
                break;
        }
    }

    /**
     * 五秒钟发送点赞
     */
    private void AfterFiveSecondsSendThumb()
    {
        if (barTimer != null)
        {
            barTimer.cancel();
            barTimer = null;
        }
        barTimer = new Timer();
        barTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (currentCoin >= thumbCount)
                        {
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().liveRoomSendGift(getContext(), YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId, liveRoomBean.getUserid(),
                                            "为主播点赞", thumbCount, thumbCount, giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                }
                            });
                        }
                        else
                        {
                            thumbCount = 0;
                            YNToastMaster.showToast(getContext(), "您的余额不足，请及时充值");
                        }
                    }
                });
            }
        }, 5 * 1000);
    }

    public void hideKeyBoard()
    {
        if (inputPanel.getVisibility() == View.VISIBLE)
        {
            YNCommonUtils.hideSoftInput(getActivity(), inputPanel.getInputView());
            inputPanel.setVisibility(View.GONE);
            buttonPanel.setVisibility(View.VISIBLE);
//            ((YNLiveDetailsActivity)getActivity()).showTopBar();
        }
    }

    // 评价
    private void showEvaluateDialog()
    {
        mEvaluateDialog = new YNLiveEvaluateDialog.Builder(getContext())
                .setButtonTextSize(18)
                .setHeight(0.4f)
                .setWidth(0.8f)
                .setHeadImg(liveRoomBean.getIcon())
                .setuName(liveRoomBean.getUsername())
                .setLiveType(liveRoomBean.getTag() + "-" + liveRoomBean.getTag2())
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new YNLiveEvaluateDialog.OnClickRadioGroupDialogListener()
                {
                    @Override
                    public void clickLeftButton(View view)
                    {
                        mEvaluateDialog.dismiss();
                    }

                    @Override
                    public void clickRightButton(View view, final int liveEvaluateIndex)
                    {
                        mEvaluateDialog.dismiss();
                        if (AccountUtils.getLoginInfo())
                        {
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().liveEvaluate(getContext(), YNCommonConfig.LIVE_EVALUATE_URL, liveRoomBean.getUserid(), userId, liveEvaluateIndex,
                                            handler, YNCommonConfig.LIVE_EVALUATE_FLAG, false);
                                }
                            });
                        }
                        else
                        {
                            Intent intent = new Intent(getContext(), YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }
                }).build();
        mEvaluateDialog.show();
    }


    /**
     *  添加点赞动画效果
     */
    public void addHeartLayout() {
        heartLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                int rgb = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));
                heartLayout.addHeart(rgb);
            }
        }, 200);
    }

    protected synchronized void showLeftGiftVeiw(UserInfo user, GiftBean giftBean) {
        if (!isGift2Showing) {
            showGift1Direct(user, giftBean);
        } else if (!isGiftShowing) {
            showGift2Direct(user, giftBean);
        } else {
            toShowList.add(user);
        }
    }

    private void showGift1Direct(final UserInfo user, final GiftBean giftBean)
    {
        isGiftShowing = true;
        getActivity().runOnUiThread(new Runnable()
        {
            @Override public void run() {
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setName(user.getName());
                leftGiftView.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView.setGiftName("送出" + giftBean.getGiftName());
                leftGiftView.setGiftImageView(giftBean.getGiftId());
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setTranslationY(0);
                ViewAnimator.animate(leftGiftView)
                        .alpha(0, 1)
                        .translationX(-leftGiftView.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop()
                        {
                            @Override public void onStop()
                            {
                                UserInfo user = null;
                                try {
                                    user = toShowList.remove(0);
                                }
                                catch (Exception e)
                                {

                                }
                                if (user != null) {
                                    showGift1Direct(user, giftBean);
                                } else {
                                    isGiftShowing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView.getGiftImageView())
                        .translationX(-leftGiftView.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    private void showGift2Direct(final UserInfo user, final GiftBean giftBean)
    {
        isGift2Showing = true;
        getActivity().runOnUiThread(new Runnable() {
            @Override public void run() {
                leftGiftView2.setVisibility(View.VISIBLE);
                leftGiftView2.setName(user.getName());
                leftGiftView2.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView2.setGiftName("送出" + giftBean.getGiftName());
                leftGiftView2.setGiftImageView(giftBean.getGiftId());
                leftGiftView2.setTranslationY(0);
                ViewAnimator.animate(leftGiftView2)
                        .alpha(0, 1)
                        .translationX(-leftGiftView2.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView2)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView2.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop() {
                            @Override public void onStop() {
                                UserInfo user = null;
                                try
                                {
                                    user = toShowList.remove(0);
                                }
                                catch (Exception e)
                                {

                                }
                                if (user != null)
                                {
                                    showGift2Direct(user, giftBean);
                                } else {
                                    isGift2Showing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView2.getGiftImageView())
                        .translationX(-leftGiftView2.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    /** 创建顶部列表弹出框 */
    private void creatChatRoomDialog(final ChatRoomUserBean chatRoomUserBean)
    {
        boolean isAllGone = false;
        boolean isBeClickedManager = false;
        boolean isBeClickedHost = false;
        boolean isHost = false;
        boolean isManager = false;
        boolean isShowManagerCount = false;

        if (beClickedUserId.equals(liveRoomBean.getUserid()))
        {
            isBeClickedHost = true;
        }
        if (clickManagerList || (chatRoomUserBean.getIs_manage() == 1))
        {
            isBeClickedManager = true;
        }
        if (AccountUtils.getLoginInfo())
        {
            if (beClickedUserId.equals(AccountUtils.getAccountBean().getId()))
            {
                isAllGone = true;
            }
            if (userId.equals(liveRoomBean.getUserid()))
            {
                isHost = true;
            }
            if (chatRoomUserBean.getIs_selfManage() == 1)
            {
                isManager = true;
            }
        }
        if (!isAllGone && isHost)
        {
            isShowManagerCount = true;
        }

        chatRoomDialog = new YNChatRoomAlertDialog.Builder(getActivity())
                .setHeight(0.4f)
                .setWidth(0.8f)
                .setAllGone(isAllGone)
                .setLiveHost(isHost)
                .setRoomManager(isManager)
                .setBeClickedLiveHost(isBeClickedHost)
                .setBeClickedManager(isBeClickedManager)
                .setChatRoomUserBean(chatRoomUserBean)
                .setCanceledOnTouchOutside(true)
                .setShowManagerCount(isShowManagerCount)
                .setOnclickListener(new IDialogOnClickListener()
                {
                    @Override
                    public void clickTopLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_manage() == 1)
                        {
                            // 取消房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().deleteRoomManager(getActivity(), YNCommonConfig.DELETE_ROOM_MANAGE_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.DELETE_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 设置房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().addRoomManager(getActivity(), YNCommonConfig.ADD_ROOM_MANAGE_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.ADD_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickTopRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_say() == 1)
                        {
                            // 删除禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomCancelGagUser(getActivity(), YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomGagUser(getActivity(), YNCommonConfig.GAG_CHAT_ROOM_USER_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }
                }).build();
        chatRoomDialog.show();

    }

    /**
     * 创建举报弹出框
     */
    private void createReportDialog()
    {
        View view = getActivity().getLayoutInflater().inflate(R.layout.report_dialog, null);
        Button mBtnReport1 = (Button) view.findViewById(R.id.btn_report1);
        Button mBtnReport2 = (Button) view.findViewById(R.id.btn_report2);
        Button mBtnReport3 = (Button) view.findViewById(R.id.btn_report3);
        Button mBtnReport4 = (Button) view.findViewById(R.id.btn_report4);
        Button mBtnReport5 = (Button) view.findViewById(R.id.btn_report5);
        Button mBtnCancel = (Button) view.findViewById(R.id.btn_cancel);
        final Dialog dialog = new Dialog(getActivity(), R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getActivity().getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);

        mBtnCancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        mBtnReport1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(getActivity(), YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                1, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(getActivity(), YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                2, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(getActivity(), YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                3, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(getActivity(), YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                4, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(getActivity(), YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                5, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });
        dialog.show();

    }

    /**
     * 显示礼物选择弹出框
     */
    private void showChooseGift()
    {

        mGiftPopupWindows = new GiftPopupWindows(getActivity(), R.layout.popwindow_give_gift);
        // 设置layout在PopupWindow中显示的位置
        mGiftPopupWindows.showAtLocation(mLLBottomGift, Gravity.BOTTOM , 0, 0);

    }

    /**
     * 送礼物弹出框
     */
    private class GiftPopupWindows extends PopupWindow
    {
        private View rootView;

        private LinearLayout mLLGoldCoin;
        private TextView mTVSend;
        private Button mBtnSend;
        private GiftLayout mGiftLayout;

        public GiftPopupWindows(Context context, int itemLayoutId)
        {
            super(context);

            rootView = View.inflate(context, itemLayoutId, null);
            rootView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.popup_window_anim));
            setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
            setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            setAnimationStyle(R.style.popup_window_style);
            setBackgroundDrawable(new BitmapDrawable());
            setFocusable(true);
            setOutsideTouchable(true);
            setContentView(rootView);

            initView();
        }

        private void initView()
        {
            mLLBottomGift = (ViewGroup) rootView.findViewById(R.id.ll_bottom_gift);
            mGoldCount = (TextView) rootView.findViewById(R.id.tv_gold_count);
            mLLGoldCoin = (LinearLayout) rootView.findViewById(R.id.ll_gold_coin);
            mBtnSend = (Button) rootView.findViewById(R.id.btn_send);
            mTVSend = (TextView) rootView.findViewById(R.id.tv_send);
            mGiftLayout = (GiftLayout) rootView.findViewById(R.id.gift_layout);

            mGoldCount.setText(currentCoin + "");

            mLLGoldCoin.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    if (YNBaseActivity.isConnectNet)
                    {
                        Intent intent = new Intent();
                        // 需要判断用户是否登录
                        if (AccountUtils.getLoginInfo())
                        {
                            intent.setClass(getActivity(), YNGoldCoinActivity.class);
                            startActivity(intent);
                        }
                        else
                        {
                            intent.setClass(getActivity(), YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.no_net));
                    }
                }
            });

            mTVSend.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    mGiftPopupWindows.dismiss();
                    gift = mGiftLayout.getGiftBean();
                    giftIndex = mGiftLayout.index();
                    if (YNBaseActivity.isConnectNet)
                    {
                        if (liveRoomBean.getLiving() == 1)
                        {
                            // 判断账户余额是否足够支付
                            if (AccountUtils.getLoginInfo())
                            {
                                if (currentCoin >= gift.getGiftCount())
                                {
                                    handler.post(new Runnable()
                                    {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance().liveRoomSendGift(getActivity(), YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId,
                                                    liveRoomBean.getUserid(), gift.getGiftName(), 1, gift.getGiftCount(), giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                        }
                                    });
                                }
                                else
                                {
                                    YNToastMaster.showToast(getActivity(), "您的余额不足，请及时充值");
                                }

                            }
                            else
                            {
                                Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                                startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                                startActivity(intent);
                            }
                        }
                        else
                        {
                            YNToastMaster.showToast(getActivity(), "主播不在线，无法赠送礼物");
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.no_net));
                    }
                }
            });
        }
    }


    /**
     * 显示底部分享弹出框
     */
    private void showSharePopupWindow()
    {
        mPopupWindows = new YNPopupWindows(getActivity(), R.layout.popwindow_share);
        // 设置layout在PopupWindow中显示的位置
        mPopupWindows.showAtLocation(mLLBottomShare, Gravity.BOTTOM , 0, 0);
    }

    /**
     * 分享弹出框
     */
    private class YNPopupWindows extends PopupWindow implements View.OnClickListener {
        private View rootView;

        private TextView mTVShareWeChat;
        private TextView mTVShareFriendsCircle;
        private TextView mTVShareQQ;
        private TextView mTVShareSinaBlog;

        public YNPopupWindows(Context context, int itemLayoutId) {
            super(context);

            rootView = View.inflate(context, itemLayoutId, null);
            rootView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.popup_window_anim));
            setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
            setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            setAnimationStyle(R.style.popup_window_style);
            setBackgroundDrawable(new BitmapDrawable());
            setFocusable(true);
            setOutsideTouchable(true);
            setContentView(rootView);

            initView();
        }

        private void initView()
        {
            mLLBottomShare = (LinearLayout) rootView.findViewById(R.id.ll_bottom_share);
            mTVShareWeChat = (TextView) rootView.findViewById(R.id.tv_share_wechat);
            mTVShareFriendsCircle = (TextView) rootView.findViewById(R.id.tv_share_friends_circle);
            mTVShareQQ = (TextView) rootView.findViewById(R.id.tv_share_qq);
            mTVShareSinaBlog = (TextView) rootView.findViewById(R.id.tv_share_sina);

            mTVShareWeChat.setOnClickListener(this);
            mTVShareFriendsCircle.setOnClickListener(this);
            mTVShareQQ.setOnClickListener(this);
            mTVShareSinaBlog.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.tv_share_wechat:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.WEIXIN)
//                                .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_friends_circle:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
//                                .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_qq:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.QQ)
//                                .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_sina:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.QZONE)
//                                .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;
            }
            mPopupWindows.dismiss();
        }
    }

    private void initShareContent()
    {
        String shareUrl;
        if (userId.equals(liveRoomBean.getUserid()))
            shareUrl = AccountUtils.getShareAddress() + "?ID=" + liveRoomBean.getUserid();
        else
            shareUrl = AccountUtils.getShareAddress() + "?ID=" + liveRoomBean.getUserid() + "&shareID=" + userId;
        web = new UMWeb(shareUrl);
        web.setTitle("[" + liveRoomBean.getUsername() + "] 正在直播中...");
        web.setThumb(new UMImage(getActivity(), R.mipmap.app_logo));
//        web.setDescription(liveRoomBean.getDescribe() + "尽在[" + liveRoomBean.getUsername() + "] 的直播间");
        web.setDescription(liveRoomBean.getDescribe());
    }

    private UMShareListener shareListener = new UMShareListener()
    {
        @Override
        public void onStart(SHARE_MEDIA platform)
        {
            SocializeUtils.safeShowDialog(shareDialog);
        }

        @Override
        public void onResult(SHARE_MEDIA platform)
        {
            SocializeUtils.safeCloseDialog(shareDialog);
            YNToastMaster.showToast(getActivity(), "成功了");
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t)
        {
            SocializeUtils.safeCloseDialog(shareDialog);
            YNToastMaster.showToast(getActivity(), "失败"+t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform)
        {
            SocializeUtils.safeCloseDialog(shareDialog);
            YNToastMaster.showToast(getActivity(), "取消了");
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(getActivity()).onActivityResult(requestCode,resultCode,data);
        if (requestCode == YNCommonConfig.ACTIVITY_RESULT)
        {
            loginRefreshUI();
        }
    }

    @Override
    protected void onResumeLazy()
    {
//        if (AccountUtils.getLoginInfo())
//        {
//            userId = AccountUtils.getAccountBean().getId();
//            userName = AccountUtils.getAccountBean().getUsername();
//            userImg = AccountUtils.getAccountBean().getIcon();
//            loginRefreshUI();
//        }
//        else
//        {
//            userId = System.currentTimeMillis() + "";
//            userName = "游客<" + YNCommonUtils.getRandomNumber() + ">";
//            userImg = "http://www.qqw21.com/article/uploadpic/2012-9/201291893228996.jpg";
//        }
//
//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().getRongCloudToken(getActivity(), YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId,
//                        userName, userImg, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, true, 500);
//            }
//        });
        super.onResumeLazy();
    }

    @Override
    public void onDestroy()
    {
        UMShareAPI.get(getActivity()).release();
        LiveKit.removeEventHandler(handler);
        LiveKit.quitChatRoom(new RongIMClient.OperationCallback()
        {
            @Override
            public void onSuccess()
            {

            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {

            }
        });
        LiveKit.logout();
        super.onDestroy();
    }

    private void loginRefreshUI()
    {
        if (AccountUtils.getLoginInfo())
        {
            Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
            intent.putExtra("liveRoom", true);
            LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);

            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();
            userImg = AccountUtils.getAccountBean().getIcon();

            if (userId.equals(liveRoomBean.getUserid()))
            {
                mIVGift.setVisibility(View.INVISIBLE);
                mIVThumb.setVisibility(View.INVISIBLE);
                mIVEvaluate.setVisibility(View.INVISIBLE);
            }

            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getRongCloudToken(getActivity(), YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId,
                            userName, userImg, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
                }
            });

            takePartInLiveRoom();

            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getCurrentGoldCoin(getActivity(), YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, handler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

                }
            });
        }

    }

    /**
     * 参与直播间
     */
    private void takePartInLiveRoom()
    {
        if (liveRoomBean.getLiving() == 1)
        {
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().liveRoomTakePartIn(getContext(), YNCommonConfig.LIVE_ROOM_TAKE_PART_IN_URL, userId, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_LIVE_ROOM_TAKE_PART_IN_FLAG, false);
                }
            });
        }
    }

    /**
     * 聊天室重新加入
     * @param liveRoomBean
     */
    private void quitChatRoom(final LiveRoomBean liveRoomBean)
    {
        if (liveRoomBean.getLiving() == 1)
        {
            joinChatRoom(liveRoomBean.getRoom_id(), -1);
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().liveRoomTakePartIn(getContext(), YNCommonConfig.LIVE_ROOM_TAKE_PART_IN_URL, userId, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_LIVE_ROOM_TAKE_PART_IN_FLAG, false);
                }
            });
        }
    }
}
