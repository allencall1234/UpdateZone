package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import me.iwf.photopicker.entity.Photo;

/**
 * 认证时填写经历界面
 * Created by Administrator on 2017/6/6.
 */
public class WriteExperienceActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mETContent;
    private TextView mTVNumberWords;
    private String title;
    private String content;
    private Intent intent;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.RELEASE_LIVE_NOTICE_FLAG:
                    getRightTV().setClickable(true);
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 108)
                        {
                            YNToastMaster.showToast(WriteExperienceActivity.this, "发布公告成功", Toast.LENGTH_SHORT, Gravity.CENTER);
                            mETContent.setText("");
                            intent.putExtra(YNCommonConfig.OBJECT, content);
                            setResult(YNCommonConfig.ACTIVITY_RESULT, intent);
                            finish();
                        }
                        else
                        {
                            YNToastMaster.showToast(WriteExperienceActivity.this, "发布公告失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(WriteExperienceActivity.this, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_experience);
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        intent = this.getIntent();
//        content = intent.getStringExtra(YNCommonConfig.OBJECT);
        title = intent.getStringExtra(YNCommonConfig.TITLE);

        configTopBarCtrollerWithTitle(title);

        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(R.string.save);
        getRightTV().setTextColor(Color.parseColor("#006cc8"));

        mETContent = (EditText) findViewById(R.id.et_content);
        mTVNumberWords = (TextView) findViewById(R.id.tv_number_words);

        if (getString(R.string.room_notice).equals(title))
        {
            // 设置最大输入内容的数量
            mETContent.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});
            mTVNumberWords.setText("1~60字");
        }
        else
        {
            mETContent.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
            mTVNumberWords.setText("1~500字");
        }
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);

        mETContent.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {

            }

            @Override
            public void afterTextChanged(Editable s)
            {
                content = s.toString();
                if (!content.isEmpty() && !TextUtils.isEmpty(content.toString().trim()))
                {
                    getRightTV().setTextColor(ContextCompat.getColor(WriteExperienceActivity.this, R.color.live_details_text_blue));
                    getRightTV().setClickable(true);
                }
                else
                {
                    getRightTV().setTextColor(Color.parseColor("#006cc8"));
                    getRightTV().setClickable(false);
                }
            }
        });
    }



    @Override
    protected void settingDo() {
        super.settingDo();
    }

    // 发布直播公告
    private void releaseLiveNotice()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().releaseLiveNotice(WriteExperienceActivity.this, YNCommonConfig.RELEASE_LIVE_NOTICE_URL, AccountUtils.getAccountBean().getRoom_id(),
                        content, mHandler, YNCommonConfig.RELEASE_LIVE_NOTICE_FLAG, true);
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                YNCommonUtils.hideSoftInput(this, view);
                break;

            case R.id.star_1_com_topbar_tv_right:
                if (TextUtils.isEmpty(content))
                {
                    YNToastMaster.showToast(this, "内容不能为空", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (getString(R.string.room_notice).equals(title))
                {
                    getRightTV().setClickable(false);
                    releaseLiveNotice();
                }
                else
                {
                    intent.putExtra(YNCommonConfig.OBJECT, content);
                    setResult(YNCommonConfig.ACTIVITY_RESULT, intent);
                    finish();
                }
                break;
        }
    }
}

