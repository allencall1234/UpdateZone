package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 账户安全界面
 * Created by Administrator on 2017/7/17.
 */
public class YNAccountSafeActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout mRLUpdatePass;
    private RelativeLayout mRLPhoneBind;
//    private RelativeLayout mRLEmailBind;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_safe);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.account_safe));

        mRLUpdatePass = (RelativeLayout) findViewById(R.id.rl_update_pass);
        mRLPhoneBind = (RelativeLayout) findViewById(R.id.rl_phone_bind);
//        mRLEmailBind = (RelativeLayout) findViewById(R.id.rl_email_bind);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLUpdatePass.setOnClickListener(this);
        mRLPhoneBind.setOnClickListener(this);
//        mRLEmailBind.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.rl_update_pass:
                intent.setClass(this, YNSetPasswordActivity.class);
                intent.putExtra(YNCommonConfig.PHONE_NUMBER, AccountUtils.getAccountBean().getPhone());
                intent.putExtra(YNCommonConfig.FORGET_PASS, false);
                startActivity(intent);
                break;

            case R.id.rl_phone_bind:
                intent.setClass(this, YNBindPhoneActivity.class);
                startActivity(intent);
                break;

//            case R.id.rl_email_bind:
//                intent.setClass(this, YNBindEMailBoxActivity.class);
//                startActivity(intent);
//                break;
        }

    }
}
