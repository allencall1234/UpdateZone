package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.FindCategaryBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.fragment.BaseFragment;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.mContext;
import static com.yeneikeji.ynzhibo.utils.YNJsonUtil.JsonToLBean;

/**
 * 发现->家教界面
 * Created by Administrator on 2016/8/18.
 */
public class FamilyEducationFindFragment
        extends BaseFragment
        implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private SmoothListView mListView;
    private RelativeLayout mRLEmpty;
    private ImageView      mIVEmpty;
    private TextView       mTVEmpty;
    private TextView       mTVRefreshNet;
    private List<FindCategaryBean> mFindTeachList = new ArrayList<>();
    private CommonAdapter mTeachAdapter;
    private FindCategaryBean             findCategaryBean;

    public static final String TAG = "FinancialFindFragment";
    private String    userId="";
    private YNPayDialog  buytDialog;
    private String       toBuyArticalaid;//记录要买文章的aid
    private String       toBuyArticalCoin;//记录要买文章的费用，以便更新本地保存的用户余额状态
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_FIND_FIRST_PAGE_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) {
                            mRLEmpty.setVisibility(View.GONE);
                            mListView.setVisibility(View.VISIBLE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array = jsonObject.optJSONArray("data");
                                if (array != null)
                                {
                                    Type type = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                    mFindTeachList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    mTeachAdapter.updateListView(mFindTeachList);
                                }
                            }
                            catch (JSONException e)
                            {
                                mRLEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        } else {

                            mRLEmpty.setVisibility(View.VISIBLE);
                        }
                    } else {
                        mRLEmpty.setVisibility(View.VISIBLE);
                    }
                    onStopLoad();
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) {
                            try {
                                if (mFindTeachList != null) {
                                    mFindTeachList.removeAll(mFindTeachList);
                                }
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array      = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<FindCategaryBean>>() {}.getType();
                                mFindTeachList = JsonToLBean(array.toString(), type);
                                mTeachAdapter.updateListView(mFindTeachList);
                            } catch (JSONException e) {
                                mRLEmpty.setVisibility(View.VISIBLE);
                                e.printStackTrace();
                            }
                        } else {
                            mRLEmpty.setVisibility(View.VISIBLE);
                            if (mFindTeachList != null) {
                                mFindTeachList.removeAll(mFindTeachList);

                            }
                        }
                    } else {
                        mRLEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    mListView.stopRefresh();
                    break;
                //购买文章
                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null) {

                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 102) {
                            //购买成功
                            Toast.makeText(getActivity(), "购买成功", Toast.LENGTH_SHORT)
                                 .show();
                            for (FindCategaryBean bean : mFindTeachList) {
                                if (toBuyArticalaid.equals(bean.getId())) {
                                    bean.setIs_purchase(1);
                                    //刷新数据
                                    mTeachAdapter.notifyDataSetChanged();
                                    //跳转到文章详情页面
                                    Intent intent = new Intent(getActivity(),
                                                               ArticalDetailsActivity.class);
                                    intent.putExtra("aid", toBuyArticalaid);
                                    getActivity().startActivity(intent);
                                    break;
                                }
                            }
                        }
                    } else {
                        YNToastMaster.showToast(getActivity(),
                                                "购买失败",
                                                Toast.LENGTH_SHORT,
                                                Gravity.CENTER);
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };
    protected void addEvents()
    {
        mRLEmpty.setOnClickListener(this);
        mTVRefreshNet.setOnClickListener(this);
        mListView.setLoadMoreEnable(false);
        mListView.setSmoothListViewListener(this);
        mListView.setOnScrollListener(new SmoothListView.OnSmoothScrollListener() {
            @Override
            public void onSmoothScrolling(View view)
            {

            }
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
                // 当不滚动时
                if (scrollState == NumberPicker.OnScrollListener.SCROLL_STATE_IDLE) {
                    //判断是否滚动到底部
                    if (view.getLastVisiblePosition() == view.getCount() - 1) {
                        //                        YNToastMaster.showToast(mContext, "滚动到底部");
                        onLoadMore();
                    }
                }
            }
            @Override
            public void onScroll(AbsListView view,
                                 int firstVisibleItem,
                                 int visibleItemCount,
                                 int totalItemCount)
            {

            }
        });
    }

    @Override
    protected void onResumeLazy() {
        if (AccountUtils.getLoginInfo()) {
            userId = AccountUtils.getAccountBean()
                                 .getId();
        }
    }

    protected void settingDo()
    {
        if (AccountUtils.getLoginInfo()) {
            userId = AccountUtils.getAccountBean()
                                 .getId();
        }

        if (!YNBaseActivity.isConnectNet)
        {
            mRLEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mRLEmpty.setVisibility(View.GONE);
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("点击屏幕刷新界面~");

            mHandler.post(new Runnable()
            {
                @Override
                public void run() {
                    UserHttpUtils.newInstance()
                                 .getFindFirstPageTeach(getActivity(),
                                                        YNCommonConfig.GET_FIND_FIRST_PAGE_TEACH_URL,
                                                        userId,
                                                        mHandler,
                                                        YNCommonConfig.GET_FIND_FIRST_PAGE_FLAG,
                                                        true);
                }
            });
        }

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                //判断是否需要付费
                FindCategaryBean findCategaryBean = mFindTeachList.get(position - 1);
                //判断是否需要购买(设置是收费且是未购买)
                if (findCategaryBean.getIs_pay()
                                    .equals("0") || findCategaryBean.getIs_purchase() == 1)
                {
                    Intent intent = new Intent(getActivity(), ArticalDetailsActivity.class);
                    intent.putExtra("aid", findCategaryBean.getId());
                    startActivity(intent);
                } else {
                    //登录了才能判断
                    if (AccountUtils.getLoginInfo()) {
                        //需要购买,如果是自己发表的文章那个就不需要支付了
                        if (AccountUtils.getAccountBean()
                                        .getId()
                                        .equals(findCategaryBean.getUserid()))
                        {
                            Intent intent = new Intent(getActivity(), ArticalDetailsActivity.class);
                            intent.putExtra("aid", findCategaryBean.getId());
                            startActivity(intent);
                        } else {
                            //需要购买才能进入文章详情
                            showBuyDialog(findCategaryBean.getPayCoin(), findCategaryBean.getId());
                        }

                    } else {
                        //跳转到登录界面
                        Intent intent = new Intent(getActivity(), YNLoginActivity.class);
                        startActivity(intent);
                    }
                    Intent intent = new Intent(getActivity(), ArticalDetailsActivity.class);
                    intent.putExtra("aid", findCategaryBean.getId());
                    startActivity(intent);
                }
            }
        });

        mTeachAdapter = new CommonAdapter<FindCategaryBean>(getContext(), mFindTeachList, R.layout.item_upbringing)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, FindCategaryBean item)
            {
                viewHolder.setText(R.id.tv_education_title, item.getTitle());
                viewHolder.setText(R.id.tv_education_content, item.getContent());
                viewHolder.setText(R.id.tv_education_author, item.getUsername());
                viewHolder.setText(R.id.tv_education_time, DateUtil.timeStamp2StringSHort(item.getTime()));
                //不收费或者已经购买了就不显示金币
                if(!(item.getPayCoin()).equals("0")||item.getIs_purchase()==0){
                    viewHolder.setTextVisible(R.id.tv_education_paycoin,false);
                }else {
                    viewHolder.setTextVisible(R.id.tv_education_paycoin,true);
                    viewHolder.setText(R.id.tv_education_paycoin, item.getPayCoin()+"金币");
                }
                final List<PhotoInfoBean> photos = new ArrayList<>();

                if (item.getPicture() == null)
                {
                    viewHolder.getView(R.id.iv_education_picture).setVisibility(View.GONE);
                }
                else
                {
                    viewHolder.getView(R.id.iv_education_picture).setVisibility(View.VISIBLE);
                    for (int i = 0; i < item.getPicture().size(); i++)
                    {
                        photos.add(new PhotoInfoBean(item.getPicture().get(i).getBig(), item.getPicture().get(i).getSmall(), 640, 792));
                    }
                }
                ((MultiImageView)viewHolder.getView(R.id.iv_education_picture)).setList(photos);
                ((MultiImageView)viewHolder.getView(R.id.iv_education_picture)).setOnItemClickListener(new MultiImageView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(View view, int position)
                    {
                        ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());
                        List<String> photoUrls = new ArrayList<>();
                        for (PhotoInfoBean photoInfo : photos)
                        {
                            photoUrls.add(photoInfo.getBig());
                        }
                        ImagePagerActivity.startImagePagerActivity(getActivity(), photoUrls, position, imageSize);
                    }

                });
            }
        };

        mListView.setAdapter(mTeachAdapter);
    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId()) {

            case R.id.tv_refresh_net:

            case R.id.empty:
                if (YNBaseActivity.isConnectNet) {
                    mRLEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有内容，点击屏幕刷新界面~");
                        mHandler.post(new Runnable() {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance()
                                             .getFindFirstPageTeach(getActivity(),
                                                                    YNCommonConfig.GET_FIND_FIRST_PAGE_TEACH_URL,
                                                                  userId,
                                                                    mHandler,
                                                                    YNCommonConfig.ON_REFRESH,
                                                                    true);
                            }
                        });

                }
                //                else {
                //                    YNToastMaster.showToast(mContext, "网络未连接");
                //                }
                break;
        }
    }

    @Override
    public void onRefresh()
    {
        if (!YNBaseActivity.isConnectNet) {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        } else {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("暂时没有内容，点击屏幕刷新界面~");
        }
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance()
                                 .getFindFirstPageTeach(getActivity(),
                                                        YNCommonConfig.GET_FIND_FIRST_PAGE_TEACH_URL,
                                                        userId,
                                                        mHandler,
                                                        YNCommonConfig.ON_REFRESH,
                                                        true);
                }
            });
    }

    @Override
    public void onLoadMore() {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    protected void initView()
    {
        mListView = (SmoothListView) findViewById(R.id.mListView);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) findViewById(R.id.tv_refresh_net);
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_recomment;
    }

    @Override
    protected void loadData() {
        addEvents();
        settingDo();
    }
    public void showBuyDialog(final String payCoin, final String aid) {
        buytDialog = new YNPayDialog.Builder(getActivity()).setHeight(0.3f)  //屏幕高度*0.3
                                                           .setWidth(0.65f)  //屏幕宽度*0.65
                                                           .setTitleVisible(true)
                                                           .setTitleText("温馨提示")
                                                           .setTitleTextColor(R.color.black_light)
                                                           .setContentText("此文章需要付费" + payCoin + "金币，是否付费阅读？")
                                                           .setContentTextColor(R.color.black_light)
                                                           .setLeftButtonText("取消")
                                                           .setLeftButtonTextColor(R.color.ynkj_black)
                                                           .setRightButtonText("确定")
                                                           .setRightButtonTextColor(R.color.live_details_text_blue)
                                                           .setCanceledOnTouchOutside(false)
                                                           .setOnclickListener(new IDialogOnClickListener() {
                                                               @Override
                                                               public void clickTopLeftButton(View view)
                                                               {

                                                               }

                                                               @Override
                                                               public void clickTopRightButton(View view)
                                                               {

                                                               }

                                                               //取消
                                                               @Override
                                                               public void clickBottomLeftButton(
                                                                       View view)
                                                               {

                                                                   buytDialog.dismiss();
                                                               }

                                                               //确定
                                                               @Override
                                                               public void clickBottomRightButton(
                                                                       View view)
                                                               {
                                                                   if (AccountUtils.getLoginInfo()) {
                                                                       //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                                                                       if (AccountUtils.getAccountBean()
                                                                                       .getCurrentCoin() > Integer.parseInt(
                                                                               payCoin))
                                                                       {
                                                                           toBuyArticalaid = aid;
                                                                           toBuyArticalCoin = payCoin;
                                                                           mHandler.post(new Runnable() {
                                                                               @Override
                                                                               public void run()
                                                                               {
                                                                                   UserHttpUtils.newInstance()
                                                                                                .buyArticle(
                                                                                                        getActivity(),
                                                                                                        YNCommonConfig.BUY_ARTICLE_URL,
                                                                                                        aid,
                                                                                                        userId,
                                                                                                        Integer.parseInt(
                                                                                                                payCoin),
                                                                                                        mHandler,
                                                                                                        YNCommonConfig.BUY_ARTICLE_FLAG,
                                                                                                        false);
                                                                               }
                                                                           });
                                                                           buytDialog.dismiss();

                                                                       } else {
                                                                           Toast.makeText(
                                                                                   getActivity(),
                                                                                   "您的余额不足，请充值后再购买",
                                                                                   Toast.LENGTH_SHORT)
                                                                                .show();
                                                                       }
                                                                   } else {
                                                                       Toast.makeText(getActivity(),
                                                                                      "请先登录哦，亲",
                                                                                      Toast.LENGTH_SHORT)
                                                                            .show();
                                                                       Intent intent = new Intent(
                                                                               getActivity(),
                                                                               YNLoginActivity.class);
                                                                       startActivity(intent);
                                                                       buytDialog.dismiss();
                                                                   }
                                                               }

                                                               @Override
                                                               public void clickBottomButton(View view)
                                                               {

                                                               }
                                                           })
                                                           .build();
        buytDialog.show();
    }
}
