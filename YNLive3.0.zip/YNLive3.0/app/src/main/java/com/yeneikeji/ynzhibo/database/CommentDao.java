package com.yeneikeji.ynzhibo.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.yeneikeji.ynzhibo.model.CommentBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/5/8.
 */
public class CommentDao
{
    public static final String TABLE_NAME = "comment";
    public static final String COLUMN_NAME_ID = "id";
    public static final String COLUMN_NAME_USER_ID = "user_id";
    public static final String COLUMN_NAME_CID = "cid";
    public static final String COLUMN_NAME_CONTENT = "content";
    public static final String COLUMN_NAME_TIME = "time";
    public static final String COLUMN_NAME_ICON = "icon";
    public static final String COLUMN_NAME_USERNAME = "username";
    public static final String COLUMN_NAME_IS_READ = "is_read";

    private DbOpenHelper dbHelper;

    public CommentDao(Context context) {
        dbHelper = DbOpenHelper.getInstance(context);
    }

    /**
     * 保存评论、点赞list
     * @param commentList
     */
    public void saveCommentList(List<CommentBean> commentList)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if (db.isOpen())
        {
//            db.delete(TABLE_NAME, null, null);
            for (CommentBean comment : commentList)
            {
                ContentValues values = new ContentValues();
                values.put(COLUMN_NAME_ID, comment.getId());
                values.put(COLUMN_NAME_USER_ID, comment.getUserid());
                values.put(COLUMN_NAME_CID, comment.getCid());
                values.put(COLUMN_NAME_CONTENT, comment.getContent());
                values.put(COLUMN_NAME_TIME, comment.getTime());
                values.put(COLUMN_NAME_ICON, comment.getIcon());
                values.put(COLUMN_NAME_USERNAME, comment.getUsername());
                values.put(COLUMN_NAME_IS_READ, comment.getIsRead());
                db.insert(TABLE_NAME, null, values);
            }
            dbHelper.closeDb();
        }
    }

    /**
     * 获取评论、点赞list
     * @return
     */
    public List<CommentBean> getCommentList()
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<CommentBean> comments = new ArrayList<CommentBean>();
        if(db.isOpen()){
            Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " desc",null);
            while(cursor.moveToNext()){
                CommentBean commentBean = new CommentBean();
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_ID));
                int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_USER_ID));
                int cid = cursor.getInt(cursor.getColumnIndex(COLUMN_NAME_CID));
                String content = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_CONTENT));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_TIME));
                String icon = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_ICON));
                String username = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_USERNAME));
                String is_read = cursor.getString(cursor.getColumnIndex(COLUMN_NAME_IS_READ));

                commentBean.setId(String.valueOf(id));
                commentBean.setUserid(String.valueOf(userId));
                commentBean.setCid(String.valueOf(cid));
                commentBean.setContent(content);
                commentBean.setTime(time);
                commentBean.setIcon(icon);
                commentBean.setUsername(username);
                commentBean.setIsRead(is_read + "");

                comments.add(commentBean);
            }
            cursor.close();
            dbHelper.closeDb();
        }
        return comments;
    }

    /**
     * 更新评论、点赞
     * @param commentId
     * @param values
     */
    public void updateCommentOrThumb(int commentId, ContentValues values){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if(db.isOpen())
        {
            db.update(TABLE_NAME, values, COLUMN_NAME_ID + " = ?", new String[]{String.valueOf(commentId)});
            dbHelper.closeDb();
        }
    }

    /**
     * 删除一个评论、点赞
     * @param commentId
     */
    public void deleteCommentOrThumb(int commentId)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if(db.isOpen())
        {
            db.delete(TABLE_NAME, COLUMN_NAME_ID + " = ?", new String[] {String.valueOf(commentId)});
            dbHelper.closeDb();
        }
    }

}
