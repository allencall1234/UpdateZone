package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.TotalWealthEpAdapter;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserWealthBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.yeneikeji.ynzhibo.http.YNCommonConfig.GET_TOTALL_WEALTH_FLAG;

public class TotalWealthIncome
        extends YNBaseTopBarActivity
        implements View.OnClickListener, ExpandableListView.OnGroupClickListener
{
    private TextView                                         mTotalWealth;
    private ExpandableListView                               mTotalWealthEplistview;
    private    List<UserWealthBean.DataBean.YeIncomeBean> yeIncome ;
    private    List<UserWealthBean.DataBean.YeIncomeBean> datas ;
    private UserWealthBean       totallWealthBean;
    private int mCurrentYear;
    private int mCurrentMonth;
    private int mCurrentDay;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case GET_TOTALL_WEALTH_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {

                            try {
                               /* JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array      = jsonObject.getJSONArray("data");
                                Type       type       = new TypeToken<List<UserWealthBean>>() {}.getType();
                                myWealth = YNJsonUtil.JsonToLBean(array.toString(), type);*/
                                // JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                Gson gson =new Gson();

                                totallWealthBean =gson.fromJson(msg.obj.toString(),
                                                                                  UserWealthBean.class);
                                /***封装数据**/
                                 yeIncome = totallWealthBean.getData().getYeIncome();
                                if(yeIncome!=null){
                                    datas=yeIncome;
                                }else{
                                    datas=new ArrayList();
                                }
                                TotalWealthEpAdapter adapter =new TotalWealthEpAdapter(TotalWealthIncome.this,  datas);
                                mTotalWealthEplistview.setAdapter(adapter);

                             //   for(int i=0;i<3;i++){
                              // }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(context, "网络请求错误，请重试", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {

                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_wealth_income);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initMyView();
        initialData();
        addListenener();

        /***设置ExpendingListview没有默认箭头**/
        mTotalWealthEplistview.setGroupIndicator(null);
        /***设置ExpendingListview的适配器**/

    }

    private void initMyView() {
        String total=getIntent().getStringExtra("total");
        configTopBarCtrollerWithTitle("累计财富");
        mTotalWealth = (TextView) findViewById(R.id.tv_total_wealth);
        mTotalWealth.setText(total);
        /*TotalWealth_expandablelistview*/
        mTotalWealthEplistview = (ExpandableListView) findViewById(R.id.TotalWealth_expandablelistview);
        Calendar calendar =Calendar.getInstance();
        //获得当前时间的月份，月份从0开始所以结果要加1
        mCurrentYear = calendar.get(Calendar.YEAR);
        mCurrentMonth = calendar.get(Calendar.MONTH)+1;
        mCurrentDay = calendar.get(Calendar.DAY_OF_MONTH);
        int type =mCurrentYear*10000+mCurrentMonth*100+mCurrentDay;
        getData(type);

    }
    private void getData(final int type) {

        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getMyWealthIncome(TotalWealthIncome.this,
                                                YNCommonConfig.GET_MYWEALTH_INCOMING_URL,
                                                AccountUtils.getAccountBean()
                                                            .getId(),
                                                type,
                                                handler,
                                                GET_TOTALL_WEALTH_FLAG,false);
            }
        });

    }

    private void addListenener() {

        getLeftBtn().setOnClickListener(this);
        mTotalWealthEplistview.setOnGroupClickListener(this);
    }

    //点击事件处理
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            default:
                break;
        }
    }


    private void initialData() {
      //  groupArray = new ArrayList<String>();
      //  childArray = new ArrayList();
       // groupArray.add("2017年");
       // groupArray.add("2016年");
        //groupArray.add("2015年");

    }


    // 记录之前打开的外层条目的脚标
    private int lastPosition = -1;
    @Override
    public boolean onGroupClick(ExpandableListView parent, View v,
                                int groupPosition, long id) {
        // 没有一个条目被展开,点击一个条目就展开一个条目

        if (lastPosition == -1) {
            // 展开一个外层的条目
            mTotalWealthEplistview.expandGroup(groupPosition);
            // 重新赋值
            lastPosition = groupPosition;
        } else {
            // 有一个条目被展开,点击同一个条目, 就关闭该条目
            if (lastPosition == groupPosition) {
                // 关闭一个外层的条目
                mTotalWealthEplistview.collapseGroup(groupPosition);
                lastPosition = -1;
            } else {
                // 有一个条目被展开,点击其他条目,就关闭之前的条目,打开新的条目

                // 关闭之前的条目
                mTotalWealthEplistview.collapseGroup(lastPosition);
                // 打开新的条目
                mTotalWealthEplistview.expandGroup(groupPosition);
                lastPosition = groupPosition;

            }
        }
        return true;
    }
}
