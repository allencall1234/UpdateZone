package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.DynamicAdapter;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.YNBaseFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *  社区推荐界面
 * Created by Administrator on 2016/11/16.
 */
public class RecommendedFragment extends YNBaseFragment implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private String tag = "RecommendedFragment";

    private AppBarLayout mLayoutAppBar;
    private SmoothListView mRecommendedLV;// 推荐
    private RelativeLayout mRLRecommendedEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;
    private List<DynamicBean> recommendedList;

    private DynamicAdapter mRecommendAdapter;

    private YNCommonConfig commonConfig;

    private int totalPages = 0;
    private int curragePage = 0;// 当前页
    private String userId = null;

    @Override
    public String getFragmentName()
    {
        return tag;
    }

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_HOME_PAGE_DYNAMIC_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                totalPages = UserHttpUtils.newInstance().getTotalPages(jsonObject.getInt("count"));
                                if (curragePage + 1 >= totalPages)
                                    mRecommendedLV.setLoadMoreEnable(false);
                                else
                                    mRecommendedLV.setLoadMoreEnable(true);

                                JSONArray array = jsonObject.getJSONArray("data");
                                Type type = new TypeToken<List<DynamicBean>>() {}.getType();
                                recommendedList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                if (recommendedList.isEmpty())
                                {
                                    mRLRecommendedEmpty.setVisibility(View.VISIBLE);
                                    mRecommendedLV.setVisibility(View.GONE);
                                }
                                else
                                {
                                    mRLRecommendedEmpty.setVisibility(View.GONE);
                                    mRecommendedLV.setVisibility(View.VISIBLE);
                                }
                                mRecommendAdapter.setDynamicList(recommendedList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

//                            YNToastMaster.showToast(getActivity(), bean.getInfo());
                        }
                        else
                        {
                            mRecommendedLV.setVisibility(View.GONE);
                            mRLRecommendedEmpty.setVisibility(View.VISIBLE);
                        }
                    }
                    else
                    {
                        mRecommendedLV.setVisibility(View.GONE);
                        mRLRecommendedEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.LOAD_MORE:
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            if (curragePage + 1 >= totalPages)
                                mRecommendedLV.setLoadMoreEnable(false);
                            else
                                mRecommendedLV.setLoadMoreEnable(true);

                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.getJSONArray("data");
                                for (int i = 0; i < array.length(); i++)
                                {
                                    DynamicBean dynamicBean = YNJsonUtil.JsonToBean(array.getJSONObject(i).toString(), DynamicBean.class);
                                    recommendedList.add(dynamicBean);
                                }
                                mRecommendAdapter.setDynamicList(recommendedList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                    }
                    onStopLoad();
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (recommendedList != null)
                        recommendedList.removeAll(recommendedList);

                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28) // 请求成功
                        {
                            curragePage = 0;
                            mRecommendedLV.setVisibility(View.VISIBLE);
                            mRLRecommendedEmpty.setVisibility(View.GONE);
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                totalPages = UserHttpUtils.newInstance().getTotalPages(jsonObject.getInt("count"));
                                if (curragePage + 1 >= totalPages)
                                    mRecommendedLV.setLoadMoreEnable(false);
                                else
                                    mRecommendedLV.setLoadMoreEnable(true);

                                JSONArray array = jsonObject.getJSONArray("data");
                                Type type = new TypeToken<List<DynamicBean>>() {}.getType();
                                recommendedList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                if (recommendedList.isEmpty())
                                {
                                    mRLRecommendedEmpty.setVisibility(View.VISIBLE);
                                    mRecommendedLV.setVisibility(View.GONE);
                                }
                                else
                                {
                                    mRLRecommendedEmpty.setVisibility(View.GONE);
                                    mRecommendedLV.setVisibility(View.VISIBLE);
                                }
                                mRecommendAdapter.setDynamicList(recommendedList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }


//                            YNToastMaster.showToast(getActivity(), "刷新成功");
                        }
                        else
                        {
//                            YNToastMaster.showToast(getActivity(), "刷新失败");
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                        mRLRecommendedEmpty.setVisibility(View.VISIBLE);
                        mRecommendedLV.setVisibility(View.GONE);
                    }
                    onStopLoad();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_recomment, container, false);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    protected void initView(View view)
    {
//        mLayoutAppBar = (AppBarLayout) view.findViewById(R.id.layout_appbar);
        mRecommendedLV = (SmoothListView) view.findViewById(R.id.mListView);
        mRLRecommendedEmpty = (RelativeLayout) view.findViewById(R.id.empty);
        mIVEmpty = (ImageView) view.findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) view.findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) view.findViewById(R.id.tv_refresh_net);

//        mRecommendedLV.addHeaderView(addRecommendedHeadView());

//        mLayoutAppBar.setVisibility(View.GONE);
        mRecommendedLV.setVisibility(View.GONE);
    }

    /**
     * 添加头部推荐布局
     */
    private View addRecommendedHeadView()
    {
        View headView = getActivity().getLayoutInflater().inflate(R.layout.dynamic_headview, null);
        return  headView;
    }

    @Override
    public void onResume()
    {
//        if (!NetUtils.isConnected(mContext))
//        {
//            mIVEmpty.setImageResource(R.drawable.refresh_cat);
//            mTVEmpty.setText("当前网络未连接~");
//        }
//        else
//        {
//            mIVEmpty.setImageResource(R.drawable.blank);
//            mTVEmpty.setText("空的，什么都没有~");
//        }
        super.onResume();
    }

    @Override
    protected void addEvents()
    {
        mRecommendedLV.setLoadMoreEnable(false);// 设置上拉加载
        mRecommendedLV.setSmoothListViewListener(this);
        mRLRecommendedEmpty.setOnClickListener(this);

        mRecommendedLV.setOnScrollListener(new AbsListView.OnScrollListener()
        {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
//                if(scrollState == SCROLL_STATE_IDLE)
//                {
//                    Glide.with(mContext).resumeRequests();
//                }
//                else
//                {
//                    Glide.with(mContext).pauseRequests();
//                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
            {

            }
        });

    }

    @Override
    protected void settingDo()
    {
//        presenter = new DynamicPresenter(DynamicFragmentTest.this);
        if (!YNBaseActivity.isConnectNet)
        {
            mRLRecommendedEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mRLRecommendedEmpty.setVisibility(View.GONE);
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("空的，什么也没有~");
            initListData();
        }

        mRecommendedLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if (YNBaseActivity.isConnectNet)
                {
//                    if (position >= 1)
//                    {
                        DynamicBean item = recommendedList.get(position - 1);
                        Intent intent = new Intent();
//                        intent.setClass(mContext, DynamicDetailsActivity.class);
                        intent.setClass(mContext, DynamicDetailsActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable(YNCommonConfig.OBJECT, item);
//                    bundle.putBoolean(YNCommonConfig.ISSHOW, true);
                        intent.putExtras(bundle);
                        startActivity(intent);
//                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, "网络未连接");
                }
            }
        });
    }

    /**
     * 初始化界面数据
     */
    private void initListData()
    {
        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();

        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getHomePageDynamic(getActivity(), YNCommonConfig.GET_HOME_PAGE_DYNAMIC_URL, YNApplication.deviceId, userId, curragePage, mHandler, YNCommonConfig.GET_HOME_PAGE_DYNAMIC_FLAG, true);
            }
        }, 1000);

        mRecommendAdapter = new DynamicAdapter(getActivity(), new ArrayList<DynamicBean>(), true);
        mRecommendedLV.setAdapter(mRecommendAdapter);

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.tv_refresh_net:
            case R.id.empty:
                if (YNBaseActivity.isConnectNet)
                {
                    mRLRecommendedEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("空的，什么也没有~");
                    initListData();
                }
                else
                {
                    YNToastMaster.showToast(mContext, "网络未连接");
                }
                break;
        }
    }

    @Override
    public void onRefresh()
    {
        if (!YNBaseActivity.isConnectNet)
        {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("空的，什么也没有~");
        }
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getHomePageDynamic(getActivity(), YNCommonConfig.GET_HOME_PAGE_DYNAMIC_URL, YNApplication.deviceId, userId, 0, mHandler, YNCommonConfig.ON_REFRESH, false);
            }
        }, 1000);
    }

    @Override
    public void onLoadMore()
    {
        if (curragePage + 1 < totalPages)
        {
            curragePage++;
            mHandler.postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getHomePageDynamic(getActivity(), YNCommonConfig.GET_HOME_PAGE_DYNAMIC_URL, YNApplication.deviceId, userId, curragePage, mHandler, YNCommonConfig.LOAD_MORE, false);
                }
            }, 1000);
        }
        else
        {
            mRecommendedLV.setLoadMoreEnable(false);
        }

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mRecommendedLV.stopRefresh();
        mRecommendedLV.stopLoadMore();
        mRecommendedLV.setRefreshTime(DateUtil.getNowDate());
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }
}
