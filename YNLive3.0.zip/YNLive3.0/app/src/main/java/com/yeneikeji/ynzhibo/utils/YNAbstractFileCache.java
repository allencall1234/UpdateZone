
package com.yeneikeji.ynzhibo.utils;

import android.content.Context;
import android.util.Log;

import java.io.File;

public abstract class YNAbstractFileCache {
    private Context mContext;

    private String dirString;

    public YNAbstractFileCache(Context context) {

        dirString = getCacheDir(context);
        boolean ret = YNFileUtil.createDirectory(dirString);
        Log.e("", "FileHelper.createDirectory:" + dirString + ", ret = " + ret);
    }

    public File getFile(String url, Context context) {
        File f = new File(getSavePath(url, context));
        return f;
    }

    public abstract String getSavePath(String url, Context context);

    public abstract String getCacheDir(Context context);

    public void clear() {
        YNFileUtil.deleteDirectory(dirString);
    }

}
