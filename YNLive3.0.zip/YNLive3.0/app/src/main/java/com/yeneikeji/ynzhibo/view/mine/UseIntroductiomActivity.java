package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/*
* 这是平台使用指南的类
* */
public class UseIntroductiomActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private TextView mPushToolIntroduction;
    private TextView mRoomManageIntroduction;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_use_introductiom);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("平台使用指南");
        mPushToolIntroduction = (TextView) findViewById(R.id.pushstream_tool_use_introduction);
        mRoomManageIntroduction = (TextView) findViewById(R.id.room_manage_use_introduction);

    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mPushToolIntroduction.setOnClickListener(this);
        mRoomManageIntroduction.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                 break;
            case R.id.pushstream_tool_use_introduction:
                mIntent = new Intent(UseIntroductiomActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG,"pushstreamIntroduction");
                startActivity(mIntent);
                break;

            case R.id.room_manage_use_introduction:
                mIntent = new Intent(UseIntroductiomActivity.this, YNTotalRuleDetails.class);
                mIntent.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG,"roomManageintroduction");
                startActivity(mIntent);
                break;

        }
    }
}
