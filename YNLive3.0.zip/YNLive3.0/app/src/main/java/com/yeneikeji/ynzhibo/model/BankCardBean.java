package com.yeneikeji.ynzhibo.model;

/**
 * Created by Administrator on 2017/7/26.
 */

public class BankCardBean {

    /**
     * code : 28
     * data : {"Amount":0,"bank":"福建海峡银行","cardId":"KZm7Kxj9cdQcVPZ2+tV+lmf3ibsb0TMwJvb6ZqJzMZAsBiPuTMOohg4PGS2qV4hLEuMehu4UvesisLccodVwDzfbnJCzArK0XqDtv4sxSvQMW8WrsiUNZmmEQXqC73OIXbb9RBJ9Y3NSczdNa2pu5cN549LFckzY+1zDqb9V6Jk=","id":"10004","is_card":1,"name":"暗夜","userid":"10001","wealth":"0"}
     * info : 获取数据成功！
     */

    public int code;
    public DataBean data;
    public String   info;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public static class DataBean {
        /**
         * Amount : 0
         * bank : 福建海峡银行
         * cardId : KZm7Kxj9cdQcVPZ2+tV+lmf3ibsb0TMwJvb6ZqJzMZAsBiPuTMOohg4PGS2qV4hLEuMehu4UvesisLccodVwDzfbnJCzArK0XqDtv4sxSvQMW8WrsiUNZmmEQXqC73OIXbb9RBJ9Y3NSczdNa2pu5cN549LFckzY+1zDqb9V6Jk=
         * id : 10004
         * is_card : 1
         * name : 暗夜
         * userid : 10001
         * wealth : 0
         */

        public int Amount;
        public String bank;
        public String cardId;
        public String id;
        public int    is_card;
        public String name;
        public String userid;
        public String wealth;

        public int getAmount() {
            return Amount;
        }

        public void setAmount(int amount) {
            Amount = amount;
        }

        public String getBank() {
            return bank;
        }

        public void setBank(String bank) {
            this.bank = bank;
        }

        public String getCardId() {
            return cardId;
        }

        public void setCardId(String cardId) {
            this.cardId = cardId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getIs_card() {
            return is_card;
        }

        public void setIs_card(int is_card) {
            this.is_card = is_card;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUserid() {
            return userid;
        }

        public void setUserid(String userid) {
            this.userid = userid;
        }

        public String getWealth() {
            return wealth;
        }

        public void setWealth(String wealth) {
            this.wealth = wealth;
        }
    }
}
