package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNMyTextView;

/**
 *  公共带动画的弹出框(带确定、取消按钮)
 * Created by Administrator on 2016/11/11.
 */
public class YNCommonDialog extends Dialog implements View.OnClickListener
{
    private Context context;
    boolean cancelable;

    private YNMyTextView mTVContent;
    private Button mConfirmBtn;
    private Button mCancelBtn;

    private CustomDialogListener cdListener;
    private String content;

    private  String btnLeftTxt;
    private  String btnRightTxt;

    private int contentColor;
    private String setColorContent;

    /**
     * @param context
     * @param cancelable
     * 触摸屏幕是否可以取消对话框,true:就是可以取消。FALSE：就是不可以取消。
     * 在四个主界面可以设置为true，可以取消。其他都设置为FALSE 在做网络访问和提交数据的一律设置为false
     */

    public YNCommonDialog(Context context, int themeResId, String content, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.context = context;
        this.content = content;
        this.cancelable = cancelable;
        this.cdListener = cdListener;
    }

    public YNCommonDialog(Context context, int themeResId, String content, String btnRightTxt, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.context = context;
        this.content = content;
        this.btnRightTxt = btnRightTxt;
        this.cancelable = cancelable;
        this.cdListener = cdListener;
    }

    public YNCommonDialog(Context context, int themeResId, String content, String btnLeftTxt, String btnRightTxt, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.context = context;
        this.content = content;
        this.btnLeftTxt = btnLeftTxt;
        this.btnRightTxt = btnRightTxt;
        this.cancelable = cancelable;
        this.cdListener = cdListener;
    }

    public YNCommonDialog(Context context, int themeResId, String content, String setColorContent, int contentColor, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.context = context;
        this.content = content;
        this.setColorContent = setColorContent;
        this.contentColor = contentColor;
        this.cancelable = cancelable;
        this.cdListener = cdListener;
    }

    public YNCommonDialog(Context context, int themeResId, String content, String setColorContent, int contentColor, String btnRightTxt, boolean cancelable, CustomDialogListener cdListener)
    {
        super(context, themeResId);
        this.context = context;
        this.content = content;
        this.setColorContent = setColorContent;
        this.contentColor = contentColor;
        this.btnRightTxt = btnRightTxt;
        this.cancelable = cancelable;
        this.cdListener = cdListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_cleancache);
        initView();
    }

    private void initView()
    {
        setCanceledOnTouchOutside(cancelable); //点击外部不会消失
        mTVContent = (YNMyTextView) findViewById(R.id.tv_content);
        mCancelBtn = (Button) findViewById(R.id.btnCancel);
        mConfirmBtn = (Button) findViewById(R.id.btnConfirm);

        mTVContent.setText(content);

        if (btnLeftTxt != null)
        {
            setBtnLeftTxt();
        }
        if (btnRightTxt != null)
        {
            setBtnRightTxt();
        }
        if (setColorContent != null)
        {
            setTxtColor();
        }

        mCancelBtn.setOnClickListener(this);
        mConfirmBtn.setOnClickListener(this);
    }

    public void setTxtColor()
    {
        mTVContent.setSpecifiedTextsColor(content, setColorContent, contentColor);
    }

    public void setBtnLeftTxt()
    {
        mCancelBtn.setText(btnLeftTxt);
    }

    public void setBtnRightTxt()
    {
        mConfirmBtn.setText(btnRightTxt);
    }

    @Override
    public void onClick(View v)
    {
        cdListener.OnClick(v);
    }

    public interface CustomDialogListener
    {
        void OnClick(View view);
    }
}
