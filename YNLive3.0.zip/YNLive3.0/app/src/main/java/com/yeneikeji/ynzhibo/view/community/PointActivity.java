package com.yeneikeji.ynzhibo.view.community;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.List;

/*
* 这是观点界面
* */
public class PointActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private Button mWriteNote;
    private Button mWriteVoice;
    private Intent mIntent;
    private RelativeLayout mExamineRl;
    private RelativeLayout mRefusedPoint;
    private  List<RecordVideoBean> mExamDatas;
    private  List<RecordVideoBean> mRefuseDatas;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("aaa", msg.obj.toString());
                        BaseBean   baseBean   = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        JSONObject jsonObject = null;
                        if (baseBean.getCode() ==28) {
                            try {
                                jsonObject = new JSONObject(msg.obj.toString());
                                //审核中
                                JSONArray data1 = jsonObject.optJSONArray("data1");
                                Type type = new TypeToken<List<RecordVideoBean>>() {
                                }.getType();
                                if(data1!=null) {
                                    mExamDatas = YNJsonUtil.JsonToLBean(data1.toString(), type);
                                    mExamTv.setText("正在审核中(" + mExamDatas.size() + ")");
                                    mExamTv.setTextColor(getResources().getColor(R.color.live_details_text_black));
                                }else{
                                    mExamTv.setText("正在审核中(" +0+ ")");
                                    mExamTv.setTextColor(getResources().getColor(R.color.month_wealth_tv_time));
                                }
                                //被驳回
                                JSONArray data2 = jsonObject.optJSONArray("data2");
                                Type type2 = new TypeToken<List<RecordVideoBean>>() {
                                }.getType();
                                if(data2!=null) {
                                    mRefuseDatas = YNJsonUtil.JsonToLBean(data2.toString(), type2);
                                    mRefuseTv.setText("被驳回(" + mRefuseDatas.size() + ")");
                                    mRefuseTv.setTextColor(getResources().getColor(R.color.live_details_text_black));
                                }else{
                                    mRefuseTv.setText("被驳回(" +0+ ")");
                                    mRefuseTv.setTextColor(getResources().getColor(R.color.month_wealth_tv_time));
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                    break;
            }
        }
    };
    private TextView mExamTv;
    private TextView mRefuseTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
    }

    @Override
    protected void initView() {
        configTopBarCtrollerWithTitle("观点");
        //正在审核
        mExamineRl = (RelativeLayout) findViewById(R.id.examine_ing);
        mExamTv = (TextView) findViewById(R.id.exam_tv);

        //驳回
        mRefusedPoint = (RelativeLayout) findViewById(R.id.point_has_refused);
        mRefuseTv = (TextView) findViewById(R.id.refused_tv);
        mWriteNote = (Button) findViewById(R.id.write_note);
        mWriteVoice = (Button) findViewById(R.id.write_voice);

        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getFindPointHomePage(PointActivity.this, YNCommonConfig.GET_FIND_POINT_HOME_URL,
                                                                    AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG, true);
            }
        });
    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        mExamineRl.setOnClickListener(this);
        mRefusedPoint.setOnClickListener(this);
        mWriteNote.setOnClickListener(this);
        mWriteVoice.setOnClickListener(this);

    }

    @Override
    protected void settingDo() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //跳转到正在审核的界面中去,带上标识审核中
            case R.id.examine_ing:
                if(mExamDatas!=null&&mExamDatas.size()>0) {
                    mIntent = new Intent(PointActivity.this, ExamingActivity.class);
                    mIntent.putExtra("pointType", "examing");
                    mIntent.putExtra("comefrom", (Serializable) mExamDatas);
                    if (mExamDatas != null && mExamDatas.size() > 0) {
                    }
                    startActivity(mIntent);
                }
                break;
            //跳转到正在审核的界面中去,带上标识驳回
            case R.id.point_has_refused:
                if(mRefuseDatas!=null&&mRefuseDatas.size()>0) {
                    mIntent = new Intent(PointActivity.this, ExamingActivity.class);
                    mIntent.putExtra("pointType", "refuse");
                    mIntent.putExtra("comefrom", (Serializable) mRefuseDatas);
                    if (mRefuseDatas != null && mRefuseDatas.size() > 0) {
                        startActivity(mIntent);
                    }
                }
                break;
            //跳转到发表文章
            case R.id.write_note:
                mIntent = new Intent(PointActivity.this, ArticalPublishActivity.class);
                mIntent.putExtra("pointType","edit");
                startActivity(mIntent);
                break;
            //跳转到发表语音观点
            case R.id.write_voice:
                mIntent=new Intent(PointActivity.this,VoicePointActivity.class);
                startActivity(mIntent);
                break;

        }
    }
}
