package com.yeneikeji.ynzhibo.view.live;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.florent37.viewanimator.AnimationListener;
import com.github.florent37.viewanimator.ViewAnimator;
import com.google.gson.reflect.TypeToken;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.Base;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.utils.SocializeUtils;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.ChatListAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonRecyclerViewHolder;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.adapter.YNFragmentAdapter;
import com.yeneikeji.ynzhibo.animation.HeartLayout;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.BottomPanelFragment;
import com.yeneikeji.ynzhibo.fragment.YNBaseFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.AnchorInfoBean;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.rongcloud.message.GiftMessage;
import com.yeneikeji.ynzhibo.rongcloud.message.InfoMsgView;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.AutoUtils;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.utils.FullScreenUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.UIUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.view.mine.WriteExperienceActivity;
import com.yeneikeji.ynzhibo.view.mine.YNGoldCoinActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.view.mine.YNRegisterActivity;
import com.yeneikeji.ynzhibo.widget.ChatListView;
import com.yeneikeji.ynzhibo.widget.GiftLayout;
import com.yeneikeji.ynzhibo.widget.InputPanel;
import com.yeneikeji.ynzhibo.widget.LiveLeftGiftView;
import com.yeneikeji.ynzhibo.widget.badgeview.BadgeTextView;
import com.yeneikeji.ynzhibo.widget.dialog.YNChatRoomAlertDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNEditDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLiveAlertDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLiveEvaluateDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNUnLoginLiveDialog;
import com.yeneikeji.ynzhibo.widget.videoplayer.BDCloudVideoView;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.ColorBar;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.FixedIndicatorView;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.Indicator;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.IndicatorViewPager;
import com.yeneikeji.ynzhibo.widget.viewpagerindicator.OnTransitionTextListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import io.rong.imlib.RongIMClient;
import io.rong.imlib.model.Conversation;
import io.rong.imlib.model.MessageContent;
import io.rong.imlib.model.UserInfo;
import io.rong.message.CommandNotificationMessage;
import io.rong.message.ImageMessage;
import io.rong.message.InformationNotificationMessage;
import io.rong.message.TextMessage;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * 直播间逻辑交互界面
 * Created by Administrator on 2017/5/15.
 */
public class LiveLayerFragment extends YNBaseFragment implements View.OnClickListener, Handler.Callback
{
    public static final String TAG = "LiveLayerFragment";

    private ViewGroup rellayout_root1;
    private RelativeLayout headerBar = null;
    private RelativeLayout fullHeaderRl = null;
    private RelativeLayout normalHeaderRl = null;
    private RelativeLayout controllerRL = null;
    private RelativeLayout fullControllerRl = null;
    private RelativeLayout normalControllerRl = null;

    private RelativeLayout mRLHostMsg;// 主播信息
    private ImageView mIVHostImg;// 主播头像
    private TextView mTVHostName;// 主播昵称或姓名
    private TextView mTVPageViews;//  视频浏览量或者关注数量
    private TextView mTVFollow;
    private RecyclerView horizontalRecyclerView;// 在线观众

    private ImageView mIVClose;
    private LinearLayout mLLList;
    private RelativeLayout mRLContributionList;
    private TextView mUserList;

    private LinearLayout liveContributionList;
    private RelativeLayout mRLCover;
    private ImageView mCoverImg;
    private ListView mOnLineUserList;
    private TextView mTVEmpty;

    private BottomPanelFragment bottomPanel;// 底部组件
    private LinearLayout mLLBottomLeft;
    private LinearLayout mLLBottomRight;
    private ImageView mIVSpeak;//  聊天
    private ImageView mIVShare;//  分享
    private ImageView mIVEvaluate;// 评价
    private ImageView mIVGift;
    private ImageView mIVThumb;//  点赞
//    private ImageView mIVBottomFullScreen;
    private HeartLayout heartLayout;// 心形气泡
    private ViewGroup buttonPanel;
    private InputPanel inputPanel;
    private LiveLeftGiftView leftGiftView;
    private LiveLeftGiftView leftGiftView2;
    public ImageView fullscreen;
    private ChatListView mChatListView;
    private LinearLayout mLLBtn;
    private ImageView mIVReConnection;
    private ImageView mIVHighDefinition;

    private LinearLayout mLLBottomShare;
    private ViewGroup mLLBottomGift;
    private YNPopupWindows mPopupWindows;
    private GiftPopupWindows mGiftPopupWindows;

    private LinearLayout mLLTabs;
//    private TabLayout tabs;
    private ViewPager mViewPager;
//    private Indicator mIndicator;
    private FixedIndicatorView mIndicator;
    private IndicatorViewPager indicatorViewPager;
    private View mLine;

    private TextView mGoldCount;

    private YNFragmentAdapter mFragmentAdapter;
    private ChatListAdapter mChatListAdapter;
    private MyAdapter mAdapter;

    /** Tab标题 */
    private  String[] tabTitle =  null;

    private ArrayList<Fragment> fragments;
    private LiveRoomBean liveRoomBean = null;
    private ChatRoomUserBean chatRoomUserBean = null;
    private CommonRecyclerViewAdapter mContributionAdapter;
    private List<ChatRoomUserBean> mContributionList = new ArrayList<>();
    private CommonAdapter mUserValueAdapter;
    private List<ChatRoomUserBean> mUserValueList = new ArrayList<>();
    public float currentCoin;// 当前金币
    private int isPay;// 是否付费
    private String beClickedUserId;// 被点击的人的用户id
    List<UserInfo> toShowList = Collections.synchronizedList(new LinkedList<UserInfo>());
    private int onLineNumber;// 在线人数
    private String userId;
    private String userName;
    private String userIcon;
    private int giftType = 0;
    private int thumbCount;
    private GiftBean gift;
    private int giftIndex;
    private int contributionListType = 0;
    private Context mMsgreceiveContext;

    private boolean processFlag = true; //默认可以点击
    private boolean clickManagerList = false; // 标识是否点击的是管理员列表
    public volatile boolean isFullScreen = false;
    // 显示礼物
    volatile boolean isGiftShowing = false;
    volatile boolean isGift2Showing = false;
    private boolean isAttention;
    private boolean isOpen = false;
    private boolean isShowRedPoint = false;
    private boolean isLogin = false;

    private YNLiveAlertDialog dialog;
    private YNChatRoomAlertDialog chatRoomDialog;
    private YNUnLoginLiveDialog unLoginLiveDialog;
    private YNEditDialog mInputPassDialog;
    private YNPayDialog mPayDialog;
    private YNLiveEvaluateDialog mEvaluateDialog;

    // 分享
    private ProgressDialog shareDialog;
    private UMWeb web;

    private Timer barTimer;
    private MyCount myCount;

    private Handler handler = new Handler(this);
    private Random random = new Random();
    private AnimatorSet animatorSetHide = new AnimatorSet();
    private AnimatorSet animatorSetShow = new AnimatorSet();

    private MessageReceiver mAskReplayMessageReceiver;
//    public static final String MESSAGE_RECEIVED_ACTION = "com.yeneikeji.ynzhibo.MESSAGE_RECEIVED_ACTION";
    public static final String MESSAGE_RECEIVED_ACTION = "MESSAGE_ASK_REPLAY_ACTION";

    private LocalBroadcastManager broadcastManager;
    private BroadcastReceiver mRefreshReceiver;

    ChatFragment chatFragment;
    AskQuestionFragment askQuestionFragment;
    private int pageSelectedIndex = -1;
    private boolean isPhoneLiving = false;
    private boolean isShowFullScreen = false;

    @Override
    public boolean handleMessage(Message msg)
    {
        switch (msg.what)
        {
            case LiveKit.MESSAGE_SENT:
            case LiveKit.MESSAGE_ARRIVED:
                queryLiveRoomPersonalNum();
                io.rong.imlib.model.Message msgContent = (io.rong.imlib.model.Message)msg.obj;
                MessageContent content = msgContent.getContent();
                // 过滤消息
                if (liveRoomBean.getPid().length() <= 1)
                {
                    if (content instanceof GiftMessage)
                    {
                        GiftMessage giftMsg = (GiftMessage) content;
                        if ("0".equals(giftMsg.getType()))
                        {
                            if (isFullScreen)
                                showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                        }
                        else
                            addHeartLayout();
                    }

                    if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                    {
                        mChatListAdapter.addMessage(content);
                        mChatListAdapter.addMsg(msgContent);
                        mChatListView.setTranscriptMode(2);
                    }
                }
                else
                {
                    if ("0".equals(YNCommonUtils.interceptionMultichannelRoomPID(liveRoomBean.getPid())))
                    {
                        if (content instanceof GiftMessage)
                        {
                            GiftMessage giftMsg = (GiftMessage) content;
                            if ("0".equals(giftMsg.getType()))
                                showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                            else
                                addHeartLayout();
                        }

                        if (!(content instanceof ImageMessage) && !(content instanceof CommandNotificationMessage))
                        {
                            mChatListAdapter.addMessage(content);
                            mChatListAdapter.addMsg(msgContent);
                            mChatListView.setTranscriptMode(2);
                        }
                    }
                    else
                    {
                        // 判断是否属于此房间的消息
                        if (content instanceof InformationNotificationMessage)
                        {
                            if (!TextUtils.isEmpty(((InformationNotificationMessage) content).getExtra()))
                            {
                                if (((InformationNotificationMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                        if (content instanceof TextMessage)
                        {
                            if (!TextUtils.isEmpty(((TextMessage) content).getExtra()))
                            {
                                if (((TextMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                        if (content instanceof GiftMessage)
                        {
                            if (!TextUtils.isEmpty(((GiftMessage) content).getExtra()))
                            {
                                if (((GiftMessage) content).getExtra().equals(liveRoomBean.getPid()))
                                {
                                    GiftMessage giftMsg = (GiftMessage) content;
                                    if ("0".equals(giftMsg.getType()))
                                        showLeftGiftVeiw(content.getUserInfo(), DataUtils.getGiftList().get(Integer.parseInt(giftMsg.getIndex())));
                                    else
                                        addHeartLayout();
                                    mChatListAdapter.addMessage(content);
                                    mChatListAdapter.addMsg(msgContent);
                                    mChatListView.setTranscriptMode(2);
                                }
                            }
                        }
                    }
                }
                break;

            case LiveKit.MESSAGE_SEND_ERROR:
                break;

            case YNCommonConfig.ATTENTION_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 43)
                    {
                        liveRoomBean.setIs_attention(1);
                        isAttention = true;
                        mTVFollow.setVisibility(View.GONE);
                        Intent intent = new Intent(YNCommonConfig.UPDATE_USER_STATE_FLAG);
                        intent.putExtra("liveRoom", true);
                        LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);
                    }

                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:

                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 13)
                    {
                        YNToastMaster.showToast(mContext, "取消关注成功");
                        liveRoomBean.setIs_attention(0);
                        isAttention = false;
                        mTVFollow.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        YNToastMaster.showToast(mContext, "取消关注失败");
                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG:
//                if (msg.obj != null)
//                {
//                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 28)
//                    {
//                        try
//                        {
//                            JSONObject object = new JSONObject(msg.obj.toString());
//                            String token = object.getString("0");
//                            connectRongYunServers(token);
//                        }
//                        catch (JSONException e)
//                        {
//                            e.printStackTrace();
//                        }
//                    }
//                    else
//                    {
////                        mLLChatRoomLoading.setVisibility(View.VISIBLE);
////                        mProgressBar.setVisibility(View.GONE);
////                        mTVLoadingTxt.setText("加入聊天室失败");
//                    }
//                }
//                else
//                {
//                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
////                    mProgressBar.setVisibility(View.GONE);
////                    mTVLoadingTxt.setText("加入聊天室失败");
//                }
//                break;

                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNLogUtil.e("tag", msg.obj.toString());
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject object = new JSONObject(msg.obj.toString());
                            String token = object.getString("0");
                            connectRongYunServers(token);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                else
                {
                    YNToastMaster.showToast(getActivity(), getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                        YNToastMaster.showToast(mContext, "禁言成功");

                    else
                        YNToastMaster.showToast(mContext, "禁言失败");
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                        YNToastMaster.showToast(mContext, "解禁成功");
                    else
                        YNToastMaster.showToast(mContext, "解禁失败");
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.REPORT_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.DELETE_ROOM_MANAGE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 54)
//                    {
//                        for (int i = 0; i < mManagerList.size(); i++)
//                        {
//                            if (mManagerList.get(i).getUserid().equals(chatRoomUserBean.getUserid()))
//                            {
//                                mManagerList.remove(i);
//                                break;
//                            }
//                        }
//                        mManagerAdapter.updateListView(mManagerList);
//                    }

                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.request_fail);
                }
                break;

            case YNCommonConfig.ADD_ROOM_MANAGE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 52)
//                    {
//                        mManagerList.add(chatRoomUserBean);
//                        mManagerAdapter.updateListView(mManagerList);
//                    }

                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.QUERY_BE_BLOCKED_USER_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 200)
                    {
                        if (baseBean.getUsers() != null)
                        {
                            for (UserInfoBean userInfoBean : baseBean.getUsers())
                            {
                                if (userId.equals(userInfoBean.getId()))
                                {
//                                    mTVLoadingTxt.setText("您已被禁言，加入聊天室失败");
                                    break;
                                }
                                else
                                {
//                                    handler.postDelayed(new Runnable()
//                                    {
//                                        @Override
//                                        public void run()
//                                        {
//                                            UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
//                                                    AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false);
//                                        }
//                                    }, 200);
                                }
                            }
                        }
                        else
                        {
//                            handler.postDelayed(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
//                                            AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false);
//                                }
//                            }, 200);
                        }
                    }
                }
                else
                {
//                    mTVLoadingTxt.setText("加入聊天室失败");
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
//                            onLineNumber = jsonObject.getInt("total");
//                            isPay = jsonObject.getInt("is_pay");
                            JSONArray array = jsonObject.optJSONArray("data");
                            if (array != null)
                            {
                                Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                                mUserValueList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mContributionList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                onLineNumber = mUserValueList.size();
                                mUserList.setText("在线  " + onLineNumber);
//                                mContributionAdapter.updateListView(topOnLineUserList(mContributionList));
                                mContributionAdapter.updateListView(mContributionList);
                                mUserValueAdapter.updateListView(mUserValueList);
                            }


                            if (liveRoomBean.getLive_status() == 2 && isPay == 0)
                            {
                                if (!userId.equals(liveRoomBean.getUserid()))
                                {
                                    ((YNLiveDetailsActivity)getActivity()).stopVideo();
                                    initPaymentDialog();
                                }
                            }

                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            chatRoomUserBean = YNJsonUtil.JsonToBean(jsonObject.get("data").toString(), ChatRoomUserBean.class);
//                            chatRoomDialog.dismiss();
                            createChatRoomDialog(chatRoomUserBean);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;

           /* case YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                            if (array != null)
                            {
                                mManagerList = YNJsonUtil.JsonToLBean(array.toString(), type);
                            }

                            mManagerAdapter.updateListView(mManagerList);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;*/

           /* case YNCommonConfig.GET_CONTRIBUTION_VALUE_TOP_TWENTY_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.getJSONArray("data");
                            Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                            mUserValueList = YNJsonUtil.JsonToLBean(array.toString(), type);
                            mUserValueAdapter.updateListView(mUserValueList);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                else
                {

                }
                break;*/

            case YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (!mUserValueList.isEmpty())
                    {
                        mUserValueList.removeAll(mUserValueList);
                        mUserValueAdapter.updateListView(mUserValueList);
                    }

                    if (baseBean.getCode() == 28)
                    {
                        mOnLineUserList.setVisibility(View.VISIBLE);
                        mTVEmpty.setVisibility(View.GONE);
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            JSONArray array = jsonObject.optJSONArray("data");
                            if (array != null)
                            {
                                Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                                mUserValueList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                mUserValueAdapter.updateListView(mUserValueList);
                            }
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                    else
                    {
                        mOnLineUserList.setVisibility(View.GONE);
                        mTVEmpty.setVisibility(View.VISIBLE);
                    }
                }
                else
                {
                    mOnLineUserList.setVisibility(View.GONE);
                    mTVEmpty.setVisibility(View.VISIBLE);
                }
                break;

            case YNCommonConfig.WATCH_LIVE_VALIDATION_PASS_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 90)
                    {
                        mInputPassDialog.dismiss();
                        ((YNLiveDetailsActivity)getActivity()).playVideo();
                        initEvaluateDialog();
//                        handler.postDelayed(new Runnable()
//                        {
//                            @Override
//                            public void run()
//                            {
//                                UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
//                                        AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false);
//                            }
//                        }, 200);
                    }

                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.WATCH_LIVE_VALIDATION_PAY_COIN_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 93 || baseBean.getCode() == 94)
                    {
                        if (baseBean.getCode() == 94)
                        {
                            currentCoin = currentCoin - liveRoomBean.getPayCoin();
                            AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                        }

                        mPayDialog.dismiss();
                        ((YNLiveDetailsActivity)getActivity()).playVideo();
                        initEvaluateDialog();
//                        handler.postDelayed(new Runnable()
//                        {
//                            @Override
//                            public void run()
//                            {
//                                UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
//                                        AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false);
//                            }
//                        }, 200);
                    }

                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 70)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            currentCoin = Float.parseFloat(jsonObject.getJSONObject("0").optString("currentCoin"));
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                        if (giftType == 1)
                        {
//                            currentCoin = currentCoin - thumbCount;
//                            for (int i = 0; i < thumbCount; i++)
//                            {
//                                GiftMessage giftMsg = new GiftMessage("1", "", "0");
//
//                                LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
//                            }
//                            thumbCount = 0;
//                            currentCoin = currentCoin - 0.1f;
                            GiftMessage giftMsg = new GiftMessage("1", "", "0", liveRoomBean.getPid());
                            LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
                        }
                        else
                        {
//                            currentCoin = currentCoin - gift.getGiftCount();
                            mGoldCount.setText(currentCoin + "");
                            GiftMessage giftMsg = new GiftMessage("0", gift.getGiftName(), String.valueOf(giftIndex), liveRoomBean.getPid());
                            LiveKit.sendMessage(giftMsg, Conversation.ConversationType.CHATROOM);
                        }
                        AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                    }

//                    YNToastMaster.showToast(mContext, baseBean.getInfo());
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.request_fail);
                }
                break;

            case YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            currentCoin = Float.parseFloat(jsonObject.getString("data"));
                            AccountUtils.getAccountBean().setCurrentCoin(currentCoin);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                }
                break;

            case YNCommonConfig.LIVE_EVALUATE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 130)

                    YNToastMaster.showToast(mContext, baseBean.getInfo(), Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                else
                {
                    YNToastMaster.showToast(mContext, R.string.request_fail, Toast.LENGTH_SHORT, Gravity.CENTER);
                }
                break;

            case YNCommonConfig.GET_LIVE_HOST_INFO_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            AnchorInfoBean anchorInfo = YNJsonUtil.JsonToBean(jsonObject.optString("data"), AnchorInfoBean.class);
                            dialog.updateDialog(anchorInfo);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }

                    }
                }
                else
                {

                }
                break;

//            case YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_FLAG:
//                if (msg.obj != null)
//                {
//                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                    if (baseBean.getCode() == 28)
//                    {
//                        try
//                        {
//                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
//                            onLineNumber = jsonObject.getInt("total");
//                            mUserList.setText("在线  " + onLineNumber);
//                        }
//                        catch (JSONException e)
//                        {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//                break;

            case YNCommonConfig.UPDATE_LIVE_ROOM_USER_STATE_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            int attentionFlag = jsonObject.getJSONObject("data").optInt("is_attention");
//                            int selfISManageFlag = jsonObject.getJSONObject("data").optInt("is_selfManage");
                            isPay = jsonObject.getJSONObject("data").optInt("is_selfManage");
                            if (attentionFlag == 0)
                            {
                                isAttention = false;
                                liveRoomBean.setIs_attention(0);
                            }
                            else
                            {
                                isAttention = true;
                                liveRoomBean.setIs_attention(1);
                            }

                            updateLiveRoomUI();
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case YNCommonConfig.GET_SHARE_ADDRESS_FLAG:
                if (msg.obj != null)
                {
                    BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                    if (baseBean.getCode() == 28)
                    {
                        try
                        {
                            JSONObject jsonObject = new JSONObject(msg.obj.toString());
                            String address = jsonObject.getJSONObject("data").optString("address");
                            AccountUtils.saveShareAddress(address);
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                break;
        }
        mChatListAdapter.notifyDataSetChanged();
        return false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_live_layer, container, false);
        Bundle bundle = getArguments();
        if (bundle != null)
        {
            liveRoomBean = (LiveRoomBean) bundle.getSerializable(YNCommonConfig.OBJECT);
        }
//        AutoUtils.auto(view);
        initView(view);
        LiveKit.addEventHandler(handler);
        initFragment();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);
        broadcastManager = LocalBroadcastManager.getInstance(getActivity());
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(YNCommonConfig.UPDATE_USER_STATE_FLAG);
        mRefreshReceiver= new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent){
                if (intent.getBooleanExtra("liveRoom", true))
                {
                    updateLiveRoomUserState();
                }
                else
                {
                    liveRoomBean = (LiveRoomBean)intent.getSerializableExtra(YNCommonConfig.OBJECT);
                    setPoriraitFullScreen();
//                    quitChatRoom(liveRoomBean);
                }
            }
        };
        broadcastManager.registerReceiver(mRefreshReceiver, intentFilter);
    }

    @Override
    public void onResume()
    {
//        connectRongCloud();

//        if (AccountUtils.getLoginInfo())
//        {
//            userId = AccountUtils.getAccountBean().getId();
//            loginRefreshUI();
//        }
//        else
//        {
//            unLoginRefreshUI();
//        }
//
//        queryChatRoomUserListInfo();
//        queryChatRoomManagerInfo();
//
//        if (liveRoomBean.getLock() == 0 && liveRoomBean.getLive_status() != 2 && liveRoomBean.getLiving() == 1)
//        {
//            if (!(AccountUtils.getLoginInfo() && userId.equals(liveRoomBean.getUserid())))
//            {
//                initEvaluateDialog();
//            }
//        }
//
//        if (liveRoomBean.getLock() == 1 && liveRoomBean.getLiving() == 1)
//        {
//            if (!(AccountUtils.getLoginInfo() && userId.equals(liveRoomBean.getUserid())))
//            {
//                ((YNLiveDetailsActivity)getActivity()).stopVideo();
//                initInputPassEditDialog();
//            }
//        }

        registerMessageReceiver();
//        animateToShow();
        super.onResume();
    }

    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    @Override
    protected void initView(View view)
    {
        rellayout_root1 = (ViewGroup) view.findViewById(R.id.rellayout_root1);
        fullHeaderRl = (RelativeLayout) view.findViewById(R.id.rl_fullscreen_header);
        headerBar = (RelativeLayout) view.findViewById(R.id.rl_header_bar);
        normalHeaderRl = (RelativeLayout) view.findViewById(R.id.rl_normalscreen_header);
        fullControllerRl = (RelativeLayout) view.findViewById(R.id.rl_fullscreen_controller);
        controllerRL = (RelativeLayout) view.findViewById(R.id.rl_controller);
        normalControllerRl = (RelativeLayout) view.findViewById(R.id.rl_normalscreen_controller);

        mIVHostImg = (ImageView) view.findViewById(R.id.iv_hostImg);
        mTVHostName = (TextView) view.findViewById(R.id.tv_hostName);
        mTVPageViews = (TextView) view.findViewById(R.id.tv_pageViews);
        mTVFollow = (TextView) view.findViewById(R.id.tv_follow);
        horizontalRecyclerView = (RecyclerView) view.findViewById(R.id.horizontal_recycle_view);
        mRLHostMsg = (RelativeLayout) view.findViewById(R.id.rl_hostMessage);
        mIVClose = (ImageView) view.findViewById(R.id.iv_close);

        mLLList = (LinearLayout) view.findViewById(R.id.ll_list);
        mRLContributionList = (RelativeLayout) view.findViewById(R.id.rl_contribution_list);
        mUserList = (TextView) view.findViewById(R.id.tv_user_list);

        heartLayout = (HeartLayout) view.findViewById(R.id.heart_layout);
        bottomPanel = (BottomPanelFragment) getChildFragmentManager().findFragmentById(R.id.bottom_bar);
        mLLBottomLeft = (LinearLayout) bottomPanel.getView().findViewById(R.id.ll_bottom_left);
        mLLBottomRight = (LinearLayout) bottomPanel.getView().findViewById(R.id.ll_bottom_right);
        mIVShare = (ImageView) bottomPanel.getView().findViewById(R.id.iv_share);
        mIVEvaluate = (ImageView) bottomPanel.getView().findViewById(R.id.iv_evaluate);
        mIVGift = (ImageView) bottomPanel.getView().findViewById(R.id.iv_gift);
        mIVThumb = (ImageView) bottomPanel.getView().findViewById(R.id.iv_thumb);
        mIVSpeak = (ImageView) bottomPanel.getView().findViewById(R.id.iv_speak);
        buttonPanel = (ViewGroup) bottomPanel.getView().findViewById(R.id.button_panel);
        inputPanel = (InputPanel) bottomPanel.getView().findViewById(R.id.input_panel);
//        mIVBottomFullScreen = (ImageView) bottomPanel.getView().findViewById(R.id.iv_bottom_fullscreen);
        leftGiftView = (LiveLeftGiftView) view.findViewById(R.id.left_gift_view1);
        leftGiftView2 = (LiveLeftGiftView) view.findViewById(R.id.left_gift_view2);
        fullscreen = (ImageView) view.findViewById(R.id.iv_fullscreen);
        mChatListView = (ChatListView) view.findViewById(R.id.chat_listview);
        mLLBtn = (LinearLayout) view.findViewById(R.id.ll_btn);
        mIVReConnection = (ImageView) view.findViewById(R.id.iv_reconnection);
        mIVHighDefinition = (ImageView) view.findViewById(R.id.iv_high_definition);

        mRLCover = (RelativeLayout) view.findViewById(R.id.rl_cover);
        liveContributionList = (LinearLayout) view.findViewById(R.id.live_contribution_list);
        mCoverImg = (ImageView) view.findViewById(R.id.iv_cover);

        mLLTabs = (LinearLayout) view.findViewById(R.id.ll_tabs);
//        tabs = (TabLayout) view.findViewById(R.id.tabs);
        mIndicator = (FixedIndicatorView) view.findViewById(R.id.fragment_tabmain_indicator);
        mViewPager = (ViewPager) view.findViewById(R.id.vp_live_player);
        mLine = view.findViewById(R.id.line);

        mIVClose.setVisibility(View.INVISIBLE);
        fullscreen.setVisibility(View.INVISIBLE);

        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        horizontalRecyclerView.setLayoutManager(layoutManager);

        tabTitle = new String[]{"聊天", "提问", "主页", "公告"};

        setPoriraitFullScreen();

//        if (YNCommonConfig.screenSize > 5.0)
//        {
//            YNLogUtil.i("cdy123", YNCommonConfig.screenSize + "");
//            mLLTabs.setY(UIUtils.dp2px(getActivity(), 27));
//            fullscreen.setY(UIUtils.dp2px(getActivity(), 41));

//            RelativeLayout.LayoutParams linearParams =(RelativeLayout.LayoutParams) mLLTabs.getLayoutParams();
//            linearParams.height = YNCommonConfig.ScreenHeight - 200 - 440;
//            mLLTabs.setLayoutParams(linearParams);
//        }

//        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mLLTabs.getLayoutParams();
//        params.height = UIUtils.dp2px(getActivity(), UIUtils.px2dip(getActivity(), YNCommonConfig.ScreenHeight) - UIUtils.px2dip(getActivity(), ScreenSizeUtil.getViewHigh(headerBar)) - 220);
//        YNLogUtil.i("cdy123", params.height + "," + YNCommonConfig.ScreenHeight  + "," + ScreenSizeUtil.getViewHigh(headerBar));
//        mLLTabs.setLayoutParams(params);

        addFragment();
    }

    @Override
    protected void addEvents()
    {
        rellayout_root1.setOnClickListener(this);
        mIVClose.setOnClickListener(this);
        mRLHostMsg.setOnClickListener(this);
        mIVShare.setOnClickListener(this);
        mIVEvaluate.setOnClickListener(this);
        mIVGift.setOnClickListener(this);
        mIVThumb.setOnClickListener(this);
        mIVSpeak.setOnClickListener(this);
//        mIVBottomFullScreen.setOnClickListener(this);

        fullscreen.setOnClickListener(this);
        mRLContributionList.setOnClickListener(this);
        mUserList.setOnClickListener(this);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels)
            {

            }

            @Override
            public void onPageSelected(int position)
            {
                pageSelectedIndex = position;
                if (position == 1)
                {
                    if (isShowRedPoint)
                    {
                        ((BadgeTextView)mIndicator.getItemView(1)).setBadgeShown(false);
                        Intent msgIntent = new Intent(AskQuestionFragment.MESSAGE_RECEIVED_ACTION);
                        mMsgreceiveContext.sendBroadcast(msgIntent);
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state)
            {

            }
        });

        mChatListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
/*                if (processFlag)
                {
                    setProcessFlag();
                    if (mChatListAdapter.getMsg().get(position).getContent() instanceof InformationNotificationMessage)
                    {
                        beClickedUserId = mChatListAdapter.getMessage().get(position).getUserInfo().getUserId();
                        // 查询被点击的用户信息
//                        creatChatRoomDialog(chatRoomUserBean);
                        handler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().getChatRoomUserInfo(mContext, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, liveRoomBean.getRoom_id(),
                                        beClickedUserId, userId, handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                            }
                        }, 200);
                    }
                    new TimeThread().start();
                }*/
                YNCommonUtils.hideSoftInput(mContext, inputPanel.getInputView());
                inputPanel.setVisibility(View.GONE);
                buttonPanel.setVisibility(View.VISIBLE);
            }
        });

        mUserValueAdapter = new CommonAdapter<ChatRoomUserBean>(mContext, mUserValueList, R.layout.contribution_charts_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, ChatRoomUserBean item)
            {
                if (item.getSort() == 1)
                {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.gold);
                }
                if (item.getSort() == 2)
                {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.silver);
                }
                if (item.getSort() == 3)
                {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.getView(R.id.tv_ranking).setVisibility(View.GONE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.copper);
                }
                if (item.getSort() > 3)
                {
                    viewHolder.getView(R.id.iv_ranking).setVisibility(View.INVISIBLE);
                    viewHolder.getView(R.id.tv_ranking).setVisibility(View.VISIBLE);
                    viewHolder.setText(R.id.tv_ranking, item.getSort() + "");
                }

                viewHolder.setImage(mContext, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_userName, item.getUsername(), ContextCompat.getColor(mContext, R.color.ynkj_white));
                viewHolder.setText(R.id.tv_contribution_num, "贡献  " + item.getTotals(), ContextCompat.getColor(mContext, R.color.contribution_charts_orange));
            }
        };

        // 发送消息
        bottomPanel.setInputPanelListener(new InputPanel.InputPanelListener()
        {
            @Override
            public void onSendClick(String text)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo())
                    {
                        final TextMessage content = TextMessage.obtain(text);
                        content.setExtra(liveRoomBean.getPid());
                        LiveKit.sendMessage(content, Conversation.ConversationType.CHATROOM);
                    }
                    else
                    {
//                        YNToastMaster.showToast(mContext, getString(R.string.un_login_opreate_notice));
                        Intent intent = new Intent(getContext(), YNLoginActivity.class);
                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                        startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.no_net));
                }
            }
        });

    }

    @Override
    protected void settingDo()
    {
//        showMemberList();

        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();
            userIcon = AccountUtils.getAccountBean().getIcon();
//            initShareContent();
            takePartInLiveRoom();
            getCurrentCoin();
            YNLogUtil.e("tag", liveRoomBean.getIs_attention() + "");
            if (userId.equals(liveRoomBean.getUserid()))
            {
                mTVFollow.setVisibility(View.GONE);
                mIVGift.setVisibility(View.GONE);
                mIVThumb.setVisibility(View.GONE);
            }
            else
            {
                mTVFollow.setVisibility(liveRoomBean.getIs_attention() == 0 ? View.VISIBLE : View.GONE);
            }
        }
        else
        {
            mTVFollow.setVisibility(liveRoomBean.getIs_attention() == 0 ? View.VISIBLE : View.GONE);
            userId = YNCommonUtils.getRandomNumber();
            userName = "游客<" + YNCommonUtils.getRandomNumber() + ">";
            userIcon = "http://www.qqw21.com/article/uploadpic/2012-9/201291893228996.jpg";
        }

//        if (liveRoomBean.getLiving() == 0)
//        {
//            handler.post(new Runnable()
//            {
//                @Override
//                public void run()
//                {
//                    UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId, userName,
//                            userIcon, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
//                }
//            });
//        }

        if (liveRoomBean.getIs_attention() == 0)
            isAttention = false;
        else
            isAttention = true;



        // 查询聊天室用户信息
//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().queryChatRoomUserList(mContext, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, liveRoomBean.getRoom_id(),
//                        500, 1, userId, handler, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG, false);
//            }
//        });

        if (AccountUtils.getShareAddress().isEmpty())
        {
            // 获取分享地址
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getShareAddress(getContext(), YNCommonConfig.GET_SHARE_ADDRESS_URL, handler, YNCommonConfig.GET_SHARE_ADDRESS_FLAG, false);
                }
            });
        }

        // 查询聊天室房管信息
//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().queryChatRoomManagerInfo(mContext, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_URL, liveRoomBean.getRoom_id(), handler, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG, false);
//            }
//        });

        if (liveRoomBean.getLock() == 1 && liveRoomBean.getLiving() == 1)
        {
            if (!(AccountUtils.getLoginInfo() && userId.equals(liveRoomBean.getUserid())))
            {
                ((YNLiveDetailsActivity)getActivity()).stopVideo();
                initInputPassEditDialog();
            }
        }
//        if (liveRoomBean.getLock() != 1 || (liveRoomBean.getLive_status() == 2 && liveRoomBean.getIs_pay() == 1))
//        {
//            connectRongCloud();
//        }

        if (liveRoomBean.getLock() == 0 && liveRoomBean.getLive_status() != 2 && liveRoomBean.getLiving() == 1)
        {
            if (!(AccountUtils.getLoginInfo() && userId.equals(liveRoomBean.getUserid())))
            {
                initEvaluateDialog();
            }
        }

        if (liveRoomBean.getLiving() == 1 && !AccountUtils.getLoginInfo()) {
            myCount = new MyCount(180000, 1000);// 创建一个倒计时 总时长3分钟 间隔1秒
            myCount.start();
        }

        if (liveRoomBean.getLiving() == 0)
        {
            mIndicator.setCurrentItem(2);
            mViewPager.setCurrentItem(2);
        }

        mContributionAdapter = new CommonRecyclerViewAdapter<ChatRoomUserBean>(mContext, mContributionList, R.layout.live_details_recycleview_item)
        {
            @Override
            public void convert(CommonRecyclerViewHolder holder, ChatRoomUserBean data, int position)
            {
                if (!mContributionList.isEmpty())
                    holder.setImage(mContext, R.id.iv_img, data.getIcon());

                if (data.getSort() == 1) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking1);
                }
                if (data.getSort() == 2) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking2);
                }
                if (data.getSort() == 3) {
                    holder.findView(R.id.iv_ranking).setVisibility(VISIBLE);
                    holder.setImageResource(R.id.iv_ranking, R.drawable.live_ranking3);
                }
                if (data.getSort() > 3) {
                    holder.findView(R.id.iv_ranking).setVisibility(GONE);
                }

            }
        };

        horizontalRecyclerView.setAdapter(mContributionAdapter);

        // 顶部在线用户列表点击
        mContributionAdapter.setOnItemClickListener(new CommonRecyclerViewAdapter.OnItemClickListener()
        {
            @Override
            public void OnItemClickListener(View view, final int position)
            {
                clickManagerList = false;
                if (!mContributionList.isEmpty())
                {
                    beClickedUserId = mContributionList.get(position).getUserid();
                    if (processFlag)
                    {
                        setProcessFlag();
//                        creatChatRoomDialog(chatRoomUserBean);
                        handler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().getChatRoomUserInfo(mContext, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, liveRoomBean.getRoom_id(), beClickedUserId, userId,
                                        handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                            }
                        }, 500);

                        new TimeThread().start();
                    }
                }
            }
        });

        YNImageLoaderUtil.setImage(mContext, mIVHostImg, liveRoomBean.getIcon());
        mTVHostName.setText(liveRoomBean.getUsername());
        mTVPageViews.setText(liveRoomBean.getAcount() + " 人");
        shareDialog = new ProgressDialog(mContext);

        initShareContent();

        mChatListAdapter = new ChatListAdapter(mContext, liveRoomBean, mContributionAdapter, buttonPanel, inputPanel);
        mChatListView.setAdapter(mChatListAdapter);
    }

    /**
     * 五秒后隐藏界面上的控件
     */
    private void hideOuterAfterFiveSeconds()
    {
//        if (liveRoomBean.getEquipment() == 1)
//        {
//            if (mLLTabs.getVisibility() == View.VISIBLE)
//                mLLTabs.setVisibility(View.GONE);
//            else
//                mLLTabs.setVisibility(View.VISIBLE);
//        }

        if (mIVClose.getVisibility() == View.VISIBLE)
            mIVClose.setVisibility(View.INVISIBLE);
        else
            mIVClose.setVisibility(View.VISIBLE);

        if (isShowFullScreen)
        {
//            if (!isFullScreen && liveRoomBean.getEquipment() == 0)
//            {
//                if (fullscreen.getVisibility() == View.VISIBLE)
//                    fullscreen.setVisibility(View.INVISIBLE);
//                else
//                    fullscreen.setVisibility(View.VISIBLE);
//            }
//            else
//            {
//                fullscreen.setVisibility(View.INVISIBLE);
//            }
            YNLogUtil.e("cdy", "开始执行");
            if (!isFullScreen && !isPhoneLiving)
            {
                if (fullscreen.getVisibility() == View.VISIBLE)
                    fullscreen.setVisibility(View.INVISIBLE);
                else
                    fullscreen.setVisibility(View.VISIBLE);
                YNLogUtil.e("cdy", "竖屏");
            }
            else
            {
                YNLogUtil.e("cdy", "横屏");
                fullscreen.setVisibility(View.INVISIBLE);
            }
        }

        if (isFullScreen)
        {
            if (mLLBtn.getVisibility() == View.VISIBLE)
                mLLBtn.setVisibility(View.GONE);
            else
                mLLBtn.setVisibility(View.VISIBLE);
        }

        if (barTimer != null)
        {
            barTimer.cancel();
            barTimer = null;
        }
        barTimer = new Timer();
        barTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        mIVClose.setVisibility(View.INVISIBLE);
                        fullscreen.setVisibility(View.INVISIBLE);
                        mLLBtn.setVisibility(View.GONE);
//                        mViewPager.setVisibility(View.GONE);
                    }
                });
            }

        }, 5 * 1000);
    }

    /**
     * 五秒钟发送点赞
     */
    private void AfterFiveSecondsSendThumb()
    {
        if (barTimer != null)
        {
            barTimer.cancel();
            barTimer = null;
        }
        barTimer = new Timer();
        barTimer.schedule(new TimerTask()
        {
            @Override
            public void run()
            {
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if (currentCoin >= thumbCount)
                        {
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().liveRoomSendGift(mContext, YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId, liveRoomBean.getUserid(),
                                            "为主播点赞", thumbCount, thumbCount, giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                }
                            });
                        }
                        else
                        {
                            thumbCount = 0;
                            YNToastMaster.showToast(mContext, "您的余额不足，请及时充值");
                        }
                    }
                });
            }
        }, 5 * 1000);
    }

//    /**
//     * 显示直播房间管理员列表
//     */
//    private void showMemberList()
//    {
//        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
//        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
//        horizontalRecyclerView.setLayoutManager(layoutManager);
//        horizontalRecyclerView.setAdapter(mContributionAdapter);
//    }

    /**
     * 更新直播间用户状态
     */
    public void updateLiveRoomUserState()
    {
        userId = AccountUtils.getAccountBean().getId();
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().updateLiveRoomUserState(getContext(), YNCommonConfig.UPDATE_LIVE_ROOM_USER_STATE_URL, userId, liveRoomBean.getUserid(),
                        handler, YNCommonConfig.UPDATE_LIVE_ROOM_USER_STATE_FLAG, false);
            }
        });

    }

    /**
     * 更新电脑、手机直播状态
     */
    public void updateEquipment(boolean isPhoneLiving)
    {
        this.isPhoneLiving = isPhoneLiving;
        setPoriraitFullScreen();
//        hideOuterAfterFiveSeconds();
    }

    /**
     * 是否直播中、是否显示全屏
     */
    public void isShowScreen(boolean isShowFullScreen)
    {
        this.isShowFullScreen = isShowFullScreen;
    }

    /**
     * 添加房管
     */
    public void addManager(ChatRoomUserBean chatRoomUserBean)
    {
//        mManagerList.add(chatRoomUserBean);
//        mManagerAdapter.updateListView(mManagerList);
    }

    /**
     * 删除房管
     */
    public void deleteManager(ChatRoomUserBean chatRoomUserBean)
    {
//        for (int i = 0; i < mManagerList.size(); i++)
//        {
//            if (mManagerList.get(i).getUserid().equals(chatRoomUserBean.getUserid()))
//            {
//                mManagerList.remove(i);
//                break;
//            }
//        }
//        mManagerAdapter.updateListView(mManagerList);
    }

    private void initShareContent()
    {
        String shareUrl;
        if (userId.equals(liveRoomBean.getUserid()))
            shareUrl = AccountUtils.getShareAddress() + "?ID=" + liveRoomBean.getUserid();
        else
            shareUrl = AccountUtils.getShareAddress() + "?ID=" + liveRoomBean.getUserid() + "&shareID=" + userId;
        YNLogUtil.e("tag", shareUrl);
        web = new UMWeb(shareUrl);
        web.setTitle("[" + liveRoomBean.getUsername() + "] 正在直播中...");
        web.setThumb(new UMImage(getActivity(), R.mipmap.app_logo));
        web.setDescription(liveRoomBean.getDescribe() + "尽在[" + liveRoomBean.getUsername() + "] 的直播间");
    }

    /**
     * 查询在线人数
     */
    private void queryLiveRoomPersonalNum()
    {
//        handler.post(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                UserHttpUtils.newInstance().getLiveRoomPersonalNum(getContext(), YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_URL, liveRoomBean.getRoom_id(), 500, 2,
//                        handler, YNCommonConfig.GET_LIVE_ROOM_PERSONAL_NUM_FLAG, false);
//            }
//        });

        // 查询聊天室用户信息
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().queryChatRoomUserList(mContext, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, liveRoomBean.getRoom_id(),
                        500, 2, userId, handler, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG, false);
            }
        });
    }

    private void connectRongCloud()
    {
        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();
            userName = AccountUtils.getAccountBean().getUsername();
            userIcon = AccountUtils.getAccountBean().getIcon();
        }
        else
        {
            userId = YNCommonUtils.getRandomNumber();
            userName = "游客" + userId;
            userIcon = "http://p7.qhmsg.com/t01f641d70d0e57b2f5.jpg";
        }
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId, userName,
                        userIcon, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, true, 500);
            }
        });
    }

    /**
     * 设置竖屏全屏方法
     */
    private void setPoriraitFullScreen()
    {
//        if (liveRoomBean.getEquipment() == 1)
//        {
        if (isPhoneLiving)
        {
            setPortraitFullScreenUI();
//            mLLTabs.setVisibility(View.GONE);
//            mIndicator.setVisibility(View.GONE);
//            mLine.setVisibility(View.GONE);

            fullscreen.setVisibility(View.INVISIBLE);
            fullHeaderRl.setVisibility(View.VISIBLE);
//            normalControllerRl.setVisibility(View.VISIBLE);
//            fullControllerRl.setVisibility(View.VISIBLE);

            if (null != normalHeaderRl)
            {
                normalHeaderRl.removeAllViews();
            }
            if (null != normalControllerRl)
            {
                normalControllerRl.removeAllViews();
            }
            if (fullHeaderRl != null)
            {
                fullHeaderRl.addView(headerBar);
            }
            if (fullControllerRl != null)
            {
                fullControllerRl.addView(controllerRL);
            }
            ((YNLiveDetailsActivity)getActivity()).setPoriraitFullScreen();
        }
        else
        {
            setPortraitScreenUI();
        }
    }

    /**
     * 设置竖屏全屏直播间控件显示
     */
    private void setPortraitFullScreenUI()
    {
        float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#1694ff");
        int unSelectColor = Color.parseColor("#ffffff");
        ColorBar line1 = new ColorBar(getActivity(), Color.parseColor("#1694ff"), 5);
        line1.setWidth(UIUtils.dp2px(getActivity(), 55));
        line1.setHeight(UIUtils.dp2px(getActivity(), 2));
        mIndicator.setScrollBar(line1);
        mIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mViewPager.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mIndicator, mViewPager);

        mLLTabs.setBackgroundColor(Color.parseColor("#30000000"));
    }

    /**
     * 设置竖屏方法
     */
    private void setPorirait()
    {
        fullHeaderRl.setVisibility(View.GONE);
//        normalControllerRl.setVisibility(View.GONE);
//        fullControllerRl.setVisibility(View.GONE);
        controllerRL.setVisibility(View.GONE);
//        mIVBottomFullScreen.setVisibility(View.GONE);
        mLLTabs.setVisibility(View.VISIBLE);

        ((YNLiveDetailsActivity)getActivity()).setBVideoViewSize(240);
        fullscreen.setVisibility(View.VISIBLE);
//        mRLContributionList.setVisibility(View.VISIBLE);
//        ((ViewGroup.MarginLayoutParams)mLLBottomLeft.getLayoutParams()).setMargins(0, 0, screenHeight - 10, 0);
        headerBar.setBackgroundColor(ContextCompat.getColor(mContext, R.color.transparent));
//        getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
//        FullScreenUtils.toggleHideyBar(getActivity());

        // to mini size, to portrait
        if (fullControllerRl != null)
        {
            fullHeaderRl.removeAllViews();
        }
        if (normalHeaderRl != null)
        {
            fullControllerRl.removeAllViews();
        }
        if (normalHeaderRl != null)
        {
            normalHeaderRl.addView(headerBar);
        }
        if (normalControllerRl != null)
        {
            normalControllerRl.addView(controllerRL);
//            normalControllerRl.addView(mRLCover);
        }
        isFullScreen = false;
    }

    /**
     * 设置竖屏直播间界面控件显示
     */
    private void setPortraitScreenUI()
    {
        float unSelectSize = 15;
        float selectSize = 15;
        int selectColor = Color.parseColor("#ffffff");
        int unSelectColor = Color.parseColor("#808080");
        ColorBar line1 = new ColorBar(getActivity(), Color.parseColor("#ffffff"), 5);
        line1.setWidth(UIUtils.dp2px(getActivity(), 55));
        line1.setHeight(UIUtils.dp2px(getActivity(), 2));
        mIndicator.setScrollBar(line1);
        mIndicator.setOnTransitionListener(new OnTransitionTextListener().setColor(selectColor, unSelectColor).setSize(selectSize, unSelectSize));
        mViewPager.setOffscreenPageLimit(tabTitle.length);
        indicatorViewPager = new IndicatorViewPager(mIndicator, mViewPager);

        mLLTabs.setBackgroundColor(Color.parseColor("#00000000"));
    }

    /**
     * 设置横屏方法
     */
    private void setLandscape()
    {
//        handler.post(new Runnable()
//        {
//            @Override
//            public void run() {
//                UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, AccountUtils.getAccountBean().getId(),
//                        AccountUtils.getAccountBean().getUsername(), AccountUtils.getAccountBean().getIcon(), liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false);
//            }
//        });

        animateToShow();
        fullscreen.setVisibility(View.INVISIBLE);
        fullHeaderRl.setVisibility(View.VISIBLE);
        normalControllerRl.setVisibility(View.VISIBLE);
        fullControllerRl.setVisibility(View.VISIBLE);
        controllerRL.setVisibility(View.VISIBLE);
        mLLTabs.setVisibility(View.GONE);
        mLLBtn.setVisibility(View.GONE);
        mIVClose.setVisibility(View.INVISIBLE);

        mRLHostMsg.setVisibility(View.VISIBLE);
        mChatListView.setVisibility(View.VISIBLE);
        horizontalRecyclerView.setVisibility(View.VISIBLE);
//        if (AccountUtils.getLoginInfo() && AccountUtils.getAccountBean().getId().equals(liveRoomBean.getUserid()))
//        {
//            mIVGift.setVisibility(View.GONE);
//            mIVThumb.setVisibility(View.GONE);
//        }
//        else
//        {
//            mIVGift.setVisibility(View.VISIBLE);
//            mIVThumb.setVisibility(View.VISIBLE);
//        }
        mIVShare.setVisibility(View.VISIBLE);
        mIVSpeak.setVisibility(View.VISIBLE);

        if (AccountUtils.getLoginInfo())
        {
            if (userId.equals(liveRoomBean.getUserid()))
            {
                mIVEvaluate.setVisibility(View.GONE);
            }
        }
//        mIVBottomFullScreen.setVisibility(View.VISIBLE);
//        mRLContributionList.setVisibility(View.GONE);

        ((YNLiveDetailsActivity)getActivity()).setBVideoViewSize(0);

        ((ViewGroup.MarginLayoutParams)mLLBottomLeft.getLayoutParams()).setMargins(screenHeight - ScreenSizeUtil.getViewWidth(mLLBottomRight) - ScreenSizeUtil.getViewWidth(mLLBottomLeft) - 20, 0, 0 , 0);
//        ((ViewGroup.MarginLayoutParams)mLLBottomLeft.getLayoutParams()).setMargins(screenHeight / 3 * 2 - ScreenSizeUtil.getViewHigh(mLLBottomRight), 0, ScreenSizeUtil.getViewHigh(mLLBottomRight) + 10, 0);
//        ((ViewGroup.MarginLayoutParams)mLLBottomLeft.getLayoutParams()).setMargins(screenHeight / 3 * 2 - 150, 0, 0, 0);
        headerBar.setBackgroundColor(ContextCompat.getColor(mContext, R.color.transparent));
//        getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
//        FullScreenUtils.toggleHideyBar(getActivity());

        if (null != normalHeaderRl)
        {
            normalHeaderRl.removeAllViews();
        }
        if (null != normalControllerRl)
        {
            normalControllerRl.removeAllViews();
        }
        if (fullHeaderRl != null)
        {
            fullHeaderRl.addView(headerBar);
        }
        if (fullControllerRl != null)
        {
            fullControllerRl.addView(controllerRL);
//            fullControllerRl.addView(mRLCover);
        }
        isFullScreen = true;
    }

    /**
     * 连接融云服务器
     * @param token
     */
    private void connectRongYunServers(String token)
    {
        /**
         * 建立与融云服务器的连接
         * @param token
         */
        LiveKit.connect(token, new RongIMClient.ConnectCallback()
        {
            @Override
            public void onTokenIncorrect()
            {
                // 检查appKey与token是否匹配
                YNLogUtil.d(TAG, "connect onTokenIncorrect");
            }

            @Override
            public void onSuccess(String s)
            {
                UserInfo userInfo1;
                if (AccountUtils.getLoginInfo())
                {
                    userInfo1 = new UserInfo(AccountUtils.getAccountBean().getId(), AccountUtils.getAccountBean().getUsername(), Uri.parse(AccountUtils.getAccountBean().getIcon()));
//                    userInfo1 = new UserInfo(userId, userName, Uri.parse(userIcon));
                    LiveKit.setCurrentUser(userInfo1);
                }

                joinChatRoom(liveRoomBean.getRoom_id(), -1);
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {
                // 根据errorCode检查原因
                YNLogUtil.d(TAG, "connect onError = " + errorCode);
            }
        });
    }

    /**
     * 加入融云聊天室
     * @param roomId
     */
    private void joinChatRoom(final String roomId, int defMessageCount)
    {

        LiveKit.joinChatRoom(roomId, defMessageCount, new RongIMClient.OperationCallback()
        {
            @Override
            public void onSuccess()
            {
                if (AccountUtils.getLoginInfo())
                {
                    InformationNotificationMessage sysMsg = InformationNotificationMessage.obtain("系统提示：股市有风险，入市需谨慎!");
                    InformationNotificationMessage msg = InformationNotificationMessage.obtain(LiveKit.getCurrentUser().getName() + " 加入聊天室");
                    sysMsg.setExtra(liveRoomBean.getPid());
                    msg.setExtra(liveRoomBean.getPid());
//                    msg.setUserInfo(LiveKit.getCurrentUser());
                    LiveKit.sendMessage(sysMsg, Conversation.ConversationType.CUSTOMER_SERVICE);
                    LiveKit.sendMessage(msg, Conversation.ConversationType.CHATROOM);
                }
            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {
                // 根据errorCode检查原因
                YNLogUtil.d(TAG, "connect onError = " + errorCode);
            }
        });
    }

    /* 定义一个倒计时的内部类 */
    class MyCount extends CountDownTimer {
        /**
         *
         * @param millisInFuture
         *            持续时长
         * @param countDownInterval
         *            间隔时长
         */
        public MyCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        /**
         * 在倒计时结束时调用
         */
        @Override
        public void onFinish()
        {
            ((YNLiveDetailsActivity)getActivity()).stopVideo();
            final Intent intent = new Intent();
            if (unLoginLiveDialog == null)
            {
                unLoginLiveDialog = new YNUnLoginLiveDialog.Builder(mContext)
                        .setWidth(0.8f)
                        .setHeight(0.45f)
                        .setInterceptBack(true)
                        .setCanceledOnTouchOutside(false)
                        .setOnclickListener(new IDialogOnClickListener()
                        {
                            @Override
                            public void clickTopLeftButton(View view) {

                            }

                            @Override
                            public void clickTopRightButton(View view)
                            {
                                unLoginLiveDialog.dismiss();
                                getActivity().finish();
                                myCount.cancel();
                            }

                            @Override
                            public void clickBottomLeftButton(View view)
                            {
                                unLoginLiveDialog.dismiss();
                                intent.setClass(mContext, YNRegisterActivity.class);
                                startActivity(intent);
                                myCount.cancel();
                            }

                            @Override
                            public void clickBottomRightButton(View view)
                            {
                                unLoginLiveDialog.dismiss();
                                intent.setClass(mContext, YNLoginActivity.class);
                                startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
                                myCount.cancel();
//                                startActivity(intent);
                            }

                            @Override
                            public void clickBottomButton(View view) {

                            }
                        }).build();
                unLoginLiveDialog.show();
            }
        }

        /**
         * 每间隔countDownInterval会调用一次
         * @param millisUntilFinished 已经过去了多长时间
         *
         */
        @Override
        public void onTick(long millisUntilFinished)
        {

        }
    }

    // 评价主播对话框
    private void initEvaluateDialog()
    {
        handler.postDelayed(timerRunnable, 1200000);
//        handler.postDelayed(timerRunnable, 1200);
//        timerRunnable.run();
    }

    /**
     * 循环执行线程
     */
    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(timerRunnable, 1200000);
            showEvaluateDialog();
        }
    };

    // 评价
    private void showEvaluateDialog()
    {
        if (mEvaluateDialog == null)
        {
            mEvaluateDialog = new YNLiveEvaluateDialog.Builder(mContext)
                    .setButtonTextSize(18)
                    .setHeight(0.4f)
                    .setWidth(0.8f)
                    .setHeadImg(liveRoomBean.getIcon())
                    .setuName(liveRoomBean.getUsername())
                    .setLiveType(liveRoomBean.getTag() + "-" + liveRoomBean.getTag2())
                    .setCanceledOnTouchOutside(false)
                    .setOnclickListener(new YNLiveEvaluateDialog.OnClickRadioGroupDialogListener()
                    {
                        @Override
                        public void clickLeftButton(View view)
                        {
                            mEvaluateDialog.dismiss();
                            mEvaluateDialog = null;
                        }

                        @Override
                        public void clickRightButton(View view, final int liveEvaluateIndex)
                        {
                            if (AccountUtils.getLoginInfo())
                            {
                                mEvaluateDialog.dismiss();
                                mEvaluateDialog = null;
                                handler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().liveEvaluate(mContext, YNCommonConfig.LIVE_EVALUATE_URL, liveRoomBean.getUserid(), userId, liveEvaluateIndex,
                                                handler, YNCommonConfig.LIVE_EVALUATE_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                Intent intent = new Intent(mContext, YNLoginActivity.class);
                                startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                                startActivity(intent);
                            }
                        }
                    }).build();
            mEvaluateDialog.show();
        }
    }

    // 输入密码对话编辑框
    private void initInputPassEditDialog()
    {
        mInputPassDialog = new YNEditDialog.Builder(mContext)
                .setTitleVisible(true)
                .setTitleText("请输入直播房间密码")
                .setTitleTextSize(16)
                .setTitleTextColor(R.color.black_light)
                .setContentTextSize(14)
                .setContentText("")
                .setMaxLength(6)
                .setHintText("6位字符")
                .setMaxLines(1)
                .setContentTextColor(R.color.colorPrimary)
                .setButtonTextSize(14)
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setLeftButtonText("取消")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setRightButtonText("确定")
                .setLineColor(R.color.colorPrimary)
//                .setInputTpye(InputType.TYPE_CLASS_NUMBER)
                .setOnclickListener(new YNEditDialog.OnClickEditDialogListener()
                {
                    @Override
                    public void clickLeftButton(View view, String text)
                    {
                        mInputPassDialog.dismiss();
                        getActivity().finish();
                    }

                    @Override
                    public void clickRightButton(View view, final String text)
                    {
                        if (TextUtils.isEmpty(text))
                        {
                            YNToastMaster.showToast(mContext, "请输入直播间密码");
                            return;
                        }
                        handler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().watchLiveValidationPass(mContext, YNCommonConfig.WATCH_LIVE_VALIDATION_PASS_URL, liveRoomBean.getUserid(),
                                        text, handler, YNCommonConfig.WATCH_LIVE_VALIDATION_PASS_FLAG, false);
                            }
                        });
                    }
                })
                .setMinHeight(0.23f)
                .setWidth(0.8f)
                .build();
        mInputPassDialog.show();
    }

    // 付费对话框
    private void initPaymentDialog()
    {
        mPayDialog = new YNPayDialog.Builder(mContext)
                .setHeight(0.23f)  //屏幕高度*0.23
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("此视频需要付费" + liveRoomBean.getPayCoin() + "金币，是否付费观看直播？")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        mPayDialog.dismiss();
                        getActivity().finish();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        if (AccountUtils.getLoginInfo())
                        {
                            if (currentCoin >= liveRoomBean.getPayCoin())
                            {
                                handler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().watchLiveValidationPayCoin(mContext, YNCommonConfig.WATCH_LIVE_VALIDATION_PAY_COIN_URL, AccountUtils.getAccountBean().getId(), liveRoomBean.getUserid(),
                                                handler, YNCommonConfig.WATCH_LIVE_VALIDATION_PAY_COIN_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                YNToastMaster.showToast(mContext, "您的余额不足，请及时充值");
                            }
                        }
                        else
                        {
                            YNToastMaster.showToast(mContext, R.string.un_login_opreate_notice);
                            Intent intent = new Intent(getContext(), YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        mPayDialog.show();
    }

    /**
     * 显示直播贡献列表
     * @param isShowRadioGroup
     */
    private void showLiveContributionList(boolean isShowRadioGroup)
    {
        ((YNLiveDetailsActivity)getActivity()).setBtnClose(false);
        mRLCover.setVisibility(View.VISIBLE);
        liveContributionList.setVisibility(View.VISIBLE);
        mCoverImg.setVisibility(View.VISIBLE);
        final ImageView mClose = (ImageView) liveContributionList.findViewById(R.id.iv_close);
        TextView mOnLine = (TextView) liveContributionList.findViewById(R.id.tv_on_line);
        final RadioGroup mContributionList = (RadioGroup) liveContributionList.findViewById(R.id.rg_list);
        mOnLineUserList = (ListView) liveContributionList.findViewById(R.id.lv_live_contribution);
        mTVEmpty = (TextView) liveContributionList.findViewById(R.id.tv_empty);
        mContributionList.setVisibility(isShowRadioGroup ? View.VISIBLE : View.GONE);
        mOnLine.setVisibility(isShowRadioGroup ? View.GONE : View.VISIBLE);
        mOnLine.setText("在线  " + onLineNumber);

        mClose.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                mRLCover.setVisibility(View.INVISIBLE);
                mCoverImg.setVisibility(View.INVISIBLE);
                liveContributionList.setVisibility(View.INVISIBLE);
                ((YNLiveDetailsActivity)getActivity()).setBtnClose(true);
            }
        });

        mContributionList.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch (checkedId)
                {
                    case R.id.rb_week_list:
                        contributionListType = 0;
                        break;

                    case R.id.rb_total_list:
                        contributionListType = 1;
                        break;
                }
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getContributionValueList(mContext, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL, liveRoomBean.getUserid(), contributionListType,
                                handler, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG, true);
                    }
                });
            }
        });

        // 点击用户列表
        mOnLineUserList.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id)
            {
                clickManagerList = false;
                beClickedUserId = mUserValueList.get(position).getUserid();
                if (processFlag)
                {
                    setProcessFlag();
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getChatRoomUserInfo(mContext, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_URL, liveRoomBean.getRoom_id(), beClickedUserId, userId,
                                    handler, YNCommonConfig.GET_CHAT_ROOM_USER_INFO_FLAG, false);
                        }
                    }, 500);
                    new TimeThread().start();
                }
            }
        });

        mOnLineUserList.setAdapter(mUserValueAdapter);
    }

    /** 创建顶部列表弹出框 */
    private void createChatRoomDialog(final ChatRoomUserBean chatRoomUserBean)
    {
        boolean isAllGone = false;
        boolean isBeClickedManager = false;
        boolean isBeClickedHost = false;
        boolean isHost = false;
        boolean isManager = false;
        boolean showManagerCount = false;

        if (beClickedUserId.equals(liveRoomBean.getUserid()))
        {
            isBeClickedHost = true;
        }
        if (clickManagerList || (chatRoomUserBean.getIs_manage() == 1))
        {
            isBeClickedManager = true;
        }
        if (AccountUtils.getLoginInfo())
        {
            if (beClickedUserId.equals(AccountUtils.getAccountBean().getId()))
            {
                isAllGone = true;
            }
            if (userId.equals(liveRoomBean.getUserid()))
            {
                isHost = true;
            }
            if (chatRoomUserBean.getIs_selfManage() == 1)
            {
                isManager = true;
            }
        }
        if (isHost && !isAllGone)
        {
            showManagerCount = true;
        }

        chatRoomDialog = new YNChatRoomAlertDialog.Builder(mContext)
                .setHeight(0.4f)
                .setWidth(0.8f)
                .setAllGone(isAllGone)
                .setLiveHost(isHost)
                .setRoomManager(isManager)
                .setBeClickedLiveHost(isBeClickedHost)
                .setBeClickedManager(isBeClickedManager)
                .setChatRoomUserBean(chatRoomUserBean)
                .setCanceledOnTouchOutside(false)
                .setShowManagerCount(showManagerCount)
                .setOnclickListener(new IDialogOnClickListener()
                {
                    @Override
                    public void clickTopLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_manage() == 1)
                        {
                            // 取消房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().deleteRoomManager(mContext, YNCommonConfig.DELETE_ROOM_MANAGE_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.DELETE_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 设置房管
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().addRoomManager(mContext, YNCommonConfig.ADD_ROOM_MANAGE_URL, beClickedUserId, liveRoomBean.getUserid(),
                                            handler, YNCommonConfig.ADD_ROOM_MANAGE_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickTopRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getIs_say() == 1)
                        {
                            // 删除禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomCancelGagUser(mContext, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.CANCEL_GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                        else
                        {
                            // 禁言
                            handler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().chatRoomGagUser(mContext, YNCommonConfig.GAG_CHAT_ROOM_USER_URL, liveRoomBean.getRoom_id(), beClickedUserId,
                                            handler, YNCommonConfig.GAG_CHAT_ROOM_USER_FLAG, false);
                                }
                            }, 500);
                        }
                    }

                    @Override
                    public void clickBottomButton(View view)
                    {
                        chatRoomDialog.dismiss();
                        if (chatRoomUserBean.getReport() == 0)
                            // 举报
                            createReportDialog();
                    }
                }).build();
        chatRoomDialog.show();

    }

    /**
     * 创建举报弹出框
     */
    private void createReportDialog()
    {
        View view = getActivity().getLayoutInflater().inflate(R.layout.report_dialog, null);
        Button mBtnReport1 = (Button) view.findViewById(R.id.btn_report1);
        Button mBtnReport2 = (Button) view.findViewById(R.id.btn_report2);
        Button mBtnReport3 = (Button) view.findViewById(R.id.btn_report3);
        Button mBtnReport4 = (Button) view.findViewById(R.id.btn_report4);
        Button mBtnReport5 = (Button) view.findViewById(R.id.btn_report5);
        Button mBtnCancel = (Button) view.findViewById(R.id.btn_cancel);
        final Dialog dialog = new Dialog(mContext, R.style.transparentFrameWindowStyle);
        dialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = dialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getActivity().getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        dialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        dialog.setCanceledOnTouchOutside(false);

        mBtnCancel.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
            }
        });

        mBtnReport1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(mContext, YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                1, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(mContext, YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                2, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(mContext, YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                3, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(mContext, YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                4, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });

        mBtnReport5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dialog.dismiss();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().reportUser(mContext, YNCommonConfig.REPORT_USER_URL, userId, beClickedUserId,
                                5, handler, YNCommonConfig.REPORT_USER_FLAG, false);
                    }
                });
            }
        });
        dialog.show();

    }

    /**
     * 设置按钮在短时间内被重复点击的有效标识（true表示点击有效，false表示点击无效）
     */
    private synchronized void setProcessFlag()
    {
        processFlag = false;
    }

    /**
     * 计时线程（防止在一定时间段内重复点击按钮）
     */
    private class TimeThread extends Thread
    {
        public void run()
        {
            try
            {
                sleep(2000);
                processFlag = true;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    /**
     *  添加点赞动画效果
     */
    public void addHeartLayout() {
        heartLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                int rgb = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));
                heartLayout.addHeart(rgb);
            }
        }, 200);
    }

    protected synchronized void showLeftGiftVeiw(UserInfo user, GiftBean giftBean) {
        YNLogUtil.e("cdy", "礼物");
        if (!isGift2Showing) {
            showGift1Direct(user, giftBean);
        } else if (!isGiftShowing) {
            showGift2Direct(user, giftBean);
        } else {
            toShowList.add(user);
        }
    }

    private void showGift1Direct(final UserInfo user, final GiftBean giftBean)
    {
        isGiftShowing = true;
        getActivity().runOnUiThread(new Runnable()
        {
            @Override public void run()
            {
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setName(user.getName());
                leftGiftView.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView.setGiftName("送出" + giftBean.getGiftName());
                leftGiftView.setGiftImageView(giftBean.getGiftId());
                leftGiftView.setVisibility(View.VISIBLE);
                leftGiftView.setTranslationY(0);
                ViewAnimator.animate(leftGiftView)
                        .alpha(0, 1)
                        .translationX(-leftGiftView.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop()
                        {
                            @Override public void onStop()
                            {
                                UserInfo user = null;
                                try {
                                    user = toShowList.remove(0);
                                }
                                catch (Exception e)
                                {

                                }
                                if (user != null) {
                                    showGift1Direct(user, giftBean);
                                } else {
                                    isGiftShowing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView.getGiftImageView())
                        .translationX(-leftGiftView.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    private void showGift2Direct(final UserInfo user, final GiftBean giftBean)
    {
        isGift2Showing = true;
        getActivity().runOnUiThread(new Runnable() {
            @Override public void run()
            {
                leftGiftView2.setVisibility(View.VISIBLE);
                leftGiftView2.setName(user.getName());
                leftGiftView2.setAvatar(String.valueOf(user.getPortraitUri()));
                leftGiftView2.setGiftName("送出" + giftBean.getGiftName());
                leftGiftView2.setGiftImageView(giftBean.getGiftId());
                leftGiftView2.setTranslationY(0);
                ViewAnimator.animate(leftGiftView2)
                        .alpha(0, 1)
                        .translationX(-leftGiftView2.getWidth(), 0)
                        .duration(600)
                        .thenAnimate(leftGiftView2)
                        .alpha(1, 0)
                        .translationY(-1.5f * leftGiftView2.getHeight())
                        .duration(800)
                        .onStop(new AnimationListener.Stop() {
                            @Override public void onStop() {
                                UserInfo user = null;
                                try
                                {
                                    user = toShowList.remove(0);
                                }
                                catch (Exception e)
                                {

                                }
                                if (user != null)
                                {
                                    showGift2Direct(user, giftBean);
                                } else {
                                    isGift2Showing = false;
                                }
                            }
                        })
                        .startDelay(2000)
                        .start();
                ViewAnimator.animate(leftGiftView2.getGiftImageView())
                        .translationX(-leftGiftView2.getGiftImageView().getX(), 0)
                        .duration(1100)
                        .start();
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.rellayout_root1:
                if (pageSelectedIndex == 0)
                {
                    if (chatFragment != null)
                    {
                        chatFragment.hideKeyBoard();
                    }
                }
                if (pageSelectedIndex == 1)
                {
                    if (askQuestionFragment != null)
                    {
                        askQuestionFragment.hideKeyBoard();
                    }

                }

                if (isFullScreen)
                {
                    if (inputPanel.getVisibility() == View.VISIBLE)
                    {
                        YNCommonUtils.hideSoftInput(getActivity(), inputPanel.getInputView());
                        inputPanel.setVisibility(View.GONE);
                        buttonPanel.setVisibility(View.VISIBLE);
                    }
                }

                hideOuterAfterFiveSeconds();
                break;

            case R.id.iv_speak:
                buttonPanel.setVisibility(View.GONE);
                inputPanel.setVisibility(View.VISIBLE);
                inputPanel.getInputView().requestFocus();
                inputPanel.getInputView().requestFocusFromTouch();

                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        YNCommonUtils.showSoftInput(mContext, inputPanel.getInputView());
                    }
                });
                break;

            case R.id.iv_share:
                showSharePopupWindow();
                break;

            case R.id.iv_evaluate:
                if (liveRoomBean.getLiving() == 0)
                {
                    YNToastMaster.showToast(getContext(), "主播不在线，不能进行直播评价");
                }
                else
                {
                    showEvaluateDialog();
                }
                break;

            case R.id.iv_close:
                if (isFullScreen)
                {
//                    FullScreenUtils.toggleHideyBar(getActivity());
                    setPorirait();
                }
                else
                {
                    getActivity().finish();
//                    YNApplication.getInstance().finishActivity(getActivity());
                }
                break;

//            case R.id.iv_close:
//                if (isFullScreen)
//                {
//                    setPorirait();
//                }
//                else
//                {
//                    LiveKit.quitChatRoom(new RongIMClient.OperationCallback() {
//                        @Override
//                        public void onSuccess() {
//
//                        }
//
//                        @Override
//                        public void onError(RongIMClient.ErrorCode errorCode) {
//                        }
//                    });
//                    YNCommonUtils.hideSoftInput(mContext, inputPanel.getInputView());
//                    getActivity().finish();
//                }
//                break;

            case R.id.rl_hostMessage:
                boolean isHide = false;
                if (YNBaseActivity.isConnectNet)
                {
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getAnchorInfo(mContext, YNCommonConfig.GET_LIVE_HOST_INFO_URL, liveRoomBean.getUserid(),
                                    handler, YNCommonConfig.GET_LIVE_HOST_INFO_FLAG, false);
                        }
                    });

                    if (AccountUtils.getLoginInfo() && userId.equals(liveRoomBean.getUserid()))
                    {
                        isHide = true;
                    }

                    dialog = new YNLiveAlertDialog.Builder(mContext)
                            .setHeight(0.4f)
                            .setWidth(0.8f)
                            .setHeadImgUrl(liveRoomBean.getIcon())
                            .setuName(liveRoomBean.getUsername())
                            .setRoomId(liveRoomBean.getRoom_id())
                            .setuIntroduce(liveRoomBean.getTitle())
                            .setFollowCount(liveRoomBean.getAcount())
                            .setLiveType(liveRoomBean.getTag() + "-"+ liveRoomBean.getTag2())
                            .setAttention(isAttention)
                            .setHide(isHide)
                            .setCanceledOnTouchOutside(false)
                            .setOnclickListener(new IDialogOnClickListener()
                            {
                                @Override
                                public void clickTopLeftButton(View view)
                                {
                                    if (AccountUtils.getLoginInfo())
                                    {
                                        dialog.dismiss();
                                        beClickedUserId = liveRoomBean.getUserid();
                                        createReportDialog();
                                    }
                                    else
                                    {
                                        dialog.dismiss();
                                        Intent intent = new Intent(mContext, YNLoginActivity.class);
                                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                                        startActivity(intent);
                                    }
                                }

                                @Override
                                public void clickTopRightButton(View view)
                                {
                                    dialog.dismiss();
                                }

                                @Override
                                public void clickBottomLeftButton(View view)
                                {
                                    dialog.dismiss();
                                    Intent intent = new Intent(mContext, FindAnchorHomeActivity.class);
                                    intent.putExtra("userId", liveRoomBean.getUserid());
                                    startActivity(intent);
                                }

                                @Override
                                public void clickBottomRightButton(View view) {

                                }

                                @Override
                                public void clickBottomButton(View view)
                                {
                                    if (AccountUtils.getLoginInfo())
                                    {
                                        dialog.dismiss();
                                        if (isAttention)
                                        {
                                            handler.postDelayed(new Runnable()
                                            {
                                                @Override
                                                public void run()
                                                {
                                                    UserHttpUtils.newInstance().cancelAttentionUser(mContext, YNCommonConfig.CANCEL_ATTENTION_USER_URL, userId,
                                                            liveRoomBean.getUserid(), handler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, false);
                                                }
                                            }, 500);

                                        }
                                        else
                                        {
                                            handler.postDelayed(new Runnable()
                                            {
                                                @Override
                                                public void run()
                                                {
                                                    UserHttpUtils.newInstance().attentionUser(mContext, YNCommonConfig.ATTENTION_USER_URL, userId,
                                                            liveRoomBean.getUserid(), handler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                                                }
                                            }, 500);
                                        }
                                    }
                                    else
                                    {
                                        dialog.dismiss();
                                        Intent intent = new Intent(mContext, YNLoginActivity.class);
                                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                                        startActivity(intent);
                                    }
                                }
                            }).build();
                    dialog.show();

                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.no_net));
                }
                break;

            case R.id.tv_follow:
                if (AccountUtils.getLoginInfo())
                {
                    if (isAttention)
                    {
                        handler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().cancelAttentionUser(mContext, YNCommonConfig.CANCEL_ATTENTION_USER_URL, userId,
                                        liveRoomBean.getUserid(), handler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, false);
                            }
                        }, 500);
                    }
                    else
                    {
                        handler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().attentionUser(mContext, YNCommonConfig.ATTENTION_USER_URL, userId,
                                        liveRoomBean.getUserid(), handler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                            }
                        }, 500);
                    }
                }
                else
                {
                    Intent intent = new Intent(mContext, YNLoginActivity.class);
                    startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                    startActivity(intent);
                }
                break;

            case R.id.iv_gift:
                giftType = 0;
                showChooseGift();
                break;

            case R.id.iv_thumb:
                giftType = 1;
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo() && liveRoomBean.getLiving() == 1)
                    {
//                        thumbCount ++;
//                        AfterFiveSecondsSendThumb();
                        if (currentCoin >= 0.1)
                        {
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().liveRoomSendGift(mContext, YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId, liveRoomBean.getUserid(),
                                            "为主播点赞", 1, 0.1f, giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                }
                            });
                        }
                        else
                        {
                            YNToastMaster.showToast(mContext, "您的余额不足，请及时充值");
                        }
                    }
                    else
                    {
                        Intent intent = new Intent(mContext, YNLoginActivity.class);
                        startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                        startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.no_net));
                }
                break;

            case R.id.iv_fullscreen:
                setLandscape();
                break;

//            case R.id.iv_bottom_fullscreen:
//                setPorirait();
//                break;

            case R.id.rl_contribution_list:
                if (YNBaseActivity.isConnectNet)
                {
                    showLiveContributionList(true);
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getContributionValueList(mContext, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL, liveRoomBean.getUserid(), contributionListType,
                                    handler, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG, true);
                        }
                    });
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.no_net));
                }
                break;

            case R.id.tv_user_list:
                showLiveContributionList(false);
                // 查询聊天室用户信息
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().queryChatRoomUserList(mContext, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, liveRoomBean.getRoom_id(),
                                500, 2, userId, handler, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG, true);
                    }
                });
//                if (onLineNumber > 0)
//                {
//                    showLiveContributionList(false);
//                }
//                else
//                {
//                    YNToastMaster.showToast(mContext, "直播间暂时无观众在线");
//                }
                break;

            case R.id.tv_empty:
                if (YNBaseActivity.isConnectNet)
                {
                    showLiveContributionList(true);
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getContributionValueList(mContext, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL, liveRoomBean.getUserid(), contributionListType,
                                    handler, YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG, true);
                        }
                    });
                }
                else
                {
                    YNToastMaster.showToast(mContext, getString(R.string.no_net));
                }
                break;

//            case R.id.tv_retry:
//                if (!YNBaseActivity.isConnectNet)
//                {
//                    YNToastMaster.showToast(mContext, R.string.no_net);
//                }
//                else
//                {
//                    mLLNoNet.setVisibility(View.GONE);
//                    mBVV.start();
//                }
//                break;
        }
    }

    /**
     * 顶部在线用户列表(不包含主播)
     */
    private List<ChatRoomUserBean> topOnLineUserList(List<ChatRoomUserBean> onLineUserList)
    {
        if (!onLineUserList.isEmpty())
        {
            for (ChatRoomUserBean onLineUser : onLineUserList)
            {
                if (onLineUser.getUserid().equals(liveRoomBean.getUserid()))
                {
                    onLineUserList.remove(onLineUser);
                    break;
                }
            }
        }

        return onLineUserList;
    }

    /**
     * 显示礼物选择弹出框
     */
    private void showChooseGift()
    {

        mGiftPopupWindows = new GiftPopupWindows(mContext, R.layout.popwindow_give_gift);
        // 设置layout在PopupWindow中显示的位置
        mGiftPopupWindows.showAtLocation(mLLBottomGift, Gravity.BOTTOM , 0, 0);

    }

    /**
     * 送礼物弹出框
     */
    private class GiftPopupWindows extends PopupWindow
    {
        private View rootView;

        private LinearLayout mLLGoldCoin;
        private TextView mTVSend;
        private Button mBtnSend;
        private GiftLayout mGiftLayout;

        public GiftPopupWindows(Context context, int itemLayoutId)
        {
            super(context);
            mContext = context;

            rootView = View.inflate(context, itemLayoutId, null);

            rootView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.popup_window_anim));
            setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
            setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            setAnimationStyle(R.style.popup_window_style);
            setBackgroundDrawable(new BitmapDrawable());
            setFocusable(true);
            setOutsideTouchable(true);
            setContentView(rootView);

            initView();
        }

        private void initView()
        {
            mLLBottomGift = (ViewGroup) rootView.findViewById(R.id.ll_bottom_gift);
            mGoldCount = (TextView) rootView.findViewById(R.id.tv_gold_count);
            mLLGoldCoin = (LinearLayout) rootView.findViewById(R.id.ll_gold_coin);
            mBtnSend = (Button) rootView.findViewById(R.id.btn_send);
            mTVSend = (TextView) rootView.findViewById(R.id.tv_send);
            mGiftLayout = (GiftLayout) rootView.findViewById(R.id.gift_layout);

            mGoldCount.setText(currentCoin + "");

            mLLGoldCoin.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    if (YNBaseActivity.isConnectNet)
                    {
                        Intent intent = new Intent();
                        // 需要判断用户是否登录
                        if (AccountUtils.getLoginInfo())
                        {
                            intent.setClass(mContext, YNGoldCoinActivity.class);
                            startActivity(intent);
                        }
                        else
                        {
                            intent.setClass(mContext, YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(mContext, getString(R.string.no_net));
                    }
                }
            });

            mTVSend.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    mGiftPopupWindows.dismiss();
                    gift = mGiftLayout.getGiftBean();
                    giftIndex = mGiftLayout.index();
                    if (YNBaseActivity.isConnectNet)
                    {
                        // 判断账户余额是否足够支付
                        if (AccountUtils.getLoginInfo())
                        {
                            if (currentCoin >= gift.getGiftCount())
                            {
                                handler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance().liveRoomSendGift(mContext, YNCommonConfig.LIVE_ROOM_SEND_GIFT_URL, userId,
                                                liveRoomBean.getUserid(), gift.getGiftName(), 1, gift.getGiftCount(), giftType, handler, YNCommonConfig.LIVE_ROOM_SEND_GIFT_FLAG, false);
                                    }
                                });
                            }
                            else
                            {
                                YNToastMaster.showToast(mContext, "您的余额不足，请及时充值");
                            }

                        }
                        else
                        {
                            Intent intent = new Intent(mContext, YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
//                            startActivity(intent);
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(mContext, getString(R.string.no_net));
                    }
                }
            });
        }
    }

    /**
     * 显示底部分享弹出框
     */
    private void showSharePopupWindow()
    {
        mPopupWindows = new YNPopupWindows(mContext, R.layout.popwindow_share);
        // 设置layout在PopupWindow中显示的位置
        mPopupWindows.showAtLocation(mLLBottomShare, Gravity.BOTTOM , 0, 0);

        requestPermissions();
    }

    protected void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkPermissions())
            getPermissions();
    }

    protected boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED;
    }

    protected void getPermissions() {
        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {

        if (requestCode == 22)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            } else {
                getPermissions();
                YNToastMaster.showToast(mContext, "You denied the permission");
            }
            // 用户允许修改权限,0表示允许，-1表示拒绝 PERMISSION_GRANTED = 0, PERMISSION_GRANTED = -1;
            // 授权允许的处理
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
//                YNLogUtil.e("tag", "获取权限成功");
//            else
//                getPermissions();
        }
//        else
//        {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

//        }
    }

    /**
     * 分享弹出框
     */
    private class YNPopupWindows extends PopupWindow implements View.OnClickListener {
        private View rootView;

        private TextView mTVShareWeChat;
        private TextView mTVShareFriendsCircle;
        private TextView mTVShareQQ;
        private TextView mTVShareSinaBlog;

        public YNPopupWindows(Context context, int itemLayoutId) {
            super(context);
            rootView = View.inflate(context, itemLayoutId, null);
            AutoUtils.auto(rootView);
            rootView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.popup_window_anim));
            setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
            setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            setAnimationStyle(R.style.popup_window_style);
            setBackgroundDrawable(new BitmapDrawable());
            setFocusable(true);
            setOutsideTouchable(true);
            setContentView(rootView);

            initView();
        }

        private void initView()
        {
            mLLBottomShare = (LinearLayout) rootView.findViewById(R.id.ll_bottom_share);
            mTVShareWeChat = (TextView) rootView.findViewById(R.id.tv_share_wechat);
            mTVShareFriendsCircle = (TextView) rootView.findViewById(R.id.tv_share_friends_circle);
            mTVShareQQ = (TextView) rootView.findViewById(R.id.tv_share_qq);
            mTVShareSinaBlog = (TextView) rootView.findViewById(R.id.tv_share_sina);

            mTVShareWeChat.setOnClickListener(this);
            mTVShareFriendsCircle.setOnClickListener(this);
            mTVShareQQ.setOnClickListener(this);
            mTVShareSinaBlog.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.tv_share_wechat:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.WEIXIN)
//                            .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_friends_circle:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
//                            .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_qq:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.QQ)
//                            .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;

                case R.id.tv_share_sina:
                    new ShareAction(getActivity()).setPlatform(SHARE_MEDIA.QZONE)
//                            .withText(YNCommonConfig.SHARE_TEXT)
                            .withMedia(web)
                            .setCallback(shareListener)
                            .share();
                    break;
            }
            mPopupWindows.dismiss();
        }
    }

    /**
     * 头部布局执行显示的动画
     */
    public void animateToShow()
    {
        ObjectAnimator leftAnim = ObjectAnimator.ofFloat(headerBar, "translationX", -headerBar.getWidth(), 0);
//        ObjectAnimator topAnim = ObjectAnimator.ofFloat(mLLList, "translationY", -mLLList.getHeight(), 0);
        animatorSetShow.playTogether(leftAnim);
        animatorSetShow.setDuration(300);
        animatorSetShow.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isOpen = false;
            }
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                isOpen = true;
            }
        });
        if(!isOpen) {
            animatorSetShow.start();
        }
    }

    /**
     * 头部布局执行退出的动画
     */
    public void animateToHide()
    {
        ObjectAnimator leftAnim = ObjectAnimator.ofFloat(headerBar, "translationX", 0, -headerBar.getWidth());
//        ObjectAnimator topAnim = ObjectAnimator.ofFloat(mLLList, "translationY", 0, -mLLList.getHeight());
        animatorSetHide.playTogether(leftAnim);
        animatorSetHide.setDuration(300);
        animatorSetHide.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isOpen = false;
            }
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                isOpen = true;
            }
        });
        if (!isOpen) {
            animatorSetHide.start();
        }
    }

    /**
     * 初始化Fragment
     */
    private void addFragment()
    {
        fragments = new ArrayList<>();
        fragments.clear();//清空

        Bundle mBundle = new Bundle();
        mBundle.putSerializable(YNCommonConfig.OBJECT, liveRoomBean);

        chatFragment = new ChatFragment();
        chatFragment.setArguments(mBundle);
//        chatFragment.setLiveRoomBean(liveRoomBean);

        askQuestionFragment = new AskQuestionFragment();
        askQuestionFragment.setArguments(mBundle);
//        askQuestionFragment.setLiveRoomBean(liveRoomBean);

        LiveRoomHomePageFragment homePageFragment = new LiveRoomHomePageFragment();
        homePageFragment.setArguments(mBundle);

        NoticeFragment noticeFragment = new NoticeFragment();
        noticeFragment.setArguments(mBundle);
//        noticeFragment.setLiveRoomBean(liveRoomBean);

        fragments.add(chatFragment);
        fragments.add(askQuestionFragment);
        fragments.add(homePageFragment);
        fragments.add(noticeFragment);

        mAdapter = new MyAdapter(getChildFragmentManager());
        mAdapter.setFragments(fragments);
        indicatorViewPager.setAdapter(mAdapter);

//        mFragmentAdapter = new YNFragmentAdapter(getFragmentManager(), fragments, tabTitle);
//        mViewPager.setOffscreenPageLimit(tabTitle.length);
//        mViewPager.setAdapter(mFragmentAdapter);
//        tabs.setupWithViewPager(mViewPager, true);
//        UIUtils.dynamicSetTabLayoutMode(tabs);
    }

    private void registerMessageReceiver()
    {
        mAskReplayMessageReceiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
        filter.addAction(MESSAGE_RECEIVED_ACTION);
        this.getActivity().registerReceiver(mAskReplayMessageReceiver, filter);
    }

    // 接收消息
    private class MessageReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(final Context context, final Intent intent)
        {
            if (MESSAGE_RECEIVED_ACTION.equals(intent.getAction()))
            {
                if (intent.getBooleanExtra(YNCommonConfig.TITLE, true))
                {
                    isShowRedPoint = false;
                    ((BadgeTextView)mIndicator.getItemView(1)).setBadgeShown(isShowRedPoint);
                }
                else
                {
                    mMsgreceiveContext = context;
                    isShowRedPoint = true;
                    ((BadgeTextView)mIndicator.getItemView(1)).setBadgeShown(isShowRedPoint);
                }
            }
        }
    }

    private class MyAdapter extends IndicatorViewPager.IndicatorFragmentPagerAdapter
    {
        private List<Fragment> fragments = new ArrayList<>();
        public MyAdapter(FragmentManager fragmentManager)
        {
            super(fragmentManager);
        }

        public void setFragments( List<Fragment> fragments)
        {
            this.fragments = fragments;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return tabTitle.length;
        }

        @Override
        public View getViewForTab(int position, View convertView, ViewGroup container)
        {
            if (convertView == null)
            {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.tab_textview, container, false);
            }
            BadgeTextView textView = (BadgeTextView) convertView;
            textView.setText(tabTitle[position]);
            return convertView;
        }

        @Override
        public Fragment getFragmentForPage(int position)
        {
            return fragments.get(position);
        }
    }

    private UMShareListener shareListener = new UMShareListener()
    {
        @Override
        public void onStart(SHARE_MEDIA platform)
        {
            SocializeUtils.safeShowDialog(shareDialog);
        }

        @Override
        public void onResult(SHARE_MEDIA platform)
        {
            YNToastMaster.showToast(mContext, "成功了");
            SocializeUtils.safeCloseDialog(shareDialog);
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t)
        {
            SocializeUtils.safeCloseDialog(shareDialog);
            YNToastMaster.showToast(mContext, "失败"+t.getMessage());
        }

        @Override
        public void onCancel(SHARE_MEDIA platform)
        {
            SocializeUtils.safeCloseDialog(shareDialog);
            YNToastMaster.showToast(mContext, "取消了");
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(mContext).onActivityResult(requestCode,resultCode,data);
        if (requestCode == YNCommonConfig.ACTIVITY_RESULT)
        {
            loginRefreshUI();
        }
    }

    @Override
    public void onPause()
    {
        this.getActivity().unregisterReceiver(mAskReplayMessageReceiver);
        super.onPause();
    }

    @Override
    public void onDestroy()
    {
        broadcastManager.unregisterReceiver(mRefreshReceiver);
        UMShareAPI.get(getActivity()).release();
        LiveKit.removeEventHandler(handler);
        if (myCount != null)
           myCount.cancel();


        handler.removeCallbacksAndMessages(null);

        LiveKit.quitChatRoom(new RongIMClient.OperationCallback()
        {
            @Override
            public void onSuccess()
            {

            }

            @Override
            public void onError(RongIMClient.ErrorCode errorCode)
            {

            }
        });
        LiveKit.logout();
        super.onDestroy();
    }

    @Override
    public void loginRefreshUI()
    {
        if (AccountUtils.getLoginInfo())
        {
            userId = AccountUtils.getAccountBean().getId();

            if (isFullScreen)
            {
                userName = AccountUtils.getAccountBean().getUsername();
                userIcon = AccountUtils.getAccountBean().getIcon();
//                initShareContent();
                handler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getRongCloudToken(mContext, YNCommonConfig.GET_RONG_CLOUD_TOKEN_URL, userId, userName,
                                userIcon, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_RONG_CLOUD_TOKEN_FLAG, false, 500);
                    }
                });

                takePartInLiveRoom();
            }


            updateLiveRoomUserState();
            btnAttentionShow();
//            getCurrentCoin();

//            addFragment();
        }

    }

    private void btnAttentionShow()
    {
        if (AccountUtils.getAccountBean().getId().equals(liveRoomBean.getUserid()))
        {
            mTVFollow.setVisibility(View.GONE);
            mIVGift.setVisibility(View.GONE);
            mIVThumb.setVisibility(View.GONE);
        }
        else
        {
            mTVFollow.setVisibility(liveRoomBean.getIs_attention() == 0 ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * 用户状态请求成功后更新界面UI
     */
    private void updateLiveRoomUI()
    {
        btnAttentionShow();
        if (liveRoomBean.getLive_status() == 2 && isPay == 0)
        {
            if (!userId.equals(liveRoomBean.getUserid()))
            {
                ((YNLiveDetailsActivity)getActivity()).stopVideo();
                initPaymentDialog();
            }
        }
    }

    // 参与直播间
    private void takePartInLiveRoom()
    {
        if (liveRoomBean.getLiving() == 1)
        {
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().liveRoomTakePartIn(mContext, YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_LIVE_ROOM_TAKE_PART_IN_FLAG, false);

                }
            });
        }
    }

    // 获取用户当前金币
    private void getCurrentCoin()
    {
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getCurrentGoldCoin(mContext, YNCommonConfig.GET_CURRENT_GOLD_COIN_URL, userId, handler, YNCommonConfig.GET_CURRENT_GOLD_COIN_FLAG, false);

            }
        });
    }

    private void queryChatRoomUserListInfo()
    {
        // 查询聊天室用户信息
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().queryChatRoomUserList(mContext, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_URL, liveRoomBean.getRoom_id(),
                        500, 1, userId, handler, YNCommonConfig.QUERY_CHAT_ROOM_USER_LIST_FLAG, false);
            }
        });
    }

    private void queryChatRoomManagerInfo()
    {
        handler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().queryChatRoomManagerInfo(mContext, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_URL, liveRoomBean.getRoom_id(), handler, YNCommonConfig.QUERY_CHAT_ROOM_MANAGER_INFO_FLAG, false);
            }
        });
    }

    @Override
    public void unLoginRefreshUI()
    {
//        mTVFollow.setVisibility(liveRoomBean.getIs_attention() == 0 ? View.VISIBLE : View.GONE);
    }

    /**
     * 聊天室重新加入
     * @param liveRoomBean
     */
    private void quitChatRoom(final LiveRoomBean liveRoomBean)
    {
        if (liveRoomBean.getLiving() == 1)
        {
            handler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().liveRoomTakePartIn(getContext(), YNCommonConfig.LIVE_ROOM_TAKE_PART_IN_URL, userId, liveRoomBean.getUserid(), handler, YNCommonConfig.GET_LIVE_ROOM_TAKE_PART_IN_FLAG, false);
                }
            });
        }

        joinChatRoom(liveRoomBean.getRoom_id(), -1);
    }


}
