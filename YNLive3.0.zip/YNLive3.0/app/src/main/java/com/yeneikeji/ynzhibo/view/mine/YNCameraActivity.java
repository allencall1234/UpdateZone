package com.yeneikeji.ynzhibo.view.mine;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserStatusBean;
import com.yeneikeji.ynzhibo.model.YNLiveCategrayBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.FileUtils;
import com.yeneikeji.ynzhibo.utils.NetUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.live.PushStreamingActivity;
import com.yeneikeji.ynzhibo.view.live.YNLiveDetailsActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.AccountUtils.getAccountBean;

/**
 * 我要直播界面
 */
public class YNCameraActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private static final String TAG ="YNCameraActivity" ;
    private TextView mBtnStartLive;// 开始直播
    private ImageView imgHead;
    private TextView mTVDescribeInfo;
    private EditText mLiveTitle;

//    private RadioGroup mRGSign;
//    private RadioButton mRBLbelOne, mRBLbelTwo, mRBLbelThree, mRBLbelFour;

//    private LinearLayout mLLLiveAddress;
//    private TextView mTVLiveAddress;
//    private TextView mTVRateAddress;

    private String path = null;//图片保存路径
    private File imgFile = null;
    private ImageView imgIdentification;
    private TextView mTVMyLive;
    private ImageView imgBack;
    // 默认未认证
    private int checkStatus = 3;
    private UserStatusBean userStatusBean;
//    private int liveTag = 1;
    private String[] typeName ;
    private String[] clumName ;
    private  boolean selectTypeToggle;
    private  boolean selectClumToggle;
    private TextView mSelectType;
    private GridView       mTypeGridleView;
    private GridView       mClumGridleView;
    private ImageView mArrowIv;
    private  int sendMessageToggle=0;
    private  int mSelectTypeposition=0;
    private  int mSelectClumposition=0;
    private MyAdapter mTYpeGridleViewAdapter;
    private MyAdapter mClumGridleViewAdapter;
    private RelativeLayout mRlselectClum;
    private TextView mSelectClum;
    private ImageView mClumArrow;
    private RelativeLayout mRlselectType;
    private CheckBox mSendLiveMessageToggle;
    private List<YNLiveCategrayBean> mTypeBeen;
    private List<YNLiveCategrayBean> mClumBeen;

    private Uri            imageUri;
    private Dialog         mDialog;
    private File           mTmpFile;

    private YNPayDialog noticeDialog;
    private boolean isUpdate = false;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_PUSH_ADDRESS_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("cdy", msg.obj.toString());
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 39)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                userStatusBean = YNJsonUtil.JsonToBean(jsonObject.getString("data"), UserStatusBean.class);
                                AccountUtils.saveUserStatus(userStatusBean);
                                Intent intent = new Intent();
                                intent.setClass(YNCameraActivity.this, PushStreamingActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putSerializable(YNCommonConfig.OBJECT, userStatusBean);
                                intent.putExtras(bundle);
                                startActivity(intent);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        YNToastMaster.showToast(YNCameraActivity.this, bean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(YNCameraActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.UPDATE_LIVE_HOST_INFO_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("cdy", msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 39)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                userStatusBean = YNJsonUtil.JsonToBean(jsonObject.getString("0"), UserStatusBean.class);
                                AccountUtils.saveUserStatus(userStatusBean);
                                Intent intent = new Intent();
                                intent.setClass(YNCameraActivity.this, PushStreamingActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putSerializable(YNCommonConfig.OBJECT, userStatusBean);
                                intent.putExtras(bundle);
                                startActivity(intent);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(YNCameraActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(YNCameraActivity.this, getString(R.string.request_fail));
                    }
                    break;

            }
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        //封装选择数据
        InitialData();
        initView();
        addEvent();
        settingDo();
    }

    private void InitialData() {
        // mDataList = (List<List<YNLiveCategrayBean>>) getIntent().getSerializableExtra("dataList");
        //是否可以发送开播通知 1表示可以发送，2表示不可以发送
        mTypeBeen = (List<YNLiveCategrayBean>) getIntent().getSerializableExtra("dataList1");
        mClumBeen = (List<YNLiveCategrayBean>) getIntent().getSerializableExtra("dataList2");
        //类型id
       int typeId= getAccountBean().getTag2();
        //栏目id
        int clumId= getAccountBean().getClassify();

        if(mTypeBeen !=null) {
            typeName=new String [mTypeBeen.size()];
            for (int i = 0; i < mTypeBeen.size(); i++) {
                typeName[i] = mTypeBeen.get(i).name;
                if(mTypeBeen.get(i).id.equals(""+typeId)){
                    mSelectTypeposition=i;
                }
            }
        }
        if(mClumBeen !=null) {
            clumName=new String [mClumBeen.size()];
            for (int j = 0; j < mClumBeen.size(); j++) {
                clumName[j] = mClumBeen.get(j).name;
                if(mClumBeen.get(j).id.equals(""+clumId)){
                    mSelectClumposition=j;
                }
            }
        }
    }

    @Override
    protected void initView()
    {

        imgHead = (ImageView) findViewById(R.id.imgAvatar);
        //        mCBInvestment = (CheckBox) findViewById(R.id.cb_investment);
        //        mCBRealtimeJiePan = (CheckBox) findViewById(R.id.cb_realtime_jiepan);
        //        mCBCommodityFutures = (CheckBox) findViewById(R.id.cb_commodity_futures);
        //        mCBInsuranceFinancing = (CheckBox) findViewById(R.id.cb_insurance_financing);
//        mRGSign = (RadioGroup) findViewById(R.id.rg_sign);
//        mRBLbelOne = (RadioButton) findViewById(R.id.rb_label_one);
//        mRBLbelTwo = (RadioButton) findViewById(R.id.rb_label_two);
//        mRBLbelThree = (RadioButton) findViewById(R.id.rb_label_three);
//        mRBLbelFour = (RadioButton) findViewById(R.id.rb_label_four);
        mBtnStartLive = (TextView) findViewById(R.id.btn_startLive);
        imgIdentification = (ImageView) findViewById(R.id.imgIdentification);
        mTVMyLive = (TextView) findViewById(R.id.tv_my_live);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        mLiveTitle = (EditText) findViewById(R.id.et_live_title);
//        mLLLiveAddress = (LinearLayout) findViewById(R.id.ll_live_address);
//        mTVLiveAddress = (TextView) findViewById(R.id.tv_live_address);
//        mTVRateAddress = (TextView) findViewById(R.id.tv_rate_address);
        mTVDescribeInfo = (TextView) findViewById(R.id.tv_describe_info);
        mSendLiveMessageToggle = (CheckBox) findViewById(R.id.livebegin_send_toggle);
        /****弹出选择直播类型***/
        mRlselectType = (RelativeLayout) findViewById(R.id.rl_select_type);
        mSelectType = (TextView) findViewById(R.id.select_type_tv);
        mArrowIv = (ImageView) findViewById(R.id.select_type_iv);
        /****弹出选择直播栏目***/
        mRlselectClum = (RelativeLayout) findViewById(R.id.rl_colum_select);
        mSelectClum = (TextView) findViewById(R.id.select_colum_tv);
        mClumArrow = (ImageView) findViewById(R.id.select_colum_iv);
        // 获取用户认证状态
        if(AccountUtils.getUserStatus() != null && AccountUtils.getUserStatus().getTag() != 0)
        {
            checkStatus = Integer.parseInt(AccountUtils.getUserStatus().getCheck_status());
            mTVDescribeInfo.setVisibility(View.GONE);
            //            mLLLiveAddress.setVisibility(View.VISIBLE);
//            mTVLiveAddress.setText(YNCommonUtils.interceptionLiveAddressString(AccountUtils.getUserStatus().getPush_address()));
//            mTVRateAddress.setText(YNCommonUtils.interceptionString(AccountUtils.getUserStatus().getPush_address()));
            mSelectType.setText(typeName[mSelectTypeposition]);
            mSelectClum.setText(clumName[mSelectClumposition]);

            path = AccountUtils.getUserStatus().getPicture();
            if (!TextUtils.isEmpty(path))
               YNImageLoaderUtil.setImage(this, imgHead, path);


            mLiveTitle.setText(AccountUtils.getUserStatus().getTitle());
//            liveTag = AccountUtils.getUserStatus().getTag();
//            if (AccountUtils.getUserStatus().getTag() == 1)
//                mRBLbelOne.setChecked(true);
//            if (AccountUtils.getUserStatus().getTag() == 2)
//                mRBLbelTwo.setChecked(true);
//            if (AccountUtils.getUserStatus().getTag() == 3)
//                mRBLbelThree.setChecked(true);
//            if (AccountUtils.getUserStatus().getTag() == 4)
//                mRBLbelFour.setChecked(true);
        }

//        if(mSelectTypeposition!=-1) {
//            mSelectType.setText(typeName[mSelectTypeposition]);
//        }else{
//            mSelectType.setText("无");
//        }
//        if(mSelectClumposition!=-1) {
//            mSelectClum.setText(clumName[mSelectClumposition]);
//        }else{
//            mSelectClum.setText("无");
//        }
    }

    @Override
    protected void addEvent()
    {
        mLiveTitle.setOnClickListener(this);
        imgIdentification.setOnClickListener(this);
        mTVMyLive.setOnClickListener(this);
        imgBack.setOnClickListener(this);
        imgHead.setOnClickListener(this);
        //是否发送通知的开关,如果没有超过两次就可以点击发送。否则不能发送开播通知
        if(getAccountBean().getSend_status().equals("1")){
            mSendLiveMessageToggle.setClickable(true);
        }else{
            mSendLiveMessageToggle.setClickable(false);
        }
        mSendLiveMessageToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    sendMessageToggle=1;
                }else{
                        sendMessageToggle=0;
                }
            }
        });
        //弹出直播类型选择
        mRlselectType.setOnClickListener(this);
        if(typeName==null||typeName.length<1){
            mSelectType.setText("无");
        }
        //弹出直播栏目选择
        mRlselectClum.setOnClickListener(this);
        if(clumName==null||clumName.length<1){
            mSelectClum.setText("无");
        }

        //        mCBInvestment.setOnClickListener(this);
        //        mCBRealtimeJiePan.setOnClickListener(this);
        //        mCBCommodityFutures.setOnClickListener(this);
        //        mCBInsuranceFinancing.setOnClickListener(this);
        // 设置性别，存储当前性别数据，用于上传
//        mRGSign.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId)
//            {
//                switch (checkedId)
//                {
//                    case R.id.rb_label_one:
//                        liveTag = 1;
//                        break;
//
//                    case R.id.rb_label_two:
//                        liveTag = 2;
//                        break;
//
//                    case R.id.rb_label_three:
//                        liveTag = 3;
//                        break;
//
//                    case R.id.rb_label_four:
//                        liveTag = 4;
//                        break;
//                }
//            }
//        });
        mBtnStartLive.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
//        requestPermissions();
    }

    @Override
    protected void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkPermissions())
            getPermissions();
    }

    @Override
    protected boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void getPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO}, 22);
    }

    @Override
    public void onClick(View view)
    {
        Intent intent = new Intent();
        switch (view.getId())
        {
            case R.id.imgBack:
                finish();
                break;

            case R.id.imgIdentification:
                // 0代表用户认证通过
                if(checkStatus == 0)
                {
                    intent.setClass(this, MyLiveActivity.class);
                    startActivity(intent);
                    // 弹出认证信息Dialog
                    //                    Toast.makeText(getApplicationContext(),"姓名"+AccountUtils.getUserStatus().getRealname(),Toast.LENGTH_SHORT).show();
                    //                    Toast.makeText(getApplicationContext(),"身份证"+AccountUtils.getUserStatus().getId_card(),Toast.LENGTH_SHORT).show();
                }
                else
                {
                    intent.setClass(this, YNRealNameActivity.class);
                    startActivity(intent);
                    finish();
                }
                break;
            case R.id.tv_my_live:
                intent.setClass(this, MyLiveActivity.class);
                startActivity(intent);
                break;

            case R.id.imgAvatar:
                showDialog();
                break;

            case R.id.btn_startLive:
                //要先判断类型和栏目是否有选择
                if (!TextUtils.isEmpty(AccountUtils.getUserStatus().getPicture())
                        && !TextUtils.isEmpty(AccountUtils.getUserStatus().getTitle()))
                {
//                    if (AccountUtils.getUserStatus().getPicture().equals(path) && AccountUtils.getUserStatus().getTitle().equals(mLiveTitle.getText().toString())
//                            && (AccountUtils.getUserStatus().getTag1() == tag1)
//                            && (AccountUtils.getUserStatus().getTag2() == tag2)
//                            && (AccountUtils.getUserStatus().getTag3() == tag3)
//                            && (AccountUtils.getUserStatus().getTag4() == tag4))
//                    {
//                        addLiveHostInfoNetworkRequest();
//                    }
                    if (AccountUtils.getUserStatus().getPicture().equals(path) && AccountUtils.getUserStatus().getTitle().equals(mLiveTitle.getText().toString())
                           && (""+ getAccountBean().getTag2()).equals(mTypeBeen.get(mSelectTypeposition).id)&&(""+ getAccountBean().getClassify()).equals(mClumBeen.get(mSelectClumposition).id))
                    {
                        isUpdate = false;
                        showNoticeDilaog();

                    }
                    else
                    {
                        isUpdate = true;
                        showNoticeDilaog();
                    }
                }
                else
                {
                    if (TextUtils.isEmpty(path))
                    {
                        YNToastMaster.showToast(YNCameraActivity.this, "请选择直播封面");
                        return;
                    }
                    if (TextUtils.isEmpty(mLiveTitle.getText().toString()))
                    {
                        YNToastMaster.showToast(YNCameraActivity.this, "请填写直播标题");
                        return;
                    }
                    isUpdate = false;
                }
                break;

            //            case R.id.cb_investment:
            //                tag1 = (mCBInvestment.isChecked() == true ? 1 : 0);
            //                break;
            //
            //            case R.id.cb_realtime_jiepan:
            //                tag2 = (mCBRealtimeJiePan.isChecked() == true ? 2 : 0);
            //                break;
            //
            //            case R.id.cb_commodity_futures:
            //                tag3 = (mCBCommodityFutures.isChecked() == true ? 3 : 0);
            //                break;
            //
            //            case R.id.cb_insurance_financing:
            //                tag4 = (mCBInsuranceFinancing.isChecked() == true ? 4 : 0);
            //                break;

            case R.id.tv_describe_info:
                mLiveTitle.setFocusable(true);
                break;
            //gridleview选择直播类型
            case R.id.rl_select_type :
                selectTypeToggle=!selectTypeToggle;
                //判断栏目选择是否展开
                if(selectClumToggle){
                    selectClumToggle=!selectClumToggle;
                    updataSelectClumStatu(selectClumToggle);
                }
                //更新类型选择
                updataSelectStyteStatu(selectTypeToggle);
                break;
            //gridleview选择直播栏目
            case R.id.rl_colum_select:
                selectClumToggle = !selectClumToggle;
                //判断类型选择是否展开
                if(selectTypeToggle) {
                    selectTypeToggle=!selectTypeToggle;
                    updataSelectStyteStatu(selectTypeToggle);
                }
                //更新栏目选择
                updataSelectClumStatu(selectClumToggle);
                break;
        }
    }

    /**
     * 显示提示框
     */
    private void showNoticeDilaog()
    {
        if (NetUtils.isConnected(this))
        {
            if (!NetUtils.isWifi(this))
            {
                noticeDialog = new YNPayDialog.Builder(this)
                        .setContentText("您当前处于非WIFI环境下，是否要观看直播？")
                        .setRightButtonTextColor(R.color.ynkj_red)
                        .setCanceledOnTouchOutside(false)
                        .setOnclickListener(new IDialogOnClickListener() {
                            @Override
                            public void clickTopLeftButton(View view) {

                            }

                            @Override
                            public void clickTopRightButton(View view)
                            {

                            }

                            @Override
                            public void clickBottomLeftButton(View view)
                            {
                                noticeDialog.dismiss();
                            }

                            @Override
                            public void clickBottomRightButton(View view)
                            {
                                noticeDialog.dismiss();
                                if (isUpdate)
                                    addLiveHostInfoNetworkRequest();
                                else
                                    updateLiveHostInfoNetworkRequest();
                            }

                            @Override
                            public void clickBottomButton(View view) {

                            }
                        })
                        .build();
                noticeDialog.show();
            }
        }
    }

    //更新类型选择状态
    private void updataSelectStyteStatu(boolean selectTypeToggle) {
        if(selectTypeToggle) {
            //  mGridleView= (GridView) getLayoutInflater().inflate( R.layout.gridleview_item, null,false);
            mTypeGridleView= (GridView) findViewById(R.id.gridleview);
            mTypeGridleView.setVisibility(View.VISIBLE);
            mTYpeGridleViewAdapter = new MyAdapter(typeName);
          //  int typeposition = SpUtils.getPosition(YNCameraActivity.this, "typeposition");
            mTYpeGridleViewAdapter.setTypeSelection(mSelectTypeposition);
            mTypeGridleView.setAdapter(mTYpeGridleViewAdapter);
            //mPopupWindowType = new PopupWindow(mGridleView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            //   mPopupWindowType.showAsDropDown(mRlselectType);
            mArrowIv.setImageResource(R.drawable.label_choice_open);
            mSelectType.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.praise_item_default));
            mTypeGridleView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    mTYpeGridleViewAdapter.setTypeSelection(position);
                    mSelectType.setText(mTypeBeen.get(position).name);
                    mTYpeGridleViewAdapter.notifyDataSetChanged();
                  //  SpUtils.putPosition(YNCameraActivity.this,position,"typeposition");
                }
            });
        }else{
            //  mPopupWindowType.dismiss();
            mTypeGridleView.setVisibility(View.GONE);
            mArrowIv.setImageResource(R.drawable.label_choice_close);
            mSelectType.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.private_msg_introduce_txt));
        }
        // mSelectType.setText();
    }
    //更新栏目选择状态
    private void updataSelectClumStatu(boolean selectClumToggle) {
        if (selectClumToggle) {
            // mGridleView= (GridView) getLayoutInflater().inflate( R.layout.gridleview_item, null,false);
            mClumGridleView = (GridView) findViewById(R.id.colum_gridleview);
            mClumGridleView.setVisibility(View.VISIBLE);
            mClumGridleViewAdapter = new MyAdapter(clumName);
          //  int columposition = SpUtils.getPosition(YNCameraActivity.this, "columposition");
            mClumGridleViewAdapter.setClumSelection(mSelectClumposition);
            mClumGridleView.setAdapter(mClumGridleViewAdapter);
            //mPopupWindowClum = new PopupWindow(mGridleView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            //mPopupWindowClum.showAsDropDown(mRlselectClum);
            mClumArrow.setImageResource(R.drawable.label_choice_open);
            mSelectClum.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.praise_item_default));
            mClumGridleView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {

                   // SpUtils.putPosition(YNCameraActivity.this,position,"columposition");
                    mClumGridleViewAdapter.setClumSelection(position);
                    mSelectClum.setText(mClumBeen.get(position).name);
                    mClumGridleViewAdapter.notifyDataSetChanged();

                }
            });
        } else {
            //  mPopupWindowClum.dismiss();
            mClumGridleView.setVisibility(View.GONE);
            mClumArrow.setImageResource(R.drawable.label_choice_close);
            mSelectClum.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.private_msg_introduce_txt));
        }
    }

    /**
     * 获取、添加主播开播时填写信息
     */
    private void addLiveHostInfoNetworkRequest()
    {
        if (NetUtils.isConnected(this))
        {
            BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(path);
            int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
            int imgMax = Math.max(options.outWidth, options.outHeight);
            int inSimpleSize = 1;
            if (screenMax <= imgMax)
            {
                inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
            }


            if (AccountUtils.getUserStatus().getPicture().equals(path))
            {
                imgFile = null;
            }
            else
            {
                path = YNBitMapUtil.compressBitmap(context, path, Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                imgFile = new File(path);
            }
           /* //判断栏目选项内容是否为空
            if(clumName==null||clumName.length<1){
              clum="";
            }else{
                clum =mClumBeen.get(mSelectClumposition).id;
            }*/

            mHandler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getPushAddressUrl(YNCameraActivity.this, YNCommonConfig.GET_PUSH_ADDRESS_URL, getAccountBean().getId(), YNCommonUtils.interceptionString(AccountUtils.getUserStatus().getPush_address()),
                                                                  imgFile,
                                                                  mLiveTitle.getText().toString().trim(),
                                                                  mTypeBeen.get(mSelectTypeposition).id,
                                                                  mClumBeen.get(mSelectClumposition).id,
                                                                  ""+sendMessageToggle, 1, mHandler, YNCommonConfig.GET_PUSH_ADDRESS_FLAG, true);
                }
            });
        }
        else
        {
            YNToastMaster.showToast(YNCameraActivity.this, "网络未连接");
        }
    }

    /**
     * 修改主播开播时填写信息
     */
    private void updateLiveHostInfoNetworkRequest()
    {

        if (NetUtils.isConnected(this))
        {
            if (AccountUtils.getUserStatus().getPicture().equals(path))
            {
                imgFile = null;
            }
            else
            {
                BitmapFactory.Options options = YNBitMapUtil.getBitmapOptions(path);
                int screenMax = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
                int imgMax = Math.max(options.outWidth, options.outHeight);
                int inSimpleSize = 1;
                if (screenMax <= imgMax)
                {
                    inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
                }

                path = YNBitMapUtil.compressBitmap(context, path, Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                imgFile = new File(path);
            }
            //判断栏目选项内容是否为空
           /* if(clumName==null||clumName.length<1){
                clum="";
            }else{
                clum =mClumBeen.get(mSelectClumposition).id;
            }*/

           /* Toast.makeText(context, "type="+mTypeBeen.get(mSelectTypeposition).name+"clum="+mClumBeen.get(mSelectClumposition).name, Toast.LENGTH_SHORT)
                 .show();*/

            mHandler.postDelayed(new Runnable()
            {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().updateLiveInfo(YNCameraActivity.this, YNCommonConfig.UPDATE_LIVE_INFO_URL, getAccountBean().getId(), imgFile, mLiveTitle.getText().toString().trim(), mTypeBeen.get(mSelectTypeposition).id, mClumBeen.get(mSelectClumposition).id, ""+sendMessageToggle, mHandler, YNCommonConfig.UPDATE_LIVE_HOST_INFO_FLAG, true);
                }
            }, 500);
        }
        else
        {
            YNToastMaster.showToast(YNCameraActivity.this, "网络未连接");
        }

    }

    //创建修改头像弹出框
    private void showDialog()
    {
        View view = getLayoutInflater().inflate(R.layout.head_image_choose_dialog, null);
        mDialog = new Dialog(this, R.style.transparentFrameWindowStyle);
        mDialog.setContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                                               ViewGroup.LayoutParams.WRAP_CONTENT));

        Window window = mDialog.getWindow();
        // 设置显示动画
        window.setWindowAnimations(R.style.main_menu_animstyle);
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.x = 0;
        wl.y = getWindowManager().getDefaultDisplay().getHeight();

        // 以下这两句是为了保证按钮可以水平满屏
        wl.width = ViewGroup.LayoutParams.MATCH_PARENT;
        wl.height = ViewGroup.LayoutParams.WRAP_CONTENT;

        // 设置显示位置
        mDialog.onWindowAttributesChanged(wl);
        // 设置点击外围解散
        mDialog.setCanceledOnTouchOutside(true);

        buttonHeadOnClickListenner();

        mDialog.show();
    }

    // 修改头像监听
    private void buttonHeadOnClickListenner()
    {
        Button btn_takephoto = (Button) mDialog.getWindow().findViewById(R.id.btn_takephoto);
        Button btn_choose_images = (Button) mDialog.getWindow().findViewById(R.id.btn_choose_images);
        Button btn_cancel = (Button) mDialog.getWindow().findViewById(R.id.btn_cancel);

//        btn_takephoto.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(intent, YNCommonConfig.TAKE_PHOTO);
//                path = YNFileUtil.getRootFilePath(YNCameraActivity.this) + YNCommonConfig.PHOTO_DIR + "/" + YNCommonConfig.COVER_PHOTO_NAME;
//                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(path)));//拍照后输出，保存在本地中
//                dialog.dismiss();
//            }
//        });
//
//        btn_choose_images.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent in = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                startActivityForResult(in, YNCommonConfig.CHOOSE_IMAGES);
//                dialog.dismiss();
//            }
//        });

        btn_takephoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(context,
                                                      Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(YNCameraActivity.this,
                                                      new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                                                   Manifest.permission.CAMERA},
                                                      2);
                } else {
                    openCamera();
                }

            }
        });


        btn_choose_images.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(context,
                                                      android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(YNCameraActivity.this,
                                                      new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                                      1);
                } else {
                    openAlbum();
                }

            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

    }

    private void openCamera() {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(context.getPackageManager()) != null) {
            try {
                mTmpFile = FileUtils.createTmpFile(context);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (mTmpFile != null && mTmpFile.exists()) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                    imageUri = Uri.fromFile(mTmpFile);
                } else {
                    ContentValues contentValues = new ContentValues(1);
                    contentValues.put(MediaStore.Images.Media.DATA, mTmpFile.getAbsolutePath());
                    imageUri = context.getContentResolver()
                                      .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                              contentValues);
                }
                YNLogUtil.e(TAG, " imagUri -------> " + imageUri);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, YNCommonConfig.TAKE_PHOTO);
            } else {
                YNToastMaster.showToast(context, " File is not exists");
            }
        } else {
            YNToastMaster.showToast(context, "No camera");
        }
        mDialog.dismiss();
    }

    private void openAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK,
                                   MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, YNCommonConfig.CHOOSE_IMAGES);
        mDialog.dismiss();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openAlbum();
                } else {
                    YNToastMaster.showToast(this, "You denied the permission");
                }
                break;
            case 2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                } else {
                    YNToastMaster.showToast(this, "You denied the permission");
                }
                break;
        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        YNLogUtil.i(TAG, (data == null) + "");
        Bitmap image = null;

        switch (requestCode) {
            case YNCommonConfig.TAKE_PHOTO:
                if (resultCode == Activity.RESULT_OK) {
                    path = YNBitMapUtil.getPathByUri(this, imageUri);
                    image = BitmapFactory.decodeFile(path);

                }
                break;

            case YNCommonConfig.CHOOSE_IMAGES:
                if (data == null) return;
                if (resultCode == Activity.RESULT_OK) {
                    Uri uri = data.getData();
                    path = YNBitMapUtil.getPathByUri(this, uri);
                    image = BitmapFactory.decodeFile(path);
                }
                break;

            // 取得裁剪后的图片
            case YNCommonConfig.CUT_IMAGES:
                /**
                 * 非空判断大家一定要验证，如果不验证的话，
                 * 在剪裁之后如果发现不满意，要重新裁剪，丢弃
                 * 当前功能时，会报NullException，小马只
                 * 在这个地方加下，大家可以根据不同情况在合适的
                 * 地方做判断处理类似情况
                 *
                 */
//                if (data != null) {
//                    image = setPicToView(data);
//                }
                break;

            default:
                break;
        }
        imgHead.setImageBitmap(image);//设置显示图片

/*        //将图片保存在本地的文件夹中
        YNBitMapUtil.savePreviewBitmap(YNCommonConfig.photoName, image);
        imgFile = new File(path);
        Bitmap bitmap = YNBitMapUtil.getBitmapFromFile(imgFile, R.dimen.layout_x_100, R.dimen.layout_x_100);
        imgHead.setImageBitmap(bitmap);//设置显示图片
        //getDrawingCache()获取imageview显示的图片，获取前，先将setDrawingCacheEnabled设置为true，
        //操作完成后，要及时将setDrawingCacheEnabled 再重新设置为false,否则，该imageview将不能更新图片
        imgHead.setDrawingCacheEnabled(true);
        YNBitMapUtil.savePreviewBitmap(YNCommonConfig.photoName, imgHead.getDrawingCache());
        imgHead.setDrawingCacheEnabled(false);*/

        //保存到后台
/*        if(UserHelper.getInstance()!=null)
        {
            File file=new File(path);
            UserBean bean=MyApp.globelUser;
            UserHttpClass.newInstance().updateuser(PersonMessageActivity.this, handler,
                    bean.getUserId(),null,null, file, null, null, bean.getAge(),
                    bean.getConstellation(), null,bean.getNebulaValue(),
                    bean.getNebulaMoney(),FLAG_UPDATE_USERINFO);
        }*/
    }

    /**
     * 裁剪图片方法实现
     * @param uri
     */
    public void startPhotoZoom(Uri uri)
    {
        /*
         * 至于下面这个Intent的ACTION是怎么知道的，大家可以看下自己路径下的如下网页
         * yourself_sdk_path/docs/reference/android/content/Intent.html
         * 直接在里面Ctrl+F搜：CROP ，之前小马没仔细看过，其实安卓系统早已经有自带图片裁剪功能,
         */
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        //下面这个crop=true是设置在开启的Intent中设置显示的VIEW可裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 150);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, YNCommonConfig.CUT_IMAGES);
    }

    /**
     * 保存裁剪之后的图片数据
     * @param picdata
     */
    private Bitmap setPicToView(Intent picdata)
    {
        Bundle extras = picdata.getExtras();
        Bitmap photo = null;
        if (extras != null)
        {
            photo = extras.getParcelable("data");
            YNBitMapUtil.savePreviewBitmap(path, photo);
            /**
             * 下面注释的方法是将裁剪之后的图片以Base64Coder的字符方式上
             * 传到服务器，QQ头像上传采用的方法跟这个类似
             */

            /*ByteArrayOutputStream stream = new ByteArrayOutputStream();
            photo.compress(Bitmap.CompressFormat.JPEG, 60, stream);
            byte[] b = stream.toByteArray();
            // 将图片流以字符串形式存储下来

            tp = new String(Base64Coder.encodeLines(b));
            这个地方大家可以写下给服务器上传图片的实现，直接把tp直接上传就可以了，
            服务器处理的方法是服务器那边的事了，吼吼

            如果下载到的服务器的数据还是以Base64Coder的形式的话，可以用以下方式转换
            为我们可以用的图片类型就OK啦...吼吼
            Bitmap dBitmap = BitmapFactory.decodeFile(tp);
            Drawable drawable = new BitmapDrawable(dBitmap);
            */
        }
        return photo;
    }

    class MyAdapter extends BaseAdapter{

        private String[] content;
        public MyAdapter(String[] content) {
            this.content = content;
        }


        @Override
        public int getCount() {
            if(content!=null){
                return   content.length;
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return content[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            TextView tv= (TextView) getLayoutInflater().from(YNCameraActivity.this).inflate(R.layout.gridleview_item_tv, null);
            tv.setText(content[position]);
            if(mSelectTypeposition==position && selectTypeToggle==true ||mSelectClumposition==position && selectClumToggle==true){
                tv.setBackgroundResource(R.drawable.label_act01);
                tv.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.colorWealthbtn));
            }else{
                tv.setBackgroundResource(R.drawable.corners_bg_null);
                tv.setTextColor(ContextCompat.getColor(YNCameraActivity.this, R.color.praise_item_default));
            }
            notifyDataSetChanged();
            return tv;
        }
        public void setTypeSelection(int position){
            mSelectTypeposition=position;

        }
        public void setClumSelection(int position){

            mSelectClumposition=position;

        }
    }

}
