
package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCacheUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

/**
 * 设置界面
 */
public class YNSettingActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    public static final String TAG = "YNSettingActivity";

    private RelativeLayout mRLAccountSafe;
    private RelativeLayout mRLPushSetting;
    private RelativeLayout mRLSuggestionFedBack;
    private TextView txtCache;
    private RelativeLayout rlCache;
    private RelativeLayout rlQuit;
//    private CheckBox chbSwitch;
    private RelativeLayout mRLAbout;
    private View line;
    private View bottomLine;

    private YNApplication app;
//    private YNCommonDialog comDialog;
    private YNPayDialog exitDialog;
    private String userId;
    private MessageBean mMessageBean;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.APP_EXIT_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 81)
                        {
                            AccountUtils.saveLogin(false);
                            finish();
                        }

                        YNToastMaster.showToast(YNSettingActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(YNSettingActivity.this, R.string.request_fail);
                    }
                    break;

//                case YNCommonConfig.OPEN_OR_CLOSE_PUSH_FLAG:
//                    if (msg.obj != null)
//                    {
//                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
//                        if (baseBean.getCode() == 85)
//                        {
//                            chbSwitch.setChecked(!AccountUtils.getPushStatus());
//                            AccountUtils.savePushStatus(!AccountUtils.getPushStatus());
//                        }
//                    }
//                    break;

                case YNCommonConfig.SET_JPUSH_ALIAS:
                    // 调用 JPush 接口来设置别名。
                    JPushInterface.setAliasAndTags(getApplicationContext(),
                            (String) msg.obj,
                            null,
                            mAliasCallback);
                    break;

            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_setting,null);
       // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        if (app == null)
        {
            app = YNApplication.getInstance();
        }

        configTopBarCtrollerWithTitle(getString(R.string.setting));

        mRLPushSetting = (RelativeLayout) findViewById(R.id.rl_push_setting);
        mRLAccountSafe = (RelativeLayout) findViewById(R.id.rl_account_safe);
        mRLSuggestionFedBack = (RelativeLayout) findViewById(R.id.rl_suggestion_fed_back);
        rlCache = (RelativeLayout) findViewById(R.id.rlCache);
        txtCache = (TextView) findViewById(R.id.txtCache);
        mRLAbout = (RelativeLayout) findViewById(R.id.rl_about);
        rlQuit = (RelativeLayout) findViewById(R.id.rl_quit);
//        chbSwitch = (CheckBox) findViewById(R.id.chbSwtich);
        line = findViewById(R.id.line);
        bottomLine = findViewById(R.id.bottom_line);
    }

    @Override
    protected void onResume()
    {
        if (AccountUtils.getLoginInfo())
            loginRefreshUI();
        else
            unLoginRefreshUI();
        super.onResume();
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLAccountSafe.setOnClickListener(this);
        mRLPushSetting.setOnClickListener(this);
        mRLSuggestionFedBack.setOnClickListener(this);
        rlCache.setOnClickListener(this);
        mRLAbout.setOnClickListener(this);
        rlQuit.setOnClickListener(this);

//        chbSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
//            {
//                if (AccountUtils.getLoginInfo())
//                {
//                    mHandler.post(new Runnable()
//                    {
//                        @Override
//                        public void run()
//                        {
//                            UserHttpUtils.newInstance().openOrClosePush(YNSettingActivity.this, YNCommonConfig.OPEN_OR_CLOSE_PUSH_URL, userId, mHandler, YNCommonConfig.OPEN_OR_CLOSE_PUSH_FLAG, false);
//                        }
//                    });
//                }
//                else
//                {
//                    YNToastMaster.showToast(YNSettingActivity.this, R.string.un_login_opreate_notice);
//                }
//            }
//        });
    }

    @Override
    protected void settingDo()
    {
     //   chbSwitch.setChecked(AccountUtils.getPushStatus());
        showCacheSize();
        mMessageBean = new MessageBean();
    }

    private void showCacheSize()
    {
        try
        {
            txtCache.setText(YNCacheUtil.getTotalCacheSize(getApplicationContext()));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

           case R.id.rl_account_safe:
               if (AccountUtils.getLoginInfo())
               {
                   intent.setClass(this, YNAccountSafeActivity.class);
//                   intent.setClass(this, YNSetPasswordActivity.class);
//                   intent.putExtra(YNCommonConfig.PHONE_NUMBER, AccountUtils.getAccountBean().getPhone());
//                   intent.putExtra(YNCommonConfig.FORGET_PASS, false);
               }
               else
               {
                   intent.setClass(this, YNLoginActivity.class);
               }
               startActivity(intent);
               break;

            case R.id.rl_push_setting:
                if (AccountUtils.getLoginInfo())
                {
                    intent.setClass(this, PushSetUpActivity.class);
                }
                else
                {
                    intent.setClass(this, YNLoginActivity.class);
                }
                startActivity(intent);
                break;

            case R.id.rl_suggestion_fed_back:
                if (AccountUtils.getLoginInfo())
                {
                    intent.setClass(this, YNSuggestionActivity.class);
                }
                else
                {
                    intent.setClass(this, YNLoginActivity.class);
                }
                startActivity(intent);
                break;

            case R.id.rlCache:
                createDialog(YNCommonConfig.CACHE);
                break;

            case R.id.rl_about:
                intent.setClass(this, YNAboutActivity.class);
                startActivity(intent);
                break;

            case R.id.rl_quit:
                createDialog(YNCommonConfig.QUIT);
                break;
        }
    }

    private void createDialog(final int flag)
    {
        String content = (flag == YNCommonConfig.CACHE  ? "确定要清除缓存？" : "确定要退出吗？");

        exitDialog = new YNPayDialog.Builder(this)
                .setContentText(content)
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setContentTextSize(18)
                .setRightButtonTextColor(R.color.ynkj_red)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener()
                {
                    @Override
                    public void clickTopLeftButton(View view)
                    {

                    }

                    @Override
                    public void clickTopRightButton(View view)
                    {

                    }

                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        exitDialog.dismiss();
                    }

                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        if (flag == YNCommonConfig.CACHE)
                        {
                            new Thread() {
                                @Override
                                public void run()
                                {
                                    super.run();
                                    YNCacheUtil.clearAllCache(getApplicationContext());
                                }
                            }.start();
                            txtCache.setText("0K");
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setAlias("");
                                }
                            });
                            AccountUtils.saveLogin(false);
                            finish();
//                            mHandler.post(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    UserHttpUtils.newInstance().userExitApp(YNSettingActivity.this, YNCommonConfig.APP_EXIT_URL, AccountUtils.getAccountBean().getPhone(),
//                                            "0", mHandler, YNCommonConfig.APP_EXIT_FLAG);
//                                }
//                            });
                        }
                        exitDialog.dismiss();
                    }

                    @Override
                    public void clickBottomButton(View view)
                    {

                    }
                })
                .build();
        exitDialog.show();

        /*comDialog = new YNCommonDialog(this, R.style.NormalDialogStyle, content, false, new YNCommonDialog.CustomDialogListener() {
            @Override
            public void OnClick(View view)
            {
                switch (view.getId())
                {
                    case R.id.btnCancel:
                        comDialog.dismiss();

                        break;

                    case R.id.btnConfirm:
                        if (flag == YNCommonConfig.CACHE)
                        {
                            new Thread() {
                                @Override
                                public void run()
                                {
                                    super.run();
                                    YNCacheUtil.clearAllCache(getApplicationContext());
                                }
                            }.start();
                            txtCache.setText("0K");
                        }
                        else
                        {
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    setAlias("");
                                }
                            });
                            AccountUtils.saveLogin(false);
                            finish();
//                            mHandler.post(new Runnable()
//                            {
//                                @Override
//                                public void run()
//                                {
//                                    UserHttpUtils.newInstance().userExitApp(YNSettingActivity.this, YNCommonConfig.APP_EXIT_URL, AccountUtils.getAccountBean().getPhone(),
//                                            "0", mHandler, YNCommonConfig.APP_EXIT_FLAG);
//                                }
//                            });
                        }
                        comDialog.dismiss();
                        break;
                }
            }
        });
        comDialog.show();*/
    }

    // 这是来自 JPush Example 的设置别名的 Activity 里的代码。一般 App 的设置的调用入口，在任何方便的地方调用都可以。
    private void setAlias(String alias)
    {
        // 调用 Handler 来异步设置别名
        mHandler.sendMessage(mHandler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, alias));
    }

    private final TagAliasCallback mAliasCallback = new TagAliasCallback() {

        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs ;
            switch (code) {
                case 0:
                    logs = "Set tag and alias success";
                    AccountUtils.saveSetAlias(alias);
                    // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
                    break;

                case 6002:
                    logs = "Failed to set alias and tags due to timeout. Try again after 60s.";
                    // 延迟 60 秒来调用 Handler 设置别名
                    mHandler.sendMessageDelayed(mHandler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, alias), 1000 * 60);
                    break;

                default:
                    logs = "Failed with errorCode = " + code;
            }
        }
    };

    @Override
    public void loginRefreshUI()
    {
        userId = AccountUtils.getAccountBean().getId();
        line.setVisibility(View.VISIBLE);
        bottomLine.setVisibility(View.VISIBLE);
        rlQuit.setVisibility(View.VISIBLE);
    }

    @Override
    public void unLoginRefreshUI()
    {
        line.setVisibility(View.INVISIBLE);
        bottomLine.setVisibility(View.INVISIBLE);
        rlQuit.setVisibility(View.INVISIBLE);
    }

}
