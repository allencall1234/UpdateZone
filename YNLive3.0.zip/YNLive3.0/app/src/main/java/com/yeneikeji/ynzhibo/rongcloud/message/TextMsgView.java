package com.yeneikeji.ynzhibo.rongcloud.message;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.rongcloud.EmojiManager;
import com.yeneikeji.ynzhibo.rongcloud.LiveKit;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;

import io.rong.imlib.model.MessageContent;
import io.rong.message.TextMessage;

public class TextMsgView extends BaseMsgView {

    public TextView username;
    private TextView msgText;

    public TextMsgView(Context context) {
        super(context);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.msg_text_view, this);
        username = (TextView) view.findViewById(R.id.username);
        msgText = (TextView) view.findViewById(R.id.msg_text);
    }

    @Override
    public void setContent(MessageContent msgContent) {
        TextMessage msg = (TextMessage) msgContent;
        if (!TextUtils.isEmpty(msg.getExtra()))
            YNLogUtil.e("cdy聊天室文本消息", msg.getExtra());

        if (("0x0x0x1230x0x加入聊天室").equals(msg.getContent()))
        {
            YNLogUtil.e("1231", (msg.getContent() + ("加入聊天室" + LiveKit.getCurrentUser().getUserId()).equals(msg.getContent())));
            username.setTextColor(Color.parseColor("#ffb83c"));
            username.setText(msg.getUserInfo().getName() + " ");
            msgText.setTextColor(Color.parseColor("#ffb83c"));
            msgText.setText("加入聊天室");
        }
        else
        {
            YNLogUtil.e("1232", (msg.getContent() + ("加入聊天室" + LiveKit.getCurrentUser().getUserId()).equals(msg.getContent())));
            username.setText(msg.getUserInfo().getName() + ": ");
            username.setTextColor(Color.parseColor("#3ce1ff"));
            msgText.setText(EmojiManager.parse(msg.getContent(), msgText.getTextSize()));
            msgText.setTextColor(Color.parseColor("#ffffff"));
        }
    }

//    @Override
//    public void setOnClickListener(View view)
//    {
//        username.setOnClickListener(new OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
////                YNLogUtil.i("cdy", "点击TextMsgView");
//            }
//        });
//    }
}
