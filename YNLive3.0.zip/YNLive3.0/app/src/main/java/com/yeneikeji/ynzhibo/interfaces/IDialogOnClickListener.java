package com.yeneikeji.ynzhibo.interfaces;

import android.view.View;

/**
 *
 */
public interface IDialogOnClickListener
{
    void clickTopLeftButton(View view);

    void clickTopRightButton(View view);

    void clickBottomLeftButton(View view);

    void clickBottomRightButton(View view);

    void clickBottomButton(View view);
}
