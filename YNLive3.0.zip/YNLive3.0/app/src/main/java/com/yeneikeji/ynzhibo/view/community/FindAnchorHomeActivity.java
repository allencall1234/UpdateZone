package com.yeneikeji.ynzhibo.view.community;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNFragmentAdapter;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.live.AdvancedPlayActivity;
import com.yeneikeji.ynzhibo.view.live.YNLiveDetailsActivity;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.TabPageIndicator;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;
import com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/*
* 发现主播主页
* */
public class FindAnchorHomeActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private LiveRoomBean      mUserBean;
    private RecordVideoBean   mMostNewBean;
    private YNCircleImageView CircleImageView;
    private TabPageIndicator  mArticalTabs;
//    private FixedIndicatorView mArticalTabs;
    public  ViewPager         mArticalViewPager;
    private String[] tabTitle = null;
    private ArrayList<Fragment> fragments;
  //  private  YNFragmentAdapter      mAdapter;
    private  ImageView              mBack;
    private  View                   mTopRelativeView;
    private  com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout       mScrollableLayout;
    private  ImageView              mTopBack;
    private  TextView               mFollowNumb;
    private  TextView               mFansNumb;
    private  TextView               mAddFollow;
    private  TextView               mTvDescrible;
    private  TextView               mName;
    private  TextView               mTopTitle;
    public   String                 mUserid;
    public   String                 mMyselfId="";
//    private  int                    isAttention;

    private YNFragmentAdapter mAdapter;
    private YNPayDialog buytDialog;
//    private MyAdapter mAdapter;

    private LocalBroadcastManager broadcastManager;
    private BroadcastReceiver mRefreshReceiver;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG:
                    if (msg.obj != null)
                    {
                        YNLogUtil.e("aaa",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNLogUtil.e("cdy", msg.obj.toString());
                        JSONObject jsonObject = null;
                        if (baseBean.getCode() ==28) {
                            try {
                                 jsonObject = new JSONObject(msg.obj.toString());
                                 JSONObject obj = jsonObject.getJSONObject("data");
                                 mUserBean = YNJsonUtil.JsonToBean(obj.getString("data1").toString(), LiveRoomBean.class);
                                 mMostNewBean = YNJsonUtil.JsonToBean(obj.getString("data2").toString(), RecordVideoBean.class);
                                if(mUserBean.getLive_status()==0){
                                    mLiveStatuIv.setVisibility(View.GONE);
                                }else{
                                    mLiveStatuIv.setVisibility(View.VISIBLE);
                                }

                                if(mMostNewBean==null){
                                    mNoticeInfo.setVisibility(View.GONE);
                                }
                                initEvent();
                                //没有最新动态就不显示
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;

                case YNCommonConfig.ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43) {
                            mUserBean.setIs_attention(1);
                            mFansNumb.setText("粉丝：" + (mUserBean.getFuns_count() + 1));
                            mAddFollow.setText("已关注");
                            mAddFollow.setBackgroundResource(R.drawable.corners_wealth_gray);
                        }
                        // YNToastMaster.showToast(PersonalHomePageActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(FindAnchorHomeActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13) {
                            mUserBean.setIs_attention(0);
                            mAddFollow.setText("+关注");
                            mFansNumb.setText("粉丝：" + (mUserBean.getFuns_count() - 1));
                            mAddFollow.setTextColor(ContextCompat.getColor(FindAnchorHomeActivity.this, R.color.white));
                            mAddFollow.setBackgroundResource(R.drawable.corners_wealth_white);
                        }
                        //弹出取消成功提示
                        YNToastMaster.showToast(FindAnchorHomeActivity.this, baseBean.getInfo());
                    } else {
                        YNToastMaster.showToast(FindAnchorHomeActivity.this, getString(R.string.request_fail));
                    }
                    break;
                //购买最新文章
                case YNCommonConfig.BUY_ARTICLE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 102) {
                            //购买成功
                            Toast.makeText(FindAnchorHomeActivity.this, "购买成功", Toast.LENGTH_SHORT)
                                 .show();

                                    //跳转到文章详情页面
                                    Intent intent = new Intent(FindAnchorHomeActivity.this, ArticalDetailsActivity.class);
                                    intent.putExtra("aid", mMostNewBean.getId());
                                    startActivity(intent);
                                    break;
                        }
                    }else
                    {
                        YNToastMaster.showToast(FindAnchorHomeActivity.this, "购买失败", Toast.LENGTH_SHORT, Gravity.CENTER);
                    }
                    break;

                // 更新用户登录成功后状态
                case YNCommonConfig.UPDATE_LIVE_ROOM_USER_STATE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                mUserBean = YNJsonUtil.JsonToBean(jsonObject.getString("data1").toString(), LiveRoomBean.class);
                                mMostNewBean = YNJsonUtil.JsonToBean(jsonObject.getString("data2").toString(), RecordVideoBean.class);
                                //没有最新动态就不显示
                                if(mMostNewBean==null||mMostNewBean.getTime()==null){
                                    mNoticeInfo.setVisibility(View.GONE);
                                }

                                if (mAddFollow.getVisibility() == View.VISIBLE)
                                {
                                    updateAttentionState();
                                }
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                    break;
            }
        }
    };
    private RelativeLayout mNoticeInfo;
    private ImageView mDeletIv;
    private ImageView mIvType;
    private TextView mTvTitle;
    private TextView mClickDoTv;
    private ImageView mLiveStatuIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // AutoUtils.setSize(this, false, 750, 1334);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            //透明状态栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            //透明导航栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//        }
        View view=View.inflate(this, R.layout.find_anchorhome_activity_artical, null);
      //  AutoUtils.auto(view);//放在加载布局的前面
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.parseColor("#449aed"));
        initView();
        broadcastManager = LocalBroadcastManager.getInstance(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(YNCommonConfig.UPDATE_USER_STATE_FLAG);
        mRefreshReceiver= new BroadcastReceiver()
        {
            @Override
            public void onReceive(Context context, Intent intent)
            {
                if (!intent.getBooleanExtra("liveRoom", false))
                {
                    mMyselfId = AccountUtils.getAccountBean().getId();
                    updateLoginUI();
                    updateTopUserInfo();
                }
            }
        };
        broadcastManager.registerReceiver(mRefreshReceiver, intentFilter);
    }

    @Override
    protected void initView() {
     if(AccountUtils.getLoginInfo()) {
         mMyselfId = AccountUtils.getAccountBean()
                                 .getId();
     }
        mUserid = getIntent().getStringExtra("userId");
        mTopTitle = (TextView) findViewById(R.id.top_tv_Title);
        //直播状态图片
        mLiveStatuIv = (ImageView) findViewById(R.id.iv_living_statu);
        //渐变的view
        mTopRelativeView = findViewById(R.id.top_relative_view);
        //渐变的view
        CircleImageView = (YNCircleImageView) findViewById(R.id.YNCircleImageView);
        mTopBack = (ImageView) findViewById(R.id.totalartical_img_Back);
        mName = (TextView) findViewById(R.id.top_tv_name);
        mTvDescrible = (TextView) findViewById(R.id.personhome_top_describle);
        mFollowNumb = (TextView) findViewById(R.id.find_hometv_artical_follow);
        mFansNumb = (TextView) findViewById(R.id.find_hometv_fans_count);
        mAddFollow = (TextView) findViewById(R.id.find_hometv_add_follow);
        /***中间通知栏*/
        mNoticeInfo = (RelativeLayout) findViewById(R.id.notice_inform_relative_lauout);
        mIvType = (ImageView) findViewById(R.id.iv_type);
        mTvTitle = (TextView) findViewById(R.id.tv_title);
        mClickDoTv = (TextView) findViewById(R.id.click_do_tv);
        mDeletIv = (ImageView) findViewById(R.id.iv_delete);
        /**中间通知栏**/
        mArticalTabs = (TabPageIndicator) findViewById(R.id.artical_activity_tabs);
        mArticalViewPager = (ViewPager) findViewById(R.id.artical_activity_viewpager);
        tabTitle = getResources().getStringArray(R.array.articalColumnTitles);
        mScrollableLayout = (com.yeneikeji.ynzhibo.widget.weelwight.ScrollableLayout) findViewById(R.id.anchor_home_ScrollableLayout);

        mLiveStatuIv.setOnClickListener(this);
        mTopBack.setOnClickListener(this);
        mAddFollow.setOnClickListener(this);
        mClickDoTv.setOnClickListener(this);
        //中间通知栏
        mDeletIv.setOnClickListener(this);
        mScrollableLayout.setOnScrollListener(new ScrollableLayout.OnScrollListener() {
            @Override
            public void onScroll(int currentY, int maxY, float diatance) {
                //上滑
                if(diatance>30){
                    mTopTitle.setVisibility(View.VISIBLE);
                    mTopRelativeView.setBackgroundColor(getResources().getColor(R.color.ynkj_topbar_bg));
                    tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));

                }else{
                    mTopTitle.setVisibility(View.GONE);
                    mTopRelativeView.setBackgroundColor(getResources().getColor(R.color.personal_homepage_bg));
                    tintManager.setStatusBarTintColor(Color.rgb(38,154,252));
                }

            }
        });

        //是点击自己头像进入就不显示下面添加关注按钮
        if(mUserid.equals(mMyselfId))
        {
            mAddFollow.setVisibility(View.GONE);
        }
        else
        {
            mAddFollow.setVisibility(View.VISIBLE);
        }

        getTopUserInfo();
        addFragment();

    }

    /**
     * 获取头部用户信息
     */
    private void getTopUserInfo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getFindPersonalHomePage(FindAnchorHomeActivity.this, YNCommonConfig.GET_FINF_PERSONAL_HOME_HEAD_URL, mUserid, mMyselfId, mHandler, YNCommonConfig.PERSONAL_DYNAMIC_HOME_PAGE_FLAG, false);
            }
        });
    }

    /**
     * 更新顶部登录信息
     */
    private void updateTopUserInfo()
    {
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getFindPersonalHomePage(FindAnchorHomeActivity.this, YNCommonConfig.GET_FINF_PERSONAL_HOME_HEAD_URL, mUserid, mMyselfId, mHandler, YNCommonConfig.UPDATE_LIVE_ROOM_USER_STATE_FLAG, false);
            }
        });
    }

    private void initEvent()
    {
        //初始化头部信息
        YNImageLoaderUtil.setImage(getApplicationContext(), CircleImageView, mUserBean.getIcon());
        mName.setText(mUserBean.getUsername());
        mTopTitle.setText(mUserBean.getUsername());
        mTvDescrible.setText(mUserBean.getDescribe());
        mFollowNumb.setText("关注：" + mUserBean.getFocus_count());
        mFansNumb.setText("粉丝：" + mUserBean.getFuns_count());
        //通知栏
        mTvTitle.setText(mMostNewBean.getTitle());

         updateAttentionState();
//由于最新消息有默认返回值，所以要再加上是否有发表时间来再次判断
     if(mMostNewBean.getTime()==null||mMostNewBean.getTime().equals("0")){
       mNoticeInfo.setVisibility(View.GONE);
         return;
         }else {
         mNoticeInfo.setVisibility(View.VISIBLE);
     }
        switch (mMostNewBean.getType()) {
            case 0:
                mIvType.setImageResource(R.drawable.icon_person_note);
                mClickDoTv.setText("点击阅读");
                 break;
            case 1:
                mIvType.setImageResource(R.drawable.icon_person_voice);
                mClickDoTv.setText("点击收听");
            break;
            case 2:
                mIvType.setImageResource(R.drawable.icon_person_video);
                mClickDoTv.setText("点击观看");
            break;
        }

    }

    private void addFragment() {
        fragments = new ArrayList();
        fragments.clear();

        Bundle mBundle = new Bundle();
        mBundle.putString(YNCommonConfig.USER_ID, mUserid);
        mBundle.putInt(YNCommonConfig.HOME_PAGE_FLAG, 2);
        mBundle.putBoolean(YNCommonConfig.ISSHOW, false);

        if (mAddFollow.getVisibility() == View.GONE)
        {
            PersonalNoteFragment personalNoteFragment = new PersonalNoteFragment();
            personalNoteFragment.setArguments(mBundle);
            fragments.add(personalNoteFragment);
        }
        else
        {
            NoteFragment noteFragment = new NoteFragment();
            noteFragment.setArguments(mBundle);
            fragments.add(noteFragment);
        }

        VoiceFragment voiceFragment = new VoiceFragment();
        voiceFragment.setArguments(mBundle);

        VideoFragment videoFragment = new VideoFragment();
        videoFragment.setArguments(mBundle);


        fragments.add(voiceFragment);
        fragments.add(videoFragment);

        mAdapter = new YNFragmentAdapter(getSupportFragmentManager(), fragments, tabTitle);
        mArticalViewPager.setAdapter(mAdapter);
        mArticalViewPager.setOffscreenPageLimit(tabTitle.length);
        mArticalTabs.setViewPager(mArticalViewPager);
        setTabPagerIndicator();

//        mAdapter = new MyAdapter(getSupportFragmentManager());
//        mAdapter.setFragments(fragments);
//        indicatorViewPager.setAdapter(mAdapter);

    }

    private void setTabPagerIndicator()
    {
        mArticalTabs.setIndicatorMode(TabPageIndicator.IndicatorMode.MODE_WEIGHT_NOEXPAND_SAME);// 设置模式，一定要先设置模式
//        mArticalTabs.setDividerColor(Color.parseColor("#d9d9d9"));// 设置分割线的颜色
//        mArticalTabs.setUnderlineColor(Color.parseColor("#d9d9d9"));
//        mArticalTabs.setDividerPadding(UIUtils.dp2px(this, 10));
//        mArticalTabs.setIndicatorColor(Color.parseColor("#1694ff"));// 设置底部导航线的颜色
//        mArticalTabs.setTextColorSelected(Color.parseColor("#1694ff"));// 设置tab标题选中的颜色
//        mArticalTabs.setTextColor(Color.parseColor("#333333"));// 设置tab标题未被选中的颜色
//        mArticalTabs.setTextSize(UIUtils.sp2px(this, 15));// 设置字体大小
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.totalartical_img_Back:
                finish();
                break;
            //中间通知栏
            case R.id.iv_delete:
                mNoticeInfo.setVisibility(View.GONE);
                break;

            //根据选择的不通类型做相应处理
            case R.id.click_do_tv:
                switch (mMostNewBean.getType()) {
                    //阅读，先判断是否收费，免费的才可以读，否则需要购买
                    case 0:
                       if(mMostNewBean.getIs_pay().equals("0") || mMostNewBean.getIs_purchase()==1 || mMostNewBean.getUserid().equals(mMyselfId))
                       {
                           Intent intentNote=new Intent(FindAnchorHomeActivity.this,ArticalDetailsActivity.class);
                           intentNote.putExtra("aid",mMostNewBean.getId());
                           startActivity(intentNote);
                       }
                       else
                       {
                      //需要购买
                           showBuyDialog(mMostNewBean.getPayCoin(),mMostNewBean.getId());
                       }
                        break;

                    //收听
                    case 1:
                        Intent intentVoice=new Intent(FindAnchorHomeActivity.this,VoiceDetailActivity.class);
                        intentVoice.putExtra("aid",mMostNewBean.getId());
                        startActivity(intentVoice);
                        break;

                    //观看
                    case 2:
                       /* Intent intentVideo=new Intent(FindAnchorHomeActivity.this,.class);
                        intentVideo.putExtra("aid",mMostNewBean.getId());
                        startActivity(intentVideo);*/
                        ArrayList<RecordVideoBean> playList=new ArrayList();
                        playList.add(mMostNewBean);
                        Intent intent = new Intent(FindAnchorHomeActivity.this, AdvancedPlayActivity.class);
                        intent.putExtra("List<RecordVideoBean>", playList);
                        intent.putExtra(YNCommonConfig.POSITION, 0);
                        startActivity(intent);
                        break;
                }
                break;

            case R.id.find_hometv_add_follow:
                if (AccountUtils.getLoginInfo()) {
                    if (mUserBean.getIs_attention() == 1) {
                        //弹出dialog提示用户
                        //弹出dailog
                        AlertDialog.Builder builder = new AlertDialog.Builder(FindAnchorHomeActivity.this);
                        builder.setMessage("确认要取消关注吗？");
                        builder.setTitle("提示");
                        builder.setPositiveButton("确认",
                                                  new DialogInterface.OnClickListener() {
                                                      @Override
                                                      public void onClick(DialogInterface dialog, int which) {
                                                          //更新个人对主播关注状态
//                                                          mUserBean.setIs_attention(0);
                                                          //不刷新出现取消后粉丝数量不对的问题
                                                          //弹出dialog
                                                          mHandler.post(new Runnable() {
                                                              @Override
                                                              public void run() {
                                                                  UserHttpUtils.newInstance().cancelAttentionUser(FindAnchorHomeActivity.this, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), mUserid, mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, false);

                                                              }
                                                          });

                                                      }
                                                  });
                        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();

                    }
                    else
                    {
//                        mUserBean.setIs_attention(1);
                        //不刷新出现粉丝数量不对的问题
                        mHandler.post(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().attentionUser(FindAnchorHomeActivity.this, YNCommonConfig.ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(), mUserid, mHandler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                            }
                        });

                    }
                }
                else {
                    //跳转到登录界面
                    Intent intent=new Intent(FindAnchorHomeActivity.this,YNLoginActivity.class);
                    startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
                }
                break;
            //跳转到主播直播间 todo
            case R.id.iv_living_statu :
                /*Toast.makeText(context, "我被打了", Toast.LENGTH_SHORT)
                     .show();*/
                Intent intent = new Intent(FindAnchorHomeActivity.this, YNLiveDetailsActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(YNCommonConfig.OBJECT, mUserBean);
                intent.putExtras(bundle);
                startActivity(intent);
            break;
        }
    }

    public void showBuyDialog(final String payCoin, final String aid) {
        buytDialog = new YNPayDialog.Builder(FindAnchorHomeActivity.this)
                .setHeight(0.3f)  //屏幕高度*0.3
                .setWidth(0.65f)  //屏幕宽度*0.65
                .setTitleVisible(true)
                .setTitleText("温馨提示")
                .setTitleTextColor(R.color.black_light)
                .setContentText("此文章需要付费" + payCoin + "金币，是否付费阅读？")
                .setContentTextColor(R.color.black_light)
                .setLeftButtonText("取消")
                .setLeftButtonTextColor(R.color.ynkj_black)
                .setRightButtonText("确定")
                .setRightButtonTextColor(R.color.live_details_text_blue)
                .setCanceledOnTouchOutside(false)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }
                    //取消
                    @Override
                    public void clickBottomLeftButton(View view) {

                        buytDialog.dismiss();
                    }
                    //确定
                    @Override
                    public void clickBottomRightButton(View view) {
                        if (AccountUtils.getLoginInfo())
                        {
                            //判断用户余额是否大于文章收费金额，否则跳转到充值界面
                            if (AccountUtils.getAccountBean().getCurrentCoin() >= Integer.parseInt(payCoin))
                            {
                                mHandler.post(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance()
                                                     .buyArticle(FindAnchorHomeActivity.this,
                                                                 YNCommonConfig.BUY_ARTICLE_URL,
                                                                 aid,
                                                                 AccountUtils.getAccountBean().getId(),
                                                                 Integer.parseInt(payCoin),
                                                                 mHandler,
                                                                 YNCommonConfig.BUY_ARTICLE_FLAG,
                                                                 true);
                                    }
                                });
                                buytDialog.dismiss();

                            }
                            else
                            {
                                YNToastMaster.showToast(FindAnchorHomeActivity.this, "余额不足，请先充值再购买哦", Toast.LENGTH_SHORT, Gravity.CENTER);
                            }
                        }
                        else
                        {
                            Intent intent = new Intent(FindAnchorHomeActivity.this, YNLoginActivity.class);
                            startActivityForResult(intent, YNCommonConfig.ACTIVITY_RESULT);
                        }
                        buytDialog.dismiss();
                    }
                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();
        buytDialog.show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        broadcastManager.unregisterReceiver(mRefreshReceiver);
        mHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == YNCommonConfig.ACTIVITY_RESULT)
        {
            loginRefreshUI();
        }
    }

    @Override
    public void loginRefreshUI()
    {
        if (AccountUtils.getLoginInfo())
        {
            mMyselfId = AccountUtils.getAccountBean().getId();
            updateLoginUI();
            updateTopUserInfo();
        }
    }

    /**
     * 更新关注按钮状态
     */
    private void updateAttentionState()
    {
        if (mUserBean.getIs_attention()== 1)
        {
            mAddFollow.setText("已关注");
            mAddFollow.setBackgroundResource(R.drawable.corners_wealth_gray);
        }
        else
        {
            mAddFollow.setText("+关注");
            mAddFollow.setBackgroundResource(R.drawable.corners_wealth_white);
        }
    }

    /**
     * 更新登录成功后界面UI
     */
    private void updateLoginUI()
    {
        //是点击自己头像进入就不显示下面添加关注按钮
        if(mUserid.equals(mMyselfId))
        {
            mAddFollow.setVisibility(View.GONE);
        }
        else
        {
            mAddFollow.setVisibility(View.VISIBLE);
            mNoticeInfo.setVisibility(View.VISIBLE);
        }

        addFragment();

//        fragments = new ArrayList();
//        fragments.clear();
//
//        Bundle mBundle = new Bundle();
//        mBundle.putString(YNCommonConfig.USER_ID, mUserid);
//        mBundle.putInt(YNCommonConfig.HOME_PAGE_FLAG, 2);
//        mBundle.putBoolean(YNCommonConfig.ISSHOW, false);
//
//        if (mAddFollow.getVisibility() == View.GONE)
//        {
//            PersonalNoteFragment personalNoteFragment = new PersonalNoteFragment();
//            personalNoteFragment.setArguments(mBundle);
//            fragments.add(personalNoteFragment);
//        }
//        else
//        {
//            NoteFragment noteFragment = new NoteFragment();
//            noteFragment.setArguments(mBundle);
//            fragments.add(noteFragment);
//        }
//
//        VoiceFragment voiceFragment = new VoiceFragment();
//        voiceFragment.setArguments(mBundle);
//
//        VideoFragment videoFragment = new VideoFragment();
//        videoFragment.setArguments(mBundle);
//
//
//        fragments.add(voiceFragment);
//        fragments.add(videoFragment);
//
//        mAdapter = new YNFragmentAdapter(getSupportFragmentManager(), fragments, tabTitle);
//        mArticalViewPager.setAdapter(mAdapter);
//        mArticalViewPager.setOffscreenPageLimit(tabTitle.length);
//        mArticalTabs.setViewPager(mArticalViewPager);
//
//        mArticalTabs.setIndicatorMode(TabPageIndicator.IndicatorMode.MODE_WEIGHT_NOEXPAND_SAME);
    }
}
