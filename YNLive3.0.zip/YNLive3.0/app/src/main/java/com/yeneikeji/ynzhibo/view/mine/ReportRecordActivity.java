package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveReportedBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.List;

import static com.yeneikeji.ynzhibo.utils.DateUtil.timeStamp2StringSHort;

/*
* 这是我的被举报记录的类
*
* */
public class ReportRecordActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{

    private static final String TAG = "ReportRecordActivity";
    private ExpandableListView mExpandableListview;
    private TextView mTotalReported;
    private  List<LiveReportedBean.DataBean.CurrentBean.Current1Bean> currentMonth =new ArrayList();
    private  List<LiveReportedBean.DataBean.CurrentBean.Current1Bean>   longBefore   =new ArrayList();
    private  List< List<LiveReportedBean.DataBean.CurrentBean.Current1Bean>>   datas   =new ArrayList();
    private    LiveReportedBean    mLiveReportedBean;
    private Handler                                                   mHandler     = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_MY_LIVE_REPORTED_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 28)
                        {
                            try
                            {
                                Gson gson=new Gson();
                                 mLiveReportedBean = gson.fromJson(msg.obj.toString(),
                                                                                  LiveReportedBean.class);
                                mTotalReported.setText("累计被举报"+(mLiveReportedBean.getData().getCurrent().getNum()+mLiveReportedBean.getData().getBefore().getNum())+"次");
                                //封装本月bean
                                if(mLiveReportedBean.getData().getCurrent().getCurrent1()!=null){
                                    for (int i=0;i<mLiveReportedBean.getData().getCurrent().getCurrent1().size();i++){

                                        currentMonth.add(mLiveReportedBean.getData().getCurrent().getCurrent1().get(i));
                                    }


                                }else{
                                    currentMonth.add(new LiveReportedBean.DataBean.CurrentBean.Current1Bean());

                                }
                                //封装之前bean
                                if(mLiveReportedBean.getData().getBefore().getBefore1()!=null){
                                    for (int j=0;j<mLiveReportedBean.getData().getBefore().getBefore1().size();j++){

                                        longBefore.add(mLiveReportedBean.getData().getBefore().getBefore1().get(j));
                                    }


                                }else{
                                    longBefore.add(new LiveReportedBean.DataBean.CurrentBean.Current1Bean());
                                }
                                datas.add(currentMonth);
                                datas.add(longBefore);
                                  MyExpandableAdapter adapter =new MyExpandableAdapter(ReportRecordActivity.this,datas);
                                 mExpandableListview.setAdapter(adapter);

                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }else{
                            mTotalReported.setText("累计被举报0次");
                            Toast.makeText(context, "暂时没有您的记录", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }
                    else
                    {

                    }
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_record);
        initView();
        addEvent();
        settingDo();
    }
    protected void initView()
    {
        configTopBarCtrollerWithTitle("被举报记录");
        mTotalReported = (TextView) findViewById(R.id.total_reported);
        mExpandableListview = (ExpandableListView) findViewById(R.id.my_reported_record_expandlistview);
        mExpandableListview.setGroupIndicator(null);

        //请求数据
        mHandler.post(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().myReportedList(ReportRecordActivity.this, YNCommonConfig.MY_LIVE_REPORTED_URL,
                                                           AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.GET_MY_LIVE_REPORTED_FLAG, true);
            }
        });
    }
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

        }
    }
    class MyExpandableAdapter extends BaseExpandableListAdapter

    {
        private List< List<LiveReportedBean.DataBean.CurrentBean.Current1Bean>> mdatas;
        private Context                    mContext;

        public MyExpandableAdapter(Context context, List< List<LiveReportedBean.DataBean.CurrentBean.Current1Bean>> datas) {
            mContext = context;
            this.mdatas = datas;
        }


        @Override
        public int getGroupCount() {
            if (mdatas != null) {
                return mdatas.size();
            }
            return 0;
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            if (mdatas.get(groupPosition)!= null) {
                return mdatas.get(groupPosition).size();

            }
            return 0;
        }

        @Override
        public List<LiveReportedBean.DataBean.CurrentBean.Current1Bean> getGroup(int groupPosition) {
            if (mdatas != null) {
                return mdatas.get(groupPosition);
            }
            return null;


        }

        @Override
        public LiveReportedBean.DataBean.CurrentBean.Current1Bean getChild(int groupPosition, int childPosition) {
            if (mdatas.get(groupPosition)!= null) {
                return mdatas.get(groupPosition).get(childPosition);

            }
            return null;
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent)
        {
            View                                              view   = convertView;
            GroupHolder holder = null;
            if (view == null) {
                holder = new GroupHolder();
                view = LayoutInflater.from(mContext)
                                     .inflate(R.layout.livevideo_group_expandlistview, null);
                holder.groupName = (TextView) view.findViewById(R.id.tv_group_name);
                holder.arrow = (ImageView) view.findViewById(R.id.videogroup_iv_arrow);
                holder.reportednumb= (TextView) view.findViewById(R.id.have_reported_numb);
                holder.reportednumb.setVisibility(View.VISIBLE);
                view.setTag(holder);
            } else {
                holder = (GroupHolder)view.getTag();
            }
            List<LiveReportedBean.DataBean.CurrentBean.Current1Bean> current1Been = mdatas.get(
                    groupPosition);

            //判断是否已经打开列表
            if (isExpanded) {
                holder.arrow.setBackgroundResource(R.drawable.report_list_open);
            } else {
                holder.arrow.setBackgroundResource(R.drawable.report_list_close);
            }
            switch (groupPosition) {
                case 0:
                    if(mLiveReportedBean.getData().getCurrent()!=null) {
                        holder.reportednumb.setText("" + mLiveReportedBean.getData()
                                                                          .getCurrent()
                                                                          .getNum() + "次");
                    }
                    holder.groupName.setText("本月");
                     break;
                case 1:
                    if(mLiveReportedBean.getData().getBefore()!=null) {
                        holder.reportednumb.setText("" + mLiveReportedBean.getData()
                                                                          .getBefore()
                                                                          .getNum() + "次");
                    }
                    holder.groupName.setText("更早");
                    break;
            }


            return view;
        }

        @Override
        public View getChildView(int groupPosition,
                                 int childPosition,
                                 boolean isLastChild,
                                 View convertView,
                                 ViewGroup parent)
        {
            View                                              view   = convertView;
            ChildHolder holder = null;
            if (view == null) {
                holder = new ChildHolder();
                view = LayoutInflater.from(mContext)
                                     .inflate(R.layout.reported_expandlist_child_item, null);
                holder.type = (TextView) view.findViewById(R.id.reported_type);
                holder.time = (TextView) view.findViewById(R.id.reported_time);
                view.setTag(holder);
            } else {
                holder = (ChildHolder) view.getTag();
            }

            LiveReportedBean.DataBean.CurrentBean.Current1Bean current1Bean = mdatas.get(groupPosition).get(childPosition);
            if(TextUtils.isEmpty(current1Bean.getContent()) && TextUtils.isEmpty(current1Bean.getTime())){
//                YNLogUtil.e(TAG,"content or time : " + current1Bean.getContent() + ", "+current1Bean.getTime());
                holder.type.setText("");
                holder.time.setText("");
            }else{
                holder.type.setText(current1Bean.getContent());
                holder.time.setText(timeStamp2StringSHort(current1Bean.getTime()));
            }

            return view;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }


        class GroupHolder {
            public TextView  groupName;
            public  TextView reportednumb;
            public ImageView arrow;
        }

        class ChildHolder {
            public TextView type;
            public TextView time;

        }


    }
}
