package com.yeneikeji.ynzhibo.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yeneikeji.ynzhibo.utils.NetUtils;

/**
 * Created by Administrator on 2016/8/10.
 */
public abstract class YNBaseFragment extends Fragment
{
    protected Context mContext;

    /**** 辨别手机分辨率 ***/
    public Display display;
    public int screenWidth;
    public int screenHeight;

    public boolean isConnectNet;

    @Override
    public void onAttach(Activity activity)
    {
        super.onAttach(activity);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        if (NetUtils.isConnected(mContext))
            isConnectNet = true;
        else
            isConnectNet = false;
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    protected void initFragment()
    {
        mContext = getActivity();
        // 方法1 Android获得屏幕的宽和高
        Display mDisplay = ((Activity) mContext).getWindowManager()
                .getDefaultDisplay();
        screenWidth = mDisplay.getWidth();
        screenHeight = mDisplay.getHeight();

        addEvents();
        settingDo();
    }

    /**
     * 绑定界面
     */
    protected void initView(View view) {

    }

    /**
     * 做事情
     */
    protected void settingDo() {

    }

    /**
     * 增加事件
     */
    protected void addEvents() {

    }

    @Override
    public void onStart()
    {
        super.onStart();
    }

    @Override
    public void onResume()
    {
        super.onResume();
    }

    @Override
    public void onPause()
    {
        super.onPause();
    }

    @Override
    public void onStop()
    {
        super.onStop();
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }

    @Override
    public void onDetach()
    {
        super.onDetach();
    }

    /**
     * fragment name
     * @return
     */
    public abstract String getFragmentName();

    public abstract void loginRefreshUI();

    public abstract void unLoginRefreshUI();
}
