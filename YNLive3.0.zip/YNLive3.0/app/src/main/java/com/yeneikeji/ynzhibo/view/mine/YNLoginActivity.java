package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.InputType;
import android.text.Selection;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.PersonInfoBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.YNMainTabActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;
import cn.smssdk.EventHandler;

/**
 * 登录界面
 * Created by Administrator on 2016/8/4.
 */
public class YNLoginActivity extends YNBaseTopBarActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private static final String TAG = "JPush";

    private EventHandler eh;
    private Button btnToRegister;
    private Button btnToForget;
    private TextView txtLogin;
    private EditText edtPhoneNum, edtPassword;
    private CheckBox chbEye;
    private ImageView imgBack;

    private RelativeLayout mRLErrorNotice;
    private final int REGISTER_RESULT = 0;
    private String ACTION_TAG = "Login";

    private boolean mHidden = false;// 设置是否隐藏密码标识
    private String login_flag;
    private int mIndex;
    private Intent mIntent;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.USER_LOGIN_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 5)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                UserInfoBean infoBean = YNJsonUtil.JsonToBean(object.getString("data"), UserInfoBean.class);
                                // 将登陆成功后返回的用户信息类保存
//                                infoBean.setPassword(edtPassword.getText().toString());
                                AccountUtils.saveAccountBean(infoBean);
                                JPushInterface.init(getApplicationContext());

                                handler.postDelayed(new Runnable()
                                {
                                    @Override
                                    public void run()
                                    {
                                        if (!AccountUtils.getAccountBean().getId().equals(AccountUtils.getSetAlias()))
                                            setAlias();
                                    }
                                }, 10000);

                                // 设置状态为登陆状态，保存标志位
                                AccountUtils.saveLogin(true);
                                PersonInfoBean personInfoBean = YNJsonUtil.JsonToBean(object.getString("data"), PersonInfoBean.class);
                                AccountUtils.saveLocalPerson(personInfoBean);
                                YNCommonUtils.hideSoftInput(YNLoginActivity.this, view);
                                mIntent = new Intent(context, YNMainTabActivity.class);
                                context.startActivity(mIntent);
                                finish();
                             /*   // 根据跳转标志的值，确定下一步需要跳转的页面
                                Intent intent;
                                switch (ACTION_TAG)
                                {
                                    // 回跳"社区"界面
                                    case "DynamicFragment":
                                        intent = new Intent(YNLoginActivity.this, YNMainTabActivity.class);
                                        intent.setAction("DynamicBack");
                                        startActivity(intent);
                                        finish();
                                        break;

                                    // 回跳"我的"界面
                                    default:
                                        intent = new Intent(YNLoginActivity.this, YNMainTabActivity.class);
                                        intent.setAction("MineBack");
                                        startActivity(intent);
                                        finish();
                                        break;
                                }*/
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            AccountUtils.saveLogin(false);
                        }

                        YNToastMaster.showToast(YNLoginActivity.this, baseBean.getInfo());
                    }
                    else
                    {
                        AccountUtils.saveLogin(false);
                        YNToastMaster.showToast(YNLoginActivity.this, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.SET_JPUSH_ALIAS:
                    YNLogUtil.d(TAG, "Set alias in handler.");
                    // 调用 JPush 接口来设置别名。
                    JPushInterface.setAliasAndTags(getApplicationContext(),
                            (String) msg.obj,
                            null,
                            mAliasCallback);
                    break;
            }
        }
    };
    private LinearLayout llMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        tintManager.setStatusBarTintColor(Color.rgb(137, 131, 144));
        initView();
        addEvent();

    }

    protected void initView()
    {
//        login_flag = getIntent().getStringExtra(YNCommonConfig.INTO_LOGIN_FLAG);

        btnToRegister = (Button) findViewById(R.id.btnToRegister);
        btnToForget = (Button) findViewById(R.id.txtToForget);
        txtLogin = (TextView) findViewById(R.id.btn_login);
        edtPhoneNum = (EditText) findViewById(R.id.edtPhoneNum);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        mRLErrorNotice = (RelativeLayout) findViewById(R.id.rl_error_notice);
        chbEye = (CheckBox) findViewById(R.id.chbEye);
        imgBack = (ImageView) findViewById(R.id.imgBack);
        llMain = (LinearLayout) findViewById(R.id.llMain);
        // 获取页面跳转标志，用于登录成功后回跳页面
      /*  Intent intent = getIntent();
        if(intent!=null){
            ACTION_TAG = intent.getAction()==null?"Login":intent.getAction();
        }*/
    }

    protected void addEvent() {
        btnToRegister.setOnClickListener(this);
        btnToForget.setOnClickListener(this);
        txtLogin.setOnClickListener(this);
        chbEye.setOnCheckedChangeListener(this);
        imgBack.setOnClickListener(this);
    }

    // 这是来自 JPush Example 的设置别名的 Activity 里的代码。一般 App 的设置的调用入口，在任何方便的地方调用都可以。
    private void setAlias()
    {
        // 调用 Handler 来异步设置别名
        handler.sendMessage(handler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, AccountUtils.getAccountBean().getId()));
    }

    private final TagAliasCallback mAliasCallback = new TagAliasCallback() {

        @Override
        public void gotResult(int code, String alias, Set<String> tags) {
            String logs ;
            switch (code) {
                case 0:
                    logs = "Set tag and alias success";
                    YNLogUtil.i(TAG, logs);
                    AccountUtils.saveSetAlias(alias);
                    // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
                    break;

                case 6002:
                    logs = "Failed to set alias and tags due to timeout. Try again after 60s.";
                    YNLogUtil.i(TAG, logs);
                    // 延迟 60 秒来调用 Handler 设置别名
                    handler.sendMessageDelayed(handler.obtainMessage(YNCommonConfig.SET_JPUSH_ALIAS, alias), 1000 * 60);
                    break;

                default:
                    logs = "Failed with errorCode = " + code;
                    YNLogUtil.e(TAG, logs);
            }
        }
    };

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }


    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {

            case R.id.imgBack:
                YNCommonUtils.hideSoftInput(this, view);
                finish();
                break;

            case R.id.btnToRegister:
                intent.setClass(YNLoginActivity.this, YNRegisterActivity.class);
                startActivity(intent);
//                finish();
                break;

            case R.id.txtToForget:
                intent.setClass(YNLoginActivity.this, YNForgetActivity.class);
                intent.putExtra(YNCommonConfig.FORGET_PASS, true);
                startActivity(intent);
                finish();
                break;

            case R.id.btn_login:
                if (TextUtils.isEmpty(edtPhoneNum.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "请输入您的手机号码！");
                    return;
                }
                if (!YNCommonUtils.isCellPhone(edtPhoneNum.getText().toString()))
                {
                    YNToastMaster.showToast(this, "您输入的电话号码有误！");
                    return;
                }
                if (TextUtils.isEmpty(edtPassword.getText().toString()))
                {
                    YNToastMaster.showToast(this, "请输入登录密码！");
                    return;
                }

                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userLogin(YNLoginActivity.this, YNCommonConfig.USER_LOGIN_URL, edtPhoneNum.getText().toString(),
                                edtPassword.getText().toString(), YNApplication.deviceId, handler, YNCommonConfig.USER_LOGIN_FLAG, true);
                    }
                }, 1000);
                break;

        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked)
    {
        if (isChecked)
        {
            // 显示为普通文本
            edtPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            // 使光标始终在最后位置
            Editable etable = edtPassword.getText();
            Selection.setSelection(etable, etable.length());
        }
        else
        {
            // 显示为密码
            edtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            // 使光标始终在最后位置
            Editable etable = edtPassword.getText();
            Selection.setSelection(etable, etable.length());
        }

    }
}

