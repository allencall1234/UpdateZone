package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.adapter.HeartFansAdapter;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 *  关注粉丝界面
 * Created by Administrator on 2016/11/9.
 */
public class YNHeartFansActivity extends YNBaseActivity implements View.OnClickListener, SmoothListView.ISmoothListViewListener
{
    private static final String TAG ="YNHeartFansActivity" ;
    private ImageView mIVBack;
    private RadioGroup mRadioGroup;
    private SmoothListView mHeartFansLV;
    private TextView mTVPeopleNum;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;

    private int type = 0;
    private CommonAdapter mAdapter;
    private HeartFansAdapter mHeartFansAdapter;
    private List<LiveRoomBean> followList;
    private int followCount;
    private int totalPages = 0;
    private int curragePage = 0;// 当前页

//    private ViewPager mViewPager;
//    private LinearLayout mLayoutLoading;
//    private TabFragmentAdapter mAdapter;
//    private List<Fragment> list;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.MY_ATTENTION_LIST_FLAG:
                    getData(msg);
                    break;

                case YNCommonConfig.MY_FANS_LIST_FLAG:
                    getData(msg);
                    break;

                case YNCommonConfig.ON_REFRESH:
                    getData(msg);
                    onStopLoad();
                    break;

            }
            super.handleMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view = getLayoutInflater().inflate(R.layout.activity_ynheartfans, null);
      //  AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        mIVBack = (ImageView) findViewById(R.id.iv_back);
        mRadioGroup = (RadioGroup) findViewById(R.id.rg_heart_fans);
        mHeartFansLV = (SmoothListView) findViewById(R.id.lv_heart_fans);
        mRLEmpty = (RelativeLayout) findViewById(R.id.empty);
        mIVEmpty = (ImageView) findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) findViewById(R.id.tv_empty);

        mHeartFansLV.addHeaderView(addHeadView());
        mHeartFansLV.setLoadMoreEnable(false);
//        mViewPager = (ViewPager) findViewById(R.id.vp_heart_fans);
//        mLayoutLoading = (LinearLayout) findViewById(R.id.layout_loading);

    }

    private View addHeadView()
    {
        View headView = getLayoutInflater().inflate(R.layout.heart_fans_headview, null);
        mTVPeopleNum = (TextView) headView.findViewById(R.id.tv_people_num);
//        mTVPeopleNum.setVisibility(View.GONE);
        return headView;
    }

    @Override
    protected void addEvent()
    {
        mIVBack.setOnClickListener(this);
        mHeartFansLV.setSmoothListViewListener(this);
        mRLEmpty.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        getNetData();

        mHeartFansAdapter = new HeartFansAdapter(this, new ArrayList<LiveRoomBean>());

//        if(followList == null || followList.size()<0){
//            mTVPeopleNum.setVisibility(View.GONE);
//        }else{
//            mTVPeopleNum.setVisibility(View.VISIBLE);
//        }

        mAdapter = new CommonAdapter<LiveRoomBean>(this, new ArrayList<LiveRoomBean>(), R.layout.fragment_follow_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, LiveRoomBean item)
            {
                viewHolder.setImage(YNHeartFansActivity.this, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_userName, item.getUsername());
                viewHolder.setText(R.id.tv_userIntroduce, item.getDescribe());

                if (item.getLiving() == 1)
                {
                    viewHolder.getView(R.id.iv_living_state).setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_living_state, R.drawable.my_attention_living);
                }
                else
                {
                    viewHolder.getView(R.id.iv_living_state).setVisibility(View.INVISIBLE);
                }
            }
        };

        mHeartFansLV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                LiveRoomBean liveRoomBean = followList.get(position - 2);
                //是主播才能跳转进他的主页
                if (liveRoomBean.getUser_status()==0) {
                    Intent intent = new Intent();
                    intent.setClass(YNHeartFansActivity.this, FindAnchorHomeActivity.class);
                    if (YNBaseActivity.isConnectNet) {
                        if (type == 1) intent.putExtra(YNCommonConfig.USER_ID, liveRoomBean.getUserid());
                        else intent.putExtra(YNCommonConfig.USER_ID, liveRoomBean.getAttentionid());

                        startActivity(intent);
                    } else {
                        YNToastMaster.showToast(YNHeartFansActivity.this, R.string.no_net);
                    }
                }
            }
        });

        mHeartFansLV.setAdapter(mHeartFansAdapter);

        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch (checkedId)
                {
                    case R.id.rb_heart:
                        type = 0;
                        mHeartFansLV.setAdapter(mHeartFansAdapter);
//                        mViewPager.setCurrentItem(0);
                        break;

                    case R.id.rb_fans:
                        type = 1;
                        mHeartFansLV.setAdapter(mAdapter);
//                        mViewPager.setCurrentItem(1);
                        break;
                }
//                if(followList!=null) {
//                    followList.removeAll(followList);
//                    if (type == 0)
//                        mHeartFansAdapter.updateListView(followList);
//                    else
//                        mAdapter.updateListView(followList);
                    getNetData();
//                }
            }
        });

    }

    private void getNetData()
    {
        if (type == 0)
        {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyAttentionList(YNHeartFansActivity.this, YNCommonConfig.GET_MY_ATTENTION_LIST_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.MY_ATTENTION_LIST_FLAG, true);
                }
            });
        }
        else
        {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyAttentionList(YNHeartFansActivity.this, YNCommonConfig.GET_MY_FANS_LIST_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.MY_FANS_LIST_FLAG, true);
                }
            });
        }
    }

    private void getRefreshData()
    {
        if (type == 0)
        {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyAttentionList(YNHeartFansActivity.this, YNCommonConfig.GET_MY_ATTENTION_LIST_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.ON_REFRESH, false);
                }
            });
        }
        else
        {
            mHandler.post(new Runnable() {
                @Override
                public void run()
                {
                    UserHttpUtils.newInstance().getMyAttentionList(YNHeartFansActivity.this, YNCommonConfig.GET_MY_FANS_LIST_URL, AccountUtils.getAccountBean().getId(), mHandler, YNCommonConfig.ON_REFRESH, false);
                }
            });
        }
    }

    private void getData(Message msg)
    {
        if (msg.obj != null)
        {
            BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
            if (baseBean.getCode() == 28)
            {
                mHeartFansLV.setVisibility(View.VISIBLE);
                mRLEmpty.setVisibility(View.GONE);
                try
                {
                    JSONObject jsonObject = new JSONObject(msg.obj.toString());
                    JSONArray jsonArray = jsonObject.optJSONArray("data");
                    if (type == 0)
                    {
                        followCount = jsonObject.getInt("acount");
                        totalPages = UserHttpUtils.newInstance().getTotalPages(followCount);
                        mTVPeopleNum.setText("关注人数 ( " + followCount + " )");
                    }
                    else
                    {
                        followCount = jsonObject.getInt("count");
                        totalPages = UserHttpUtils.newInstance().getTotalPages(followCount);
                        mTVPeopleNum.setText("粉丝数量 ( "  + followCount + " )");
                    }

                    if (followCount > 10)
                        mHeartFansLV.setLoadMoreEnable(true);

                    Type typeToken = new TypeToken<List<LiveRoomBean>>() {}.getType();
                    if (jsonArray != null)
                    {
                        followList = YNJsonUtil.JsonToLBean(jsonArray.toString(), typeToken);
                        if (type == 0)
                        {
                            mHeartFansAdapter.updateListView(followList);
                        }
                        else
                        {
                            mAdapter.updateListView(followList);
                        }
                    }
                    else
                    {
//                        mRLEmpty.setVisibility(View.VISIBLE);
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }
            else
            {
                mTVPeopleNum.setText("粉丝数量 ( "  + followCount + " )");
                mRLEmpty.setVisibility(View.VISIBLE);
            }

//            YNToastMaster.showToast(YNHeartFansActivity.this, baseBean.getInfo());
        }
        else
        {
//            YNToastMaster.showToast(YNHeartFansActivity.this, getString(R.string.request_fail));
//            mRLEmpty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI() {

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.iv_back:
                finish();
                break;
        }
    }

    @Override
    public void onRefresh()
    {
        getRefreshData();
    }

    @Override
    public void onLoadMore()
    {

    }

    /** 停止刷新 */
    private void onStopLoad()
    {
        mHeartFansLV.stopRefresh();
        mHeartFansLV.stopLoadMore();
        mHeartFansLV.setRefreshTime(DateUtil.getNowDate());
    }
}
