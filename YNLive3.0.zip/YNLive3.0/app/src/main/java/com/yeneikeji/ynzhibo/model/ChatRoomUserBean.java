package com.yeneikeji.ynzhibo.model;

/**
 * 聊天室用户详情
 * Created by Administrator on 2017/3/3.
 */
public class ChatRoomUserBean extends BaseBean
{
    private String userid;
    private String id;
    private String username;
    private String icon;
    private String describes;
    private int is_say;// 点击的用户是否被禁言
    private int is_manage;// 点击的用户是否是房管
    private int is_selfSay;// 自己是否被禁言
    private int is_selfManage;// 自己是否是房管
    private int is_myselfHost;
    private int report;
    private int attention_count;
    private int funs_count;
    private int manage_count;
    private float currentCoin; // 当前余额
    private float incomeCoin; // 收入
    private float payCoin; //支出
    private int totals; // 贡献值
    private int sort;
    //新增字段
    public String myselfId;
    public String name;
    public String user_status;

    public String getDescribes() {
        return describes;
    }

    public void setDescribes(String describes) {
        this.describes = describes;
    }

    public String getMyselfId() {
        return myselfId;
    }

    public void setMyselfId(String myselfId) {
        this.myselfId = myselfId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUser_status() {
        return user_status;
    }

    public void setUser_status(String user_status) {
        this.user_status = user_status;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDescribe() {
        return describes;
    }

    public void setDescribe(String describe) {
        this.describes = describe;
    }

    public int getIs_say() {
        return is_say;
    }

    public void setIs_say(int is_say) {
        this.is_say = is_say;
    }

    public int getIs_manage() {
        return is_manage;
    }

    public void setIs_manage(int is_manage) {
        this.is_manage = is_manage;
    }

    public int getIs_selfSay() {
        return is_selfSay;
    }

    public void setIs_selfSay(int is_selfSay) {
        this.is_selfSay = is_selfSay;
    }

    public int getIs_selfManage() {
        return is_selfManage;
    }

    public void setIs_selfManage(int is_selfManage) {
        this.is_selfManage = is_selfManage;
    }

    public int getIs_myselfHost() {
        return is_myselfHost;
    }

    public void setIs_myselfHost(int is_myselfHost) {
        this.is_myselfHost = is_myselfHost;
    }

    public int getFuns_count() {
        return funs_count;
    }

    public void setFuns_count(int funs_count) {
        this.funs_count = funs_count;
    }

    public int getAttention_count() {
        return attention_count;
    }

    public void setAttention_count(int attention_count) {
        this.attention_count = attention_count;
    }

    public int getReport() {
        return report;
    }

    public void setReport(int report) {
        this.report = report;
    }

    public int getManage_count() {
        return manage_count;
    }

    public void setManage_count(int manage_count) {
        this.manage_count = manage_count;
    }

    public float getCurrentCoin() {
        return currentCoin;
    }

    public void setCurrentCoin(float currentCoin) {
        this.currentCoin = currentCoin;
    }

    public float getIncomeCoin() {
        return incomeCoin;
    }

    public void setIncomeCoin(float incomeCoin) {
        this.incomeCoin = incomeCoin;
    }

    public float getPayCoin() {
        return payCoin;
    }

    public void setPayCoin(float payCoin) {
        this.payCoin = payCoin;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public int getTotals() {
        return totals;
    }

    public void setTotals(int totals) {
        this.totals = totals;
    }
}
