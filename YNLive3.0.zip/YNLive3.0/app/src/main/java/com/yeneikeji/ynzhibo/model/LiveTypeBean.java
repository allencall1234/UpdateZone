package com.yeneikeji.ynzhibo.model;

import java.util.List;

/**
 * 直播分类实体类
 * Created by Administrator on 2016/12/8.
 */
public class LiveTypeBean extends BaseBean
{
    private String title;// 分类标题
    private int img;// 分类标题背景
    private List<LiveRoomBean> liveRoomList;

//    public LiveTypeBean(String title, int img)
//    {
//        this.title = title;
//        this.img = img;
//    }

    public List<LiveRoomBean> getLiveRoomList() {
        return liveRoomList;
    }

    public void setLiveRoomList(List<LiveRoomBean> liveRoomList) {
        this.liveRoomList = liveRoomList;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
