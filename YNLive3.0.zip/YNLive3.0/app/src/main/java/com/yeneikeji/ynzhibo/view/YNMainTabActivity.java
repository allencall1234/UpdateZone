package com.yeneikeji.ynzhibo.view;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.View;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;
import com.yeneikeji.ynzhibo.common.YNTabWidget;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.FindFragment;
import com.yeneikeji.ynzhibo.fragment.LiveFragment;
import com.yeneikeji.ynzhibo.fragment.MineFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.SpUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.view.mine.YNLoginActivity;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

/**
 * 主界面
 * Created by Administrator on 2016/8/5.
 */

public class YNMainTabActivity extends YNBaseActivity implements YNTabWidget.OnTabSelectedListener
{
    private static final String TAG = "YNMainTabActivity";
    private YNApplication app;
    private YNTabWidget mTabWidget;

    private FragmentManager mFragmentManager;

    private LiveFragment   mLiveFragment;
    private FindFragment   mFindFragment;
    private MineFragment   mMineFragment;

    private int mIndex = YNCommonConfig.BOTTOM_TABLE_ONE;

    private long mExitTime = 0;
    // 判断是否为登录后跳转动作
    private boolean isLogin = false;
    private String ACTION_TAG = "Main";
    private String tempIndex = "index";

    private YNPayDialog settingDialog;
    private YNPayDialog offLineDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view =View.inflate(this, R.layout.activity_main, null);
        setContentView(view);
//        AutoUtils.auto(this);
        YNApplication.getInstance().setOHandler(oHanlder);
        initIntent();
        initView();
        addEvent();
        settingDo();
    }

    private void initIntent() {
        // 获取跳转标志的值
        Intent intent = getIntent();
        if(intent != null){
           ACTION_TAG = intent.getAction()==null?"Main":intent.getAction();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SpUtils.remove(this,tempIndex);
    }

    @Override
    protected void initView()
    {
        app = new YNApplication();
        mFragmentManager = getSupportFragmentManager();
        mTabWidget = (YNTabWidget) findViewById(R.id.tab_widget);
    }

    @Override
    protected void addEvent()
    {
        mTabWidget.setOnTabSelectedListener(this);
    }

    @Override
    protected void settingDo()
    {
        if (!YNCommonUtils.isNotificationEnabled(this))
        {
            settingDialog = new YNPayDialog.Builder(context)
                    .setHeight(0.35f)  //屏幕高度
                    .setWidth(0.8f)  //屏幕宽度
                    .setTitleVisible(true)
                    .setTitleText("温馨提示")
                    .setTitleTextSize(17)
                    .setTitleTextColor(R.color.live_details_text_black)
                    .setContentText("您的通知权限未打开，无法接收到推送通知，请在设置中开启通知")
                    .setContentTextColor(R.color.live_details_text_black)
                    .setContentTextSize(14)
                    .setLeftButtonText("取消")
                    .setLeftButtonTextColor(R.color.live_details_text_black)
                    .setRightButtonText("设置")
                    .setRightButtonTextColor(R.color.live_details_text_blue)
                    .setButtonTextSize(18)
                    .setCanceledOnTouchOutside(false)
                    .setInterceptBack(true)
                    .setOnclickListener(new IDialogOnClickListener() {
                        @Override
                        public void clickTopLeftButton(View view) {

                        }

                        @Override
                        public void clickTopRightButton(View view) {

                        }

                        @Override
                        public void clickBottomLeftButton(View view)
                        {
                            settingDialog.dismiss();
                        }

                        @Override
                        public void clickBottomRightButton(View view)
                        {
                            settingDialog.dismiss();
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.BASE) {
                                // 进入设置系统应用权限界面
                                Intent intent = new Intent(Settings.ACTION_SETTINGS);
                                startActivity(intent);
                            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {// 运行系统在5.x环境使用
                                // 进入设置系统应用权限界面
                                Intent intent = new Intent(Settings.ACTION_SETTINGS);
                                startActivity(intent);
                            }
                        }

                        @Override
                        public void clickBottomButton(View view) {

                        }
                    })
                    .build();

            settingDialog.show();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mIndex = SpUtils.getIndex(context, tempIndex);
        onTabSelected(mIndex);
        mTabWidget.setTabsDisplay(this, mIndex);
       /* switch (ACTION_TAG){

            // 登录后显示社区界面
            case "DynamicBack":
                onTabSelected(YNCommonConfig.BOTTOM_TABLE_TWO);
                mTabWidget.setTabsDisplay(this, YNCommonConfig.BOTTOM_TABLE_TWO);
                break;
            // 登录后显示我的界面
            case "MineBack":
                onTabSelected(YNCommonConfig.BOTTOM_TABLE_FOUR);
                mTabWidget.setTabsDisplay(this, YNCommonConfig.BOTTOM_TABLE_FOUR);
                break;
            // 打开App时进入直播界面
            default:
                onTabSelected(mIndex);
                mTabWidget.setTabsDisplay(this, mIndex);
                break;
        }
        ACTION_TAG = "Main";*/

    }

    @Override
    public void loginRefreshUI()
    {

    }

    @Override
    public void unLoginRefreshUI()
    {

    }

    @Override
    public void onTabSelected(int index)
    {
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        switch (index)
        {
            case YNCommonConfig.BOTTOM_TABLE_ONE:
                tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
                mIndex = index;
                hideFragments(transaction);
                if (null == mLiveFragment)
                {
                    mLiveFragment = new LiveFragment();
                    transaction.add(R.id.center_layout, mLiveFragment);
                }
                else
                {
                    transaction.show(mLiveFragment);
                }
                break;

            case YNCommonConfig.BOTTOM_TABLE_TWO:
                tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
                mIndex = index;
                hideFragments(transaction);
                if (null == mFindFragment)
                {
                    mFindFragment = new FindFragment();
                    transaction.add(R.id.center_layout, mFindFragment);
                }
                else
                {
                    transaction.show(mFindFragment);
                }
                break;

            case YNCommonConfig.BOTTOM_TABLE_THREE:
                mIndex = index;
                hideFragments(transaction);
//                tintManager.setStatusBarTintColor(Color.rgb(38,154,252));
                tintManager.setStatusBarTintResource(R.drawable.my_bg);
                if (null == mMineFragment)
                {
                    mMineFragment = new MineFragment();
                    transaction.add(R.id.center_layout, mMineFragment);
                }
                else
                {
                    transaction.show(mMineFragment);
                }
                break;
        }
        SpUtils.putIndex(context,tempIndex, mIndex);
        // 当activity再次被恢复时commit之后的状态将丢失。如果丢失也没关系，那么使用commitAllowingStateLoss()方法
        transaction.commitAllowingStateLoss();
    }

    private void hideFragments(FragmentTransaction transaction)
    {
        if (null != mLiveFragment)
        {
            transaction.hide(mLiveFragment);
        }
        if (null != mFindFragment)
        {
            transaction.hide(mFindFragment);
        }
        if (null != mFindFragment)
        {
            transaction.hide(mFindFragment);
        }
        if (null != mMineFragment)
        {
            transaction.hide(mMineFragment);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("index", mIndex);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        mIndex = savedInstanceState.getInt("index");
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    public boolean dispatchKeyEvent(KeyEvent event)
    {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            ExitApp();
            return true;
        }
        else if (event.getKeyCode() == KeyEvent.KEYCODE_MENU && event.getAction() == KeyEvent.ACTION_DOWN)
        {

        }
        return super.dispatchKeyEvent(event);
    }

    public void ExitApp()
    {
        if ((System.currentTimeMillis() - mExitTime) > 2000)
        {
            YNToastMaster.showToast(this, "再按一次退出程序");
            mExitTime = System.currentTimeMillis();
        }
        else
        {
//            System.exit(0);
            finish();
//            app.AppExit(this);
//            app.finishAllActivity();
        }
    }

    private Handler oHanlder = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case COMPULSORY_DOWNLINE_FLAE:
                    if(msg.obj != null){
                        String extras = msg.obj.toString();
                        createOffLineDialog(extras);
                    }
            }
        }
    };


    private void createOffLineDialog(String extras)
    {
        if (offLineDialog == null)
        {
            offLineDialog = new YNPayDialog.Builder(context)
                    .setHeight(0.4f)  //屏幕高度
                    .setWidth(0.8f)  //屏幕宽度
                    .setTitleVisible(true)
                    .setTitleText("下线通知")
                    .setTitleTextSize(17)
                    .setTitleTextColor(R.color.live_details_text_black)
                    .setContentText(extras)
                    .setContentTextColor(R.color.live_details_text_black)
                    .setContentTextSize(14)
                    .setLeftButtonText("退出")
                    .setLeftButtonTextColor(R.color.live_details_text_black)
                    .setRightButtonText("重新登录")
                    .setRightButtonTextColor(R.color.live_details_text_black)
                    .setButtonTextSize(18)
                    .setCanceledOnTouchOutside(false)
                    .setInterceptBack(true)
                    .setOnclickListener(new IDialogOnClickListener() {
                        @Override
                        public void clickTopLeftButton(View view) {

                        }

                        @Override
                        public void clickTopRightButton(View view) {

                        }

                        @Override
                        public void clickBottomLeftButton(View view)
                        {
                            offLineDialog.dismiss();
                            offLineDialog = null;
                            finish();
                            YNApplication.getInstance().getSHandler().sendEmptyMessage(0);
                            Intent intent = new Intent(context, YNLoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);

                        }

                        @Override
                        public void clickBottomRightButton(View view)
                        {
                            final Handler mHandler = YNApplication.getInstance().getMHandler();
                            offLineDialog.dismiss();
                            offLineDialog = null;
                            YNApplication.getInstance().getSHandler().sendEmptyMessage(0);
                            mHandler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().userLogin(context, YNCommonConfig.USER_LOGIN_URL,
                                                                          AccountUtils.getAccountBean().getPhone(),
                                                                          AccountUtils.getAccountBean().getPassword(),
                                                                          YNApplication.deviceId,
                                                                          mHandler,
                                                                          YNCommonConfig.USER_LOGIN_FLAG,
                                                                          false);
                                }
                            });
                        }

                        @Override
                        public void clickBottomButton(View view) {

                        }
                    }).build();
            offLineDialog.show();
        }
    }
}
