package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.ChatRoomUserBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.community.FindAnchorHomeActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.yeneikeji.ynzhibo.http.YNCommonConfig.USER_ID;

/**
 *  贡献排行榜界面
 * Created by Administrator on 2016/11/9.
 */
public class
ContributionChartsActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener,
                   SmoothListView.ISmoothListViewListener,
                   RadioGroup.OnCheckedChangeListener,
                   AdapterView.OnItemClickListener
{
    private SmoothListView mLVContributionCharts;

    private CommonAdapter mContributionListAdapter;
    private List<ChatRoomUserBean> contributionList   = new ArrayList<>();
    private int                    WEEK_CONTRIBUTION  = 0;
    private int                    TOTAL_CONTRIBUTION = 1;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG:
                    if (msg.obj != null) {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray  array      = jsonObject.getJSONArray("data");

                                Type type = new TypeToken<List<ChatRoomUserBean>>() {}.getType();
                                contributionList = YNJsonUtil.JsonToLBean(array.toString(), type);

                                //如果没有数据就设置一个空视图背景
                                if (contributionList.size() == 0||array==null) {
                                    mEmpty.setVisibility(View.VISIBLE);
                                } else {
                                    mEmpty.setVisibility(View.GONE);
                                }

                                mContributionListAdapter.updateListView(contributionList);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                mEmpty.setVisibility(View.VISIBLE);
                            }
//请求成功后停止刷新
                            mLVContributionCharts.stopRefresh();
                            mLVContributionCharts.stopLoadMore();
                        } else {
                            mLVContributionCharts.stopRefresh();
                            mLVContributionCharts.stopLoadMore();
                            mEmpty.setVisibility(View.VISIBLE);

                        }
                    } else {
                        mEmpty.setVisibility(View.VISIBLE);
                     }
                    break;
            }
        }
    };
    private RadioGroup     mRadiogroup;
    private RadioButton    mMWeekBtn;
    private RadioButton    mTotalBtn;
    private ImageView      mBackiv;
    private RelativeLayout mEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_contribution_charts,null);
     //   AutoUtils.auto(view);//放在加载布局的前面
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        //configTopBarCtrollerWithTitle(getString(R.string.contribution_charts));
        //贡献榜没有数据时的空视图
        mEmpty = (RelativeLayout) findViewById(R.id.empty);
        mRadiogroup = (RadioGroup) findViewById(R.id.rg_contribution_title);
        mBackiv = (ImageView) findViewById(R.id.iv_contribution_back);
        mRadiogroup.setOnCheckedChangeListener(this);
        mLVContributionCharts = (SmoothListView) findViewById(R.id.lv_contribution_charts);
        //贡献榜点击按钮
        mMWeekBtn = (RadioButton) findViewById(R.id.rb_weekcontribution);
        mTotalBtn = (RadioButton) findViewById(R.id.rb_totalcontribution);

        // 设置下拉刷新及加载更多 监听
        mLVContributionCharts.setSmoothListViewListener(this);
        //设置listview的条目点击事件
        mLVContributionCharts.setOnItemClickListener(this);
        //返回图标按钮
        mBackiv.setOnClickListener(this);

    }

    @Override
    protected void addEvent()
    {
       // getLeftBtn().setOnClickListener(this);
        //没有数据时点击空视图重新加载
        mEmpty.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        getContributionCharts(WEEK_CONTRIBUTION);

        mContributionListAdapter = new CommonAdapter<ChatRoomUserBean>(this,
                                                                       contributionList,
                                                                       R.layout.contribution_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, ChatRoomUserBean item)
            {
                if (item.getSort() == 1) {
                    viewHolder.getView(R.id.iv_ranking)
                              .setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.gold);
                }
                if (item.getSort() == 2) {
                    viewHolder.getView(R.id.iv_ranking)
                              .setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.silver);
                }
                if (item.getSort() == 3) {
                    viewHolder.getView(R.id.iv_ranking)
                              .setVisibility(View.VISIBLE);
                    viewHolder.setImageResource(R.id.iv_ranking, R.drawable.copper);
                }
                if (item.getSort() > 3) {
                    viewHolder.getView(R.id.iv_ranking)
                              .setVisibility(View.INVISIBLE);
                    viewHolder.getView(R.id.tv_ranking)
                              .setVisibility(View.VISIBLE);
                    viewHolder.setText(R.id.tv_ranking, ""+item.getSort());
                }
                viewHolder.setImage(ContributionChartsActivity.this, R.id.iv_head, item.getIcon());
                viewHolder.setText(R.id.tv_userName, item.getUsername());
                viewHolder.setText(R.id.tv_contribution_num, "贡献:" + item.getTotals());

            }
        };

        mLVContributionCharts.setAdapter(mContributionListAdapter);
        // 设置允许下拉刷新及加载更多
        mLVContributionCharts.setLoadMoreEnable(false);
    }

    private void getContributionCharts(final int contributionType)

    {

        handler.post(new Runnable() {
            @Override
            public void run()
            {

                UserHttpUtils.newInstance()
                             .getContributionValueList(ContributionChartsActivity.this,
                                                       YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_URL,
                                                       AccountUtils.getAccountBean()
                                                                   .getId(),
                                                       contributionType,
                                                       handler,
                                                       YNCommonConfig.GET_CONTRIBUTION_VALUE_LIST_FLAG,true);
            }
        });

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId()) {
            case R.id.iv_contribution_back:
                finish();
                break;
            //没有数据展示时点击空示图刷新一下
            case R.id.empty:
                onRefresh();
                break;
        }
    }


    /**
     * 刷新数据
     */
    @Override
    public void onRefresh() {

        if (mMWeekBtn.isChecked()) {
            //请求周榜数据
            getContributionCharts(WEEK_CONTRIBUTION);
            //更新时间状态
            updataeRefreshTime();
            mContributionListAdapter.notifyDataSetChanged();
        } else if (mTotalBtn.isChecked()) {
            //请求总榜数据
            getContributionCharts(TOTAL_CONTRIBUTION);
            //更新状态
            updataeRefreshTime();
            mContributionListAdapter.notifyDataSetChanged();
        }


    }

    private void updataeRefreshTime() {
        Date             currentTime = new Date();
        SimpleDateFormat formatter   = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String           dateString  = formatter.format(currentTime);
        mLVContributionCharts.setRefreshTime(dateString);
    }

    /**
     * 加载更多
     */
    @Override
    public void onLoadMore() {
       /* new Thread() {
            @Override
            public void run() {
                super.run();
                handler.sendEmptyMessage(2);
            }
        }.start();
        mContributionListAdapter.notifyDataSetChanged();*/

    }

    //根据点击的不同请求贡献周榜或总榜的数据
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rb_weekcontribution:

                contributionList.clear();
                mContributionListAdapter.notifyDataSetChanged();
                getContributionCharts(WEEK_CONTRIBUTION);
                break;
            case R.id.rb_totalcontribution:
                contributionList.clear();
                mContributionListAdapter.notifyDataSetChanged();
                getContributionCharts(TOTAL_CONTRIBUTION);
                break;
        }

    }

    //listview条目点击事件，跳转到个人主页面
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent           intent = new Intent(this, FindAnchorHomeActivity.class);
        ChatRoomUserBean item   = (ChatRoomUserBean) mContributionListAdapter.getItem(position - mLVContributionCharts.getHeaderViewsCount());
       if(item.getUser_status().equals("0")){
           intent.putExtra(USER_ID, item.getUserid());
           startActivity(intent);
       }


    }

    //退出应用时清空所有消息
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
