package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.model.PhotoInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.view.community.ImagePagerActivity;
import com.yeneikeji.ynzhibo.view.community.PersonalHomePageActivity;
import com.yeneikeji.ynzhibo.widget.MultiImageView;
import com.yeneikeji.ynzhibo.widget.dialog.YNCommonDialog;
import com.yeneikeji.ynzhibo.widget.dialog.YNLoadingDialog;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 *  动态listview适配器
 * Created by Administrator on 2016/11/16.
 */
public class DynamicAdapter extends BaseAdapter
{
    private Context context;
    private List<DynamicBean> dynamicList;
    private boolean flag;
    private DynamicViewHolder holder;
    private YNCommonDialog dialog;
    private YNLoadingDialog loadingDialog;
    private String cId;
    private int index;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.ATTENTION_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 43)
                        {
                            for (DynamicBean dynamicBean : dynamicList)
                            {
                                if (dynamicList.get(index).getUserid().equals(dynamicBean.getUserid()))
                                {
                                    dynamicBean.setIs_attention(1);
                                }
                            }
                            notifyDataSetChanged();
//                            flag = false;
//                            notifyDataSetChanged();
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.COMMUNITY_USER_THUMB_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 34)
                        {
                            try
                            {
                                JSONObject object = new JSONObject(msg.obj.toString());
                                int thumb = object.getInt("thumb");
                                int thumb_num = object.getJSONObject("data").getInt("zan_num");
                                String cid = object.getJSONObject("data").getString("id");
                                for (DynamicBean dynamicBean : dynamicList)
                                {
                                    if (cid.equals(dynamicBean.getId()))
                                    {
                                        dynamicBean.setThumb(thumb);
                                        dynamicBean.setZan_num(thumb_num);
                                        break;
                                    }
                                }
                                notifyDataSetChanged();
                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.DELETE_PERSONAL_DYNAMIC_FLAG:
                    dialog.dismiss();
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 50)
                        {
                            for (DynamicBean dynamicBean : dynamicList)
                            {
                                if (cId.equals(dynamicBean.getId()))
                                {
                                    dynamicList.remove(dynamicBean);
                                    notifyDataSetChanged();
                                    break;
                                }
                            }
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13)
                        {
                            for (DynamicBean dynamicBean : dynamicList)
                            {
                                if (dynamicList.get(index).getUserid().equals(dynamicBean.getUserid()))
                                {
                                    dynamicBean.setIs_attention(0);
                                }
                            }
                            notifyDataSetChanged();
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, context.getString(R.string.request_fail));
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

/*    public DynamicAdapter(Context context, List<DynamicBean> dynamicList, boolean flag)
    {
        this.context = context;
        this.dynamicList = dynamicList;
        this.flag = flag;
    }*/

    public DynamicAdapter(Context context, List<DynamicBean> dynamicList, boolean flag)
    {
        this.context = context;
        this.dynamicList = dynamicList;
        this.flag = flag;
    }

    public void setDynamicList(List<DynamicBean> dynamicList)
    {
        this.dynamicList = dynamicList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount()
    {
        return dynamicList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return dynamicList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        final DynamicBean bean = dynamicList.get(position);
        if (convertView == null)
        {
            holder = new DynamicViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.dynamic_item, parent, false);
            holder.iv_head = (ImageView) convertView.findViewById(R.id.iv_head);
            holder.tv_uname = (TextView) convertView.findViewById(R.id.tv_uname);
            holder.tv_create_time = (TextView) convertView.findViewById(R.id.tv_create_time);
            holder.tv_focus_on = (TextView) convertView.findViewById(R.id.tv_focus_on);
            holder.iv_more = (ImageView) convertView.findViewById(R.id.iv_more);
//            holder.iv_delete = (ImageView) convertView.findViewById(R.id.iv_delete);
            holder.ll_delete = (LinearLayout) convertView.findViewById(R.id.ll_delete);
            holder.tv_content = (TextView) convertView.findViewById(R.id.tv_content);
            holder.tv_comment_num = (TextView) convertView.findViewById(R.id.tv_comment_num);
            holder.ll_thumb = (LinearLayout) convertView.findViewById(R.id.ll_thumb);
            holder.iv_praise = (ImageView) convertView.findViewById(R.id.iv_praise);
            holder.tv_praise_num = (TextView) convertView.findViewById(R.id.tv_praise_num);
            holder.multiImageView = (MultiImageView) convertView.findViewById(R.id.multiImgView);
            holder.line = convertView.findViewById(R.id.line);
            convertView.setTag(holder);
        }
        else
        {
            holder = (DynamicViewHolder) convertView.getTag();
        }

        if (flag)
        {
            if (bean.getIs_attention() == 1)
            {
                holder.tv_focus_on.setVisibility(View.GONE);
//                holder.iv_more.setVisibility(View.VISIBLE);
            }
            else
            {
                if (AccountUtils.getLoginInfo() && AccountUtils.getAccountBean().getId().equals(bean.getUserid()))
                {
                    holder.tv_focus_on.setVisibility(View.INVISIBLE);
//                    holder.iv_more.setVisibility(View.GONE);
//                    holder.iv_delete.setVisibility(View.VISIBLE);
                    holder.ll_delete.setVisibility(View.VISIBLE);
                }
                else
                {
                    holder.tv_focus_on.setVisibility(View.VISIBLE);
//                    holder.iv_more.setVisibility(View.GONE);
//                    holder.iv_delete.setVisibility(View.GONE);
                    holder.ll_delete.setVisibility(View.GONE);
                }
            }
        }
        else
        {
            if (AccountUtils.getAccountBean().getId().equals(bean.getUserid()))
            {
                holder.tv_focus_on.setVisibility(View.GONE);
                holder.iv_more.setVisibility(View.INVISIBLE);
//                holder.iv_delete.setVisibility(View.VISIBLE);
                holder.ll_delete.setVisibility(View.VISIBLE);
            }
            else
            {
                holder.tv_focus_on.setVisibility(View.INVISIBLE);
                holder.tv_focus_on.setText("已关注");
//                holder.tv_focus_on.setTextColor(ContextCompat.getColor(context, R.color.followed_text_color));
//                holder.iv_more.setVisibility(View.VISIBLE);
//                holder.iv_delete.setVisibility(View.GONE);
                holder.ll_delete.setVisibility(View.GONE);
            }
        }

        // 关注用户处理
        holder.tv_focus_on.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                index = position;
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo())
                    {
                        if (bean.getIs_attention() == 0)
                        {
                            mHandler.postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().attentionUser(context, YNCommonConfig.ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(),
                                            bean.getUserid(), mHandler, YNCommonConfig.ATTENTION_USER_FLAG, false);
                                }
                            }, 500);
                        }
//                        else
//                        {
//                            dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.cancel_attention_user), false, new YNCommonDialog.CustomDialogListener()
//                            {
//                                @Override
//                                public void OnClick(View view)
//                                {
//                                    switch (view.getId())
//                                    {
//                                        case R.id.btnCancel:
//                                            dialog.dismiss();
//                                            break;
//
//                                        case R.id.btnConfirm:
//                                            dialog.dismiss();
//                                            mHandler.postDelayed(new Runnable()
//                                            {
//                                                @Override
//                                                public void run()
//                                                {
//                                                    UserHttpUtils.newInstance().cancelAttentionUser(context, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(),  bean.getUserid(), mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG);
//                                                }
//                                            }, 1000);
//                                            break;
//                                    }
//                                }
//                            });
//                            dialog.show();
//                        }

                    }
                    else
                    {
                        YNToastMaster.showToast(context, R.string.un_login_opreate_notice);
                    }
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
            }
        });

      /*  holder.iv_more.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (AccountUtils.getLoginInfo())
                {
                    dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.cancel_attention_user), false, new YNCommonDialog.CustomDialogListener()
                    {
                        @Override
                        public void OnClick(View view)
                        {
                            switch (view.getId())
                            {
                                case R.id.btnCancel:
                                    dialog.dismiss();
                                    break;

                                case R.id.btnConfirm:
                                    dialog.dismiss();
                                    mHandler.postDelayed(new Runnable()
                                    {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance().cancelAttentionUser(context, YNCommonConfig.CANCEL_ATTENTION_USER_URL, AccountUtils.getAccountBean().getId(),  bean.getUserid(), mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG);
                                        }
                                    }, 1000);
                                    break;
                            }
                        }
                    });
                    dialog.show();
                }
                else
                {
                    Intent intent = new Intent();
                    intent.setClass(context, YNLoginActivity.class);
                    context.startActivity(intent);
                }
//                showDialog(holder.tv_focus_on, holder.iv_more);
            }
        });*/

        holder.ll_delete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    dialog = new YNCommonDialog(context, R.style.transparentFrameWindowStyle, context.getString(R.string.delete_dynamic_notice), false, new YNCommonDialog.CustomDialogListener() {
                        @Override
                        public void OnClick(View view)
                        {
                            switch (view.getId())
                            {
                                case R.id.btnCancel:
                                    dialog.dismiss();
                                    break;

                                case R.id.btnConfirm:
                                    cId =  bean.getId();
                                    dialog.dismiss();
                                    mHandler.postDelayed(new Runnable()
                                    {
                                        @Override
                                        public void run()
                                        {
                                            UserHttpUtils.newInstance().deletePersonalDynamic(context, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_URL, cId, mHandler, YNCommonConfig.DELETE_PERSONAL_DYNAMIC_FLAG, true);
                                        }
                                    }, 1000);
                                    break;
                            }
                        }
                    });
                    dialog.show();
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
            }
        });

//            holder.line.setVisibility(View.GONE);

        String name = bean.getUsername();
        String headImg = bean.getIcon();
        final String content = bean.getContent();
        String createTime = DateUtil.timeStamp2String(bean.getTime());
        String thumbs = String.valueOf(bean.getZan_num());
        final String comments = String.valueOf(bean.getComment_num());

        if (bean.getPicture() != null)
        {
            final List<PhotoInfoBean> photos = new ArrayList<>();

            for (int i = 0; i < bean.getPicture().size(); i++)
            {
                photos.add(new PhotoInfoBean(bean.getPicture().get(i).getBig(), bean.getPicture().get(i).getSmall(), 640, 792));
            }

            holder.multiImageView.setVisibility(View.VISIBLE);
            holder.multiImageView.setList(photos);
            holder.multiImageView.setOnItemClickListener(new MultiImageView.OnItemClickListener()
            {
                @Override
                public void onItemClick(View view, int position)
                {
                    //imagesize是作为loading时的图片size
                    ImagePagerActivity.ImageSize imageSize = new ImagePagerActivity.ImageSize(view.getMeasuredWidth(), view.getMeasuredHeight());

                    List<String> photoUrls = new ArrayList<String>();
                    for (PhotoInfoBean photoInfo : photos)
                    {
                        photoUrls.add(photoInfo.getBig());
                    }
                    ImagePagerActivity.startImagePagerActivity(context, photoUrls, position, imageSize);
                }

            });
        }
        else
        {
            holder.multiImageView.setVisibility(View.GONE);
        }

        YNImageLoaderUtil.setImage(context, holder.iv_head, headImg);
        holder.tv_uname.setText(name);
        holder.tv_create_time.setText(createTime);
        holder.tv_content.setText(content);
        holder.tv_comment_num.setText(comments);
        if (AccountUtils.getLoginInfo())
            holder.iv_praise.setImageResource(bean.getThumb() == 0 ? R.drawable.like : R.drawable.like_red);
        else
            holder.iv_praise.setImageResource(R.drawable.like);

        holder.tv_praise_num.setText(thumbs);
        holder.iv_head.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    Intent intent = new Intent();
                    intent.setClass(context, PersonalHomePageActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(YNCommonConfig.USER_ID, bean.getUserid());
                    intent.putExtras(bundle);
                    if (AccountUtils.getLoginInfo())
                    {
                        if (AccountUtils.getAccountBean().getId().equals(bean.getUserid()))
                        {
                            intent.putExtra(YNCommonConfig.ISSHOW, false);
                        }
                        else
                        {
                            intent.putExtra(YNCommonConfig.ISSHOW, true);
                        }
                    }
                    else
                    {
                        intent.putExtra(YNCommonConfig.ISSHOW, true);
                    }
                    context.startActivity(intent);
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
            }
        });

        // 点赞处理
        holder.ll_thumb.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (YNBaseActivity.isConnectNet)
                {
                    if (AccountUtils.getLoginInfo())
                    {
                        mHandler.postDelayed(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance().userThumbUp(context, YNCommonConfig.COMMUNITY_USER_THUMB_URL, AccountUtils.getAccountBean().getId(), bean.getId(),
                                        bean.getThumb(), mHandler, YNCommonConfig.COMMUNITY_USER_THUMB_FLAG, false);
                            }
                        }, 500);
                    }
                    else
                    {
//                        Intent intent = new Intent();
                        YNToastMaster.showToast(context, R.string.un_login_opreate_notice);
//                        context.startActivity(intent);
                    }
                }
                else
                {
                    YNToastMaster.showToast(context, R.string.no_net);
                }
            }
        });

        return convertView;
    }

    class DynamicViewHolder
    {
        private ImageView iv_head;
        private TextView tv_uname;
        private TextView tv_create_time;
        private TextView tv_focus_on;
        private ImageView iv_more;
//        private ImageView iv_delete;
        private LinearLayout ll_delete;
        private TextView tv_content;
        private TextView tv_comment_num;
        private LinearLayout ll_thumb;
        private ImageView iv_praise;
        private TextView tv_praise_num;
        private MultiImageView multiImageView;
        private View line;
    }

}
