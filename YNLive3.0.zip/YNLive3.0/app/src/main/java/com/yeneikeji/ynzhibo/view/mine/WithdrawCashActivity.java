package com.yeneikeji.ynzhibo.view.mine;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BankCardBean;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.BankInfoBean;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.utils.YNRSAUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.Cipher;

import cn.smssdk.EventHandler;

/**
 *  提现界面
 * Created by Administrator on 2016/11/10.
 */
public class WithdrawCashActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private int time = 60;
    private EventHandler eventHandler;
    private TextView     mEditBankCardInfo;
    private String       mFlag;
    private TextView     mAddBankInfo;
    private TextView     mDrawCash;
    private BankCardBean mMata;
   /* private  String mPublicKey="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDIxObC92Pn9A4edwQFpcBNAde7" +
            "lxSU+NvvYMEBr+mccb2JOkRsukGQ0eFbRldpdGeCgtjCa/ZRRAiWGeStHCwZ1/vU" +
            "thM+DQCggsvJvXuyYD5sY2eR7MnFB/kwKzo0lypq8f6/V7KCwa0PTOuU3tv9eoGB" +
            "4cL3gRnZSCt00hsd3QIDAQAB";
    private  String mPrivateKey="MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMjE5sL3Y+f0Dh53\n" +
            "BAWlwE0B17uXFJT42+9gwQGv6ZxxvYk6RGy6QZDR4VtGV2l0Z4KC2MJr9lFECJYZ\n" +
            "5K0cLBnX+9S2Ez4NAKCCy8m9e7JgPmxjZ5HsycUH+TArOjSXKmrx/r9XsoLBrQ9M\n" +
            "65Te2/16gYHhwveBGdlIK3TSGx3dAgMBAAECgYBduFTElHmFsM7ad9Jf1IUVLZQI\n" +
            "VLld5WG9t9vBLt4NkqbYpWOFodizgtYBJq/tYVJkgTIwZ/d+7hRYBVRTXwBSaBxX\n" +
            "b02P+pr8EYuBJmUKDEzJKDrSy0xCdUkfCTwpJkAvkk79i3zI5AJRqH2hYsus4rnW\n" +
            "0Gsm40+AptgDQDyxIQJBAO+vluYwdRciLc5o93UPPbGw4v3IzRETR2jg0iQSjXhT\n" +
            "oH5F9rwu78az/LSJbZER23nD3viKkV+QxG3ojUUhb6kCQQDWbzTaXM/nhtBA7c6P \n" +
            "XYg1skBYRgS/EalMJ+MZoS90pjmQy7AglhsesaFLi/PN1+0DibecceJQxwvYhgxG\n" +
            "gm0VAkAIIj1MsnhGwLItPwKmxk2hqg8J7baHzc+uj3KSJs8GNlBL+LPWzwD0DUeW\n" +
            "GNPPCHwaNbtrU8h7Jb6EvE+O+QOBAkBl3oK/UeQ622LH1bGRjh+NUtcamHjcxGkn\n" +
            "ErPikx5WTjl+viU39deAZ2Z220/BdFjWm3As1DVtpoHMJTJjtMZZAkEAgSm7s/CB\n" +
            "1VX3NFEQIWow3We+URw7RyohgWET7hdYQ75fWyILjTYi93IVghZRCZ/qbXO5kVUc\n" +
            "JJSTKLgr+/JVdw==";
*/
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what) {
                case YNCommonConfig.CODE_ING:
                    mRegetCheckMa.setClickable(false);
                    mSaveBankInfo.setClickable(false);
                    mRegetCheckMa.setText("重新获取    "+time + "秒");
                    time--;
                    break;

                case YNCommonConfig.CODE_REPEAT:
                    mRegetCheckMa.setText("重新发送");
                    time=60;
                    mRegetCheckMa.setClickable(true);
                    mSaveBankInfo.setClickable(true);
                    //重新获取验证码
                    mRegetCheckMa.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mRandomNumber = YNCommonUtils.getRandomNumber();
                            handler.post(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    UserHttpUtils.newInstance().userGetWebChineseSMSCode(WithdrawCashActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, AccountUtils.getAccountBean().getPhone(),
                                                                                         mRandomNumber, handler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                                }
                            });
                            StartCountTime();
                            //设置不可点击
                            mRegetCheckMa.setClickable(false);
                        }
                    });

                    break;
                //提现
                case YNCommonConfig.GET_TI_XIAN_FLAG:
                    if (msg.obj != null) {
                        YNLogUtil.e("yyy",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 129) {
                            Toast.makeText(context, "提现成功", Toast.LENGTH_SHORT)
                                 .show();
                            //跳转到提交成功界面
                            Intent intent=new Intent(WithdrawCashActivity.this,CashSuccessfulActivity.class);
                            startActivity(intent);
                            try {

                            } catch (Exception e) {

                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(context, "提现失败", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {

                    }
                    break;
                //保存
                case YNCommonConfig.GET_SAVE_BANKID_FLAG:
                    if (msg.obj != null) {
                        YNLogUtil.e("ddd",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            Toast.makeText(context, "保存成功", Toast.LENGTH_SHORT)
                                 .show();
                            //设置保存可点击
                            mSaveBankInfo.setClickable(true);

                            try {

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {

                    }
                    break;
                case YNCommonConfig.GET_EDIT_BANKID_FLAG:
                    if (msg.obj != null) {
                        YNLogUtil.e("eee",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            Toast.makeText(context, "修改成功", Toast.LENGTH_SHORT)
                                 .show();
                            mSaveBankInfo.setClickable(true);

                            try {

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {

                    }
                    break;
                //结算跳进来
                case YNCommonConfig.GET_CALCULATE_INCOME_FLAG:
                    if (msg.obj != null) {
                        YNLogUtil.e("ggg",msg.obj.toString());
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(),
                                                                  BaseBean.class);
                        if (baseBean.getCode() == 28) {
                            try {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                if(jsonObject.getJSONObject("data")!=null) {
                                     mMata = YNJsonUtil.JsonToBean(jsonObject.toString(), BankCardBean.class);
                                    mEditBankCardInfo.setVisibility(View.VISIBLE);
                                    mRlAddBankInfo.setVisibility(View.GONE);
                                    mSaveBankInfo.setVisibility(View.VISIBLE);
                                    mNoticeUserCheck.setVisibility(View.GONE);
                                    mLlAcceptName.setVisibility(View.VISIBLE);
                                    mLlAcceptCardId.setVisibility(View.VISIBLE);
                                    mLlAcceptBankInfo.setVisibility(View.VISIBLE);
                                    mLlDeclareNotice.setVisibility(View.VISIBLE);
                                    //顶部显示数值
                                   mEtAcceptName.setText(mMata.getData().getName());
                                    mBankName.setText(mMata.getData().getBank());
                                    //解密服务器卡号
                                    PrivateKey privateKey = YNRSAUtil.loadPrivateKey(YNCommonConfig.MPRIVATE_KRY);
                                    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                                    cipher.init(Cipher.DECRYPT_MODE, privateKey);
                                    InputStream           ins    = new ByteArrayInputStream(Base64.decode(mMata.getData().getCardId(), Base64.DEFAULT));
                                    ByteArrayOutputStream writer = new ByteArrayOutputStream();
                                    byte[]                buf    = new byte[128];
                                    int                   bufl;
                                    while ((bufl = ins.read(buf)) != -1) {
                                        byte[] block = null;
                                        if (buf.length == bufl) {
                                            block = buf;
                                        } else {
                                            block = new byte[bufl];
                                            for (int i = 0; i < bufl; i++) {
                                                block[i] = buf[i];
                                            }
                                        }
                                        writer.write(cipher.doFinal(block));
                                    }
                                    mEtAcceptCardId.setText(new String(writer.toByteArray(), "utf-8"));
                                    //设置Editext不可编辑
                                    mEtAcceptName.setFocusable(false);
                                    mEtAcceptCardId.setFocusable(false);

                                }else{
                                    mRlAddBankInfo.setVisibility(View.VISIBLE);
                                    mEditBankCardInfo.setVisibility(View.GONE);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        } else {
                            Toast.makeText(context, baseBean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    } else {

                    }
                    break;

            }
        }
    };
    private Intent mIntent;
    private EditText mEtAcceptName;
    private EditText mEtAcceptCardId;
    private EditText mEtCheckCardId;
    private LinearLayout mLlAcceptName;
    private LinearLayout mLlAcceptCardId;
    private LinearLayout mLlCheckCardId;
    private LinearLayout mLlAcceptBankInfo;
    private TextView mNoticeUserCheck;
    private LinearLayout mLlDeclareNotice;
    private CheckBox mRbBtn;
    private RelativeLayout mRlAddBankInfo;
    private String mAccepBankCardId;


    private TextView mSaveBankInfo;
    private TextView mBankName;
    private Boolean isAgree=false;
    private TextView mToCashNumb;
    private TextView mWealtnNumbTv;
    private String mWealthNumb;
    private Dialog mDialog;
    private TextView mPhoneNumbNotice;
    private TextView mRegetCheckMa;
    private EditText mCheckMa;
    private Button mSureBtn;
    private Button mCancleBtn;
    private String mRandomNumber;
    private String mMcardid;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_withdraw_cash);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }


    @Override
    protected void initView()
    {
        mFlag = getIntent().getStringExtra(YNCommonConfig.Artical_EXCITING_FLAG);

        configTopBarCtrollerWithTitle(getString(R.string.withdraw_cash_to_wechat));
        //财富值换成现金数量
        mToCashNumb = (TextView) findViewById(R.id.cash_numb);
        //财富值
        mWealtnNumbTv = (TextView) findViewById(R.id.wealth_numb);
        //整体添加银行卡账户信息
        mRlAddBankInfo = (RelativeLayout) findViewById(R.id.rl_add_bankcard);
        //添加按钮
        mAddBankInfo = (TextView) findViewById(R.id.add_bankCard_info);
        //保存按钮
        mSaveBankInfo = (TextView) findViewById(R.id.save_bankCard_info);
        //整体收款户名
        mLlAcceptName = (LinearLayout) findViewById(R.id.ll_accepet_name);
        //整体收款帐号
        mLlAcceptCardId = (LinearLayout) findViewById(R.id.ll_accepet_cardID);
        //整体验证帐号
        mLlCheckCardId = (LinearLayout) findViewById(R.id.ll_check_cardID);
        //整体收款银行
        mLlAcceptBankInfo = (LinearLayout) findViewById(R.id.ll_accepet_bankInfo);
        //提醒用户核对银行卡信息
        mNoticeUserCheck = (TextView) findViewById(R.id.tv_notice_check_bankinfo);
        //收款用户名
        mEtAcceptName = (EditText) findViewById(R.id.et_accept_income_name);
        //收款帐号
        mEtAcceptCardId = (EditText) findViewById(R.id.et_accept_income_cardid);
        //验证帐号
        mEtCheckCardId = (EditText) findViewById(R.id.et_chack_cardid);
        //收款银行名称
        mBankName = (TextView) findViewById(R.id.bank_name);
        //修改收款银行信息
        mEditBankCardInfo = (TextView) findViewById(R.id.edit_income_bankcard_info);

        //责任申明提醒
        mLlDeclareNotice = (LinearLayout) findViewById(R.id.ll_declare_notice);
        //责任申明同意
        mRbBtn = (CheckBox) findViewById(R.id.redio_btn_accept_declare);
        //提现
        mDrawCash = (TextView) findViewById(R.id.btn_withdraw_cash);
        //顶部显示财富值
        if(mFlag.equals("calculate")){

          int  wealthNumb = getIntent().getIntExtra(YNCommonConfig.CMD_GIFT, 0);
            mWealthNumb=""+wealthNumb;
            mWealtnNumbTv.setText( mWealthNumb);
            mToCashNumb.setText(""+(wealthNumb /10));
        }

        switch (mFlag) {
            case "calculate":
                handler.post(new Runnable() {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance()
                                     .getCalculateWealthInfo(WithdrawCashActivity.this,
                                                             YNCommonConfig.GET_CALCULATE_INCOMING_URL,
                                                             AccountUtils.getAccountBean().getId(),
                                                             mWealthNumb,
                                                             handler,
                                                             YNCommonConfig.GET_CALCULATE_INCOME_FLAG,
                                                             true);
                    }
                });
            break;

            case "add":
                mEditBankCardInfo.setVisibility(View.GONE);
                mAddBankInfo.setVisibility(View.GONE);
                mSaveBankInfo.setVisibility(View.VISIBLE);
                mNoticeUserCheck.setVisibility(View.GONE);
                mLlAcceptName.setVisibility(View.VISIBLE);
                mLlAcceptCardId.setVisibility(View.VISIBLE);
                mLlCheckCardId.setVisibility(View.VISIBLE);
                mLlAcceptBankInfo.setVisibility(View.VISIBLE);
                mLlDeclareNotice.setVisibility(View.VISIBLE);
                mWealthNumb= getIntent().getStringExtra(YNCommonConfig.CMD_GIFT);
                mWealtnNumbTv.setText( mWealthNumb);
                mToCashNumb.setText(""+(Integer.parseInt(mWealthNumb) /10));
            case "edit":
                mRlAddBankInfo.setVisibility(View.VISIBLE);
                mEditBankCardInfo.setVisibility(View.GONE);
                mAddBankInfo.setVisibility(View.GONE);
                mSaveBankInfo.setVisibility(View.VISIBLE);
                mNoticeUserCheck.setVisibility(View.GONE);
                mLlAcceptName.setVisibility(View.VISIBLE);
                mLlAcceptCardId.setVisibility(View.VISIBLE);
                mLlCheckCardId.setVisibility(View.VISIBLE);
                mLlAcceptBankInfo.setVisibility(View.VISIBLE);
                mLlDeclareNotice.setVisibility(View.VISIBLE);
                //设置提现不可点
                mDrawCash.setClickable(false);
                mWealthNumb= getIntent().getStringExtra(YNCommonConfig.CMD_GIFT);
                mWealtnNumbTv.setText( mWealthNumb);
                mToCashNumb.setText(""+(Integer.parseInt(mWealthNumb) /10));
                break;
        }

    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        //添加按钮
        mAddBankInfo.setOnClickListener(this);
        //保存按钮
        mSaveBankInfo.setOnClickListener(this);

        mEditBankCardInfo.setOnClickListener(this);
        //从结算过来的才可点击
        if(mFlag.equals("calculate")) {
            mDrawCash.setOnClickListener(this);
        }
        //是否点击同意协议
        mRbBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    isAgree=true;

                    mDrawCash.setBackgroundResource(R.drawable.quit_btn_bg);
                }else{
                    isAgree=false;
                    mDrawCash.setBackgroundResource(R.drawable.corners_wealth_gray);
                }
            }
        });

        //银行卡号
        mEtAcceptCardId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
            @Override
            public void afterTextChanged(Editable s) {
                mAccepBankCardId=s.toString().trim();
                BankInfoBean bankInfoBean=new BankInfoBean(mAccepBankCardId);
                mBankName.setText(bankInfoBean.getBankName());

            }
        });


    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            //添加银行卡
            case R.id.add_bankCard_info:
                mIntent = new Intent(WithdrawCashActivity.this, WithdrawCashActivity.class);
                mIntent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG, "add");
                mIntent.putExtra(YNCommonConfig.CMD_GIFT, mWealthNumb);
                startActivity(mIntent);
                break;
            //保存银行卡
            case R.id.save_bankCard_info:
              //不为空,收款帐号和验证帐号要一致
                if(TextUtils.isEmpty(mEtAcceptName.getText().toString())){
                    Toast.makeText(context, "请输入收款姓名", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }
                if(TextUtils.isEmpty(mEtAcceptCardId.getText().toString().trim())||TextUtils.isEmpty(mEtCheckCardId.getText().toString().trim())){
                    Toast.makeText(context, "请输入收款帐号并确认", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }

                if(!mEtAcceptCardId.getText().toString().equals(mEtCheckCardId.getText().toString())){
                    Toast.makeText(context, "请核对您的收款帐号", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }
                if(mBankName.getText().toString().trim().equals("未知")||mBankName.getText().toString().trim()==null){
                    Toast.makeText(context, "请输入正确收款帐号", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }
                if(isAgree){
                    //发送短信验证  todo
                    mRandomNumber = YNCommonUtils.getRandomNumber();
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userGetWebChineseSMSCode(WithdrawCashActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, AccountUtils.getAccountBean().getPhone(),
                                                                                 mRandomNumber, handler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                        }
                    });

                    showSMSDialog();
                    StartCountTime();
                    mPhoneNumbNotice.setText("已向手机号"+AccountUtils.getAccountBean().getPhone()+"发送验证码");

                    mSureBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //校验验证码
                            if(mCheckMa.getText().toString().trim()==null){
                                Toast.makeText(WithdrawCashActivity.this, "请输入验证码", Toast.LENGTH_SHORT)
                                     .show();
                                return;

                            }
                        if(mCheckMa.getText().toString().trim()!=null&&mRandomNumber.equals(mCheckMa.getText().toString().trim())){

                            //匹配的话发起保存请求保存,对话框消失
                             mDialog.dismiss();
                            //php后台加密处理方式//
                            try {
                                PublicKey publicKey = YNRSAUtil.loadPublicKey(YNCommonConfig.MPUBLIC_KRY);
                                Cipher    cipher    = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                                cipher.init(Cipher.ENCRYPT_MODE, publicKey);
                                byte plaintext[] = mEtAcceptCardId.getText().toString().trim().getBytes("UTF-8");
                                byte[] output = cipher.doFinal(plaintext);

                                mMcardid = new String(Base64.encode(output, Base64.DEFAULT));
                            } catch (Exception e) {

                            }
                            //提交信息 首次提交银行卡信息
                            if(mFlag.equals("add")) {
                                handler.post(new Runnable() {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance()
                                                     .saveBankCardInfo(WithdrawCashActivity.this,
                                                                       YNCommonConfig.GET_SAVE_BANKCARD_INFO_URL,
                                                                       AccountUtils.getAccountBean()
                                                                                   .getId(),
                                                                       mEtAcceptName.getText()
                                                                                    .toString()
                                                                                    .trim(),
                                                                       mMcardid,
                                                                       mBankName.getText()
                                                                                .toString()
                                                                                .trim(),
                                                                       handler,
                                                                       YNCommonConfig.GET_SAVE_BANKID_FLAG,
                                                                       true);
                                    }
                                });
                                //修改银行卡信息
                            }else{
                                handler.post(new Runnable() {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance()
                                                     .editBankCardInfo(WithdrawCashActivity.this,
                                                                       YNCommonConfig.GET_EDIT_BANKCARD_INFO_URL,
                                                                       AccountUtils.getAccountBean()
                                                                                   .getId(),
                                                                       mEtAcceptName.getText()
                                                                                    .toString()
                                                                                    .trim(),
                                                                       mMcardid,
                                                                       mBankName.getText()
                                                                                .toString()
                                                                                .trim(),
                                                                       handler,
                                                                       YNCommonConfig.GET_EDIT_BANKID_FLAG,
                                                                       true);
                                    }
                                });

                            }

                        }else{
                            //不匹配的话提醒用户
                            Toast.makeText(WithdrawCashActivity.this, "请输入正确验证码", Toast.LENGTH_SHORT)
                                 .show();
                            return;
                        }

                        }
                    });
                    mCancleBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();
                        }
                    });
                /*//加密传输
                    *//*php后台加密处理方式*//*
                    try {
                        PublicKey publicKey = YNRSAUtil.loadPublicKey(mPublicKey);
                        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
                        byte plaintext[] = mEtAcceptCardId.getText().toString().trim().getBytes("UTF-8");
                        byte[] output = cipher.doFinal(plaintext);

                        mMcardid = new String(Base64.encode(output, Base64.DEFAULT));
                    } catch (Exception e) {

                    }
                    //提交信息 首次提交银行卡信息
                    if(mFlag.equals("add")) {
                        handler.post(new Runnable() {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance()
                                             .saveBankCardInfo(WithdrawCashActivity.this,
                                                               YNCommonConfig.GET_SAVE_BANKCARD_INFO_URL,
                                                               AccountUtils.getAccountBean()
                                                                           .getId(),
                                                               mEtAcceptName.getText()
                                                                            .toString()
                                                                            .trim(),
                                                               mMcardid,
                                                               mBankName.getText()
                                                                        .toString()
                                                                        .trim(),
                                                               handler,
                                                               YNCommonConfig.GET_SAVE_BANKID_FLAG,
                                                               true);
                            }
                        });
                        //修改银行卡信息
                    }else{
                        handler.post(new Runnable() {
                            @Override
                            public void run()
                            {
                                UserHttpUtils.newInstance()
                                             .editBankCardInfo(WithdrawCashActivity.this,
                                                               YNCommonConfig.GET_EDIT_BANKCARD_INFO_URL,
                                                               AccountUtils.getAccountBean()
                                                                           .getId(),
                                                               mEtAcceptName.getText()
                                                                            .toString()
                                                                            .trim(),
                                                               mMcardid,
                                                               mBankName.getText()
                                                                        .toString()
                                                                        .trim(),
                                                               handler,
                                                               YNCommonConfig.GET_EDIT_BANKID_FLAG,
                                                               true);
                            }
                        });

                    }*/
                }else {
                    Toast.makeText(context, "请填写收款信息并核对", Toast.LENGTH_SHORT)
                         .show();
                }
                break;
            //修改银行卡
            case R.id.edit_income_bankcard_info:
                mIntent = new Intent(WithdrawCashActivity.this, WithdrawCashActivity.class);
                mIntent.putExtra(YNCommonConfig.Artical_EXCITING_FLAG, "edit");
                mIntent.putExtra(YNCommonConfig.CMD_GIFT, mWealthNumb);
                startActivity(mIntent);
                break;
            //提现
            case R.id.btn_withdraw_cash:
                //不为空
                if(isAgree) {
                    if (TextUtils.isEmpty(mEtAcceptName.getText()
                                                       .toString()))
                    {
                        Toast.makeText(context, "请输入收款姓名", Toast.LENGTH_SHORT)
                             .show();
                        return;
                    }
                    //直接进来就提现，还是点击修改进去提现
                    if (TextUtils.isEmpty(mEtAcceptCardId.getText()
                                                         .toString()
                                                         .trim()))
                    {
                        Toast.makeText(context, "请输入收款帐号并确认", Toast.LENGTH_SHORT)
                             .show();
                        return;
                    }

                    if (mBankName.getText()
                                 .toString()
                                 .trim()
                                 .equals("未知") || mBankName.getText().toString().trim() == null)
                    {
                        Toast.makeText(context, "请输入正确收款帐号", Toast.LENGTH_SHORT)
                             .show();
                        return;
                    }

                    //短信验证  todo
                    mRandomNumber = YNCommonUtils.getRandomNumber();
                    handler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userGetWebChineseSMSCode(WithdrawCashActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, AccountUtils.getAccountBean().getPhone(),
                                                                                 mRandomNumber, handler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                        }
                    });
                    showSMSDialog();
                    StartCountTime();
                    mPhoneNumbNotice.setText("已向手机号"+AccountUtils.getAccountBean().getPhone()+"发送验证码");
                    mSureBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                       //先匹配验证码   匹配的话发起提现请求,同时对话框消失
                            if(mCheckMa.getText().toString().trim()==null){
                                Toast.makeText(WithdrawCashActivity.this, "请输入验证码", Toast.LENGTH_SHORT)
                                     .show();
                                return;

                            }
                            if(mRandomNumber.equals(mCheckMa.getText().toString().trim())) {
                                //
                                try {
                                    PublicKey publicKey = YNRSAUtil.loadPublicKey(YNCommonConfig.MPUBLIC_KRY);
                                    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                                    cipher.init(Cipher.ENCRYPT_MODE, publicKey);
                                    byte plaintext[] = mEtAcceptCardId.getText().toString().trim().getBytes("UTF-8");
                                    byte[] output = cipher.doFinal(plaintext);
                                    mMcardid = new String(Base64.encode(output, Base64.DEFAULT));
                                } catch (Exception e) {

                                }
                                handler.post(new Runnable() {
                                    @Override
                                    public void run()
                                    {
                                        UserHttpUtils.newInstance()
                                                     .tiXian(WithdrawCashActivity.this,
                                                             YNCommonConfig.GET_TI_XIAN_URL,
                                                             ""+( Integer.parseInt(mWealthNumb)/10),
                                                             mWealthNumb,
                                                             AccountUtils.getAccountBean()
                                                                         .getId(),
                                                             mEtAcceptName.getText()
                                                                          .toString()
                                                                          .trim(),
                                                             mMcardid,
                                                             mBankName.getText()
                                                                      .toString()
                                                                      .trim(),
                                                             handler,
                                                             YNCommonConfig.GET_TI_XIAN_FLAG,
                                                             true);
                                    }
                                });


                                mDialog.dismiss();
                            }else{
                                //不匹配的话提醒用户
                                Toast.makeText(WithdrawCashActivity.this, "请输入正确验证码", Toast.LENGTH_SHORT)
                                     .show();
                                return;
                            }

                        }
                    });
                    mCancleBtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();
                        }
                    });
                    //RSA加密传输
                    /*php后台加密处理方式*/

                   /* try {
                        PublicKey publicKey = YNRSAUtil.loadPublicKey(mPublicKey);
                        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
                        byte plaintext[] = mEtAcceptCardId.getText().toString().trim().getBytes("UTF-8");
                        byte[] output = cipher.doFinal(plaintext);
                        mMcardid = new String(Base64.encode(output, Base64.DEFAULT));

                    } catch (Exception e) {

                    }
                    handler.post(new Runnable() {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance()
                                         .tiXian(WithdrawCashActivity.this,
                                                 YNCommonConfig.GET_TI_XIAN_URL,
                                                ""+( Integer.parseInt(mWealthNumb)/10),
                                                 mWealthNumb,
                                                 AccountUtils.getAccountBean()
                                                             .getId(),
                                                 mEtAcceptName.getText()
                                                              .toString()
                                                              .trim(),
                                                 mMcardid,
                                                 mBankName.getText()
                                                          .toString()
                                                          .trim(),
                                                 handler,
                                                 YNCommonConfig.GET_TI_XIAN_FLAG,
                                                 true);
                        }
                    });*/
                }else {
                    Toast.makeText(context, "请填写收款信息并核对", Toast.LENGTH_SHORT)
                         .show();
                }

                break;

        }
    }

    private void showSMSDialog() {
        View inflate = View.inflate(WithdrawCashActivity.this,R.layout.check_ma_dialog, null);
        mDialog = new Dialog(this, R.style.ActionSheetDialogStyle);
        mPhoneNumbNotice = (TextView) inflate.findViewById(R.id.notice_phone_numb);
        mRegetCheckMa = (TextView) inflate.findViewById(R.id.reget_check_ma);


        mCheckMa = (EditText) inflate.findViewById(R.id.write_check_ma);
        mSureBtn = (Button) inflate.findViewById(R.id.dialog_sure_leftbtn);
        mCancleBtn = (Button) inflate.findViewById(R.id.dialog_cancle_rightbtn);

        mDialog.setContentView(inflate);
        WindowManager windowManager = getWindowManager();
        Display                    display       = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams    mLp = mDialog.getWindow().getAttributes();
        mLp.width = (int)(display.getWidth()*0.65); //设置宽度
        mLp.height = (int)(display.getHeight()*0.3);
        mLp.gravity=(Gravity.CENTER);
        mDialog.getWindow().setAttributes(mLp);
        mDialog.setCanceledOnTouchOutside(false);
        mDialog.show();


    }
    private void StartCountTime() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                for (int i = 60; i >=0; i--)
                {
                    handler.sendEmptyMessage(YNCommonConfig.CODE_ING);
                    if (i <=0)
                    {
                        handler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
                        break;

                    }
                    try
                    {
                        Thread.sleep(1000);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }
}

