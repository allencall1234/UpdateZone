package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 手机绑定界面
 * Created by Administrator on 2017/7/17.
 */
public class YNBindPhoneActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private EditText mETPhone;
    private TextView mTVGetCode;
    private EditText mETCode;
    private EditText mETPassWord;
    private TextView mTVFinish;

    private int time = 60;
    private String userPhone;
    private String randomNumber;
    private String resultCode;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.CODE_ING:
                    mTVGetCode.setClickable(false);
                    mTVGetCode.setText(time + "秒");
                    time--;
                    break;

                case YNCommonConfig.CODE_REPEAT:
                    mTVGetCode.setText("重新发送");
                    mTVGetCode.setClickable(true);
                    break;

                case YNCommonConfig.BIND_PHONE_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNToastMaster.showToast(YNBindPhoneActivity.this, baseBean.getInfo());
                        if (baseBean.getCode() == 160)
                        {
                           AccountUtils.getAccountBean().setPhone(userPhone);
                           finish();
                        }
                    }
                    break;

                case YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG:
                    if (msg.obj != null)
                    {
                        resultCode = msg.obj.toString();
                        if ("1".equals(resultCode))
                        {
                           YNToastMaster.showToast(YNBindPhoneActivity.this, "验证码已下发到您的手机，请注意查收");
                        }
                        else
                        {
                            YNToastMaster.showToast(YNBindPhoneActivity.this, "验证码发送失败，请重新发送");
                        }
                    }
                    else
                    {
                        YNToastMaster.showToast(YNBindPhoneActivity.this, "验证码发送失败，请重新发送");
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_phone);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.bind_phone));

        mETPhone = (EditText) findViewById(R.id.et_phone);
        mTVGetCode = (TextView) findViewById(R.id.tv_get_code);
        mETCode = (EditText) findViewById(R.id.et_code);
        mETPassWord = (EditText) findViewById(R.id.et_password);
        mTVFinish = (TextView) findViewById(R.id.tv_finish);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mTVGetCode.setOnClickListener(this);
        mTVFinish.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        super.settingDo();
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken()
                        ,InputMethodManager.HIDE_NOT_ALWAYS);
                finish();
                break;

            case R.id.tv_get_code:
                if (TextUtils.isEmpty(mETPhone.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "电话号码不能为空", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!YNCommonUtils.isCellPhone(mETPhone.getText().toString()))
                {
                    YNToastMaster.showToast(this, "电话号码格式有误", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                userPhone = mETPhone.getText().toString();
                randomNumber = YNCommonUtils.getRandomSixNumber();
                // 获取验证码
                mHandler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().userGetWebChineseSMSCode(YNBindPhoneActivity.this, YNCommonConfig.GET_SMS_CODE_URL, YNCommonConfig.WEB_CHINESE_UID, YNCommonConfig.WEB_CHINESE_KEY, userPhone, "验证码:" + randomNumber + "，你正在进行设置激活业内直播账号的手机号，此验证码10分钟内有效", mHandler, YNCommonConfig.GET_WEB_CHINESE_SMS_CODE_FLAG, false);
                    }
                }, 500);
                mTVGetCode.setClickable(false);
                time = 60;
                startCountTime();
                break;

            case R.id.tv_finish:
                String code = mETCode.getText().toString().trim();
                if (TextUtils.isEmpty(mETPhone.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "电话号码不能为空", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!YNCommonUtils.isCellPhone(mETPhone.getText().toString()))
                {
                    YNToastMaster.showToast(this, "电话号码格式有误", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(mETCode.getText().toString().trim()))
                {
                    YNToastMaster.showToast(this, "验证码不能为空", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (!randomNumber.equals(code))
                {
                    YNToastMaster.showToast(this, "验证码不匹配", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                if (TextUtils.isEmpty(mETPassWord.getText().toString()))
                {
                    YNToastMaster.showToast(this, "密码不能为空", Toast.LENGTH_SHORT, Gravity.CENTER);
                    return;
                }
                userPhone = mETPhone.getText().toString();
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                       UserHttpUtils.newInstance().bindPhone(YNBindPhoneActivity.this, YNCommonConfig.BIND_PHONE_URL, AccountUtils.getAccountBean().getId(), userPhone, mETPassWord.getText().toString(), mHandler, YNCommonConfig.BIND_PHONE_FLAG, true);
                    }
                });
                break;
        }

    }

    private void startCountTime() {
        new Thread() {
            @Override
            public void run() {

                super.run();
                for (int i = 60; i > 0; i--)
                {
                    mHandler.sendEmptyMessage(YNCommonConfig.CODE_ING);
                    if (i <= 0)
                    {
                        break;
                    }
                    try
                    {
                        Thread.sleep(1000);
                        mHandler.sendEmptyMessage(YNCommonConfig.CODE_REPEAT);
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }
}
