package com.yeneikeji.ynzhibo.adapter;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.model.CoinMoneyBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WangChang on 2016/4/1.
 */
public class GoldCoinRecyclerViewAdapter extends RecyclerView.Adapter<GoldCoinRecyclerViewAdapter.BaseViewHolder>
{
    private List<CoinMoneyBean> dataList = new ArrayList<>();
    public int lastPressIndex = -1;
    private TextView mPaymentTotalTV;
    private EditText mInputnumb;

    private int coinMoney;


    public GoldCoinRecyclerViewAdapter(TextView mPaymentTotalTV, EditText inputnumb)
    {
        this.mPaymentTotalTV = mPaymentTotalTV;
        this.mInputnumb=inputnumb;
    }

    @Override
    public GoidCoinViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.gold_coin_item, parent, false);
      //  AutoUtils.auto(view);
        return new GoidCoinViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return dataList != null ? dataList.size() : 0;
    }

    public void replaceAll(List<CoinMoneyBean> list) {
        dataList.clear();
        if (list != null && list.size() > 0) {
            dataList.addAll(list);
        }
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(final BaseViewHolder holder, int position)
    {
        holder.setData(dataList.get(position));
    }

    public class BaseViewHolder extends RecyclerView.ViewHolder {

        public BaseViewHolder(View itemView) {
            super(itemView);
        }

        void setData(CoinMoneyBean data) {
        }
    }

    private class GoidCoinViewHolder extends BaseViewHolder
    {
        private LinearLayout ll_gold_coin;
        private TextView tv_gold_num;
        private TextView tv_coin_money;

        public GoidCoinViewHolder(View view)
        {
            super(view);
            ll_gold_coin = (LinearLayout) view.findViewById(R.id.ll_gold_coin);
            tv_gold_num = (TextView) view.findViewById(R.id.tv_gold_num);
            tv_coin_money = (TextView) view.findViewById(R.id.tv_coin_money);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (lastPressIndex == position)
                    {
                        lastPressIndex = -1;
                        //总的充值金额不显示
                        mPaymentTotalTV.setText(null);

                        //上面固定充值金额没有选中时editext上内容要清空
                        mInputnumb.setText(null);
                    }
                    else
                    {
                        lastPressIndex = position;
                        //上面固定充值金额选中时editext上内容要清空
                        mInputnumb.setText(null);
                    }
                    notifyDataSetChanged();
                }
            });
        }

        @Override
        void setData(CoinMoneyBean data)
        {
            if (data != null)
            {
                tv_gold_num.setText(data.getGoldNum() + "金币");
                tv_coin_money.setText("¥"+data.getCoinMoney() );
                if (getAdapterPosition() == lastPressIndex)
                {
                    ll_gold_coin.setSelected(true);
                    tv_gold_num.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.white));
                    tv_coin_money.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.white));

                    mPaymentTotalTV.setText("立即充值"+data.getGoldNum() + "金币");
                    //充值金币数量
                    coinMoney=data.getGoldNum();
                }
                else
                {
                    ll_gold_coin.setSelected(false);
                    tv_gold_num.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.ynkj_black));
                    tv_coin_money.setTextColor(ContextCompat.getColor(itemView.getContext(), R.color.ynkj_black));

                }
            }
        }
    }

    public int getCoinMoney()
    {
        return coinMoney;
    }

}
