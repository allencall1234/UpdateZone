package com.yeneikeji.ynzhibo.view.mine;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 协议展示界面
 * Created by Administrator on 2016/11/14.
 */
public class AgreementActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private ProgressBar mProgressBar;
    private WebView mAgreementWB;
    private String agreeTitle;// 协议标题

    private boolean flag;
    private TextView txtRead;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agreement);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        // agreeTitle = getIntent().getStringExtra(YNCommonConfig.AGREEMENT);
        flag = getIntent().getBooleanExtra(YNCommonConfig.AGREEMENT, flag);
        configTopBarCtrollerWithTitle(flag == true ? "用户注册协议" : "业内申请主播协议");

        mProgressBar = (ProgressBar) findViewById(R.id.pb_regisger_protocol);
        mAgreementWB = (WebView) findViewById(R.id.wb_regisger_protocol);
        txtRead = (TextView) findViewById(R.id.txtRead);
    }

    @Override
    protected void addEvent() {
        getLeftBtn().setOnClickListener(this);
        txtRead.setOnClickListener(this);
    }

    @Override
    protected void settingDo() {
        mAgreementWB.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                // 当加载到100%的时候 进度条自动消失
                mProgressBar.setProgress(newProgress);
                mProgressBar.postInvalidate();
                if (newProgress == 100) {
                    mProgressBar.setVisibility(View.GONE);
                }
            }
        });

        // 覆盖WebView默认使用第三方或系统默认浏览器打开网页的行为，使网页用WebView打开
        mAgreementWB.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
                view.loadUrl(url);
                return true;
            }
        });

        // 根据传递过来的标题判断协议显示内容
        if (flag)
        {
//            mAgreementWB.loadUrl("http://www.yeneilive.cn/test/user_agreement.html\n");
            mAgreementWB.loadUrl(YNCommonConfig.USER_REGISTER_URL);
        }
        else
        {
//            mAgreementWB.loadUrl("http://www.yeneilive.cn/test/anchor_agreemen.html\n");
            mAgreementWB.loadUrl(YNCommonConfig.USER_LIVE_AGREEMENT_URL);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;
            case R.id.txtRead:
                if(flag){
                    finish();
                } else {
                    Intent intent = new Intent(this, YNRealNameActivity.class);
                    startActivity(intent);
                    finish();
                }
                break;
        }

    }
}
