package com.yeneikeji.ynzhibo.view.mine;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;
import com.yeneikeji.ynzhibo.widget.weelwight.CenterTextView;

import java.util.HashMap;

public class MySubscribleActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private ImageView mBackIv;
    private TextView mTvManager;
    private boolean mIsshow;
    private LinearLayout mBottomLl;
    private TextView mSelectAll;
    private TextView mDelete;
    private SmoothListView mListview;
    private MyAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_subscrible);
        initView();
       // addEvent();
        //settingDo();
    }
    @Override
    protected void initView() {
        mBackIv = (ImageView) findViewById(R.id.top_head_iv);
        mTvManager = (TextView) findViewById(R.id.my_subscrible_manager_tv);
        mListview = (SmoothListView) findViewById(R.id.my_subscrible_listview);
        mBottomLl = (LinearLayout) findViewById(R.id.bottom_ll_menu);
        mSelectAll = (TextView) findViewById(R.id.tv_select_all);
        mDelete = (TextView) findViewById(R.id.tv_delete);
    }

    @Override
    protected void addEvent() {
        mListview.setDivider(null);
        mBackIv.setOnClickListener(this);
        mTvManager.setOnClickListener(this);
        mSelectAll.setOnClickListener(this);
        mDelete.setOnClickListener(this);
        mListview.setLoadMoreEnable(false);
    }

    @Override
    protected void settingDo() {
        mAdapter = new MyAdapter();
        mListview.setAdapter(mAdapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_head_iv:
                finish();
                break;
            case R.id.my_subscrible_manager_tv :
                mIsshow=!mIsshow;
                if(mIsshow){
                    mTvManager.setText("完成");
                    mBottomLl.setVisibility(View.VISIBLE);

                }else{
                    mTvManager.setText("管理");
                    mBottomLl.setVisibility(View.GONE);
                }
            break;
            case R.id.tv_select_all:
                break;

            case R.id.tv_delete:
                break;
        }
    }
    class MyAdapter extends BaseAdapter{
        private  HashMap<Integer, Boolean> isSelected;

        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder=null;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(MySubscribleActivity.this,R.layout.findfinancial_listview_item03, null);
                holder.checkBox= (CheckBox) convertView.findViewById(R.id.checkBox);
                holder.rightRl= (RelativeLayout) convertView.findViewById(R. id.rigth_relativell);
                holder.leftPicture= (ImageView) convertView.findViewById(R.id.find_financial_listview_leftIvItem);
                holder.author= (CenterTextView) convertView.findViewById(R.id.author);
                holder.contentTop= (TextView) convertView.findViewById(R.id.find_financial_listview_content);
                holder.contentMiddle= (TextView) convertView.findViewById(R.id.middle_content);
                holder.publishTime= (TextView) convertView.findViewById(R.id.publish_time);
                holder.readPeople= (TextView) convertView.findViewById(R.id.hao_many_people_readed);
                holder.paycoin= (TextView) convertView.findViewById(R.id.paycoin);
                view.setTag(holder);
            } else {
                holder = (ViewHolder) view.getTag();
            }
            if(mIsshow){
                holder.checkBox.setVisibility(View.VISIBLE);
            }else{
                holder.checkBox.setVisibility(View.GONE);
            }


          return convertView;
        }
        private class ViewHolder
        {
            private CheckBox checkBox;
            private RelativeLayout rightRl;
            private ImageView      leftPicture;
            private TextView       contentTop;
            private TextView       contentMiddle;
            private CenterTextView author;
            private TextView       publishTime;
            private TextView       readPeople;
            private TextView       paycoin;
        }
    }
}
