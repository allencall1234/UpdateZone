package com.yeneikeji.ynzhibo.view.community;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.model.DynamicBean;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import java.util.ArrayList;
import java.util.List;

/**
 *  私信界面
 * Created by Administrator on 2016/11/28.
 */
public class PrivateMessageActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private SmoothListView mPrivateMsgLV;
    private RelativeLayout mEmptyRL;
    private TextView mDynamicTV;

    private BaseAdapter mAdapter;
    private List<DynamicBean> myCommentList;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comment);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.private_letter));
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.edit));

        mPrivateMsgLV = (SmoothListView) findViewById(R.id.lv_mycomment);
        mEmptyRL = (RelativeLayout) findViewById(R.id.mycomment_empty);
        mDynamicTV = (TextView) mEmptyRL.findViewById(R.id.tv_dynamic_count);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        mAdapter = new CommonAdapter<DynamicBean>(this, getMyCommentList(), R.layout.private_msg_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, DynamicBean item)
            {

            }
        };

        mPrivateMsgLV.setAdapter(mAdapter);

    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.star_1_com_topbar_tv_right:
                break;
        }

    }

    private List<DynamicBean> getMyCommentList()
    {
        myCommentList = new ArrayList<>();
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());
        myCommentList.add(new DynamicBean());

        return myCommentList;
    }
}
