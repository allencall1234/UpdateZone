package com.yeneikeji.ynzhibo.widget.weelwight;

public interface OnWheelChangedListener {
	void onChanged(WheelView wheel, int oldValue, int newValue);
}
