package com.yeneikeji.ynzhibo.view.mine.multichannel;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.CommonAdapter;
import com.yeneikeji.ynzhibo.adapter.CommonViewHolder;
import com.yeneikeji.ynzhibo.common.YNGridView;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.utils.DataUtils;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 多通道直播界面(主房主界面)
 * Created by Administrator on 2017/7/28.
 */
public class MultichannelLiveActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private LinearLayout mLLMultichannelLiveHead;
    private LinearLayout mLLMainRoom, mLLSubRoom, mLLStatistics;
    private TextView mFirstTitle, mSecondTitle, mThreeTitle;
    private ImageView mFirstImg, mSecondImg, mThreeImg;
    private YNGridView mGVMultichannelLive;

    private CommonAdapter mMultichannelLiveAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichannel_live);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.multichannel_live_title));
        mLLMultichannelLiveHead = (LinearLayout) findViewById(R.id.ll_multichannel_live_head);
        mLLMainRoom = (LinearLayout) mLLMultichannelLiveHead.findViewById(R.id.stock_market_interpret);
        mLLSubRoom = (LinearLayout) mLLMultichannelLiveHead.findViewById(R.id.stock_market_bigShot);
        mLLStatistics = (LinearLayout) mLLMultichannelLiveHead.findViewById(R.id.stock_market_voicePoint);
        mFirstTitle = (TextView) mLLMultichannelLiveHead.findViewById(R.id.author);
        mSecondTitle = (TextView) mLLMultichannelLiveHead.findViewById(R.id.tv_second_title);
        mThreeTitle = (TextView) mLLMultichannelLiveHead.findViewById(R.id.tv_three_title);
        mFirstImg = (ImageView) mLLMultichannelLiveHead.findViewById(R.id.find_financial_listview_leftIvItem);
        mSecondImg = (ImageView) mLLMultichannelLiveHead.findViewById(R.id.iv_second_img);
        mThreeImg = (ImageView) mLLMultichannelLiveHead.findViewById(R.id.iv_three_img);

        mGVMultichannelLive = (YNGridView) findViewById(R.id.gv_multichannel_live);

        mFirstTitle.setText("主房间");
        mSecondTitle.setText("子房间");
        mThreeTitle.setText("统计");
        mFirstImg.setImageResource(R.drawable.icon_room_zhu);
        mSecondImg.setImageResource(R.drawable.icon_room_zi);
        mThreeImg.setImageResource(R.drawable.icon_room_tongji);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mLLMainRoom.setOnClickListener(this);
        mLLSubRoom.setOnClickListener(this);
        mLLStatistics.setOnClickListener(this);

    }

    @Override
    protected void settingDo()
    {
        mMultichannelLiveAdapter = new CommonAdapter<GiftBean>(this, DataUtils.getMultiChannelServiceList(), R.layout.multichannel_live_gv_item)
        {
            @Override
            public void convert(CommonViewHolder viewHolder, GiftBean item)
            {
                viewHolder.setImageResource(R.id.iv_multichannel_live, item.getGiftId());
                viewHolder.setText(R.id.tv_multichannel_live, item.getGiftCode());
            }
        };

        mGVMultichannelLive.setAdapter(mMultichannelLiveAdapter);

       /* mGVMultichannelLive.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                Intent intent = new Intent();
                if (position == 0)
                {
//                    intent.setClass(MultichannelLiveActivity.this, MyLiveVideoActivity.class);
                }
                else
                {
                    intent.setClass(MultichannelLiveActivity.this, MyLiveVideoActivity.class);
                }
                startActivity(intent);
            }
        });*/
    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            // 主房间
            case R.id.stock_market_interpret:
                // 进入主房间
                intent.setClass(this, MultichannelRoomManageActivity.class);
                intent.putExtra(YNCommonConfig.TITLE, true);
                startActivity(intent);
                break;

            // 子房间
            case R.id.stock_market_bigShot:
                intent.setClass(this, SubRoomListActivity.class);
                startActivity(intent);
                break;
            // 统计
            case R.id.stock_market_voicePoint:
                intent.setClass(this, MultichannelRoomMemberActivity.class);
                intent.putExtra(YNCommonConfig.TITLE,false);
                startActivity(intent);
                break;
        }
    }
}
