package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNCircleImageView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.listener.SimpleSwipeListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.mine.YNHeartFansActivity;
import com.yeneikeji.ynzhibo.widget.SwipeLayout;

import java.util.List;

/**
 * 粉丝、关注适配器(实现左滑删除效果)
 * Created by Administrator on 2017/6/21.
 */
public class HeartFansAdapter extends BaseSwipeAdapter
{
    private Context mContext;
    private List<LiveRoomBean> mHeartFansList;
    private int index;
    private boolean isOpen;

    private Handler mHandler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.CANCEL_ATTENTION_USER_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 13)
                        {
                            mHeartFansList.remove(mHeartFansList.get(index));
                            updateListView(mHeartFansList);
                        }

                        YNToastMaster.showToast(mContext, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(mContext, mContext.getResources().getString(R.string.request_fail));

                    }
                    break;
            }
            super.handleMessage(msg);
        }
    };

    public HeartFansAdapter(Context mContext, List<LiveRoomBean> mHeartFansList)
    {
        this.mContext = mContext;
        this.mHeartFansList = mHeartFansList;
    }

    public void updateListView(List<LiveRoomBean> mList)
    {
        mHeartFansList = mList;
        notifyDataSetChanged();
    }

    @Override
    public int getSwipeLayoutResourceId(int position)
    {
        return R.id.swipe;
    }

    @Override
    public View generateView(int position, ViewGroup parent)
    {
        index = position;
        final LiveRoomBean liveRoom = mHeartFansList.get(position);
        View view = LayoutInflater.from(mContext).inflate(R.layout.heart_fans_item, parent, false);
//        if (isOpen)
//        {
            final SwipeLayout swipeLayout = (SwipeLayout) view.findViewById(getSwipeLayoutResourceId(position));

            // 当隐藏的删除menu被打开的时候的回调函数
            swipeLayout.addSwipeListener(new SimpleSwipeListener()
            {
                @Override
                public void onOpen(SwipeLayout layout)
                {
//                Toast.makeText(mContext, "Open", Toast.LENGTH_SHORT).show();
                }
            });
            // 双击的回调函数
            swipeLayout.setOnDoubleClickListener(new SwipeLayout.DoubleClickListener() {
                @Override
                public void onDoubleClick(SwipeLayout layout,
                                          boolean surface) {
//                Toast.makeText(mContext, "DoubleClick",
//                        Toast.LENGTH_SHORT).show();
                }
            });
            // 添加删除布局的点击事件
            view.findViewById(R.id.ll_menu).setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View arg0)
                {
//                Toast.makeText(mContext, "delete", Toast.LENGTH_SHORT).show();
                    // 点击完成之后，关闭删除menu
                    mHandler.post(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().cancelAttentionUser(mContext, YNCommonConfig.CANCEL_ATTENTION_USER_URL, liveRoom.getUserid(), liveRoom.getAttentionid(),
                                    mHandler, YNCommonConfig.CANCEL_ATTENTION_USER_FLAG, true);
                        }
                    });
                    swipeLayout.close();
                }
            });
//        }
//        else
//        {
//
//        }
        return view;
    }

    // 对控件的填值操作独立出来了，我们可以在这个方法里面进行item的数据赋值
    @Override
    public void fillValues(int position, View convertView)
    {
        LiveRoomBean liveRoom = mHeartFansList.get(position);
        YNCircleImageView mIVHead = (YNCircleImageView) convertView.findViewById(R.id.iv_head);
        TextView mTVUName = (TextView) convertView.findViewById(R.id.tv_name);
        TextView mTVNoteTitle = (TextView) convertView.findViewById(R.id.tv_title);
        TextView mTVRoomId = (TextView) convertView.findViewById(R.id.tv_room_id);
        TextView mTVUIntroduce = (TextView) convertView.findViewById(R.id.tv_userIntroduce);
        ImageView mIVLivingState = (ImageView) convertView.findViewById(R.id.iv_living_state);

        if (liveRoom.getArticleTitle() == null)
        {
            mTVNoteTitle.setText(liveRoom.getTag());
            mTVRoomId.setVisibility(View.VISIBLE);
            mTVRoomId.setText("房间号: " + liveRoom.getRoom_id());
            mTVUIntroduce.setText(liveRoom.getDescribe());
        }
        else
        {
            mTVNoteTitle.setText(liveRoom.getArticleTitle());
            mTVRoomId.setVisibility(View.GONE);
            mTVUIntroduce.setText(liveRoom.getArticleContent());
        }

        YNImageLoaderUtil.setImage(mContext, mIVHead, liveRoom.getIcon());
        mTVUName.setText(liveRoom.getUsername());

        if (liveRoom.getLiving() == 1)
        {
            mIVLivingState.setVisibility(View.VISIBLE);
            mIVLivingState.setBackgroundResource(R.drawable.icon_guanzhu_live);
//            if (liveRoom.getLive_status() == 2)
//            {
//                mIVLivingState.setBackgroundResource(R.drawable.icon_lable_pay);
//            }
//            if (liveRoom.getLock() == 1)
//            {
//                mIVLivingState.setBackgroundResource(R.drawable.icon_lable_encrypt);
//            }
//            if (liveRoom.getLive_status() != 2 && liveRoom.getLock() != 1)
//            {
//                mIVLivingState.setBackgroundResource(R.drawable.icon_lable_live);
//            }
        }
        else
        {
            mIVLivingState.setVisibility(View.GONE);
//            mIVLivingState.setBackgroundResource(R.drawable.icon_lable_rest);
        }
    }

    @Override
    public int getCount() {
        return mHeartFansList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return mHeartFansList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
