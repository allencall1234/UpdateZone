package com.yeneikeji.ynzhibo.spannable;

/**
 * @author yiw
 * @Description:
 * @date 16/1/2 19:44
 */
public interface ISpanClick {
    public void onClick(int position);
}
