package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 意见反馈界面
 */
public class YNSuggestionActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout mRLErrorNotice;
    private TextView mTVErrorInfo;
    private EditText mETSuggestion, mPhoneNumber;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.FEED_BACK_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 15)
                        {
                            finish();
                        }

                        YNToastMaster.showToast(context, baseBean.getInfo());
                    }
                    else
                    {
                        YNToastMaster.showToast(context, getString(R.string.request_fail));
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_suggestion,null);
      //  AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.suggestion));
        getRightTV().setVisibility(View.VISIBLE);
        getRightTV().setText(getString(R.string.submit));

        mRLErrorNotice = (RelativeLayout) findViewById(R.id.rl_error_notice);
        mTVErrorInfo = (TextView) findViewById(R.id.tv_error_info);
        mETSuggestion = (EditText) findViewById(R.id.et_suggestion);
        mPhoneNumber = (EditText) findViewById(R.id.et_phone_number);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        getRightTV().setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                YNCommonUtils.hideSoftInput(this, view);
                finish();
                break;

            case R.id.star_1_com_topbar_tv_right:
                if (TextUtils.isEmpty(mETSuggestion.getText().toString()))
                {
                    mRLErrorNotice.setVisibility(View.VISIBLE);
                    return;
                }
                if (TextUtils.isEmpty(mPhoneNumber.getText().toString() ) && (!YNCommonUtils.isCellPhone(mPhoneNumber.getText().toString())))
                {
                    mTVErrorInfo.setText("请填写正确电话号码");
                    mRLErrorNotice.setVisibility(View.VISIBLE);
                    return;
                }

                mRLErrorNotice.setVisibility(View.GONE);

                handler.postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().feedBack(context, YNCommonConfig.FEED_BACK_URL, AccountUtils.getAccountBean().getId(),
                                mETSuggestion.getText().toString(), mPhoneNumber.getText().toString(), handler, YNCommonConfig.FEED_BACK_FLAG, false);
                    }
                }, 1000);
                break;
        }
    }
}

