package com.yeneikeji.ynzhibo.model;

/**
 * 评论实体类
 * Created by Administrator on 2017/1/17.
 */
public class CommentBean extends BaseBean
{
    private String id;
    private String cid;
    private String userid;
    private String username;
    private String icon;
    private String content;
    private String time;
    private String callbackId;
    private int zanCount;

    public String getSend_type() {
        return send_type;
    }

    public void setSend_type(String send_type) {
        this.send_type = send_type;
    }

    public String getIs_accept() {
        return is_accept;
    }

    public void setIs_accept(String is_accept) {
        this.is_accept = is_accept;
    }

    public String getIs_read() {
        return is_read;
    }

    public void setIs_read(String is_read) {
        this.is_read = is_read;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    private String      callbackUsername;
    private int         thumb;
//    private List<CommentItemBean> comments;
    private String         isRead;
    private DynamicBean publish_content;

    private String type;
    private String message_type;
    public String send_type;

/*****新加字段，保存系统消息****/
    public String is_accept;
    public String is_read;
    public String uid;
    /*********/
    public CommentBean(String id,
                       String cid,
                       String userid,
                       String username,
                       String icon,
                       String content,
                       String time,
                       String callbackId,
                       String callbackUsername,
                       int zanCount,
                       int thumb,
                       String isRead,
                       DynamicBean publish_content,
                       String type,
                       String message_type,
                       String is_accept,
                       String is_read,
                       String send_type,
                       String uid)
    {
        this.id = id;
        this.cid = cid;
        this.userid = userid;
        this.username = username;
        this.icon = icon;
        this.content = content;
        this.time = time;
        this.callbackId = callbackId;
        this.callbackUsername = callbackUsername;
        this.zanCount = zanCount;
        this.thumb = thumb;
        this.isRead = isRead;
        this.publish_content = publish_content;
        this.type = type;
        this.message_type = message_type;
        this.is_accept = is_accept;
        this.is_read = is_read;
        this.send_type = send_type;
        this.uid = uid;
    }


    /*********/
  /*  public CommentBean(String id, String cid, String userid, String username, String icon, String content, String time, String callbackId, int zanCount,
            String callbackUsername, int thumb, int isRead, String type, String message_type) {
        this.id = id;
        this.cid = cid;
        this.userid = userid;
        this.username = username;
        this.icon = icon;
        this.content = content;
        this.time = time;
        this.callbackId = callbackId;
        this.zanCount = zanCount;
        this.callbackUsername = callbackUsername;
        this.thumb = thumb;
        this.isRead = isRead;
        this.type = type;
        this.message_type = message_type;
    }
*/
    public CommentBean()
    {

    }

    //    public CommentBean(String id, String cid, int callbackId, String username, String icon, String content, String time, List<CommentItemBean> comments)
//    {
//        this.id = id;
//        this.cid = cid;
//        this.callbackId = callbackId;
//        this.username = username;
//        this.icon = icon;
//        this.content = content;
//        this.time = time;
//        this.comments = comments;
//    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getUsername() {
        return username;
    }

    public String getCallbackId() {
        return callbackId;
    }

    public void setCallbackId(String callbackId) {
        this.callbackId = callbackId;
    }

    public String getCallbackUsername() {
        return callbackUsername;
    }

    public void setCallbackUsername(String callbackUsername) {
        this.callbackUsername = callbackUsername;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon)
    {
        this.icon = icon;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public int getZanCount() {
        return zanCount;
    }

    public void setZanCount(int zanCount) {
        this.zanCount = zanCount;
    }

    public int getThumb() {
        return thumb;
    }

    public void setThumb(int thumb) {
        this.thumb = thumb;
    }

//    public List<CommentItemBean> getComments() {
//        return comments;
//    }
//
//    public void setComments(List<CommentItemBean> comments) {
//        this.comments = comments;
//    }

    public DynamicBean getPublish_content() {
        return publish_content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage_type() {
        return message_type;
    }

    public void setMessage_type(String message_type) {
        this.message_type = message_type;
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public void setPublish_content(DynamicBean publish_content)
    {
        this.publish_content = publish_content;
    }

/*
    public boolean hasComment(){
        if(comments != null && comments.size()>0){
            return true;
        }
        return false;
    }*/
}
