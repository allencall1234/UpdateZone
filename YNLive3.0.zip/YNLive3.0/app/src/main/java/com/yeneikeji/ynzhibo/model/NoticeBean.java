package com.yeneikeji.ynzhibo.model;

/**
 * 直播间公告实体类
 * Created by Administrator on 2017/5/26.
 */
public class NoticeBean extends BaseBean
{
    private String id;
    private String room_id;
    private String content;
    private String time;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoom_id() {
        return room_id;
    }

    public void setRoom_id(String room_id) {
        this.room_id = room_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
