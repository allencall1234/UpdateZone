package com.yeneikeji.ynzhibo.view.live;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.adapter.YNListViewAdapter;
import com.yeneikeji.ynzhibo.common.YNBannerView;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.fragment.YNBaseTopBarFragment;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.LiveRoomBean;
import com.yeneikeji.ynzhibo.model.LiveTypeBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.DateUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseActivity;
import com.yeneikeji.ynzhibo.widget.smoothlistView.SmoothListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * 直播推荐界面(金融、家教)
 * Created by Administrator on 2016/8/18.
 */
public class RecommendFragment extends YNBaseTopBarFragment implements View.OnClickListener, AdapterView.OnItemClickListener, SmoothListView.ISmoothListViewListener
{
    private LayoutInflater inflater;
    private Toolbar toolbar;
    private ImageView mSearch;
    private YNBannerView mYNBannerView;
    private RecyclerView mRecyclerView;
    private Activity mActivity;

    private SmoothListView mListView;
    private RelativeLayout mRLEmpty;
    private ImageView mIVEmpty;
    private TextView mTVEmpty;
    private TextView mTVRefreshNet;

    private YNListViewAdapter mLiveAdapter;

    public static final String TAG = "RecommendFragment";

//    private String[] bannerImages;
    private Integer[] bannerImgs;

    private List<LiveTypeBean> liveTypeList = new ArrayList<>();
    private List<LiveRoomBean> financeList;
    private List<LiveRoomBean> teachList;

    private int currentPage = -1;
    private String userId;
    private int liveListType = 0;

    private GestureDetector gestureDetector;

    private boolean isFirst = true;

    @Override
    public String getFragmentName()
    {
        return TAG;
    }

    @Override
    public void loginRefreshUI() {

    }

    @Override
    public void unLoginRefreshUI()
    {

    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG:
                    isFirst = false;
                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28)
                        {
                            mRLEmpty.setVisibility(View.GONE);
                            mListView.setVisibility(View.VISIBLE);

                            if (!liveTypeList.isEmpty())
                            {
                                liveTypeList.clear();
                            }

                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                JSONArray array1 = jsonObject.optJSONArray("data1");
                                Type type = new TypeToken<List<LiveRoomBean>>() {}.getType();
                                if (array != null)
                                {
                                    financeList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    LiveTypeBean financeBean = new LiveTypeBean();
                                    financeBean.setTitle("金融");
                                    financeBean.setImg(R.drawable.icon_finance);
                                    financeBean.setLiveRoomList(financeList);
                                    liveTypeList.add(financeBean);
                                }
                                if (array1 != null)
                                {
                                    teachList = YNJsonUtil.JsonToLBean(array1.toString(), type);
                                    LiveTypeBean teachBean = new LiveTypeBean();
                                    teachBean.setTitle("家教");
                                    teachBean.setImg(R.drawable.icon_teach);
                                    teachBean.setLiveRoomList(teachList);
                                    liveTypeList.add(teachBean);
                                }

                                mLiveAdapter.setLiveList(liveTypeList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            mListView.setVisibility(View.VISIBLE);
                            mRLEmpty.setVisibility(View.GONE);
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mListView.setVisibility(View.GONE);
                        mRLEmpty.setVisibility(View.VISIBLE);
                        YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    break;

                case YNCommonConfig.ON_REFRESH:
                    if (liveTypeList != null)
                    {
                        liveTypeList.removeAll(liveTypeList);
                    }

                    if (msg.obj != null)
                    {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (bean.getCode() == 28)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                JSONArray array = jsonObject.optJSONArray("data");
                                JSONArray array1 = jsonObject.optJSONArray("data1");
                                Type type = new TypeToken<List<LiveRoomBean>>() {}.getType();
                                if (array != null)
                                {
                                    financeList = YNJsonUtil.JsonToLBean(array.toString(), type);
                                    LiveTypeBean financeBean = new LiveTypeBean();
                                    financeBean.setTitle("金融");
                                    financeBean.setImg(R.drawable.icon_finance);
                                    financeBean.setLiveRoomList(financeList);
                                    liveTypeList.add(financeBean);
                                }
                                if (array1 != null)
                                {
                                    teachList = YNJsonUtil.JsonToLBean(array1.toString(), type);
                                    LiveTypeBean teachBean = new LiveTypeBean();
                                    teachBean.setTitle("家教");
                                    teachBean.setImg(R.drawable.icon_teach);
                                    teachBean.setLiveRoomList(teachList);
                                    liveTypeList.add(teachBean);
                                }

                                mLiveAdapter.setLiveList(liveTypeList);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }
                        else
                        {
                            if (liveTypeList != null)
                            {
                                liveTypeList.removeAll(liveTypeList);
                                mLiveAdapter.setLiveList(liveTypeList);
                            }
                        }

//                        YNToastMaster.showToast(getActivity(), bean.getInfo());
                    }
                    else
                    {
                        mRLEmpty.setVisibility(View.VISIBLE);
                        mListView.setVisibility(View.GONE);
//                        YNToastMaster.showToast(mContext, getString(R.string.request_fail));
                    }
                    onStopLoad();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        this.inflater = inflater;
        View view = inflater.inflate(R.layout.fragment_recomment, container, false);
//        AutoUtils.auto(view);
        initView(view);
        initFragment();
        return view;
    }

    @Override
    protected void initView(View view)
    {
//        bannerImages = getResources().getStringArray(R.array.url);
        bannerImgs = new Integer[]{ R.drawable.banner_pic01, R.drawable.banner_pic02, R.drawable.banner_pic03};

//        mSearch = (ImageView) view.findViewById(R.id.iv_search);
        mListView = (SmoothListView) view.findViewById(R.id.mListView);
        mRLEmpty = (RelativeLayout) view.findViewById(R.id.empty);
        mIVEmpty = (ImageView) view.findViewById(R.id.iv_empty);
        mTVEmpty = (TextView) view.findViewById(R.id.tv_empty);
        mTVRefreshNet = (TextView) view.findViewById(R.id.tv_refresh_net);

        mListView.setVisibility(View.GONE);
        // 添加头部
        mListView.addHeaderView(initHeaderView());

//        ptrl = ((PullToRefreshLayout) view.findViewById(R.id.refresh_view));

    }

    /**
     * 初始化listview的头部信息
     * @return
     */
    public View initHeaderView()
    {
        View headerView = inflater.inflate(
                R.layout.fragment_recommend_headerview, null);
        mYNBannerView = (YNBannerView) headerView
                .findViewById(R.id.ynBinnerView);

        return headerView;
    }

    @Override
    public void onResume()
    {

        if (AccountUtils.getLoginInfo())
            userId = AccountUtils.getAccountBean().getId();

        if (!YNBaseActivity.isConnectNet)
        {
            mRLEmpty.setVisibility(View.VISIBLE);
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            if (isFirst)
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(getContext(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, liveListType, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                    }
                });
            }
            else
            {
                mHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        UserHttpUtils.newInstance().getLiveHomePageList(getContext(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, liveListType, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
                    }
                });
            }
        }
        super.onResume();
    }

    @Override
    protected void addEvents()
    {
//        mSearch.setOnClickListener(this);
        mRLEmpty.setOnClickListener(this);
        mTVRefreshNet.setOnClickListener(this);
        mListView.setLoadMoreEnable(false);
        mListView.setSmoothListViewListener(this);
        mListView.setOnScrollListener(new SmoothListView.OnSmoothScrollListener()
        {
            @Override
            public void onSmoothScrolling(View view)
            {

            }

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState)
            {
                // 当不滚动时
                if (scrollState == NumberPicker.OnScrollListener.SCROLL_STATE_IDLE) {
                    //判断是否滚动到底部
                    if (view.getLastVisiblePosition() == view.getCount() - 1)
                    {
//                        YNToastMaster.showToast(mContext, "滚动到底部");
                        onLoadMore();
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
            {

            }
        });
    }

    @Override
    protected void settingDo()
    {
        mListView.setLoadMoreEnable(false);
        mListView.setSmoothListViewListener(this);

        // 显示圆形指示器和标题
        mYNBannerView.setBannerStyle(YNCommonConfig.CIRCLE_INDICATOR_TITLE);
        // 设置轮播间隔时间
        mYNBannerView.setDelayTime(3000);

        /**
         * 可以选择设置图片网址，或者资源文件，默认用Glide加载
         * 如果你想设置默认图片就在xml里设置default_image
         * banner.setImages(images);
         */
        mYNBannerView.setImages(bannerImgs);
        //如果你想用自己项目的图片加载,那么----->自定义图片加载框架
//        mYNBannerView.setImages(bannerImgs, new YNBannerView.OnLoadImageListener()
//        {
//            @Override
//            public void OnLoadImage(ImageView view, Object url)
//            {
//                /**
//                 * 这里你可以根据框架灵活设置
//                 */
//                Glide.with(mActivity).load(url).centerCrop().placeholder(R.mipmap.loading2)
//                        .crossFade().into(view);
//            }
//        });

        mYNBannerView.setOnBannerClickListener(new YNBannerView.OnBannerClickListener()
        {
            @Override
            public void OnBannerClick(View view, int position)
            {
//                YNToastMaster.showToast(mActivity, "你点击了：" + position);
            }
        });

//        if (AccountUtils.getLoginInfo())
//            userId = AccountUtils.getAccountBean().getId();
//
//        if (!YNBaseActivity.isConnectNet)
//        {
//            mRLEmpty.setVisibility(View.VISIBLE);
//            mTVRefreshNet.setVisibility(View.VISIBLE);
//            mIVEmpty.setImageResource(R.drawable.network_wrong);
//            mTVEmpty.setText("请检查您的手机是否联网");
//        }
//        else
//        {
//            mHandler.post(new Runnable()
//            {
//                @Override
//                public void run()
//                {
//                    UserHttpUtils.newInstance().getLiveHomePageList(getContext(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, liveListType, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
//                }
//            });
//        }

        mLiveAdapter = new YNListViewAdapter(getActivity(), liveTypeList);
        mListView.setAdapter(mLiveAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
    {

    }

    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.rl_more:
                //  跳转另一个界面
                break;

          /*  case R.id.iv_search:
                Intent intent = new Intent();
                intent.setClass(mContext, YNSearchActivity.class);
                startActivity(intent);
                break;*/

            case R.id.tv_refresh_net:
            case R.id.empty:
                if (YNBaseActivity.isConnectNet)
                {
                    mRLEmpty.setVisibility(View.GONE);
                    mTVRefreshNet.setVisibility(View.GONE);
                    mIVEmpty.setImageResource(R.drawable.blank);
                    mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");

                    mHandler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, liveListType, userId, mHandler, YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_FLAG, true);
                        }
                    }, 1000);
                }
                else
                {
//                    YNToastMaster.showToast(mContext, "网络未连接");
                }
                break;

//            case R.id.star_1_com_topbar_lo_right:
//                Intent intent = new Intent();
//                intent.setClass(mContext, YNSearchActivity.class);
//                startActivity(intent);
//                break;

        }
    }

    @Override
    public void onRefresh()
    {
        if (!YNBaseActivity.isConnectNet)
        {
            mTVRefreshNet.setVisibility(View.VISIBLE);
            mIVEmpty.setImageResource(R.drawable.network_wrong);
            mTVEmpty.setText("请检查您的手机是否联网");
        }
        else
        {
            mRLEmpty.setVisibility(View.GONE);
            mTVRefreshNet.setVisibility(View.GONE);
            mIVEmpty.setImageResource(R.drawable.blank);
            mTVEmpty.setText("暂时没有直播，点击屏幕刷新界面~");
        }
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance().getLiveHomePageList(getActivity(), YNCommonConfig.GET_HOME_PAGE_LIVE_LIST_URL, liveListType, userId, mHandler, YNCommonConfig.ON_REFRESH, false);
            }
        }, 1000);
    }

    @Override
    public void onLoadMore()
    {
        mHandler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                mLiveAdapter.notifyDataSetChanged();
                mListView.stopLoadMore();
            }
        }, 2000);
    }


    /** 停止刷新 */
    private void onStopLoad()
    {
        mListView.stopRefresh();
        mListView.stopLoadMore();
        mListView.setRefreshTime(DateUtil.getNowDate());
    }

}
