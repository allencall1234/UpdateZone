package com.yeneikeji.ynzhibo.widget.dialog;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.MessageBean;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNImageLoaderUtil;

/**
 * 邀请成为房管提示框
 * Created by Administrator on 2017/6/9.
 */
public class YNManagerNoticeDialog implements View.OnClickListener
{
    private ImageButton mIBtnClose;
    private ImageView mHeadImg;
    private TextView mHostName;
    private TextView mLiveType;
    private LinearLayout mHomePage;
    private TextView mInvitation;
    private Button mLeftBtn;
    private Button mRightBtn;
    private Dialog mDialog;
    private View mDialogView;
    private Builder mBuilder;

    public YNManagerNoticeDialog(Builder builder) {

        this.mBuilder = builder;
        mDialog = new Dialog(mBuilder.getContext(), R.style.NormalDialogStyle);
        mDialogView = View.inflate(mBuilder.getContext(), R.layout.widget_manager_notice_dialog, null);
        mIBtnClose = (ImageButton) mDialogView.findViewById(R.id.ib_close);
        mHeadImg = (ImageView) mDialogView.findViewById(R.id.iv_host_img);
        mHostName = (TextView) mDialogView.findViewById(R.id.tv_host_name);
        mLiveType = (TextView) mDialogView.findViewById(R.id.tv_live_type);
        mHomePage = (LinearLayout) mDialogView.findViewById(R.id.ll_home_page);
        mInvitation = (TextView) mDialogView.findViewById(R.id.tv_invitation);
        mLeftBtn = (Button) mDialogView.findViewById(R.id.btn_refuse);
        mRightBtn = (Button) mDialogView.findViewById(R.id.btn_accept);
        mDialogView.setMinimumHeight((int) (ScreenSizeUtil.getScreenHigh(mBuilder.getContext()) * builder.getHeight()));
        mDialog.setContentView(mDialogView);

        Window dialogWindow = mDialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = (int) (ScreenSizeUtil.getScreenWidth(mBuilder.getContext()) * builder.getWidth());
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialogWindow.setAttributes(lp);

        initDialog(builder);
    }

    private void initDialog(Builder builder)
    {
        YNImageLoaderUtil.setImage(builder.getContext(), mHeadImg, builder.getMsgBean().getIcon());
        mHostName.setText(builder.getMsgBean().getUsername());
        mLiveType.setText(builder.getMsgBean().getTag() + "-" + builder.getMsgBean().getTag2());

        mDialog.setCanceledOnTouchOutside(builder.isTouchOutside());

        mLeftBtn.setText(builder.getLeftButtonText());
        mLeftBtn.setTextColor(builder.getLeftButtonTextColor());
        mLeftBtn.setTextSize(builder.getButtonTextSize());
        mRightBtn.setText(builder.getRightButtonText());
        mRightBtn.setTextColor(builder.getRightButtonTextColor());
        mRightBtn.setTextSize(builder.getButtonTextSize());

        mIBtnClose.setOnClickListener(this);
        mHomePage.setOnClickListener(this);
        mLeftBtn.setOnClickListener(this);
        mRightBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        int i = view.getId();

        if (i == R.id.ib_close && mBuilder.getOnclickListener() != null)
        {
            mBuilder.getOnclickListener().clickTopRightButton(mIBtnClose);
            return;
        }

        if (i == R.id.btn_refuse && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomLeftButton(mLeftBtn);
            return;
        }

        if (i == R.id.btn_accept && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomRightButton(mRightBtn);
            return;
        }

        if (i == R.id.ll_home_page && mBuilder.getOnclickListener() != null) {

            mBuilder.getOnclickListener().clickBottomButton(mHomePage);
            return;
        }

    }

    public void show() {

        mDialog.show();
    }

    public void dismiss() {

        mDialog.dismiss();
    }

    public static class Builder
    {
        private MessageBean msgBean;
        private String leftButtonText;
        private int leftButtonTextColor;
        private String rightButtonText;
        private int rightButtonTextColor;
        private int buttonTextSize;
        private IDialogOnClickListener onclickListener;
        private boolean isTouchOutside;
        private float height;
        private float width;
        private Context mContext;
        private String invitationContent;

        public Builder(Context context)
        {
            mContext = context;
            leftButtonText = "拒绝";
            leftButtonTextColor = ContextCompat.getColor(mContext, R.color.search_txt);
            rightButtonText = "接受";
            rightButtonTextColor = ContextCompat.getColor(mContext, R.color.live_details_text_blue);
            onclickListener = null;
            isTouchOutside = true;
            height = 0.23f;
            width = 0.65f;
            buttonTextSize = 18;
            invitationContent = "邀请你担任他的直播间管理员";
        }

        public Context getContext() {

            return mContext;
        }

        public MessageBean getMsgBean() {
            return msgBean;
        }

        public Builder setMsgBean(MessageBean msgBean) {
            this.msgBean = msgBean;
            return this;
        }

        public String getLeftButtonText() {
            return leftButtonText;
        }

        public Builder setLeftButtonText(String leftButtonText) {
            this.leftButtonText = leftButtonText;
            return this;
        }

        public int getLeftButtonTextColor() {
            return leftButtonTextColor;
        }

        public Builder setLeftButtonTextColor(@ColorRes int leftButtonTextColor) {
            this.leftButtonTextColor = ContextCompat.getColor(mContext, leftButtonTextColor);
            return this;
        }

        public String getRightButtonText() {
            return rightButtonText;
        }

        public Builder setRightButtonText(String rightButtonText) {
            this.rightButtonText = rightButtonText;
            return this;
        }

        public int getRightButtonTextColor() {
            return rightButtonTextColor;
        }

        public Builder setRightButtonTextColor(@ColorRes int rightButtonTextColor) {
            this.rightButtonTextColor = ContextCompat.getColor(mContext, rightButtonTextColor);
            return this;
        }

        public IDialogOnClickListener getOnclickListener() {
            return onclickListener;
        }

        public Builder setOnclickListener(IDialogOnClickListener onclickListener) {
            this.onclickListener = onclickListener;
            return this;
        }

        public boolean isTouchOutside() {
            return isTouchOutside;
        }

        public Builder setCanceledOnTouchOutside(boolean isTouchOutside) {

            this.isTouchOutside = isTouchOutside;
            return this;
        }

        public int getButtonTextSize() {
            return buttonTextSize;
        }

        public Builder setButtonTextSize(int buttonTextSize) {
            this.buttonTextSize = buttonTextSize;
            return this;
        }

        public float getHeight() {
            return height;
        }

        public Builder setHeight(float height) {
            this.height = height;
            return this;
        }

        public float getWidth() {
            return width;
        }

        public Builder setWidth(float width) {
            this.width = width;
            return this;
        }

        public String getInvitationContent() {
            return invitationContent;
        }

        public Builder setInvitationContent(String invitationContent) {
            this.invitationContent = invitationContent;
            return this;
        }

        public YNManagerNoticeDialog build() {

            return new YNManagerNoticeDialog(this);
        }
    }
}
