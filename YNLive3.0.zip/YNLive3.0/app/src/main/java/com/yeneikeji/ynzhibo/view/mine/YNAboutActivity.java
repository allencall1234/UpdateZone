package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

/**
 * 关于界面
 * Created by Administrator on 2016/10/27.
 */
public class YNAboutActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private TextView mTVAppVersion;
    private RelativeLayout mRLUpdateVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_about,null);
       // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31,33,39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        configTopBarCtrollerWithTitle(getString(R.string.about));

        mTVAppVersion = (TextView) findViewById(R.id.tv_app_version);
        mRLUpdateVersion = (RelativeLayout) findViewById(R.id.rl_update_version);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        mRLUpdateVersion.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            case R.id.rl_update_version:
                break;
        }
    }
}
