package com.yeneikeji.ynzhibo.view.mine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.common.YNToastMaster;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.UserInfoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 设置密码界面
 */
public class YNSetPasswordActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private RelativeLayout rlCurrentPass;
    private EditText edtCurrentPass;
    private EditText edtPassword, edtCheckPassword;
    private TextView btnFinish;
    private TextView txtToForget;
    private String phone;

    private boolean flag = false;// true为登录时忘记, false为修改密码时忘记

    private final int REGISTER_RESULT = 0;
    private final int MODIFY_RESULT = 1;

    private Handler handler = new Handler()
    {
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
                case YNCommonConfig.USER_RESET_PASSWORD_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 7)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                String newPassWord = jsonObject.getJSONObject("data").optString("newpassword");
                                UserInfoBean userInfoBean = AccountUtils.getAccountBean();
                                userInfoBean.setPassword(newPassWord);
                                AccountUtils.saveAccountBean(userInfoBean);
                                // 跳到登录页面
                                Intent intent = new Intent(YNSetPasswordActivity.this, YNLoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }
                        }

//                        YNToastMaster.showToast(YNSetPasswordActivity.this, baseBean.getInfo());
                    }
                    break;

                case YNCommonConfig.USER_UPDATE_PASSWORD_FLAG:
                    if (msg.obj != null)
                    {
                        BaseBean baseBean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        if (baseBean.getCode() == 7)
                        {
                            try
                            {
                                JSONObject jsonObject = new JSONObject(msg.obj.toString());
                                String newPassWord = jsonObject.getJSONObject("data").optString("newpassword");
                                UserInfoBean userInfoBean = AccountUtils.getAccountBean();
                                userInfoBean.setPassword(newPassWord);
                                AccountUtils.saveAccountBean(userInfoBean);
                                finish();
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

//                            UserInfoBean userInfoBean = AccountUtils.getAccountBean();
//                            userInfoBean.setPassword(edtPassword.getText().toString());
//                            AccountUtils.saveAccountBean(userInfoBean);

                        }

                        YNToastMaster.showToast(YNSetPasswordActivity.this, baseBean.getInfo());
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.set_password,null);
   //     AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        phone = getIntent().getStringExtra(YNCommonConfig.PHONE_NUMBER);
        flag = getIntent().getBooleanExtra(YNCommonConfig.FORGET_PASS, flag);
        configTopBarCtrollerWithTitle(flag == true ? getString(R.string.set_password) : getString(R.string.update_pass));

        rlCurrentPass = (RelativeLayout) findViewById(R.id.rl_current_pass);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtCheckPassword = (EditText) findViewById(R.id.edtCheckPassword);
        txtToForget = (TextView) findViewById(R.id.txtToForget);
        btnFinish = (TextView) findViewById(R.id.btnFinish);

        rlCurrentPass.setVisibility(flag == true ? View.GONE : View.VISIBLE);
        txtToForget.setVisibility(flag == true ? View.GONE : View.VISIBLE);
        edtCurrentPass = (EditText) findViewById(R.id.edtCurrentPass);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
        txtToForget.setOnClickListener(this);
        btnFinish.setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {

    }

    @Override
    public void onClick(View v)
    {
        Intent intent = new Intent();
        switch (v.getId())
        {
            case R.id.star_1_com_topbar_iv_left:
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                finish();
                break;

            case R.id.txtToForget:
                intent.setClass(this, YNForgetActivity.class);
                startActivity(intent);
                finish();
                break;

            case R.id.btnFinish:
                final String currentPassWord = edtCurrentPass.getText().toString();
                final String newPassWord = edtPassword.getText().toString();
                final String againPassWord = edtCheckPassword.getText().toString();
                // flag true 为忘记密码时重设密码  false为登陆状态下修改密码
                if (flag)
                {
                    if (TextUtils.isEmpty(newPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "请输入新的密码");
                        return;
                    }
                    if (TextUtils.isEmpty(againPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "请再次输入密码");
                        return;
                    }
                    if (!againPassWord.equals(newPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "两次密码不一致");
                        return;
                    }

                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userResetPassWord(YNSetPasswordActivity.this, YNCommonConfig.USER_RESET_PASSWORD_URL,
                                    phone, newPassWord, handler, YNCommonConfig.USER_RESET_PASSWORD_FLAG, false);
                        }
                    }, 500);
                }
                else
                {
                    if (TextUtils.isEmpty(currentPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "请输入原密码");
                        return;
                    }
                    if (TextUtils.isEmpty(newPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "请输入新的密码");
                        return;
                    }
                    if (TextUtils.isEmpty(againPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "请再次输入密码");
                        return;
                    }
                    if (!againPassWord.equals(newPassWord))
                    {
                        YNToastMaster.showToast(YNSetPasswordActivity.this, "两次密码不一致");
                        return;
                    }
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance().userUpdatePassWord(YNSetPasswordActivity.this, YNCommonConfig.USER_UPDATE_PASSWORD_URL, AccountUtils.getAccountBean().getId(), currentPassWord,
                                    newPassWord, handler, YNCommonConfig.USER_UPDATE_PASSWORD_FLAG, false);
                        }
                    }, 500);

                }
        }
    }

}
