package com.yeneikeji.ynzhibo.interfaces;

import java.util.HashMap;

/**
 * Created by Administrator on 2016/10/19.
 */

public interface IOnCheckedChangeListener {
    void checkedChange(HashMap<Integer, Boolean> isSelected);
}
