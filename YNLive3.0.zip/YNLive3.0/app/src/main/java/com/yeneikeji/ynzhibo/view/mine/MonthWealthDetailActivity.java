package com.yeneikeji.ynzhibo.view.mine;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.model.GiftBean;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;

public class MonthWealthDetailActivity extends YNBaseTopBarActivity implements View.OnClickListener
{
    private ImageView mIVGift;
    private TextView mTVGiftName, mTVWealth, mTVSendGiftUserId, mTVSendGiftNickName, mTVGiftPrice, mTVSendGiftTime;

    private GiftBean giftBean;
    private int giftType;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_month_wealth_detail,null);
       // AutoUtils.auto(view);
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));
        initView();
        addEvent();
        settingDo();
    }

    @Override
    protected void initView()
    {
        giftType= getIntent().getIntExtra(YNCommonConfig.TITLE, giftType);
        giftBean = (GiftBean) getIntent().getSerializableExtra(YNCommonConfig.OBJECT);
        configTopBarCtrollerWithTitle(giftType == 0 ? "礼物详情" : "点赞详情");

        mIVGift = (ImageView) findViewById(R.id.iv_gift);
        mTVGiftName = (TextView) findViewById(R.id.tv_gift_name);
        mTVWealth = (TextView) findViewById(R.id.tv_wealth);
        mTVSendGiftUserId = (TextView) findViewById(R.id.tv_send_gift_user_id);
        mTVSendGiftNickName = (TextView) findViewById(R.id.tv_send_gift_user_nick);
        mTVGiftPrice = (TextView) findViewById(R.id.tv_gift_price);
        mTVSendGiftTime = (TextView) findViewById(R.id.tv_gift_send_time);
    }

    @Override
    protected void addEvent()
    {
        getLeftBtn().setOnClickListener(this);
    }

    @Override
    protected void settingDo()
    {
        if (giftBean.getGiftName().equals("豪华跑车"))
            mIVGift.setImageResource(R.mipmap.gift_car);
        if (giftBean.getGiftName().equals("股神"))
            mIVGift.setImageResource(R.mipmap.gift_warren);
        if (giftBean.getGiftName().equals("中华烟"))
            mIVGift.setImageResource(R.mipmap.gift_smoke);
        if (giftBean.getGiftName().equals("茶"))
            mIVGift.setImageResource(R.mipmap.gift_tea);
        if (giftBean.getGiftName().equals("龙井茶"))
            mIVGift.setImageResource(R.mipmap.gift_tea);
        if (giftBean.getGiftName().equals("鲜花"))
            mIVGift.setImageResource(R.mipmap.gift_flowers);

        mTVGiftName.setText(giftBean.getGiftName());
        mTVWealth.setText("+" + giftBean.getPrice());
        mTVSendGiftUserId.setText(giftBean.getToId());
        mTVSendGiftNickName.setText(giftBean.getUsername());
        mTVSendGiftNickName.setText(giftBean.getUsername());
        mTVGiftPrice.setText(giftBean.getPrice());
        mTVSendGiftTime.setText(giftBean.getTime());
    }

    //点击事件处理
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.star_1_com_topbar_iv_left:
                finish();
                break;

            default:
                break;
        }
    }
}
