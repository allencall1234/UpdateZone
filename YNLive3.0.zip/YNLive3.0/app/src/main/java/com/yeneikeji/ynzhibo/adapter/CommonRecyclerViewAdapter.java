package com.yeneikeji.ynzhibo.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yeneikeji.ynzhibo.utils.AutoUtils;

import java.util.List;

/**
 * 万能RecyclerViewAdapter适配器
 * Created by Administrator on 2016/9/20.
 */
public abstract class CommonRecyclerViewAdapter<T> extends  RecyclerView.Adapter<CommonRecyclerViewHolder>
{
    private Context mContext;
    private List<T> mDatas;
    private int mLayoutId;
    private LayoutInflater mInflater;

    private OnItemClickListener onItemClickListener;

    public CommonRecyclerViewAdapter(Context mContext, List<T> mDatas, int mLayoutId) {
        this.mContext = mContext;
        this.mDatas = mDatas;
        this.mLayoutId = mLayoutId;
        mInflater = LayoutInflater.from(mContext);
    }

    public void updateListView(List<T> mDatas){
        this.mDatas = mDatas;
        notifyDataSetChanged();
    }

    public List<T> getList()
    {
        return mDatas;
    }

    @Override
    public CommonRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(mLayoutId, parent, false);
//        AutoUtils.auto(view);
        return new CommonRecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final CommonRecyclerViewHolder holder, int position) {
        convert(holder, mDatas.get(position), position);
        if (onItemClickListener != null)
        {
            //设置背景
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    //注意，这里的position不要用上面参数中的position，会出现位置错乱\
                    onItemClickListener.OnItemClickListener(holder.itemView, holder.getLayoutPosition());
                }
            });
        }

    }

    public abstract void convert(CommonRecyclerViewHolder holder, T data, int position);

    @Override
    public int getItemCount() {
        return mDatas.size();

    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void OnItemClickListener(View view, int position);
    }

}
