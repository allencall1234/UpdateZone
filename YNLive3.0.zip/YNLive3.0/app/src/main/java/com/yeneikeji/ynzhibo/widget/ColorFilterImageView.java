package com.yeneikeji.ynzhibo.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;

import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.application.YNApplication;

/**
 *
 * @ClassName: ColorFilterImageView
 * @Description: 实现图像根据按下抬起动作变化颜色
 *
 */
public class ColorFilterImageView extends ImageView implements OnTouchListener {

    private boolean isVideo = false;
    private static Bitmap gifbmp = null;
    private static Paint paint;

    public ColorFilterImageView(Context context, boolean isVideo) {
        this(context, null, 0);
        this.isVideo = isVideo;
    }

    public ColorFilterImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ColorFilterImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        setOnTouchListener(this);
    }

    static
    {
        gifbmp = BitmapFactory.decodeResource(YNApplication.getContext().getResources(), R.drawable.video_play);

        paint = new Paint();
        paint.setColor(Color.parseColor("#469de6"));
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

//        Rect targetRect = new Rect(50, 50, 1000, 200);
//        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        paint.setStrokeWidth(3);
//        paint.setTextSize(80);
//        String testString = "测试：ijkJQKA:1234";
//        paint.setColor(Color.CYAN);
//        canvas.drawRect(targetRect, paint);
//        paint.setColor(Color.RED);
//        FontMetricsInt fontMetrics = paint.getFontMetricsInt();
//        // 转载请注明出处：http://blog.csdn.net/hursing
//        int baseline = (targetRect.bottom + targetRect.top - fontMetrics.bottom - fontMetrics.top) / 2;
//        // 下面这行是实现水平居中，drawText对应改为传入targetRect.centerX()
//        paint.setTextAlign(Paint.Align.CENTER);
//        canvas.drawText(testString, targetRect.centerX(), baseline, paint);

        if (isVideo) {
            canvas.drawRect(canvas.getWidth() - gifbmp.getWidth() - 18, canvas.getHeight() - gifbmp.getHeight(), canvas.getWidth(), canvas.getHeight(), paint);
            canvas.drawBitmap(gifbmp, canvas.getWidth() - gifbmp.getWidth() - 9, canvas.getHeight() - gifbmp.getHeight(), null);
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:  // 按下时图像变灰
                setColorFilter(Color.GRAY, Mode.MULTIPLY);
                break;
            case MotionEvent.ACTION_UP:   // 手指离开或取消操作时恢复原色
            case MotionEvent.ACTION_CANCEL:
                setColorFilter(Color.TRANSPARENT);
                break;
            default:
                break;
        }
        return false;
    }
}
