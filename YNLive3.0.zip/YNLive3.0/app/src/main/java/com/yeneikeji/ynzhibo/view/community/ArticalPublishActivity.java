package com.yeneikeji.ynzhibo.view.community;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.yeneikeji.ynzhibo.R;
import com.yeneikeji.ynzhibo.http.UserHttpUtils;
import com.yeneikeji.ynzhibo.http.YNCommonConfig;
import com.yeneikeji.ynzhibo.interfaces.IDialogOnClickListener;
import com.yeneikeji.ynzhibo.model.BaseBean;
import com.yeneikeji.ynzhibo.model.RecordVideoBean;
import com.yeneikeji.ynzhibo.utils.AccountUtils;
import com.yeneikeji.ynzhibo.utils.ScreenSizeUtil;
import com.yeneikeji.ynzhibo.utils.YNBitMapUtil;
import com.yeneikeji.ynzhibo.utils.YNCommonUtils;
import com.yeneikeji.ynzhibo.utils.YNFileUtil;
import com.yeneikeji.ynzhibo.utils.YNJsonUtil;
import com.yeneikeji.ynzhibo.utils.YNLogUtil;
import com.yeneikeji.ynzhibo.view.YNBaseTopBarActivity;
import com.yeneikeji.ynzhibo.view.mine.foldline.AmountView;
import com.yeneikeji.ynzhibo.widget.dialog.YNPayDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import me.iwf.photopicker.PhotoPicker;
import me.iwf.photopicker.PhotoPreview;

public class ArticalPublishActivity
        extends YNBaseTopBarActivity
        implements View.OnClickListener
{
    private ImageView mAddiv;
    private TextView mPublish;

    private View inflate;
    private Dialog dialog;
    private TextView choosePhoto;
    private TextView takePhoto;
    private TextView cancel;
    private WindowManager.LayoutParams mLp;
    private ArrayList<String> selectedPhotos = new ArrayList<>();
    private ImageView    mIv;
    private CheckBox     mCbox;
    private AmountView   mAmountVew;
    private ListView     mEditListView;
    private View mHeadView;
    private MyAdapter mAdapter;
    private View mFootView;
    private TextView mIsNeedPay;
    private String picPath;
    private String mTitleEt;
    private String mContentEt;
    private int mIsPay;
    private int mPayCoin;
    private String mVideoId=" ";
    //上传视频的个数
    private int mvideoCount;
    //更换发表文章里面的子图片；
    private  int updataItemPhoto=-1;
    private TextView mTvAmountMiddle;
    private File[] files = null;
    private String[] describles=new String[3];
    //保存对照片的描述
    private HashMap<Integer,String> mHashMap=new HashMap();
    //定义一个开关记录语音观点是否已经发表成功了，以便用户退出时提示
    private boolean hasPablished;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case YNCommonConfig.GET_ARTICAL_PUBLISH_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNLogUtil.e("aaa", msg.obj.toString());
                        if (bean.getCode() == 26) {
                            hasPablished=true;
                            Toast.makeText(context, "发表成功", Toast.LENGTH_SHORT)
                                 .show();
                        } else {
                            hasPablished=false;
                            Toast.makeText(context, "发表失败", Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }else{
                        Toast.makeText(context, "发表失败", Toast.LENGTH_SHORT)
                             .show();
                    }
                    //恢复按钮
                    mPublish.setClickable(true);
                    break;
              //重新发表
                case YNCommonConfig.GET_ARTICAL_REPUBLISH_FLAG:
                    if (msg.obj != null) {
                        BaseBean bean = YNJsonUtil.JsonToBean(msg.obj.toString(), BaseBean.class);
                        YNLogUtil.e("bbb", msg.obj.toString());
                        if (bean.getCode() == 26) {
                            hasPablished=true;
                            Toast.makeText(context, "发表成功", Toast.LENGTH_SHORT)
                                 .show();
                        } else {
                            hasPablished=false;
                            Toast.makeText(context, bean.getInfo(), Toast.LENGTH_SHORT)
                                 .show();
                        }
                    }else{
                        Toast.makeText(context, "发表失败", Toast.LENGTH_SHORT)
                             .show();
                    }
                    //恢复按钮
                    mPublish.setClickable(true);
                    break;
            }
        }

    };
    private EditText mEttitle;
    private EditText mEtcontent;
    private TextView mLeftTv;
    private YNPayDialog mDiaialog;
    private ImageView mIvBack;
    private String mFlag;
    private EditText mShortDescrible;
    private RecordVideoBean mRefuseBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view=View.inflate(this,R.layout.activity_artical_publish,null);
     //   AutoUtils.auto(view);//放在加载布局的前面
        setContentView(view);
        tintManager.setStatusBarTintColor(Color.rgb(31, 33, 39));

        //一进来就弹出免责提示框，拒绝的话直接finish掉
        //屏幕高度
        //屏幕宽度
        //同意
        //拒绝
        mDiaialog = new YNPayDialog.Builder(context)
                .setHeight(0.3f)  //屏幕高度
                .setWidth(0.8f)  //屏幕宽度
                .setTitleVisible(true)
                .setTitleText("免责声明")
                .setTitleTextSize(16)
                .setTitleTextColor(R.color.live_details_text_black)
                .setContentText("本人确定：笔记观点仅为个人观点，与业内直播无关；笔记的内容为原创，任何因笔记造成的版权纠纷与业内直播无关")
                .setContentTextColor(R.color.live_details_text_black)
                .setContentTextSize(14)
                .setLeftButtonText("同意")
                .setLeftButtonTextColor(R.color.Topblue)
                .setRightButtonText("拒绝")
                .setRightButtonTextColor(R.color.Topblue)
                .setButtonTextSize(16)
                .setCanceledOnTouchOutside(false)
                .setInterceptBack(true)
                .setOnclickListener(new IDialogOnClickListener() {
                    @Override
                    public void clickTopLeftButton(View view) {

                    }

                    @Override
                    public void clickTopRightButton(View view) {

                    }
                    //同意
                    @Override
                    public void clickBottomLeftButton(View view)
                    {
                        mDiaialog.dismiss();
                    }
                    //拒绝
                    @Override
                    public void clickBottomRightButton(View view)
                    {
                        mDiaialog.dismiss();
                        finish();
                    }

                    @Override
                    public void clickBottomButton(View view) {

                    }
                })
                .build();

        mDiaialog.show();

        initView();
        initEvent();
    }
   //初始化视图
    @Override
    protected void initView() {
      /*  configTopBarCtrollerWithTitle("笔记");
        getLeftBtn().setOnClickListener(this);*/
        mFlag = getIntent().getStringExtra("pointType");

        mIvBack = (ImageView) findViewById(R.id.top_head_iv);
        mEditListView = (ListView) findViewById(R.id.publis_edit_listview);
        //初始化ListView的头部view
        mHeadView= getLayoutInflater().inflate(R.layout.articalpublish_listview_headview,null);
      //  AutoUtils.auto(mHeadView);
        mEttitle = (EditText) mHeadView.findViewById(R.id.publish_artical_ettitle);
        //简介
//        mShortDescrible = (EditText) mHeadView.findViewById(R.id.publish_artical_et_shortDescrible);

        mEtcontent = (EditText) mHeadView.findViewById(R.id.publish_artical_etcontent);
        //初始化ListView的底部view
       View footView= getLayoutInflater().inflate(R.layout.articalpublish_listview_footview,null);
       // AutoUtils.auto(footView);
        mCbox = (CheckBox) footView.findViewById(R.id.artical_publish_payChbSwtich);
        mIsNeedPay = (TextView) footView.findViewById(R.id.publish_pager_bymoney);
        mAmountVew = (AmountView) footView.findViewById(R.id.amount_view);
        mTvAmountMiddle = (TextView) mAmountVew.findViewById(R.id.etAmount);
        mPublish = (TextView) footView.findViewById(R.id.publish_tv);
        mLeftTv = (TextView) footView.findViewById(R.id.coin_numb_publish);
       mEditListView.addHeaderView(mHeadView);
        mEditListView.addFooterView(footView);

        mAddiv = (ImageView) mHeadView.findViewById(R.id.add_content_iv);
        //判断是否是从被驳回界面跳转过来的,是的话标题和内容要设置为被驳回来的
        if(mFlag.equals("reEdit")){
            mRefuseBean = (RecordVideoBean) getIntent().getSerializableExtra("RecordVideoBean");
            mEttitle.setText(mRefuseBean.getTitle());
            mEtcontent.setText(mRefuseBean.getContent());
            if(mRefuseBean.getDescribes()!=null){
                mShortDescrible.setText(mRefuseBean.getDescribes());
            }
        }

    }

    private void initEvent() {
        mAdapter = new MyAdapter(ArticalPublishActivity.this);
        mEditListView.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
        mIvBack.setOnClickListener(this);
        mAddiv.setOnClickListener(this);
        mPublish.setOnClickListener(this);

        mCbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    mAmountVew.setVisibility(View.VISIBLE);
                    mLeftTv.setVisibility(View.VISIBLE);
                }else{
                    mTvAmountMiddle.setText("1");
                    mAmountVew.setVisibility(View.GONE);
                    mLeftTv.setVisibility(View.GONE);
                }
            }
        });
        mAmountVew.setGoods_storage(10000);
        mAmountVew.setOnAmountChangeListener(new AmountView.OnAmountChangeListener() {
            //可知道设置金币数量
            @Override
            public void onAmountChange(View view, int amount) {
               if(mCbox.isChecked()){
                   mIsPay=1;
                   mPayCoin=amount;

               }else{
                   mIsPay=0;
                   mPayCoin=0;
               }
            }
        });

        //标题和内容变化监听
        mEttitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                mTitleEt=s.toString().trim();
                if(mTitleEt.length()>=20){
                    Toast.makeText(context, "标题不能超过20字哦亲", Toast.LENGTH_SHORT)
                         .show();

                }
            }
        });

        mEtcontent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
       mContentEt=s.toString().trim();
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.top_head_iv:
                //点击返回时，检查是否编辑了内容，有的话要弹出提示框 是否放弃编辑,如果是发表了以后就不要提示了
                if(mEttitle!=null ||mEtcontent!=null||mShortDescrible.getText().toString().trim()!=null&& hasPablished==false){
                    mDiaialog = new YNPayDialog.Builder(context)
                            .setHeight(0.3f)  //屏幕高度
                            .setWidth(0.8f)  //屏幕宽度
                            .setTitleVisible(true)
                            .setTitleText("温馨提示")
                            .setTitleTextSize(16)
                            .setTitleTextColor(R.color.live_details_text_black)
                            .setContentText("如果现在退出，你将会放弃当前的编辑内容哦，是否确定要退出？")
                            .setContentTextColor(R.color.live_details_text_black)
                            .setContentTextSize(14)
                            .setLeftButtonText("确定")
                            .setLeftButtonTextColor(R.color.Topblue)
                            .setRightButtonText("取消")
                            .setRightButtonTextColor(R.color.Topblue)
                            .setButtonTextSize(16)
                            .setCanceledOnTouchOutside(false)
                            .setInterceptBack(true)
                            .setOnclickListener(new IDialogOnClickListener() {
                                @Override
                                public void clickTopLeftButton(View view) {

                                }

                                @Override
                                public void clickTopRightButton(View view) {

                                }
                                //同意
                                @Override
                                public void clickBottomLeftButton(View view)
                                {
                                    mDiaialog.dismiss();
                                    finish();
                                }
                                //拒绝
                                @Override
                                public void clickBottomRightButton(View view)
                                {
                                    mDiaialog.dismiss();
                                }

                                @Override
                                public void clickBottomButton(View view) {

                                }
                            })
                            .build();

                    mDiaialog.show();
                }else{
                    finish();
                }
                 break;
            //文章发表
            case R.id.publish_tv:
     if(mTitleEt==null||mContentEt==null){
                Toast.makeText(context, "标题和内容不能为空哦", Toast.LENGTH_SHORT)
                     .show();
                return;
            }
                //内容字数的限制
                if(mContentEt.length()<20){
                    Toast.makeText(context, "文章内容不能少于20字哦", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }
                //必须添加笔记描述
                if(mShortDescrible.getText().toString().trim()==null){
                    Toast.makeText(context, "请为笔记添加描述哦", Toast.LENGTH_SHORT)
                         .show();
                    return;
                }
                //处理图片描述
                Iterator iter = mHashMap.entrySet().iterator();
                int a=0;
                while (iter.hasNext()) {
                    Map.Entry entry = (Map.Entry) iter.next();
                    String    value = (String) entry.getValue();
                    describles[a]=value;
                    a++;
                }
                //处理从相册选回来的照片
                String filePath;
                if (selectedPhotos.size() > 0)
                {
                    files = new File[selectedPhotos.size()];
                    for (int i = 0; i < selectedPhotos.size(); i++)
                    {
                        BitmapFactory.Options options      = YNBitMapUtil.getBitmapOptions(selectedPhotos.get(i));
                        int                   screenMax    = Math.max(ScreenSizeUtil.getScreenWidth(context), ScreenSizeUtil.getScreenHigh(context));
                        int                   imgMax       = Math.max(options.outWidth, options.outHeight);
                        int                   inSimpleSize = 1;
                        if (screenMax <= imgMax)
                        {
                            inSimpleSize = Math.max(screenMax, imgMax) / Math.min(screenMax, imgMax);
                        }
                        filePath = YNBitMapUtil.compressBitmap(context, selectedPhotos.get(i), Bitmap.CompressFormat.JPEG, options.outWidth / inSimpleSize, options.outHeight / inSimpleSize, false);
                        files[i] = new File(filePath);
                    }
                }

            //根据标记是正常发表还是被驳回重新发表
                if(mFlag.equals("edit")) {
                    publishPoint(  YNCommonConfig.ARTICAL_PUBLISH_URL);

                }else if(mFlag.equals("reEdit")){

                    mHandler.post(new Runnable() {
                        @Override
                        public void run()
                        {
                            UserHttpUtils.newInstance()
                                         .getArticalRePublish(ArticalPublishActivity.this,
                                                            YNCommonConfig.ARTICAL_REPUBLISH_URL,
                                                            AccountUtils.getAccountBean()
                                                                        .getId(),
                                                            mTitleEt,
                                                            mShortDescrible.getText().toString().trim(),
                                                              mRefuseBean.getId(),
                                                            mContentEt,
                                                            files,
                                                            describles[1],
                                                            describles[0],
                                                            describles[2],
                                                            "" + mIsPay,
                                                            "" + mPayCoin,
                                                            "Android",
                                                            mHandler,
                                                            YNCommonConfig.GET_ARTICAL_REPUBLISH_FLAG,
                                                            true);
                        }
                    });

                }
                //按钮设置不可点击
                mPublish.setClickable(false);
                break;

            case R.id.add_content_iv:
            //弹出添加方式框
                addPictureDialog();
                break;

           /* //选择加入图片
            case R.id.topiv:
            case R.id.bottomtv:
                //弹出添加图片框
                addPictureDialog();
                break;

            //选择加入视频
            case R.id.topvideo:
            case R.id.bottom_vedio:
               *//* if(mvideoCount==0) {
                    Intent intentvideo = new Intent(ArticalPublishActivity.this, MyLiveVideoActivity.class);
                    intentvideo.putExtra(YNCommonConfig.SELECT_VIDEO_FLAG, 1);
                    startActivityForResult(intentvideo, YNCommonConfig.SELECT_VEDIO_REQUES_CODE);
                }else{
                    Toast.makeText(context, "只能上传一个视频哦，亲", Toast.LENGTH_SHORT)
                         .show();
                }*//*
                dialog.dismiss();
                break;*/

            //选择相册添加的方式后的操作
            case R.id.choosePhoto:
                ArrayList<String> Photo = new ArrayList<>();
                PhotoPicker.builder()
                           .setPhotoCount(1)
                           .setShowCamera(true)
                           .setSelected(Photo)
                           .start(this);
                dialog.dismiss();
            break;
            //选择拍照添加的方式后的操作
            case R.id.takePhoto:
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                picPath = YNFileUtil.getRootFilePath(ArticalPublishActivity.this) + YNCommonConfig.PHOTO_DIR + YNCommonUtils.getPhotoFileName();
                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(picPath)));//拍照后输出，保存在本地中
                startActivityForResult(intent, YNCommonConfig.TAKE_PHOTO);
                dialog.dismiss();

            break;

            case R.id.btn_cancel:
                dialog.dismiss();
                break;
        }
    }

    private void publishPoint(final String Url) {
        mHandler.post(new Runnable() {
            @Override
            public void run()
            {
                UserHttpUtils.newInstance()
                             .getArticalPublish(ArticalPublishActivity.this,
                                                Url,
                                                AccountUtils.getAccountBean()
                                                            .getId(),
                                                mTitleEt,
                                                mShortDescrible.getText().toString().trim(),
                                                mContentEt,
                                                files,
                                                describles[1],
                                                describles[0],
                                                describles[2],
                                                "" + mIsPay,
                                                "" + mPayCoin,
                                                "Android",
                                                mHandler,
                                                YNCommonConfig.GET_ARTICAL_PUBLISH_FLAG,
                                                true);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
    //选择完相册后的处理
        if (resultCode == RESULT_OK && (requestCode == PhotoPicker.REQUEST_CODE || requestCode == PhotoPreview.REQUEST_CODE)) {

            ArrayList<String> chosePhotos = null;
            if (data != null) {
                chosePhotos = data.getStringArrayListExtra(PhotoPicker.KEY_SELECTED_PHOTOS);
            }
            //子条目点击了更换照片
      if(updataItemPhoto!=-1&& selectedPhotos.size() < 3) {
         // selectedPhotos.remove(updataItemPhoto);
          selectedPhotos.addAll(chosePhotos);
          mAdapter.reFreshListView(selectedPhotos);
  }
            if (chosePhotos != null &&updataItemPhoto==-1&& selectedPhotos.size() < 3) {
                selectedPhotos.addAll(0,chosePhotos);
                mAdapter.reFreshListView(selectedPhotos);
            }
            updataItemPhoto=-1;
        }
        //拍照完后的处理
        if(resultCode == RESULT_OK && requestCode==YNCommonConfig.TAKE_PHOTO){

            //添加到后面
            if(picPath != null && updataItemPhoto!=-1&& selectedPhotos.size() < 3) {
                selectedPhotos.add(picPath);
                mAdapter.reFreshListView(selectedPhotos);
            }
            //添加到前面
            if(picPath != null && updataItemPhoto==-1&& selectedPhotos.size() < 3) {
                selectedPhotos.add(0,picPath);
                mAdapter.reFreshListView(selectedPhotos);
            }
            updataItemPhoto=-1;
        }

    }
    class MyAdapter extends BaseAdapter{

      Context mContext;
        ArrayList<String> mPhotos;
        public MyAdapter(Context context) {
            this.mContext=context;
        }
        public void reFreshListView( ArrayList<String> ptotos){
            this.mPhotos=ptotos;
            notifyDataSetChanged();
        }
        @Override
        public int getCount() {
            if(mPhotos!=null) {
                return mPhotos.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            return mPhotos.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final int  a =position;
            ViewHolder holer;
            if(convertView==null){
                holer=new ViewHolder();
                convertView=LayoutInflater.from(ArticalPublishActivity.this)
                                          .inflate(R.layout.articalpublish_listview_item, null);
                //AutoUtils.auto(convertView);
                holer.photoView= (ImageView) convertView.findViewById(R.id.left_select_imagView);
                holer.editView= (EditText) convertView.findViewById(R.id.publish_editext);
                holer.removeView= (ImageView) convertView.findViewById(R.id.publish_remove_iv);
                holer.addView= (ImageView) convertView.findViewById(R.id.publish_add__iv);
                holer.addView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                                //把需要跟换照片的条目position传出去
                                updataItemPhoto=a;
                        addPictureDialog();
                    }
                });
                //删除子条目
                holer.removeView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog ad=new AlertDialog.Builder(ArticalPublishActivity.this).create();
                                       ad.setTitle("温馨提示");
                                      ad.setIcon(R.drawable.ic_launcher);
                                       ad.setMessage("您确定要删除这条内容吗");
                                       ad.setButton("确定", new DialogInterface.OnClickListener() {

                                                        @Override
                                               public void onClick(DialogInterface dialog, int which) {
                                                            //删除后要重置视频的个数
                                                            if(mPhotos.get(a).startsWith("https")){
                                                                mvideoCount=0;
                                                            }
                                                            mPhotos.remove(a);
                                                            notifyDataSetChanged();
                                                    }
                                           });
                                       ad.setButton2("取消", new DialogInterface.OnClickListener() {
                                                       @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                   }
                                           });
                                      ad.show();
                                    }

                });

                //图片描述的内容
                holer.editView.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {


                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        mHashMap.put(position,s.toString().trim());
                    }
                });


        convertView.setTag(holer);
            }else {
                holer= (ViewHolder) convertView.getTag();
            }
                Uri uri = Uri.fromFile(new File(mPhotos.get(position)));
                Glide.with(mContext)
                     .load(uri)
                     .centerCrop()
                     .thumbnail(0.1f)
                     .placeholder(R.drawable.__picker_ic_photo_black_48dp)
                     .error(R.drawable.__picker_ic_broken_image_black_48dp)
                     .into(holer.photoView);

            return convertView;
        }

        class ViewHolder{
            ImageView photoView;
            ImageView removeView;
            EditText  editView;
            ImageView addView;
        }
    }
    private void addPictureDialog() {
        inflate = LayoutInflater.from(this).inflate(R.layout.dialog_imageselect_layout, null);
        //AutoUtils.auto(inflate);
        dialog = new Dialog(this, R.style.ActionSheetDialogStyle);
        choosePhoto = (TextView) inflate.findViewById(R.id.choosePhoto);
        takePhoto = (TextView) inflate.findViewById(R.id.takePhoto);
        cancel = (TextView) inflate.findViewById(R.id.btn_cancel);

        choosePhoto.setOnClickListener(this);
        takePhoto.setOnClickListener(this);
        cancel.setOnClickListener(this);
        dialog.setContentView(inflate);
        WindowManager windowManager = getWindowManager();
        Display       display       = windowManager.getDefaultDisplay();
        mLp = dialog.getWindow().getAttributes();
        mLp.width = (int)(display.getWidth()); //设置宽度
        mLp.height = (int)(display.getHeight()*0.3);
        mLp.gravity=(Gravity.BOTTOM);
        dialog.getWindow().setAttributes(mLp);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }

}
